**Purpose:** business

**Purpose Detailed:** Planning and execution of a large-scale international event involving significant financial investment and logistical coordination.

**Topic:** Eurovision 2026 in Austria