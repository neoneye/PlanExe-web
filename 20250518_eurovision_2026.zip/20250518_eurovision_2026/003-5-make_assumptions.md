
## Question 1 - What is the detailed breakdown of the €30-40 million budget, including specific allocations for venue, security, broadcasting, and artist fees?

**Assumptions:** Assumption: 40% of the budget (€12-16 million) will be allocated to venue preparation and operation, 20% (€6-8 million) to security, 25% (€7.5-10 million) to broadcasting and technical infrastructure, and 15% (€4.5-6 million) to artist fees and related expenses. This aligns with typical large-scale event budget allocations.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation's adequacy for each key area.
Details: Risk: Potential underfunding of critical areas like security or broadcasting. Impact: Compromised event quality or safety. Mitigation: Conduct a detailed cost analysis for each area and adjust allocations accordingly. Opportunity: Efficient budget management could free up funds for enhanced event features or sustainability initiatives. Metric: Track actual spending against budgeted amounts weekly.

## Question 2 - What are the key milestones and deadlines for venue selection, artist selection, ticket sales, and technical rehearsals, leading up to the event in May 2026?

**Assumptions:** Assumption: Venue selection will be finalized by August 2025, artist selection by January 2026, ticket sales will commence in February 2026, and technical rehearsals will begin two weeks prior to the event. This allows sufficient time for preparation and promotion.

**Assessments:** Title: Timeline Adherence Assessment
Description: Monitoring progress against key milestones to ensure timely completion.
Details: Risk: Delays in any milestone could impact subsequent activities and the overall event schedule. Impact: Increased costs, reduced preparation time, and potential cancellation. Mitigation: Implement a project management system with clear task assignments and deadlines. Opportunity: Early completion of milestones could allow for additional testing and refinement. Metric: Track milestone completion dates against planned dates weekly.

## Question 3 - What specific personnel and resources (technical staff, security personnel, volunteers, equipment) are required, and how will they be sourced and managed?

**Assumptions:** Assumption: 500 technical staff, 1000 security personnel, and 500 volunteers will be required. Technical staff will be sourced through ORF and external contractors, security personnel through licensed security firms, and volunteers through a recruitment campaign. This is based on the scale of similar events.

**Assessments:** Title: Resource Allocation Assessment
Description: Ensuring adequate staffing and equipment for all event operations.
Details: Risk: Shortages of personnel or equipment could disrupt event operations. Impact: Reduced event quality, safety concerns, and potential delays. Mitigation: Develop a detailed resource plan and secure commitments from suppliers and staffing agencies. Opportunity: Effective resource management could reduce costs and improve efficiency. Metric: Track staff and equipment availability against planned requirements daily.

## Question 4 - What specific regulations and permits are required from Austrian authorities (e.g., event permits, broadcasting licenses, security clearances), and what is the process for obtaining them?

**Assumptions:** Assumption: Event permits will be required from the city of Vienna, broadcasting licenses from the Austrian Communications Authority (KommAustria), and security clearances from the Ministry of the Interior. The application process will take approximately 3-6 months. This is based on typical regulatory timelines in Austria.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Ensuring adherence to all applicable laws and regulations.
Details: Risk: Delays in obtaining permits could disrupt the event schedule. Impact: Increased costs, potential legal challenges, and event cancellation. Mitigation: Engage with regulatory authorities early in the planning process and track permit applications closely. Opportunity: Proactive compliance could build positive relationships with regulators and streamline future events. Metric: Track permit application status against planned deadlines weekly.

## Question 5 - What specific safety protocols and risk management strategies will be implemented to address potential security threats, crowd control issues, and emergency situations?

**Assumptions:** Assumption: A comprehensive security plan will be developed in coordination with local law enforcement, including bag checks, metal detectors, surveillance cameras, and emergency evacuation procedures. Crowd control measures will be implemented to prevent overcrowding and ensure orderly movement of attendees. This aligns with standard security practices for large-scale events.

**Assessments:** Title: Safety and Security Assessment
Description: Evaluating the effectiveness of safety protocols and risk management strategies.
Details: Risk: Security breaches or emergency situations could endanger participants and attendees. Impact: Injuries, fatalities, reputational damage, and legal liabilities. Mitigation: Conduct regular security drills and training exercises. Opportunity: Robust safety measures could enhance the event's reputation and attract more attendees. Metric: Track incident reports and response times daily.

## Question 6 - What measures will be taken to minimize the environmental impact of the event, including waste reduction, energy conservation, and sustainable sourcing of materials?

**Assumptions:** Assumption: A sustainability plan will be implemented, including waste reduction and recycling programs, the use of energy-efficient equipment, and the sourcing of sustainable materials. This aligns with the EBU's sustainability guidelines and Austrian environmental regulations.

**Assessments:** Title: Environmental Impact Assessment
Description: Minimizing the event's environmental footprint.
Details: Risk: Negative environmental impact could damage the event's reputation and lead to fines. Impact: Pollution, resource depletion, and negative public perception. Mitigation: Conduct an environmental audit and implement best practices for waste management and energy conservation. Opportunity: Sustainable practices could enhance the event's image and attract environmentally conscious attendees. Metric: Track waste generation and energy consumption daily.

## Question 7 - How will local communities, businesses, and other stakeholders be involved in the planning and execution of the event to ensure their support and address any concerns?

**Assumptions:** Assumption: A community engagement plan will be developed, including public forums, meetings with local businesses, and partnerships with community organizations. This will ensure that local concerns are addressed and that the event benefits the community. This is based on best practices for community relations.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Ensuring positive relationships with local communities and stakeholders.
Details: Risk: Negative public reaction could disrupt the event and damage its reputation. Impact: Protests, boycotts, and negative media coverage. Mitigation: Conduct regular consultations with stakeholders and address their concerns proactively. Opportunity: Strong community support could enhance the event's success and create lasting benefits for the local area. Metric: Track stakeholder feedback and engagement levels weekly.

## Question 8 - What operational systems will be used for ticketing, accreditation, transportation, communication, and other key event functions, and how will they be integrated?

**Assumptions:** Assumption: A centralized event management system will be used to integrate ticketing, accreditation, transportation, communication, and other key functions. This system will be accessible to all relevant staff and stakeholders. This is based on industry standards for event management.

**Assessments:** Title: Operational Efficiency Assessment
Description: Streamlining event operations through integrated systems.
Details: Risk: Inefficient operational systems could lead to delays, errors, and customer dissatisfaction. Impact: Reduced event quality, increased costs, and reputational damage. Mitigation: Conduct thorough testing of all operational systems and provide adequate training to staff. Opportunity: Integrated systems could improve efficiency, reduce costs, and enhance the overall event experience. Metric: Track system performance and user satisfaction daily.