### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (ORF Director-General, EBU Representative, Host City Representative, ORF Head of Entertainment, Independent Financial Expert, Independent Legal Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor (ORF Director-General) formally appoints the Project Steering Committee Chair (ORF Director-General).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee Chair confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager establishes the PMO structure and defines roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Role Descriptions

**Dependencies:**

- Project Plan Approved

### 9. Project Manager develops project management methodologies and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Handbook
- Templates and Tools

**Dependencies:**

- PMO Structure Document

### 10. Project Manager defines reporting templates and processes for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Templates
- Reporting Process Document

**Dependencies:**

- Project Management Handbook

### 11. Project Manager recruits project team members for the PMO (Financial Controller, Logistics Coordinator, Technical Lead, Marketing Manager, Risk Manager, Compliance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Filled PMO Roles

**Dependencies:**

- Role Descriptions

### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Filled PMO Roles

### 13. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 14. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Independent Legal Expert, ORF Compliance Officer, External Ethics Consultant, Representative from the Internal Audit Department, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 15. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 16. Senior Sponsor (ORF Director-General) appoints the Ethics & Compliance Committee Chair (Independent Legal Expert).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 17. Ethics & Compliance Committee Chair confirms membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 18. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 19. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 20. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 21. Circulate Draft Technical Advisory Group ToR for review by nominated members (Independent Broadcasting Engineer, ORF Head of Technology, Cybersecurity Expert, Sound and Lighting Specialist, Voting System Expert, Representative from the PMO (Technical Lead)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 22. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Senior Sponsor (ORF Director-General) appoints the Technical Advisory Group Chair (Independent Broadcasting Engineer).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 24. Technical Advisory Group Chair confirms membership of the Technical Advisory Group.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 25. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 26. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda