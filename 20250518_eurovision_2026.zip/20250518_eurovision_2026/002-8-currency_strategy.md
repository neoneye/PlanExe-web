This plan involves money.

## Currencies

- **EUR:** Euro is the official currency of Austria and the primary currency for the Eurovision budget.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions within Austria will also use EUR. No additional international risk management is needed.