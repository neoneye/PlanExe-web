# Purpose

**Purpose:** business

**Purpose Detailed:** Planning and execution of a large-scale international event involving significant financial investment and logistical coordination.

**Topic:** Eurovision 2026 in Austria

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** Organizing Eurovision 2026 in Austria *unquestionably requires* a physical location, venue preparation, logistical coordination, and on-site management. This *inherently involves* physical components.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Venue capable of accommodating 10,000-15,000 spectators
- Accessibility for international participants and audience
- Adequate infrastructure for broadcasting and technical production
- Sufficient hotel and accommodation options for visitors

## Location 1
Austria

Vienna

Wiener Stadthalle, Vienna

**Rationale**: Vienna is the likely host city, and the Wiener Stadthalle is a large indoor arena suitable for hosting Eurovision with a capacity that meets the requirements.

## Location 2
Austria

Graz

Stadthalle Graz

**Rationale**: Graz is another major city in Austria with a suitable arena (Stadthalle Graz) and the infrastructure to support a large international event. It provides an alternative to Vienna.

## Location 3
Austria

Linz

TipsArena Linz

**Rationale**: Linz is a significant city in Austria with the TipsArena Linz, which could potentially be adapted to host Eurovision. It offers a different regional option within Austria.

## Location Summary
The plan focuses on hosting Eurovision 2026 in Austria. Vienna (Wiener Stadthalle) is the most likely host city, but Graz (Stadthalle Graz) and Linz (TipsArena Linz) are also viable alternatives, each offering suitable venues and infrastructure.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** Euro is the official currency of Austria and the primary currency for the Eurovision budget.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions within Austria will also use EUR. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Financial
Budget overruns due to unforeseen expenses, such as increased security costs, technical difficulties, or higher-than-expected venue preparation costs. The initial budget of €30-40 million might be insufficient to cover all expenses, especially considering the scale and complexity of the event.

**Impact:** Project delays, reduced event quality, potential need for additional funding from ORF or the EBU, and reputational damage. A cost overrun could range from €1 million to €5 million or more, depending on the severity of the issues.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget breakdown with contingency funds (at least 10% of the total budget). Secure firm commitments from funding partners (EBU, ORF, host city). Implement strict cost control measures and regular budget reviews.

## Risk 2 - Technical
Technical failures during the live broadcast, including sound issues, lighting malfunctions, or problems with the voting system. These failures could disrupt the show and negatively impact the viewing experience.

**Impact:** Interruption of the live broadcast, negative media coverage, viewer dissatisfaction, and potential damage to the reputation of ORF and the EBU. Could lead to a loss of viewers and advertising revenue.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct thorough testing of all technical equipment and systems well in advance of the event. Have backup systems in place for critical components. Employ experienced technical staff and provide them with adequate training. Implement robust monitoring and incident response procedures.

## Risk 3 - Operational
Logistical challenges related to transportation, accommodation, and security for participants, media, and spectators. Inadequate planning could lead to overcrowding, delays, and safety concerns.

**Impact:** Disruption of event schedules, negative experiences for participants and attendees, potential security breaches, and reputational damage. Could lead to legal liabilities if safety is compromised.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive logistics plan covering transportation, accommodation, and security. Coordinate closely with local authorities and transportation providers. Implement crowd management strategies and security protocols. Provide clear communication and information to participants and attendees.

## Risk 4 - Security
Security threats, including terrorism, civil unrest, or cyberattacks. A security incident could disrupt the event and endanger the safety of participants and attendees.

**Impact:** Cancellation or postponement of the event, injuries or fatalities, reputational damage, and significant financial losses. Could lead to legal liabilities and increased security costs in the future.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct a thorough security risk assessment. Develop a comprehensive security plan in coordination with local law enforcement and intelligence agencies. Implement security measures such as bag checks, metal detectors, and surveillance cameras. Train security personnel and establish clear communication protocols. Implement cybersecurity measures to protect against cyberattacks.

## Risk 5 - Regulatory & Permitting
Delays in obtaining necessary permits and approvals from local authorities for venue construction, event operations, and broadcasting. These delays could disrupt the project timeline and increase costs.

**Impact:** Project delays, increased costs, potential legal challenges, and reputational damage. Could lead to the need to relocate the event or scale it down.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage with local authorities early in the planning process to identify all necessary permits and approvals. Develop a detailed permitting schedule and track progress closely. Build strong relationships with key regulatory officials. Prepare contingency plans in case of delays.

## Risk 6 - Social
Negative public reaction to the event due to concerns about noise, traffic, or disruption to local communities. Protests or demonstrations could disrupt the event and damage its reputation.

**Impact:** Negative media coverage, public opposition, disruption of event operations, and reputational damage. Could lead to reduced attendance and sponsorship revenue.

**Likelihood:** Low

**Severity:** Medium

**Action:** Engage with local communities early in the planning process to address their concerns. Develop a communication plan to inform the public about the event and its benefits. Implement measures to mitigate noise and traffic impacts. Work with community leaders to address any grievances.

## Risk 7 - Supply Chain
Disruptions in the supply chain for critical equipment, materials, or services due to unforeseen events such as natural disasters, political instability, or supplier bankruptcies. These disruptions could delay the project and increase costs.

**Impact:** Project delays, increased costs, reduced event quality, and reputational damage. Could lead to the need to find alternative suppliers or scale down the event.

**Likelihood:** Low

**Severity:** Medium

**Action:** Identify critical suppliers and assess their financial stability and supply chain resilience. Develop contingency plans for alternative suppliers. Maintain adequate inventory of critical materials and equipment. Monitor global events that could impact the supply chain.

## Risk 8 - Environmental
Negative environmental impact from the event, such as increased waste generation, energy consumption, or noise pollution. Failure to comply with environmental regulations could lead to fines and reputational damage.

**Impact:** Environmental damage, fines and penalties, negative media coverage, and reputational damage. Could lead to legal challenges and increased costs for remediation.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct an environmental impact assessment. Develop a sustainability plan to minimize the event's environmental footprint. Implement waste reduction and recycling programs. Use energy-efficient equipment and practices. Comply with all environmental regulations.

## Risk summary
The most critical risks for Eurovision 2026 in Austria are financial overruns, technical failures during the live broadcast, and security threats. Financial overruns could jeopardize the event's quality and require additional funding. Technical failures could disrupt the show and damage the reputation of ORF and the EBU. Security threats could endanger the safety of participants and attendees. Mitigation strategies should focus on strict budget control, thorough technical testing, and comprehensive security planning. Overlapping mitigation strategies include robust planning and communication, which can help address both operational and social risks.

# Make Assumptions


## Question 1 - What is the detailed breakdown of the €30-40 million budget, including specific allocations for venue, security, broadcasting, and artist fees?

**Assumptions:** Assumption: 40% of the budget (€12-16 million) will be allocated to venue preparation and operation, 20% (€6-8 million) to security, 25% (€7.5-10 million) to broadcasting and technical infrastructure, and 15% (€4.5-6 million) to artist fees and related expenses. This aligns with typical large-scale event budget allocations.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation's adequacy for each key area.
Details: Risk: Potential underfunding of critical areas like security or broadcasting. Impact: Compromised event quality or safety. Mitigation: Conduct a detailed cost analysis for each area and adjust allocations accordingly. Opportunity: Efficient budget management could free up funds for enhanced event features or sustainability initiatives. Metric: Track actual spending against budgeted amounts weekly.

## Question 2 - What are the key milestones and deadlines for venue selection, artist selection, ticket sales, and technical rehearsals, leading up to the event in May 2026?

**Assumptions:** Assumption: Venue selection will be finalized by August 2025, artist selection by January 2026, ticket sales will commence in February 2026, and technical rehearsals will begin two weeks prior to the event. This allows sufficient time for preparation and promotion.

**Assessments:** Title: Timeline Adherence Assessment
Description: Monitoring progress against key milestones to ensure timely completion.
Details: Risk: Delays in any milestone could impact subsequent activities and the overall event schedule. Impact: Increased costs, reduced preparation time, and potential cancellation. Mitigation: Implement a project management system with clear task assignments and deadlines. Opportunity: Early completion of milestones could allow for additional testing and refinement. Metric: Track milestone completion dates against planned dates weekly.

## Question 3 - What specific personnel and resources (technical staff, security personnel, volunteers, equipment) are required, and how will they be sourced and managed?

**Assumptions:** Assumption: 500 technical staff, 1000 security personnel, and 500 volunteers will be required. Technical staff will be sourced through ORF and external contractors, security personnel through licensed security firms, and volunteers through a recruitment campaign. This is based on the scale of similar events.

**Assessments:** Title: Resource Allocation Assessment
Description: Ensuring adequate staffing and equipment for all event operations.
Details: Risk: Shortages of personnel or equipment could disrupt event operations. Impact: Reduced event quality, safety concerns, and potential delays. Mitigation: Develop a detailed resource plan and secure commitments from suppliers and staffing agencies. Opportunity: Effective resource management could reduce costs and improve efficiency. Metric: Track staff and equipment availability against planned requirements daily.

## Question 4 - What specific regulations and permits are required from Austrian authorities (e.g., event permits, broadcasting licenses, security clearances), and what is the process for obtaining them?

**Assumptions:** Assumption: Event permits will be required from the city of Vienna, broadcasting licenses from the Austrian Communications Authority (KommAustria), and security clearances from the Ministry of the Interior. The application process will take approximately 3-6 months. This is based on typical regulatory timelines in Austria.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Ensuring adherence to all applicable laws and regulations.
Details: Risk: Delays in obtaining permits could disrupt the event schedule. Impact: Increased costs, potential legal challenges, and event cancellation. Mitigation: Engage with regulatory authorities early in the planning process and track permit applications closely. Opportunity: Proactive compliance could build positive relationships with regulators and streamline future events. Metric: Track permit application status against planned deadlines weekly.

## Question 5 - What specific safety protocols and risk management strategies will be implemented to address potential security threats, crowd control issues, and emergency situations?

**Assumptions:** Assumption: A comprehensive security plan will be developed in coordination with local law enforcement, including bag checks, metal detectors, surveillance cameras, and emergency evacuation procedures. Crowd control measures will be implemented to prevent overcrowding and ensure orderly movement of attendees. This aligns with standard security practices for large-scale events.

**Assessments:** Title: Safety and Security Assessment
Description: Evaluating the effectiveness of safety protocols and risk management strategies.
Details: Risk: Security breaches or emergency situations could endanger participants and attendees. Impact: Injuries, fatalities, reputational damage, and legal liabilities. Mitigation: Conduct regular security drills and training exercises. Opportunity: Robust safety measures could enhance the event's reputation and attract more attendees. Metric: Track incident reports and response times daily.

## Question 6 - What measures will be taken to minimize the environmental impact of the event, including waste reduction, energy conservation, and sustainable sourcing of materials?

**Assumptions:** Assumption: A sustainability plan will be implemented, including waste reduction and recycling programs, the use of energy-efficient equipment, and the sourcing of sustainable materials. This aligns with the EBU's sustainability guidelines and Austrian environmental regulations.

**Assessments:** Title: Environmental Impact Assessment
Description: Minimizing the event's environmental footprint.
Details: Risk: Negative environmental impact could damage the event's reputation and lead to fines. Impact: Pollution, resource depletion, and negative public perception. Mitigation: Conduct an environmental audit and implement best practices for waste management and energy conservation. Opportunity: Sustainable practices could enhance the event's image and attract environmentally conscious attendees. Metric: Track waste generation and energy consumption daily.

## Question 7 - How will local communities, businesses, and other stakeholders be involved in the planning and execution of the event to ensure their support and address any concerns?

**Assumptions:** Assumption: A community engagement plan will be developed, including public forums, meetings with local businesses, and partnerships with community organizations. This will ensure that local concerns are addressed and that the event benefits the community. This is based on best practices for community relations.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Ensuring positive relationships with local communities and stakeholders.
Details: Risk: Negative public reaction could disrupt the event and damage its reputation. Impact: Protests, boycotts, and negative media coverage. Mitigation: Conduct regular consultations with stakeholders and address their concerns proactively. Opportunity: Strong community support could enhance the event's success and create lasting benefits for the local area. Metric: Track stakeholder feedback and engagement levels weekly.

## Question 8 - What operational systems will be used for ticketing, accreditation, transportation, communication, and other key event functions, and how will they be integrated?

**Assumptions:** Assumption: A centralized event management system will be used to integrate ticketing, accreditation, transportation, communication, and other key functions. This system will be accessible to all relevant staff and stakeholders. This is based on industry standards for event management.

**Assessments:** Title: Operational Efficiency Assessment
Description: Streamlining event operations through integrated systems.
Details: Risk: Inefficient operational systems could lead to delays, errors, and customer dissatisfaction. Impact: Reduced event quality, increased costs, and reputational damage. Mitigation: Conduct thorough testing of all operational systems and provide adequate training to staff. Opportunity: Integrated systems could improve efficiency, reduce costs, and enhance the overall event experience. Metric: Track system performance and user satisfaction daily.

# Distill Assumptions

- Venue: 40% (€12-16M), Security: 20% (€6-8M), Broadcast: 25% (€7.5-10M), Artists: 15% (€4.5-6M).
- Venue selection by August 2025, artists by January 2026, tickets February 2026.
- Technical rehearsals begin two weeks prior to the event in May 2026.
- Requires 500 technical staff, 1000 security personnel, and 500 volunteers.
- Event permits from Vienna, licenses from KommAustria, clearances from the Interior Ministry.
- Permit application process will take approximately 3-6 months.
- Security includes bag checks, metal detectors, cameras, and evacuation procedures.
- Sustainability includes waste reduction, efficient equipment, and sustainable materials.
- Community engagement includes forums, meetings, and partnerships with local organizations.
- Centralized system integrates ticketing, accreditation, transportation, and communication.

# Review Assumptions

## Domain of the expert reviewer
Large-Scale Event Management and Risk Assessment

## Domain-specific considerations

- Financial viability and budget adherence
- Logistical coordination and operational efficiency
- Security and safety protocols
- Regulatory compliance and permitting
- Stakeholder engagement and community relations
- Environmental sustainability
- Contingency planning for unforeseen events

## Issue 1 - Incomplete Financial Risk Assessment and Mitigation
The current financial risk assessment focuses primarily on budget overruns. It overlooks critical financial risks such as fluctuations in currency exchange rates (even within the Eurozone, variations can impact vendor costs), interest rate changes affecting loans (if any), and the potential for reduced sponsorship revenue due to economic downturns or negative publicity. The assumption that 'no additional international risk management is needed' is naive, even within the Eurozone.

**Recommendation:** Conduct a comprehensive financial risk assessment that includes currency risk, interest rate risk, and revenue shortfall scenarios. Develop mitigation strategies such as hedging currency exposure, securing fixed-rate loans, and diversifying sponsorship sources. Establish clear financial performance metrics and reporting procedures. Obtain insurance to cover event cancellation or postponement due to unforeseen circumstances.

**Sensitivity:** A 5% unfavorable shift in EUR exchange rates (baseline: no shift) could increase project costs by €500,000-€1,000,000, reducing the ROI by 1-2%. A 2% increase in interest rates (baseline: 4%) on a €10 million loan could increase project costs by €200,000 per year, impacting profitability. A 10% shortfall in sponsorship revenue (baseline: €15 million) could reduce the ROI by 3-5%.

## Issue 2 - Insufficient Detail on Technical Infrastructure and Redundancy
While the plan acknowledges technical risks, it lacks specific details about the technical infrastructure required for broadcasting, sound, lighting, and voting systems. The plan assumes backup systems will be in place, but doesn't specify the level of redundancy or the testing protocols. A failure in any of these systems could have catastrophic consequences for the live broadcast and the event's reputation. The plan also does not address the cybersecurity risks associated with the voting system and broadcast infrastructure.

**Recommendation:** Develop a detailed technical infrastructure plan that includes specifications for all critical systems, redundancy levels, and testing protocols. Conduct rigorous testing of all systems under realistic conditions. Implement cybersecurity measures to protect against cyberattacks. Secure contracts with multiple vendors for critical equipment and services to ensure redundancy. Establish a dedicated technical support team to monitor systems during the event and respond to any failures.

**Sensitivity:** A major technical failure during the live broadcast (baseline: no major failure) could result in a 20-30% drop in viewership, leading to a €1-2 million loss in advertising revenue and significant reputational damage. Rewriting the NLP algorithm due to a bug could delay the project by 1-2 months, or the ROI could be reduced by 5-10%

## Issue 3 - Lack of Contingency Planning for External Shocks
The plan identifies several risks, but it lacks a comprehensive contingency plan for dealing with external shocks such as pandemics, natural disasters, or political instability. These events could disrupt the event schedule, impact attendance, and increase costs. The plan needs to address how the event would be adapted or postponed in response to such events. The plan also does not address the risk of a major artist pulling out at the last minute.

**Recommendation:** Develop a comprehensive contingency plan that addresses potential external shocks. This plan should include procedures for postponing or relocating the event, managing travel restrictions, and communicating with stakeholders. Secure insurance to cover event cancellation or postponement due to unforeseen circumstances. Develop a backup plan for replacing a major artist who pulls out at the last minute.

**Sensitivity:** A pandemic or major natural disaster (baseline: no such event) could force the cancellation or postponement of the event, resulting in a €10-20 million loss in revenue and significant reputational damage. A major artist pulling out at the last minute could reduce ticket sales by 10-15%, leading to a €500,000-€750,000 loss in revenue.

## Review conclusion
The Eurovision 2026 plan demonstrates a good initial assessment of key areas, but it needs to be strengthened by addressing the identified missing assumptions. A more comprehensive financial risk assessment, detailed technical infrastructure plan, and robust contingency plan are essential for ensuring the event's success and mitigating potential negative impacts.