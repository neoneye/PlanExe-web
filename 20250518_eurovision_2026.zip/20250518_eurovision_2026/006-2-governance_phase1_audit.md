
## Audit - Corruption Risks

- Bribery of city officials to secure Vienna as the host city, despite other potentially more suitable bids from Graz or Linz.
- Kickbacks from security firms in exchange for being awarded the security contract for the event.
- Conflicts of interest arising from ORF employees having undisclosed financial interests in companies bidding for broadcasting or technical contracts.
- Nepotism in the selection of volunteers or technical staff, potentially compromising the quality of the event.
- Misuse of inside information regarding vendor selection to benefit friends or family members.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors, with the excess funds being diverted for personal use.
- Double-billing for services rendered, such as security or transportation.
- Inefficient allocation of resources, such as overspending on marketing while underfunding security measures.
- Unauthorized use of project funds for personal travel or entertainment.
- Misreporting of project progress to justify continued funding, even if milestones are not being met.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on high-value contracts and expense reports. Responsibility: Internal Audit Department.
- Implement a robust contract review process, with independent legal and financial review of all contracts exceeding €100,000. Responsibility: Legal and Finance Departments.
- Perform regular compliance checks to ensure adherence to EBU broadcasting standards and local regulations. Responsibility: Compliance Officer.
- Conduct a post-project external audit to assess the overall financial management and identify any irregularities. Responsibility: External Audit Firm.
- Implement a whistleblower mechanism with clear procedures for reporting suspected fraud or corruption, ensuring anonymity and protection for whistleblowers. Responsibility: HR and Legal Departments.

## Audit - Transparency Measures

- Publish a detailed project budget and financial reports on the ORF website, updated quarterly.
- Create a public dashboard tracking key project milestones, budget expenditures, and risk mitigation efforts.
- Publish minutes of key project team meetings, including decisions related to vendor selection and budget allocation.
- Establish a clear and documented selection criteria for all major vendors and contractors, publicly available on the ORF website.
- Implement a policy requiring disclosure of potential conflicts of interest for all project team members and stakeholders.