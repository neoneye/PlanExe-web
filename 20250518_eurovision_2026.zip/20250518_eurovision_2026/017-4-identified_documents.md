
## Documents to Create

### 1. Project Charter

**ID:** c1fef662-ed7a-4bef-9171-1306cef29fe3

**Description:** Formal document authorizing the Eurovision 2026 project, outlining its objectives, scope, stakeholders, and initial budget. It serves as a high-level agreement among key stakeholders.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope.
- Identify key stakeholders.
- Outline high-level budget and timeline.
- Obtain approval from EBU and ORF.

**Approval Authorities:** EBU, ORF

### 2. Risk Register

**ID:** 63aa6c80-6df5-409a-8543-40ca145764de

**Description:** A comprehensive register of potential risks associated with the Eurovision 2026 project, including their likelihood, impact, and mitigation strategies. It will be continuously updated throughout the project lifecycle.

**Responsible Role Type:** Risk Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks (financial, technical, operational, security, etc.).
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.

**Approval Authorities:** Project Manager, Financial Officer, Security Coordinator

### 3. Communication Plan

**ID:** f49e2979-0a17-42f9-834a-87774e524bd0

**Description:** A detailed plan outlining how project information will be communicated to stakeholders, including frequency, channels, and responsible parties. It ensures effective and timely communication throughout the project.

**Responsible Role Type:** Communication Specialist

**Primary Template:** Project Communication Plan Template

**Steps:**

- Identify stakeholders and their communication needs.
- Define communication channels and frequency.
- Assign responsibility for communication tasks.
- Establish a process for managing communication feedback.

**Approval Authorities:** Project Manager, Marketing Director

### 4. Stakeholder Engagement Plan

**ID:** cecb863d-ef6d-4cd2-b38e-96bf29a36e40

**Description:** A plan outlining strategies for engaging with stakeholders, addressing their concerns, and building support for the Eurovision 2026 project. It ensures proactive and effective stakeholder management.

**Responsible Role Type:** Community Liaison Officer

**Primary Template:** Stakeholder Engagement Plan Template

**Steps:**

- Identify stakeholders and their interests.
- Develop engagement strategies for each stakeholder group.
- Establish a process for addressing stakeholder concerns.
- Monitor and evaluate the effectiveness of engagement efforts.

**Approval Authorities:** Project Manager, Marketing Director

### 5. Change Management Plan

**ID:** c91b6a8e-7eae-40e7-a0c6-6e01de953ca5

**Description:** A plan outlining the process for managing changes to the project scope, budget, or timeline. It ensures that changes are properly evaluated, approved, and implemented.

**Responsible Role Type:** Project Manager

**Primary Template:** Change Management Plan Template

**Steps:**

- Establish a change control board.
- Define the process for submitting change requests.
- Develop criteria for evaluating change requests.
- Establish a process for approving and implementing changes.

**Approval Authorities:** Change Control Board (Project Manager, Financial Officer, Technical Director)

### 6. High-Level Budget/Funding Framework

**ID:** 51b2615b-3dc9-4cee-b680-b9841812b500

**Description:** A high-level overview of the project budget, including sources of funding (EBU, ORF, host city, sponsors) and major cost categories (venue, security, broadcasting, artists). It provides a financial roadmap for the project.

**Responsible Role Type:** Financial Officer

**Primary Template:** Project Budget Template

**Steps:**

- Estimate total project costs.
- Identify potential sources of funding.
- Allocate budget to major cost categories.
- Establish a process for tracking and managing expenses.

**Approval Authorities:** Project Manager, EBU, ORF

### 7. Funding Agreement Structure/Template

**ID:** 9557b157-f11f-465b-b348-c30b9edd2e77

**Description:** A template for formal agreements with funding partners (EBU, ORF, host city, sponsors), outlining the terms and conditions of funding, including payment schedules, reporting requirements, and intellectual property rights. It ensures clear and legally binding agreements with funding partners.

**Responsible Role Type:** Legal Counsel

**Primary Template:** Standard Funding Agreement Template

**Steps:**

- Define the terms and conditions of funding.
- Outline payment schedules and reporting requirements.
- Address intellectual property rights.
- Obtain legal review and approval.

**Approval Authorities:** EBU Legal Counsel, ORF Legal Counsel, Host City Legal Counsel

### 8. Initial High-Level Schedule/Timeline

**ID:** a4e99707-2b6c-4d0c-8e39-90202ae5e263

**Description:** A high-level timeline outlining key project milestones (host city selection, venue preparation, artist selection, ticket sales, event dates). It provides a roadmap for project execution.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key project milestones.
- Estimate the duration of each milestone.
- Sequence the milestones in a logical order.
- Assign responsibility for completing each milestone.

**Approval Authorities:** Project Manager, EBU

### 9. M&E Framework

**ID:** bf7f4083-b0d1-4bc5-bfb4-68e80f3d6173

**Description:** A framework for monitoring and evaluating the success of the Eurovision 2026 project, including key performance indicators (KPIs), data collection methods, and reporting frequency. It ensures that the project is on track to achieve its objectives.

**Responsible Role Type:** Project Manager

**Primary Template:** Logical Framework Template

**Steps:**

- Define project objectives and KPIs.
- Identify data sources and collection methods.
- Establish a reporting frequency.
- Assign responsibility for monitoring and evaluating project performance.

**Approval Authorities:** Project Manager, EBU

### 10. Venue Selection Criteria Document

**ID:** 6ee6d94f-435f-4580-b7a1-d8df6efbbf84

**Description:** Document outlining the specific criteria for selecting the host city and venue, including EBU requirements, logistical needs, and financial considerations. This ensures a transparent and objective selection process.

**Responsible Role Type:** Project Manager

**Steps:**

- Gather EBU requirements for venues.
- Define logistical needs (accessibility, infrastructure).
- Establish financial considerations (cost, revenue potential).
- Weight the criteria based on importance.

**Approval Authorities:** EBU, ORF

### 11. Sustainability Strategy

**ID:** 836d82eb-d0e3-4b11-996e-4e9431a35f9b

**Description:** A high-level strategy outlining the approach to minimizing the environmental impact of the event, including waste reduction, energy efficiency, and sustainable sourcing. It sets the direction for more detailed sustainability planning.

**Responsible Role Type:** Sustainability Manager

**Steps:**

- Identify key environmental impacts.
- Set high-level sustainability goals.
- Outline strategies for achieving those goals.
- Define roles and responsibilities.

**Approval Authorities:** Project Manager, EBU

### 12. Security Management Framework

**ID:** fcaff334-432e-48e0-a5d6-749e7e3207d1

**Description:** A high-level framework outlining the approach to security management for the event, including risk assessment, security planning, and coordination with law enforcement. It sets the direction for more detailed security planning.

**Responsible Role Type:** Venue Security Coordinator

**Steps:**

- Identify potential security threats.
- Set high-level security goals.
- Outline strategies for achieving those goals.
- Define roles and responsibilities.

**Approval Authorities:** Project Manager, Law Enforcement Agencies

### 13. Contingency Planning Framework

**ID:** b457db0c-aa1a-4ef7-8c74-b733e1936b78

**Description:** A high-level framework outlining the approach to contingency planning for external shocks, including pandemics, natural disasters, or political instability. It sets the direction for more detailed contingency planning.

**Responsible Role Type:** Contingency Planning Specialist

**Steps:**

- Identify potential external shocks.
- Set high-level contingency planning goals.
- Outline strategies for achieving those goals.
- Define roles and responsibilities.

**Approval Authorities:** Project Manager, EBU

## Documents to Find

### 1. Participating Nations Eurovision Viewership Data

**ID:** 23972f9b-85e7-49aa-a9a4-b563eedf40cb

**Description:** Historical data on Eurovision viewership in participating nations, used to forecast audience size and inform marketing strategies. Intended audience: Marketing Director, Financial Officer.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Marketing Director

**Access Difficulty:** Medium: Requires contacting EBU and potentially accessing proprietary data.

**Steps:**

- Contact EBU for viewership data.
- Search online databases for viewership statistics.

### 2. Participating Nations GDP Data

**ID:** 1795326a-8c2c-4767-a201-52258031b8d3

**Description:** GDP data for participating nations, used to assess economic conditions and inform sponsorship strategies. Intended audience: Financial Officer, Sponsorship Manager.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Financial Officer

**Access Difficulty:** Easy: Publicly available data.

**Steps:**

- Search World Bank Open Data.
- Search IMF Data.
- Search national statistical offices.

### 3. Existing Austrian Event Security Regulations

**ID:** a3c07374-8be5-4a9f-8356-bc27abe27221

**Description:** Current Austrian regulations related to event security, used to ensure compliance and inform security planning. Intended audience: Venue Security Coordinator, Legal Counsel.

**Recency Requirement:** Current regulations

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating Austrian legal databases.

**Steps:**

- Search Austrian government legislative portals.
- Contact Austrian Ministry of Interior.

### 4. Existing Austrian Environmental Regulations for Events

**ID:** 77e148db-11a5-47af-9b21-2b088a83e07d

**Description:** Current Austrian environmental regulations related to events, used to ensure compliance and inform sustainability planning. Intended audience: Sustainability Manager, Legal Counsel.

**Recency Requirement:** Current regulations

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating Austrian legal databases.

**Steps:**

- Search Austrian government environmental agency websites.
- Contact Austrian Ministry of Environment.

### 5. Existing Austrian Building and Safety Codes

**ID:** a0b5f644-1ead-4cd3-acab-18043d6999c5

**Description:** Current Austrian building and safety codes, used to ensure venue compliance. Intended audience: Venue Manager, Legal Counsel.

**Recency Requirement:** Current regulations

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating Austrian legal databases.

**Steps:**

- Search Austrian government building code websites.
- Contact local municipality building departments.

### 6. Official Austrian Tourism Statistics

**ID:** 61dd7104-9149-48e7-a058-1c2c4342f305

**Description:** Official statistics on tourism in Austria, used to forecast the economic impact of the event. Intended audience: Financial Officer, Marketing Director.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Marketing Director

**Access Difficulty:** Easy: Publicly available data.

**Steps:**

- Search Austrian National Tourist Office website.
- Search Austrian statistical office website.

### 7. Existing EBU Broadcasting Standards

**ID:** cd83bdbc-12b3-4fcc-ba04-5eac3d328344

**Description:** Current EBU broadcasting standards, used to ensure compliance. Intended audience: Technical Infrastructure Lead, EBU Liaison.

**Recency Requirement:** Current standards

**Responsible Role Type:** EBU Liaison

**Access Difficulty:** Medium: Requires EBU membership or direct contact.

**Steps:**

- Contact EBU directly.
- Access EBU member resources online.

### 8. Vienna/Graz/Linz Venue Availability Data

**ID:** 9954e264-d6a3-4e8b-a42f-fdfa55804ce2

**Description:** Data on the availability of suitable venues in Vienna, Graz, and Linz, including capacity, technical specifications, and cost. Intended audience: Project Manager, Venue Manager.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Project Manager

**Access Difficulty:** Medium: Requires direct contact with venue management.

**Steps:**

- Contact venue management in Vienna, Graz, and Linz.
- Review venue websites and brochures.

### 9. Vienna/Graz/Linz Event Permitting Processes

**ID:** f8392753-357b-4d2d-9204-b62f69921f2e

**Description:** Information on the event permitting processes in Vienna, Graz, and Linz, including application requirements, timelines, and fees. Intended audience: Project Manager, Legal Counsel.

**Recency Requirement:** Current processes

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires contacting local government offices.

**Steps:**

- Contact local municipality permitting offices.
- Review city government websites.

### 10. Official Austrian Crime Statistics

**ID:** ebc59624-6915-4d5b-b0c7-8b4aa8617770

**Description:** Official crime statistics for Austria, used to inform security risk assessments. Intended audience: Venue Security Coordinator.

**Recency Requirement:** Last 3 years

**Responsible Role Type:** Venue Security Coordinator

**Access Difficulty:** Easy: Publicly available data.

**Steps:**

- Search Austrian Ministry of Interior website.
- Search Austrian statistical office website.

### 11. Austrian Natural Disaster Risk Assessment Data

**ID:** a1a9b035-e2f4-42cc-8a74-30a72e997df8

**Description:** Data on natural disaster risks in Austria, used to inform contingency planning. Intended audience: Contingency Planning Specialist.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Contingency Planning Specialist

**Access Difficulty:** Medium: Requires contacting government agencies.

**Steps:**

- Search Austrian government disaster management agency website.
- Contact Austrian geological survey.

### 12. Existing Austrian Noise Regulations

**ID:** 75fe82b0-0e89-4f33-8ad7-7154ae63fb30

**Description:** Current Austrian noise regulations, used to inform community engagement and mitigate noise complaints. Intended audience: Community Liaison Officer, Legal Counsel.

**Recency Requirement:** Current regulations

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating Austrian legal databases.

**Steps:**

- Search Austrian government environmental agency websites.
- Contact local municipality environmental departments.

### 13. Vienna/Graz/Linz Public Transportation Data

**ID:** 033821ff-2a89-4e5a-af39-8e9d34b7d759

**Description:** Data on public transportation infrastructure and capacity in Vienna, Graz, and Linz, used to inform transportation planning. Intended audience: Logistics Coordinator.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Logistics Coordinator

**Access Difficulty:** Easy: Publicly available data.

**Steps:**

- Contact local public transportation authorities.
- Review city government websites.

### 14. Austrian Political Stability Indices

**ID:** e601ed29-6e71-43a5-b4ee-1db6fa7f4ac7

**Description:** Indices measuring political stability in Austria, used to inform risk assessments and contingency planning. Intended audience: Project Manager, Contingency Planning Specialist.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Contingency Planning Specialist

**Access Difficulty:** Medium: Requires accessing specialized databases.

**Steps:**

- Search World Bank governance indicators.
- Search political risk analysis websites.

### 15. Austrian Labor Laws and Regulations

**ID:** c5dab0c9-133f-4521-bb1b-235f01159216

**Description:** Current Austrian labor laws and regulations, used to ensure compliance when hiring staff and volunteers. Intended audience: HR Manager, Legal Counsel.

**Recency Requirement:** Current regulations

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires navigating Austrian legal databases.

**Steps:**

- Search Austrian government labor law websites.
- Contact Austrian Ministry of Labor.