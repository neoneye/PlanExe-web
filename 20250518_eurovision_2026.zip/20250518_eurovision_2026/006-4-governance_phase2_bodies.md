### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's significant budget, international scope, and potential risks. Ensures alignment with ORF and EBU strategic objectives.

**Responsibilities:**

- Approve overall project strategy and objectives.
- Approve major project milestones and deliverables.
- Approve budget allocations exceeding €1 million.
- Monitor and manage strategic risks.
- Resolve strategic issues and conflicts.
- Ensure alignment with EBU requirements and ORF strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office (PMO).

**Membership:**

- ORF Director-General (Chair)
- EBU Representative
- Host City Representative (Mayor or designated official)
- ORF Head of Entertainment
- Independent Financial Expert
- Independent Legal Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above €1 million), timeline, and risk management. Approval of major contracts (above €500,000).

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the ORF Director-General (Chair) has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review and approval of budget revisions.
- Discussion and resolution of strategic risks and issues.
- Reports from the PMO.
- Stakeholder updates.
- Compliance report from the Ethics & Compliance Committee.

**Escalation Path:** Escalate to the ORF Supervisory Board for unresolved strategic issues or conflicts exceeding the Committee's authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation, risk management, and adherence to project plans. Provides centralized project support and coordination.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track expenditures.
- Identify, assess, and manage project risks.
- Monitor project progress and report to the Steering Committee.
- Coordinate project activities across different teams.
- Ensure compliance with project governance standards.
- Manage contracts below €500,000.

**Initial Setup Actions:**

- Establish PMO structure and roles.
- Develop project management methodologies and tools.
- Define reporting templates and processes.
- Recruit project team members.

**Membership:**

- Project Manager (Head of PMO)
- Financial Controller
- Logistics Coordinator
- Technical Lead
- Marketing Manager
- Risk Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk mitigation within approved budget and scope. Approval of contracts below €500,000.

**Decision Mechanism:** Decisions made by the Project Manager, with input from relevant team members. Escalation to the Steering Committee for issues exceeding PMO authority.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of budget and expenditures.
- Coordination of project activities.
- Action item tracking.
- Review of compliance status.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic decisions.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical conduct, regulatory compliance (including GDPR), and anti-corruption measures, given the project's high public profile and potential for ethical breaches.

**Responsibilities:**

- Develop and enforce ethical guidelines and policies.
- Monitor compliance with relevant laws and regulations (including GDPR).
- Investigate allegations of ethical misconduct or corruption.
- Provide training on ethics and compliance.
- Review and approve vendor selection processes.
- Ensure transparency and accountability in project operations.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Develop ethical guidelines and policies.
- Establish whistleblower mechanism.

**Membership:**

- Independent Legal Expert (Chair)
- ORF Compliance Officer
- External Ethics Consultant
- Representative from the Internal Audit Department
- Data Protection Officer

**Decision Rights:** Investigative authority regarding ethical breaches and compliance violations. Authority to recommend corrective actions and sanctions. Approval of vendor selection processes.

**Decision Mechanism:** Decisions made by majority vote. The Independent Legal Expert (Chair) has the casting vote in case of a tie.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for investigations or urgent matters.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Investigation of alleged misconduct.
- Review of vendor selection processes.
- Updates on relevant laws and regulations.
- Review of whistleblower reports.

**Escalation Path:** Escalate to the ORF Director-General and the ORF Supervisory Board for serious ethical breaches or compliance violations.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on broadcasting, sound, lighting, voting systems, and cybersecurity, given the project's reliance on complex technology and the risk of technical failures.

**Responsibilities:**

- Review and approve technical specifications and designs.
- Provide technical guidance and support to the project team.
- Assess and mitigate technical risks.
- Oversee testing and quality assurance.
- Ensure redundancy and backup systems are in place.
- Advise on cybersecurity measures.
- Evaluate vendor proposals for technical services.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define technical standards and requirements.

**Membership:**

- Independent Broadcasting Engineer (Chair)
- ORF Head of Technology
- Cybersecurity Expert
- Sound and Lighting Specialist
- Voting System Expert
- Representative from the PMO (Technical Lead)

**Decision Rights:** Approval of technical specifications, designs, and vendor selections. Authority to recommend changes to technical plans to mitigate risks or improve performance.

**Decision Mechanism:** Decisions made by consensus whenever possible. In cases where consensus cannot be reached, the Independent Broadcasting Engineer (Chair) has the final decision.

**Meeting Cadence:** Bi-weekly during critical technical phases, monthly otherwise.

**Typical Agenda Items:**

- Review of technical progress and issues.
- Discussion of technical risks and mitigation strategies.
- Review of testing results.
- Evaluation of vendor proposals.
- Updates on emerging technologies.
- Cybersecurity threat assessment.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved technical issues or strategic decisions related to technology.