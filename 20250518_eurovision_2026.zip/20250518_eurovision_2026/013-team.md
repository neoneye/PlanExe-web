# Roles

## 1. Financial Risk Analyst

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial Risk Analyst requires in-depth understanding of the project's financials and ongoing monitoring, making a full-time employee the best option.

**Explanation**:
Expertise in identifying and mitigating financial risks, including currency fluctuations, interest rate changes, and revenue shortfalls, is crucial for maintaining budget stability.

**Consequences**:
Significant budget overruns due to unforeseen financial risks, potentially jeopardizing the entire event.

**People Count**:
min 1, max 2, depending on the complexity of financial instruments used and the level of hedging required.

**Typical Activities**:
Conducting financial risk assessments, developing mitigation strategies, monitoring currency fluctuations, managing hedging strategies, and ensuring budget compliance.

**Background Story**:
Anneliese Huber, born and raised in Vienna, Austria, developed a keen interest in finance and economics from a young age. She pursued a degree in Economics at the Vienna University of Economics and Business, followed by a Master's in Financial Risk Management from the University of Oxford. Anneliese has over five years of experience in financial analysis and risk management, primarily in the banking sector. She is highly skilled in statistical modeling, financial forecasting, and risk assessment. Her familiarity with Austrian financial regulations and her expertise in international finance make her particularly relevant for identifying and mitigating financial risks associated with the Eurovision 2026 project.

**Equipment Needs**:
High-performance computer with financial modeling software, access to real-time financial data feeds, secure communication channels.

**Facility Needs**:
Private office space with secure access, meeting rooms for financial reviews, access to financial databases.

## 2. Technical Infrastructure Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Technical Infrastructure Lead needs to be dedicated to the project for its duration, ensuring reliable technical infrastructure. Full-time employment allows for better control and availability.

**Explanation**:
Ensures robust and reliable technical infrastructure for broadcasting, sound, lighting, and voting systems, including redundancy and cybersecurity measures.

**Consequences**:
Technical failures during the live broadcast, leading to significant viewership drop, reputational damage, and financial losses.

**People Count**:
1

**Typical Activities**:
Designing and implementing technical infrastructure, managing broadcasting systems, ensuring redundancy and backup systems, conducting rigorous testing, and implementing cybersecurity measures.

**Background Story**:
Kenji Tanaka, originally from Tokyo, Japan, moved to Austria after completing his degree in Electrical Engineering at the University of Tokyo. He has spent the last 10 years working in the broadcasting industry, specializing in technical infrastructure and systems integration. Kenji has extensive experience in designing, implementing, and maintaining complex broadcasting systems for large-scale events. His expertise includes sound engineering, lighting design, and cybersecurity. Kenji's international experience and his deep understanding of technical infrastructure make him an ideal candidate to lead the technical aspects of Eurovision 2026.

**Equipment Needs**:
High-end computer with specialized software for broadcasting, sound, and lighting design; access to testing environments; cybersecurity tools.

**Facility Needs**:
Dedicated technical workspace with testing equipment, access to broadcasting facilities, secure server room.

## 3. Contingency Planning Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Contingency Planning Specialist requires a deep understanding of the project and its potential vulnerabilities, necessitating a full-time commitment.

**Explanation**:
Develops and maintains comprehensive contingency plans for external shocks such as pandemics, natural disasters, or political instability, ensuring the event can adapt or be postponed if necessary.

**Consequences**:
Inability to respond effectively to unforeseen events, potentially leading to cancellation of the event and significant financial losses.

**People Count**:
1

**Typical Activities**:
Developing contingency plans, conducting risk assessments, establishing communication protocols, coordinating with emergency services, and managing crisis response efforts.

**Background Story**:
Isabella Rossi, a native of Rome, Italy, has dedicated her career to emergency management and contingency planning. She holds a Master's degree in Disaster Management from the University of Copenhagen and has worked with international organizations such as the Red Cross and Doctors Without Borders. Isabella has extensive experience in developing and implementing contingency plans for various types of crises, including pandemics, natural disasters, and political instability. Her expertise in risk assessment, crisis communication, and emergency response makes her highly relevant for developing a comprehensive contingency plan for Eurovision 2026.

**Equipment Needs**:
Computer with risk assessment software, communication tools for emergency services, access to global event monitoring systems.

**Facility Needs**:
Office space with secure communication lines, access to emergency response coordination centers, meeting rooms for crisis simulation exercises.

## 4. Community Liaison Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Community Liaison Officer needs to build relationships and manage communications throughout the project, making a full-time employee the most effective choice.

**Explanation**:
Engages with local communities to address concerns about noise, traffic, and disruption, fostering positive relationships and minimizing public opposition.

**Consequences**:
Negative public reaction, protests, and boycotts, potentially disrupting the event and damaging its reputation.

**People Count**:
min 1, max 3, depending on the host city and the level of community engagement required.

**Typical Activities**:
Engaging with local communities, addressing concerns about noise and traffic, fostering positive relationships, organizing public forums, and managing community feedback.

**Background Story**:
Stefan Gruber, born and raised in Linz, Austria, has a strong background in community development and public relations. He holds a degree in Sociology from the University of Vienna and has worked for several years in local government, focusing on community engagement and stakeholder relations. Stefan is skilled in communication, conflict resolution, and community organizing. His deep understanding of Austrian culture and his experience in working with local communities make him an ideal candidate to serve as a Community Liaison Officer for Eurovision 2026.

**Equipment Needs**:
Laptop with communication and community engagement software, mobile phone, transportation for community visits.

**Facility Needs**:
Office space, access to community centers and public forums, meeting rooms for stakeholder consultations.

## 5. Venue Security Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Venue Security Coordinator requires dedicated oversight and coordination of security measures, best achieved through full-time employment.

**Explanation**:
Responsible for all aspects of venue security, including risk assessment, security planning, coordination with law enforcement, and implementation of security measures.

**Consequences**:
Security breaches, potential injuries, and reputational damage, jeopardizing the safety of participants and attendees.

**People Count**:
min 2, max 5, depending on venue size and security complexity. More people are needed to manage multiple entry points, coordinate security personnel, and oversee surveillance systems.

**Typical Activities**:
Conducting security risk assessments, developing security plans, coordinating with law enforcement, implementing security measures, and managing security personnel.

**Background Story**:
Amina Diallo, originally from Dakar, Senegal, has a distinguished career in security management. She served in the French Foreign Legion for 10 years, specializing in counter-terrorism and security operations. After leaving the military, Amina obtained a Master's degree in Security Management from the University of Leicester. She has since worked as a security consultant for various international events, including the FIFA World Cup and the Olympic Games. Amina's extensive experience in risk assessment, security planning, and coordination with law enforcement makes her an invaluable asset to the Eurovision 2026 team.

**Equipment Needs**:
Security planning software, communication devices (radios, mobile phones), access to surveillance systems, security equipment (metal detectors, etc.).

**Facility Needs**:
Office within the venue, access to security control rooms, secure storage for security equipment, direct communication lines to law enforcement.

## 6. Sustainability Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Sustainability Manager needs to integrate sustainability practices throughout the project, requiring a full-time commitment.

**Explanation**:
Develops and implements a sustainability plan to minimize the environmental impact of the event, including waste reduction, energy efficiency, and sustainable sourcing.

**Consequences**:
Negative environmental impact, fines, negative coverage, and reputational damage.

**People Count**:
1

**Typical Activities**:
Developing sustainability plans, conducting environmental impact assessments, implementing waste reduction programs, promoting energy efficiency, and ensuring sustainable sourcing.

**Background Story**:
Greta Thunberg-Schmidt, not related to the famous activist, grew up in a small village in Styria, Austria, with a deep appreciation for nature. She pursued a degree in Environmental Science at the University of Graz, followed by a Master's in Sustainable Development from the University of Uppsala in Sweden. Greta has worked for several years in the environmental sector, focusing on waste reduction, energy efficiency, and sustainable sourcing. Her passion for sustainability and her expertise in environmental management make her an ideal candidate to serve as the Sustainability Manager for Eurovision 2026.

**Equipment Needs**:
Computer with environmental impact assessment software, access to sustainability databases, testing equipment for waste and energy analysis.

**Facility Needs**:
Office space, access to environmental testing labs, meeting rooms for sustainability planning, transportation for site inspections.

## 7. Volunteer Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Volunteer Coordinator requires dedicated management of volunteers, ensuring adequate staffing and efficient operations. Full-time employment allows for better control and availability.

**Explanation**:
Recruits, trains, and manages volunteers to support various aspects of the event, ensuring adequate staffing and efficient operations.

**Consequences**:
Staffing shortages, operational inefficiencies, and increased workload for paid staff.

**People Count**:
min 2, max 4, depending on the number of volunteers required and the complexity of their roles. More people are needed to handle recruitment, training, scheduling, and on-site management of a large volunteer workforce.

**Typical Activities**:
Recruiting volunteers, training volunteers, scheduling volunteers, managing volunteers, and ensuring adequate staffing for various event activities.

**Background Story**:
Carlos Rodriguez, a vibrant individual from Buenos Aires, Argentina, has a passion for event management and community involvement. He holds a degree in Hospitality Management from the University of Belgrano and has extensive experience in volunteer coordination for various non-profit organizations. Carlos is skilled in recruitment, training, scheduling, and on-site management of volunteers. His enthusiasm, organizational skills, and experience in managing large volunteer workforces make him an excellent choice for the Volunteer Coordinator role for Eurovision 2026.

**Equipment Needs**:
Computer with volunteer management software, communication tools for volunteer coordination, training materials.

**Facility Needs**:
Office space, training rooms for volunteer sessions, on-site coordination space during the event.

## 8. EBU Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: EBU Liaison requires constant communication and coordination with the EBU, making a full-time employee the most effective choice.

**Explanation**:
Maintains constant communication with the European Broadcasting Union (EBU) to ensure compliance with all regulations and standards, and to facilitate smooth collaboration.

**Consequences**:
Failure to meet EBU standards, potentially leading to sanctions, loss of broadcasting rights, or disqualification from future events.

**People Count**:
1

**Typical Activities**:
Maintaining communication with the EBU, ensuring compliance with EBU regulations, facilitating collaboration, and managing broadcasting rights.

**Background Story**:
Ingrid Hoffmann, a Swiss national from Zurich, has spent her career working in international broadcasting and regulatory affairs. She holds a degree in Communications from the University of Zurich and has worked for the European Broadcasting Union (EBU) for over 15 years. Ingrid has extensive knowledge of EBU regulations, standards, and procedures. Her experience in liaising with various broadcasting organizations and her deep understanding of EBU requirements make her an ideal candidate to serve as the EBU Liaison for Eurovision 2026.

**Equipment Needs**:
Computer with secure communication channels, access to EBU documentation and communication platforms.

**Facility Needs**:
Office space, secure communication lines to EBU headquarters, meeting rooms for EBU coordination meetings.

---

# Omissions

## 1. Accessibility Coordinator

Ensuring accessibility for all attendees, including those with disabilities, is crucial for an inclusive event. The current plan lacks a dedicated role to oversee accessibility requirements.

**Recommendation**:
Assign a team member to be responsible for accessibility, including venue accessibility, accessible transportation, and communication materials in accessible formats. Consult with disability advocacy groups to ensure all needs are met.

## 2. Ticketing and Accreditation Manager

While technology for ticketing and accreditation is mentioned, there's no dedicated role to manage the complexities of ticket sales, distribution, and accreditation processes. This can lead to inefficiencies and potential fraud.

**Recommendation**:
Designate a team member to oversee ticketing and accreditation, including managing the ticketing system, coordinating ticket distribution, and handling accreditation for participants, press, and staff.

## 3. Fan Engagement Coordinator

Engaging with fans before, during, and after the event can enhance the overall experience and create a positive atmosphere. The current plan lacks a specific focus on fan engagement strategies.

**Recommendation**:
Assign a team member to develop and implement a fan engagement strategy, including social media campaigns, fan events, and interactive experiences. This will help build excitement and create a memorable experience for attendees.

---

# Potential Improvements

## 1. Clarify Responsibilities of Community Liaison Officer

The role of the Community Liaison Officer is defined, but the specific metrics for success and the process for escalating community concerns are not. This could lead to unclear expectations and ineffective community engagement.

**Recommendation**:
Define specific, measurable goals for the Community Liaison Officer, such as the number of community meetings held, the level of positive feedback received, and the resolution rate of community concerns. Establish a clear process for escalating unresolved issues to senior management.

## 2. Enhance Volunteer Coordinator's Role Definition

The Volunteer Coordinator's role is defined, but the plan lacks details on volunteer training programs and on-site support mechanisms. This could lead to underprepared volunteers and operational inefficiencies.

**Recommendation**:
Develop a comprehensive volunteer training program that covers event logistics, safety procedures, and customer service skills. Establish on-site support teams to assist volunteers during the event and address any issues that arise.

## 3. Refine Security Coordinator's Responsibilities

The Venue Security Coordinator's responsibilities are broad, but the plan lacks specifics on emergency evacuation procedures and coordination with medical services. This could lead to inadequate emergency response capabilities.

**Recommendation**:
Develop detailed emergency evacuation procedures for the venue, including clear signage, designated evacuation routes, and trained personnel. Establish a close working relationship with local medical services to ensure prompt response to any medical emergencies.