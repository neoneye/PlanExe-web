# Governance Audit


## Audit - Corruption Risks

- Bribery of city officials to secure Vienna as the host city, despite other potentially more suitable bids from Graz or Linz.
- Kickbacks from security firms in exchange for being awarded the security contract for the event.
- Conflicts of interest arising from ORF employees having undisclosed financial interests in companies bidding for broadcasting or technical contracts.
- Nepotism in the selection of volunteers or technical staff, potentially compromising the quality of the event.
- Misuse of inside information regarding vendor selection to benefit friends or family members.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors, with the excess funds being diverted for personal use.
- Double-billing for services rendered, such as security or transportation.
- Inefficient allocation of resources, such as overspending on marketing while underfunding security measures.
- Unauthorized use of project funds for personal travel or entertainment.
- Misreporting of project progress to justify continued funding, even if milestones are not being met.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on high-value contracts and expense reports. Responsibility: Internal Audit Department.
- Implement a robust contract review process, with independent legal and financial review of all contracts exceeding €100,000. Responsibility: Legal and Finance Departments.
- Perform regular compliance checks to ensure adherence to EBU broadcasting standards and local regulations. Responsibility: Compliance Officer.
- Conduct a post-project external audit to assess the overall financial management and identify any irregularities. Responsibility: External Audit Firm.
- Implement a whistleblower mechanism with clear procedures for reporting suspected fraud or corruption, ensuring anonymity and protection for whistleblowers. Responsibility: HR and Legal Departments.

## Audit - Transparency Measures

- Publish a detailed project budget and financial reports on the ORF website, updated quarterly.
- Create a public dashboard tracking key project milestones, budget expenditures, and risk mitigation efforts.
- Publish minutes of key project team meetings, including decisions related to vendor selection and budget allocation.
- Establish a clear and documented selection criteria for all major vendors and contractors, publicly available on the ORF website.
- Implement a policy requiring disclosure of potential conflicts of interest for all project team members and stakeholders.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's significant budget, international scope, and potential risks. Ensures alignment with ORF and EBU strategic objectives.

**Responsibilities:**

- Approve overall project strategy and objectives.
- Approve major project milestones and deliverables.
- Approve budget allocations exceeding €1 million.
- Monitor and manage strategic risks.
- Resolve strategic issues and conflicts.
- Ensure alignment with EBU requirements and ORF strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office (PMO).

**Membership:**

- ORF Director-General (Chair)
- EBU Representative
- Host City Representative (Mayor or designated official)
- ORF Head of Entertainment
- Independent Financial Expert
- Independent Legal Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above €1 million), timeline, and risk management. Approval of major contracts (above €500,000).

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the ORF Director-General (Chair) has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review and approval of budget revisions.
- Discussion and resolution of strategic risks and issues.
- Reports from the PMO.
- Stakeholder updates.
- Compliance report from the Ethics & Compliance Committee.

**Escalation Path:** Escalate to the ORF Supervisory Board for unresolved strategic issues or conflicts exceeding the Committee's authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation, risk management, and adherence to project plans. Provides centralized project support and coordination.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track expenditures.
- Identify, assess, and manage project risks.
- Monitor project progress and report to the Steering Committee.
- Coordinate project activities across different teams.
- Ensure compliance with project governance standards.
- Manage contracts below €500,000.

**Initial Setup Actions:**

- Establish PMO structure and roles.
- Develop project management methodologies and tools.
- Define reporting templates and processes.
- Recruit project team members.

**Membership:**

- Project Manager (Head of PMO)
- Financial Controller
- Logistics Coordinator
- Technical Lead
- Marketing Manager
- Risk Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk mitigation within approved budget and scope. Approval of contracts below €500,000.

**Decision Mechanism:** Decisions made by the Project Manager, with input from relevant team members. Escalation to the Steering Committee for issues exceeding PMO authority.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of budget and expenditures.
- Coordination of project activities.
- Action item tracking.
- Review of compliance status.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic decisions.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical conduct, regulatory compliance (including GDPR), and anti-corruption measures, given the project's high public profile and potential for ethical breaches.

**Responsibilities:**

- Develop and enforce ethical guidelines and policies.
- Monitor compliance with relevant laws and regulations (including GDPR).
- Investigate allegations of ethical misconduct or corruption.
- Provide training on ethics and compliance.
- Review and approve vendor selection processes.
- Ensure transparency and accountability in project operations.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Develop ethical guidelines and policies.
- Establish whistleblower mechanism.

**Membership:**

- Independent Legal Expert (Chair)
- ORF Compliance Officer
- External Ethics Consultant
- Representative from the Internal Audit Department
- Data Protection Officer

**Decision Rights:** Investigative authority regarding ethical breaches and compliance violations. Authority to recommend corrective actions and sanctions. Approval of vendor selection processes.

**Decision Mechanism:** Decisions made by majority vote. The Independent Legal Expert (Chair) has the casting vote in case of a tie.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for investigations or urgent matters.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Investigation of alleged misconduct.
- Review of vendor selection processes.
- Updates on relevant laws and regulations.
- Review of whistleblower reports.

**Escalation Path:** Escalate to the ORF Director-General and the ORF Supervisory Board for serious ethical breaches or compliance violations.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on broadcasting, sound, lighting, voting systems, and cybersecurity, given the project's reliance on complex technology and the risk of technical failures.

**Responsibilities:**

- Review and approve technical specifications and designs.
- Provide technical guidance and support to the project team.
- Assess and mitigate technical risks.
- Oversee testing and quality assurance.
- Ensure redundancy and backup systems are in place.
- Advise on cybersecurity measures.
- Evaluate vendor proposals for technical services.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define technical standards and requirements.

**Membership:**

- Independent Broadcasting Engineer (Chair)
- ORF Head of Technology
- Cybersecurity Expert
- Sound and Lighting Specialist
- Voting System Expert
- Representative from the PMO (Technical Lead)

**Decision Rights:** Approval of technical specifications, designs, and vendor selections. Authority to recommend changes to technical plans to mitigate risks or improve performance.

**Decision Mechanism:** Decisions made by consensus whenever possible. In cases where consensus cannot be reached, the Independent Broadcasting Engineer (Chair) has the final decision.

**Meeting Cadence:** Bi-weekly during critical technical phases, monthly otherwise.

**Typical Agenda Items:**

- Review of technical progress and issues.
- Discussion of technical risks and mitigation strategies.
- Review of testing results.
- Evaluation of vendor proposals.
- Updates on emerging technologies.
- Cybersecurity threat assessment.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved technical issues or strategic decisions related to technology.

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (ORF Director-General, EBU Representative, Host City Representative, ORF Head of Entertainment, Independent Financial Expert, Independent Legal Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor (ORF Director-General) formally appoints the Project Steering Committee Chair (ORF Director-General).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee Chair confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager establishes the PMO structure and defines roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Role Descriptions

**Dependencies:**

- Project Plan Approved

### 9. Project Manager develops project management methodologies and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Handbook
- Templates and Tools

**Dependencies:**

- PMO Structure Document

### 10. Project Manager defines reporting templates and processes for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Templates
- Reporting Process Document

**Dependencies:**

- Project Management Handbook

### 11. Project Manager recruits project team members for the PMO (Financial Controller, Logistics Coordinator, Technical Lead, Marketing Manager, Risk Manager, Compliance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Filled PMO Roles

**Dependencies:**

- Role Descriptions

### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Filled PMO Roles

### 13. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 14. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Independent Legal Expert, ORF Compliance Officer, External Ethics Consultant, Representative from the Internal Audit Department, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 15. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 16. Senior Sponsor (ORF Director-General) appoints the Ethics & Compliance Committee Chair (Independent Legal Expert).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 17. Ethics & Compliance Committee Chair confirms membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 18. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 19. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 20. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 21. Circulate Draft Technical Advisory Group ToR for review by nominated members (Independent Broadcasting Engineer, ORF Head of Technology, Cybersecurity Expert, Sound and Lighting Specialist, Voting System Expert, Representative from the PMO (Technical Lead)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 22. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Senior Sponsor (ORF Director-General) appoints the Technical Advisory Group Chair (Independent Broadcasting Engineer).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 24. Technical Advisory Group Chair confirms membership of the Technical Advisory Group.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 25. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 26. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for uncontrolled spending, budget overruns, and compromised project financial stability.

**Critical Risk Materialization (e.g., Security Threat)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Contingency Plan
Rationale: Materialization of a critical risk, such as a security threat, requires immediate strategic decisions and resource allocation beyond the PMO's capacity.
Negative Consequences: Potential for security breaches, injuries, reputational damage, and project cancellation.

**PMO Deadlock on Vendor Selection**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Review and Recommendation
Rationale: Disagreement within the PMO on vendor selection necessitates independent review to ensure ethical and compliant decision-making.
Negative Consequences: Potential for biased vendor selection, legal challenges, and reputational damage.

**Proposed Major Scope Change (e.g., Venue Change)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant changes to the project scope require strategic alignment and approval from the Steering Committee due to potential budget, timeline, and resource implications.
Negative Consequences: Potential for project delays, budget overruns, and failure to meet project objectives.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation and Recommendation
Rationale: Allegations of ethical misconduct require independent investigation and resolution to maintain project integrity and public trust.
Negative Consequences: Potential for legal penalties, reputational damage, and loss of stakeholder confidence.

**Unresolved Technical Issue**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Technical issues that the Technical Advisory Group cannot resolve require strategic decisions and resource allocation beyond the TAG's capacity.
Negative Consequences: Potential for technical failures, project delays, and failure to meet project objectives.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Monthly Progress Reports

**Frequency:** Weekly

**Responsible Role:** Project Manager

**Adaptation Process:** PMO proposes adjustments via Change Request to Steering Committee

**Adaptation Trigger:** KPI deviates >10% from target, or significant milestone delay

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Risk Assessment Matrix

**Frequency:** Bi-weekly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk mitigation plan updated by Risk Manager, reviewed by PMO

**Adaptation Trigger:** New critical risk identified, existing risk likelihood/impact increases significantly, or mitigation plan proves ineffective

### 3. Budget Adherence Monitoring
**Monitoring Tools/Platforms:**

  - Financial Management System
  - Budget Tracking Spreadsheet
  - Monthly Financial Reports

**Frequency:** Weekly

**Responsible Role:** Financial Controller

**Adaptation Process:** Financial Controller proposes budget adjustments to PMO, escalated to Steering Committee if exceeding PMO authority

**Adaptation Trigger:** Projected budget overrun exceeds 5%, or significant variance in expenditure against plan

### 4. Venue Selection Progress Monitoring
**Monitoring Tools/Platforms:**

  - Venue Selection Scorecard
  - Site Visit Reports
  - Negotiation Logs

**Frequency:** Monthly

**Responsible Role:** Logistics Coordinator

**Adaptation Process:** Logistics Coordinator recommends alternative venues or negotiation strategies to PMO, escalated to Steering Committee if necessary

**Adaptation Trigger:** Failure to secure preferred venue by target date (August 2025), or significant increase in venue costs

### 5. Permitting and Regulatory Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Permitting Schedule
  - Compliance Checklist
  - Communication Logs with Regulatory Bodies

**Frequency:** Weekly

**Responsible Role:** Compliance Officer

**Adaptation Process:** Compliance Officer proposes alternative compliance strategies or escalates permitting delays to PMO and Steering Committee

**Adaptation Trigger:** Permitting delays exceeding 1 month, or identification of new regulatory requirements

### 6. Security Plan Implementation Monitoring
**Monitoring Tools/Platforms:**

  - Security Plan Document
  - Incident Reports
  - Security Audit Reports

**Frequency:** Monthly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk Manager updates security plan based on incident reports and audit findings, reviewed by PMO and law enforcement

**Adaptation Trigger:** Security breach or near-miss incident, or identification of new security threats

### 7. Sponsorship Revenue Tracking
**Monitoring Tools/Platforms:**

  - Sponsorship Pipeline CRM/Spreadsheet
  - Sponsorship Agreements
  - Financial Reports

**Frequency:** Monthly

**Responsible Role:** Marketing Manager

**Adaptation Process:** Marketing Manager adjusts sponsorship outreach strategy, explores alternative revenue streams, or proposes budget cuts to PMO and Steering Committee

**Adaptation Trigger:** Projected sponsorship shortfall below 80% of target by December 2025

### 8. Technical Infrastructure Readiness Monitoring
**Monitoring Tools/Platforms:**

  - Technical Specifications Document
  - Testing Reports
  - Vendor Contracts

**Frequency:** Bi-weekly

**Responsible Role:** Technical Lead

**Adaptation Process:** Technical Lead proposes alternative technical solutions or vendor contracts to PMO and Technical Advisory Group

**Adaptation Trigger:** Technical testing failures, vendor delays, or identification of cybersecurity vulnerabilities

### 9. Stakeholder Feedback Analysis
**Monitoring Tools/Platforms:**

  - Survey Platform
  - Feedback Forms
  - Community Meeting Minutes

**Frequency:** Monthly

**Responsible Role:** Marketing Manager

**Adaptation Process:** Marketing Manager adjusts communication plan or community engagement strategy based on feedback, reviewed by PMO

**Adaptation Trigger:** Negative feedback trend from community or key stakeholders, or significant public opposition

### 10. Contingency Plan Review and Updates
**Monitoring Tools/Platforms:**

  - Contingency Plan Document
  - External Event Monitoring Reports

**Frequency:** Quarterly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk Manager updates contingency plan based on external event monitoring and risk assessments, reviewed by PMO and Steering Committee

**Adaptation Trigger:** Significant changes in external environment (e.g., pandemic outbreak, political instability), or identification of new potential external shocks

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses the defined governance bodies. The Escalation Matrix aligns with the governance hierarchy. Monitoring roles are defined and linked to responsibilities. Overall, the components show good internal consistency.
3. Point 3: Potential Gaps / Areas for Enhancement: The role and authority of the ORF Director-General, acting as the Senior Sponsor and Chair of the Project Steering Committee, needs further clarification. While efficient, this concentration of power could create bias. Are there checks and balances in place to ensure independent oversight?
4. Point 4: Potential Gaps / Areas for Enhancement: The Ethics & Compliance Committee's authority to 'recommend corrective actions and sanctions' needs to be more specific. What types of sanctions are within their purview? What is the process for implementing their recommendations if resistance is encountered?
5. Point 5: Potential Gaps / Areas for Enhancement: The Technical Advisory Group's decision-making process relies heavily on the Independent Broadcasting Engineer (Chair). While expertise is valuable, the process should outline how dissenting opinions from other members (e.g., the Cybersecurity Expert) are formally considered and documented, especially regarding security trade-offs.
6. Point 6: Potential Gaps / Areas for Enhancement: The Monitoring Progress plan lacks detail on how the 'Stakeholder Feedback Analysis' will be used to make concrete changes to the project. What are the specific thresholds or criteria that will trigger a change in the communication plan or community engagement strategy? How will conflicting feedback from different stakeholder groups be resolved?
7. Point 7: Potential Gaps / Areas for Enhancement: The 'Contingency Plan Review and Updates' process is only triggered by 'significant changes in external environment'. The plan should also include triggers based on internal project performance, such as failure to meet critical milestones or significant budget overruns, which might necessitate activating contingency plans.

## Tough Questions

1. What specific mechanisms are in place to ensure the ORF Director-General's decisions, as both Senior Sponsor and Steering Committee Chair, are subject to independent review and challenge, particularly regarding vendor selection and budget allocation?
2. Can you provide evidence of a documented process outlining the Ethics & Compliance Committee's authority to enforce sanctions and corrective actions, including examples of potential sanctions and the escalation path for non-compliance?
3. How will the Technical Advisory Group ensure that cybersecurity considerations are given appropriate weight in technical decisions, even if they conflict with other technical priorities or budget constraints? Provide examples of past trade-off decisions.
4. What are the specific, measurable criteria that will be used to evaluate the effectiveness of the community engagement plan, and what pre-defined actions will be taken if these criteria are not met?
5. What is the probability-weighted forecast for securing key sponsorships by December 2025, and what contingency plans are in place if this target is not met?
6. Show evidence of a documented and tested incident response plan for a major cybersecurity breach, including roles, responsibilities, and communication protocols.
7. What is the current status of negotiations with potential host cities (Vienna, Graz, Linz), and what are the key decision criteria that will be used to select the final venue? What are the fall-back options if negotiations with the preferred venue fail?
8. What is the detailed breakdown of the 'Security' budget (€6-8M), and how will the effectiveness of security measures be measured and reported to the Project Steering Committee?

## Summary

The governance framework for Eurovision 2026 in Austria establishes a multi-tiered structure with clear roles and responsibilities. It emphasizes strategic oversight, ethical conduct, technical expertise, and proactive risk management. The framework's strength lies in its comprehensive approach, but further refinement is needed to address potential biases, clarify enforcement mechanisms, and ensure robust contingency planning.