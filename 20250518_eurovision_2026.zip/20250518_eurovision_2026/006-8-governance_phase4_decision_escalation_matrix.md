**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for uncontrolled spending, budget overruns, and compromised project financial stability.

**Critical Risk Materialization (e.g., Security Threat)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Contingency Plan
Rationale: Materialization of a critical risk, such as a security threat, requires immediate strategic decisions and resource allocation beyond the PMO's capacity.
Negative Consequences: Potential for security breaches, injuries, reputational damage, and project cancellation.

**PMO Deadlock on Vendor Selection**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Review and Recommendation
Rationale: Disagreement within the PMO on vendor selection necessitates independent review to ensure ethical and compliant decision-making.
Negative Consequences: Potential for biased vendor selection, legal challenges, and reputational damage.

**Proposed Major Scope Change (e.g., Venue Change)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant changes to the project scope require strategic alignment and approval from the Steering Committee due to potential budget, timeline, and resource implications.
Negative Consequences: Potential for project delays, budget overruns, and failure to meet project objectives.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation and Recommendation
Rationale: Allegations of ethical misconduct require independent investigation and resolution to maintain project integrity and public trust.
Negative Consequences: Potential for legal penalties, reputational damage, and loss of stakeholder confidence.

**Unresolved Technical Issue**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Technical issues that the Technical Advisory Group cannot resolve require strategic decisions and resource allocation beyond the TAG's capacity.
Negative Consequences: Potential for technical failures, project delays, and failure to meet project objectives.