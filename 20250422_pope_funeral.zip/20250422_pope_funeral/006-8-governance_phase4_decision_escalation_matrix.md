**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and financial instability.

**Critical Risk Materialization (e.g., Major Security Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decisions and resource allocation beyond the PMO's capacity to address the significant impact on project objectives.
Negative Consequences: Severe injury/death, reputational damage, project failure, and political fallout.

**PMO Deadlock on Vendor Selection (Conflicting Proposals)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Proposals and Vote
Rationale: Ensures impartial decision-making and alignment with project objectives when the PMO cannot reach a consensus.
Negative Consequences: Project delays, inefficient resource allocation, and potential legal challenges.

**Proposed Major Scope Change (e.g., Significant Increase in Attendees)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Requires strategic evaluation of the impact on budget, timeline, resources, and overall project objectives.
Negative Consequences: Project delays, budget overruns, and failure to meet stakeholder expectations.

**Reported Ethical Concern (e.g., Allegation of Bribery)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee or Pope's personal secretary/designated successor
Rationale: Requires independent investigation and assessment to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Security and Risk Advisory Group cannot agree on a security protocol change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Requires strategic decision-making when security experts cannot agree on the best course of action, given the high-profile nature of the event.
Negative Consequences: Compromised security, increased risk of incidents, and potential harm to attendees.