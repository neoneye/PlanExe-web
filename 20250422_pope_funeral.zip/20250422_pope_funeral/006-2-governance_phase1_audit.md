
## Audit - Corruption Risks

- Bribery of Vatican officials or Italian authorities to expedite permits or security clearances.
- Kickbacks from hotel chains in exchange for guaranteed bookings, potentially inflating accommodation costs.
- Conflicts of interest in the selection of security firms or catering services, favoring companies with personal connections.
- Misuse of privileged information regarding security protocols or VIP movements for personal gain or to leak to media outlets.
- Nepotism in the hiring of personnel for security, crowd control, or VIP liaison roles, potentially compromising competence and impartiality.

## Audit - Misallocation Risks

- Inflated invoices from contractors (e.g., security, catering) with the excess funds diverted for personal use.
- Double-billing for services rendered, such as security personnel or transportation, to siphon off funds.
- Unnecessary or overpriced procurement of equipment (e.g., CCTV cameras, non-lethal crowd control devices) through favored vendors.
- Misreporting of attendance numbers to justify inflated expenses for catering or accommodation.
- Use of project funds for personal travel or entertainment expenses disguised as legitimate business costs.

## Audit - Procedures

- Conduct a pre-payment audit of all invoices exceeding €50,000, focusing on vendor selection, contract terms, and price reasonableness (Responsibility: Internal Audit, Frequency: Before payment).
- Perform surprise audits of security personnel deployment and crowd control measures during the event to verify compliance with the plan (Responsibility: External Security Consultant, Frequency: Unannounced, during the event).
- Implement a whistleblower hotline for reporting suspected fraud or corruption, with guaranteed anonymity and protection from retaliation (Responsibility: Ethics Committee, Frequency: Ongoing).
- Conduct a post-event audit of all expenses, comparing actual costs against the budget and investigating any significant variances (Responsibility: External Audit Firm, Frequency: Post-event).
- Review all contracts with vendors and suppliers to ensure compliance with procurement policies and ethical guidelines (Responsibility: Legal Counsel, Frequency: Before contract signing).

## Audit - Transparency Measures

- Publish a detailed budget breakdown on a dedicated project website, showing planned versus actual expenditures for each major category (e.g., security, accommodation, catering).
- Publish minutes of key project meetings, including decisions related to vendor selection, security protocols, and risk management, on the project website.
- Establish a clear and accessible process for stakeholders (e.g., local residents, media) to submit inquiries and receive timely responses.
- Disclose the identity of the private benefactor and the terms of their funding agreement, subject to confidentiality constraints.
- Implement a system for tracking and reporting all gifts, gratuities, or other benefits received by project personnel from vendors or stakeholders.