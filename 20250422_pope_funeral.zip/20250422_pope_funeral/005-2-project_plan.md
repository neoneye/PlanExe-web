**Goal Statement:** Plan and execute the funeral and burial of Pope Francis, ensuring security, crowd control, and dignified arrangements for attendees, including global leaders, by late April/early May 2025.

## SMART Criteria

- **Specific:** Coordinate all aspects of Pope Francis's funeral and burial, including security, crowd management, accommodations, and food safety, while maintaining dignity and order.
- **Measurable:** Success will be measured by the safe and orderly execution of the funeral and burial, positive feedback from attendees, and adherence to the budget of €20-40 million.
- **Achievable:** The goal is achievable given the Vatican's resources, the availability of external security and logistical support, and the commitment of a private benefactor to cover the costs.
- **Relevant:** This goal is necessary to honor Pope Francis, ensure a smooth transition of leadership within the Catholic Church, and maintain international relations.
- **Time-bound:** The funeral and burial arrangements must be completed by late April/early May 2025, following the passing of Pope Francis on April 21, 2025.

## Dependencies

- Confirmation of the exact date and time of death.
- Finalization of the list of confirmed attendees.
- Approval of security plans by Vatican security and Italian authorities.
- Securing necessary permits for crowd control and protest zones from the Rome authorities.
- Confirmation of funding from the private benefactor.

## Resources Required

- Security personnel (500)
- Crowd control personnel (200)
- VIP liaisons (50)
- Hotel accommodations for attendees
- Food tasters (3)
- CCTV cameras with facial recognition capabilities (50)
- Non-lethal crowd control devices (e.g., water cannons, tear gas)
- Climate-controlled, tamper-proof casket
- Portable testing kits for food tasters
- Two-way radios for crowd control personnel

## Related Goals

- Ensure a smooth transition of leadership within the Catholic Church.
- Maintain positive international relations.
- Uphold the dignity and traditions of the Catholic Church.

## Tags

- funeral
- Vatican
- security
- crowd control
- international relations
- Catholic Church

## Risk Assessment and Mitigation Strategies


### Key Risks

- Security breaches targeting high-profile attendees or the public.
- Overwhelming crowds leading to stampedes and injuries.
- Protests against attendees disrupting the event.
- Insufficient hotel capacity for attendees.
- Food poisoning affecting attendees.
- Event costs exceeding budget.
- Delays in obtaining permits from authorities.
- Cyber security risks

### Diverse Risks

- Operational risks
- Systematic risks
- Business risks

### Mitigation Plans

- Implement multi-layered security, background checks, secure perimeters, counter-surveillance, coordination with security details.
- Develop a crowd management plan, train personnel, use barriers, establish communication channels, manage traffic, implement a lottery system.
- Designate protest zones, negotiate with organizers, deploy security personnel, monitor activity, communicate regulations.
- Secure block bookings, establish a centralized booking system, provide transportation, communicate options, explore alternatives.
- Engage a food safety consultant, implement strict procedures, conduct background checks, use a food taster, ensure proper storage, have medical personnel on standby.
- Develop a detailed budget with contingency, secure multiple funding sources, control costs, negotiate favorable contracts, obtain insurance, monitor expenditures.
- Engage authorities early, communicate clearly, submit applications in advance, comply with regulations, seek legal counsel.
- Conduct a cyber security risk assessment and penetration testing, implement robust protocols, establish secure communication channels, coordinate with national cyber security agencies.

## Stakeholder Analysis


### Primary Stakeholders

- Vatican Security
- Italian Law Enforcement
- Event Coordinators
- VIP Liaisons
- Funeral Director

### Secondary Stakeholders

- International Governments
- Local Community
- Media Outlets
- Hotel Management
- Transportation Services
- Protest Organizers

### Engagement Strategies

- Provide regular updates and progress reports to primary stakeholders.
- Maintain open communication channels with secondary stakeholders to address concerns and provide information.
- Engage with protest organizers to negotiate terms and ensure peaceful demonstrations.
- Coordinate with international governments to ensure the safety and security of their representatives.
- Establish a community liaison office to address concerns from local residents and businesses.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Event Permit
- Security Clearance
- Crowd Control Permit
- Protest Zone Permit

### Compliance Standards

- Building and Electrical Codes
- Wildlife Protection
- Fire safety measures
- Biosafety Regulations
- Radiation Safety

### Regulatory Bodies

- Italian Police
- Vatican City State Authorities
- Rome City Council

### Compliance Actions

- Apply for event permit.
- Schedule security clearance checks.
- Implement crowd control plan.
- Establish protest zones.
- Implement compliance plan for fire safety.