### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start

### 3. Project Manager drafts initial Terms of Reference for the Security and Risk Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Security and Risk Advisory Group ToR v0.1

**Dependencies:**

- Project Start

### 4. Project Manager drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 5. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start

### 6. Circulate Draft SteerCo ToR for review by nominated members (Secretary of State, Prefect of the Papal Household, Commander of the Pontifical Swiss Guard, Representative of the Private Benefactor, Director of the Vatican Press Office, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by potential members (Project Manager, Security Lead, Logistics Coordinator, Communications Manager, Finance Officer, Risk Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Potential Members Identified

### 8. Circulate Draft Security and Risk Advisory Group ToR for review by potential members (Commander of the Pontifical Swiss Guard, Representative from Italian Law Enforcement, Cyber Security Expert, Risk Management Consultant, Security Lead (PMO), Representative from a global security firm).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Security and Risk Advisory Group ToR v0.1
- Potential Members Identified

### 9. Circulate Draft Ethics and Compliance Committee ToR for review by potential members (Legal Counsel, Internal Audit Director, Ethics Officer, Data Protection Officer, Representative from the Private Benefactor, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1
- Potential Members Identified

### 10. Circulate Draft Stakeholder Engagement Group ToR for review by potential members (Communications Manager (PMO), Representative from the Vatican Press Office, Community Liaison Officer, Media Relations Specialist, Representative from the Rome City Council, VIP Liaison Lead).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Potential Members Identified

### 11. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 12. Project Manager finalizes the Terms of Reference for the Project Management Office (PMO) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft PMO ToR v0.1

### 13. Project Manager finalizes the Terms of Reference for the Security and Risk Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Security and Risk Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Security and Risk Advisory Group ToR v0.1

### 14. Project Manager finalizes the Terms of Reference for the Ethics and Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics and Compliance Committee ToR v0.1

### 15. Project Manager finalizes the Terms of Reference for the Stakeholder Engagement Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Stakeholder Engagement Group ToR v0.1

### 16. Senior Sponsor (e.g., Pope's personal secretary or designated successor) formally appoints the Steering Committee Chair (Secretary of State).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Steering Committee formally established with confirmed membership and approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Steering Committee Membership List
- Approved SteerCo ToR v1.0

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 18. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Steering Committee Membership List
- Approved SteerCo ToR v1.0

### 19. Project Manager formally establishes the Project Management Office (PMO) with confirmed membership and approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Membership List
- Approved PMO ToR v1.0

**Dependencies:**

- Final PMO ToR v1.0

### 20. Hold initial PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Membership List
- Approved PMO ToR v1.0

### 21. Project Manager formally establishes the Security and Risk Advisory Group with confirmed membership and approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Security and Risk Advisory Group Membership List
- Approved Security and Risk Advisory Group ToR v1.0

**Dependencies:**

- Final Security and Risk Advisory Group ToR v1.0

### 22. Hold initial Security and Risk Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Security and Risk Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Security and Risk Advisory Group Membership List
- Approved Security and Risk Advisory Group ToR v1.0

### 23. Project Manager formally establishes the Ethics and Compliance Committee with confirmed membership and approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee Membership List
- Approved Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 24. Hold initial Ethics and Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics and Compliance Committee Membership List
- Approved Ethics and Compliance Committee ToR v1.0

### 25. Project Manager formally establishes the Stakeholder Engagement Group with confirmed membership and approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Membership List
- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 26. Hold initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Membership List
- Approved Stakeholder Engagement Group ToR v1.0