This plan involves money.

## Currencies

- **EUR:** The event budget is specified in Euros, and the Vatican City is within the Eurozone.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions within Vatican City and Italy will also be in EUR. No additional international risk management is needed.