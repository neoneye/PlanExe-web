### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the project, given its high profile, political sensitivity, and significant budget. Ensures alignment with Vatican objectives and manages strategic risks.

**Responsibilities:**

- Approve the overall project plan and budget.
- Provide strategic direction and guidance to the Project Management Office.
- Approve major project milestones and deliverables.
- Monitor project progress against strategic objectives.
- Approve budget changes exceeding €500,000.
- Oversee strategic risk management and mitigation.
- Resolve strategic issues and conflicts.
- Approve key stakeholder communication strategies.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Review project plan and budget.
- Define escalation paths.

**Membership:**

- Secretary of State (Vatican)
- Prefect of the Papal Household
- Commander of the Pontifical Swiss Guard
- Representative of the Private Benefactor (Independent)
- Director of the Vatican Press Office
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget (above €500,000), timeline, and key stakeholder management.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Secretary of State has the deciding vote.

**Meeting Cadence:** Monthly, or more frequently as needed during critical phases.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion and approval of major milestones.
- Review of strategic risks and mitigation plans.
- Budget review and approval of changes.
- Stakeholder communication updates.
- Escalated issues from the Project Management Office.

**Escalation Path:** Issues unresolved at the Steering Committee level are escalated to the Pope's personal secretary or designated successor.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient resource allocation, risk management, and adherence to the project plan. Provides operational support to the Project Steering Committee.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and resources.
- Coordinate project activities and tasks.
- Monitor project progress and performance.
- Identify and manage operational risks.
- Prepare reports for the Project Steering Committee.
- Manage communication with project stakeholders.
- Ensure compliance with project policies and procedures.
- Manage contracts with vendors and suppliers.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Recruit project team members.
- Develop project communication plan.
- Establish risk management framework.
- Set up project reporting system.

**Membership:**

- Project Manager
- Security Lead
- Logistics Coordinator
- Communications Manager
- Finance Officer
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within pre-approved budget and scope (below €500,000).

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Conflicts are resolved through discussion and consensus. If consensus cannot be reached, the Project Manager makes the final decision, documenting the rationale.

**Meeting Cadence:** Weekly, or more frequently as needed during critical phases.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Resource allocation and management.
- Review of project budget and expenses.
- Stakeholder communication updates.
- Preparation of reports for the Project Steering Committee.

**Escalation Path:** Issues exceeding the PMO's authority or requiring strategic guidance are escalated to the Project Steering Committee.
### 3. Security and Risk Advisory Group

**Rationale for Inclusion:** Provides specialized expertise and assurance on security and risk management aspects of the project, given the high-profile nature of the event and potential security threats. Ensures robust security protocols and risk mitigation strategies are in place.

**Responsibilities:**

- Review and approve the security plan.
- Advise on security protocols and procedures.
- Conduct risk assessments and identify potential threats.
- Develop risk mitigation strategies.
- Monitor security measures and compliance.
- Coordinate with Vatican Security and Italian Law Enforcement.
- Provide training to security personnel.
- Conduct penetration testing and vulnerability assessments.
- Oversee cyber security measures.

**Initial Setup Actions:**

- Define scope of security and risk advisory services.
- Recruit security experts and advisors.
- Establish communication protocols.
- Review existing security plans and risk assessments.
- Develop a cyber security risk assessment plan.

**Membership:**

- Commander of the Pontifical Swiss Guard
- Representative from Italian Law Enforcement
- Cyber Security Expert (Independent)
- Risk Management Consultant (Independent)
- Security Lead (PMO)
- Representative from a global security firm

**Decision Rights:** Advisory role on security and risk management strategies. Authority to recommend changes to security protocols and risk mitigation plans. Approval of security plans.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Commander of the Pontifical Swiss Guard has the deciding vote.

**Meeting Cadence:** Bi-weekly, or more frequently as needed during critical phases.

**Typical Agenda Items:**

- Review of security threats and vulnerabilities.
- Discussion of security protocols and procedures.
- Review of risk assessments and mitigation plans.
- Updates from Vatican Security and Italian Law Enforcement.
- Cyber security updates and incident reports.
- Penetration testing results and recommendations.

**Escalation Path:** Security and risk issues requiring strategic decisions or exceeding the group's authority are escalated to the Project Steering Committee.
### 4. Ethics and Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations, including GDPR, anti-corruption laws, and Vatican ethical standards. Mitigates risks related to bribery, fraud, and conflicts of interest.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with relevant regulations and ethical standards.
- Investigate allegations of fraud, corruption, or ethical misconduct.
- Provide training on ethics and compliance.
- Review contracts and procurement processes to ensure compliance.
- Manage the whistleblower hotline.
- Ensure data privacy and compliance with GDPR.
- Oversee transparency measures and disclosures.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a whistleblower hotline.
- Recruit ethics and compliance experts.
- Develop a training program on ethics and compliance.
- Review existing contracts and procurement processes.

**Membership:**

- Legal Counsel (Vatican)
- Internal Audit Director (Vatican)
- Ethics Officer (Independent)
- Data Protection Officer (Independent)
- Representative from the Private Benefactor (Independent)
- Project Manager

**Decision Rights:** Authority to investigate allegations of ethical misconduct and recommend corrective actions. Authority to approve ethics and compliance policies and procedures. Authority to halt project activities if ethical or compliance violations are suspected.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Quarterly, or more frequently as needed during critical phases or in response to specific incidents.

**Typical Agenda Items:**

- Review of compliance with relevant regulations and ethical standards.
- Investigation of allegations of fraud, corruption, or ethical misconduct.
- Review of contracts and procurement processes.
- Updates on data privacy and GDPR compliance.
- Review of whistleblower reports.
- Training on ethics and compliance.

**Escalation Path:** Ethical or compliance issues requiring strategic decisions or exceeding the committee's authority are escalated to the Project Steering Committee or directly to the Pope's personal secretary or designated successor.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and engagement with all relevant stakeholders, including local residents, media, and international governments. Mitigates risks related to negative publicity, protests, and community disruption.

**Responsibilities:**

- Develop and implement a stakeholder communication plan.
- Establish communication channels for addressing concerns.
- Implement proactive measures to mitigate disruptions.
- Establish a community liaison office.
- Offer compensation to affected businesses.
- Conduct public awareness campaigns.
- Manage media relations.
- Coordinate with international governments.
- Engage with protest organizers.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder communication plan.
- Establish communication channels.
- Recruit stakeholder engagement specialists.
- Establish a community liaison office.

**Membership:**

- Communications Manager (PMO)
- Representative from the Vatican Press Office
- Community Liaison Officer (Independent)
- Media Relations Specialist (Independent)
- Representative from the Rome City Council
- VIP Liaison Lead

**Decision Rights:** Authority to approve stakeholder communication plans and strategies. Authority to allocate resources for community engagement activities. Authority to negotiate with protest organizers.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Representative from the Vatican Press Office has the deciding vote.

**Meeting Cadence:** Monthly, or more frequently as needed during critical phases or in response to specific events.

**Typical Agenda Items:**

- Review of stakeholder communication plan.
- Updates on community engagement activities.
- Review of media coverage.
- Updates on coordination with international governments.
- Discussion of potential protests and mitigation strategies.
- Review of stakeholder feedback and concerns.

**Escalation Path:** Stakeholder engagement issues requiring strategic decisions or exceeding the group's authority are escalated to the Project Steering Committee.