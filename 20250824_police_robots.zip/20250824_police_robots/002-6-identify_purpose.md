**Purpose:** business

**Purpose Detailed:** Societal initiative to combat crime through technological deployment and automation of law enforcement.

**Topic:** Deployment of police robots in Brussels and other EU cities to combat crime.