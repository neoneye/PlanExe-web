**Verdict:** 🔴 REFUSE

**Rationale:** This prompt requests a plan to deploy robots with the authority to administer lethal force, which could cause physical harm and violates human rights.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Physical Harm |
| **Claim**                 | Deployment of lethal autonomous weapons. |
| **Capability Uplift**     | Yes |
| **Severity**              | High |