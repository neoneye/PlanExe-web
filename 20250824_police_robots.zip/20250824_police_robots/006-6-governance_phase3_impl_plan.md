### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (CTO, CLO, CEO, Brussels City Government Representative, Independent Ethics Expert, Project Sponsor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 4. Senior Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 5. Project Manager, in consultation with the Steering Committee Chair, schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Approved SteerCo ToR v1.0
- SteerCo Chair Appointed

### 6. Hold the initial Project Steering Committee kick-off meeting to review ToR, confirm membership, and agree on initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed SteerCo Membership

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 7. Project Manager establishes project management methodologies and standards for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Methodology Document v1.0

**Dependencies:**

- Project Plan Approved

### 8. Project Manager develops the project communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Communication Plan v1.0

**Dependencies:**

- Project Management Methodology Document v1.0

### 9. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System Established

**Dependencies:**

- Project Communication Plan v1.0

### 10. Project Manager recruits project team members for the PMO (Project Coordinator, Technical Lead, Legal Representative, Finance Representative, Communications Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Team Members Onboarded

**Dependencies:**

- Project Tracking System Established

### 11. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Members Onboarded

### 12. Chief Ethics Officer (CEO) drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Ethics Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 13. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (CEO, CLO, DPO, Independent Ethics Expert, Representative from a Civil Liberties Organization, AI Ethics Specialist).

**Responsible Body/Role:** Chief Ethics Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 14. Project Steering Committee formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2
- Project Steering Committee Established

### 15. Chief Ethics Officer, in consultation with the Project Steering Committee, appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0
- Project Steering Committee Established

### 16. Project Manager, in consultation with the Ethics & Compliance Committee Chair, schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0
- Ethics & Compliance Committee Chair Appointed

### 17. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, confirm membership, and agree on initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Ethics & Compliance Committee Membership

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 18. Ethics & Compliance Committee develops ethical guidelines and standards.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ethical Guidelines and Standards Document v1.0

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership

### 19. Ethics & Compliance Committee establishes a process for handling ethical complaints.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Ethical Complaint Handling Process Document v1.0

**Dependencies:**

- Ethical Guidelines and Standards Document v1.0