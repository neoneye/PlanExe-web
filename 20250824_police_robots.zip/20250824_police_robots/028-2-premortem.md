A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Pre-existing crime statistics accurately reflect crime rates across all demographic groups. | Compare crime statistics to victim surveys and community reports across different demographic groups. | Significant discrepancies (>= 15%) are found between crime statistics and victim surveys for specific demographic groups. |
| A2 | Unitree robots are technically capable of performing the required law enforcement tasks. | Conduct thorough performance testing of Unitree robots in realistic scenarios, including adverse weather conditions and complex urban environments. | Unitree robots fail to meet minimum performance standards (e.g., navigation accuracy, response time, obstacle avoidance) in >= 20% of test scenarios. |
| A3 | The EU regulatory framework will remain stable and predictable. | Engage proactively with EU regulatory bodies and legal experts to monitor potential changes in the regulatory landscape. | EU regulatory bodies indicate that new regulations are likely to be enacted within 6 months that would significantly restrict the project's scope or increase compliance costs by >= 20%. |
| A1 | Pre-existing crime statistics accurately reflect crime rates across all demographic groups. | Compare crime statistics with victim surveys and community reports to identify discrepancies. | Significant discrepancies (>= 15%) found between crime statistics and victim surveys for specific demographic groups. |
| A2 | Data anonymization techniques are effective in preventing re-identification of individuals. | Attempt to re-identify individuals in anonymized datasets using publicly available information and advanced data mining techniques. | Successful re-identification of individuals in anonymized datasets using realistic attack scenarios. |
| A3 | Unitree robots are technically capable of performing the required law enforcement tasks. | Conduct thorough performance testing of Unitree robots in realistic scenarios, including adverse weather conditions and complex urban environments. | Robot performance falls below acceptable thresholds (e.g., navigation accuracy < 90%, response time > 10 seconds) in realistic scenarios. |
| A4 | The public will accept a visible police presence of humanoid robots. | Deploy a small number of robots in a limited area and monitor public reaction through surveys, social media analysis, and direct observation. | Public opinion surveys show > 50% negative sentiment towards the robot presence after 1 month. |
| A5 | The robots can operate effectively within the existing Brussels infrastructure (e.g., roads, sidewalks, public transport). | Map the city's infrastructure and simulate robot navigation, identifying potential obstacles and limitations. | Simulation reveals that > 10% of the city's area is inaccessible to the robots due to infrastructure limitations. |
| A6 | The cost of electricity to power the robots will remain within acceptable budget limits. | Calculate the robots' energy consumption and project electricity costs based on current and projected prices. | Projected electricity costs exceed 15% of the total operating budget within the first year. |
| A7 | Brussels has sufficient physical infrastructure (street width, sidewalk capacity, charging stations) to support the deployment of 500 robots without significant disruption to traffic or pedestrian flow. | Conduct a detailed survey of Brussels streets, sidewalks, and public spaces to assess their suitability for robot deployment, including measuring street widths, sidewalk capacity, and the availability of charging locations. | The survey reveals that more than 20% of Brussels streets or sidewalks are too narrow for safe robot operation, or that there are insufficient charging locations within a 500-meter radius of key deployment areas. |
| A8 | The AI algorithms used by the robots will be able to accurately interpret and respond to the diverse languages and cultural nuances of the Brussels population. | Conduct a series of tests in diverse Brussels neighborhoods, where robots interact with residents speaking different languages and exhibiting various cultural behaviors, and assess the robots' ability to understand and respond appropriately. | The tests reveal that the robots misinterpret or respond inappropriately to more than 15% of interactions involving non-Dutch/French speakers or individuals exhibiting cultural behaviors not represented in the training data. |
| A9 | The Unitree robots can operate reliably in all weather conditions typical of Brussels, including rain, snow, and extreme temperatures. | Conduct field tests of the Unitree robots in Brussels during periods of heavy rain, snowfall, and extreme temperatures (both hot and cold), and assess their operational performance and reliability. | The field tests reveal that the robots experience significant performance degradation (e.g., reduced speed, sensor malfunction, battery drain) or complete failure in more than 10% of tests conducted in adverse weather conditions. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Bias Black Hole | Process/Financial | A1 | AI Ethics and Bias Mitigation Specialist | CRITICAL (20/25) |
| FM2 | The Robot Rebellion | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Regulatory Riot | Market/Human | A3 | Permitting Lead | CRITICAL (15/25) |
| FM4 | The Bias Black Hole | Process/Financial | A1 | Finance Director | CRITICAL (20/25) |
| FM5 | The Gridlock Gamble | Technical/Logistical | A3 | Head of Engineering | HIGH (12/25) |
| FM6 | The Power Drain Panic | Market/Human | A6 | Public Relations and Community Engagement Manager | HIGH (10/25) |
| FM7 | The Gridlock Gamble | Technical/Logistical | A7 | Head of Engineering | CRITICAL (16/25) |
| FM8 | The Babel Bot Breakdown | Market/Human | A8 | Public Relations and Community Engagement Manager | CRITICAL (15/25) |
| FM9 | The Weathered Warriors' Woes | Process/Financial | A9 | Finance Team | HIGH (12/25) |


### Failure Modes

#### FM1 - The Bias Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: AI Ethics and Bias Mitigation Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on pre-existing crime statistics, without adequate bias mitigation, led to a self-reinforcing cycle of discriminatory policing. The robots, trained on biased data, disproportionately targeted minority communities, leading to increased arrests and further skewing the crime statistics. This created a feedback loop, where the robots' actions validated their initial biases, resulting in a significant over-policing of certain areas and a neglect of others. The increased arrests in targeted communities led to higher court costs, strained social services, and ultimately, increased crime rates in those areas due to a lack of resources and opportunities. This also led to a significant drop in public trust, making it harder to gather information and solve crimes effectively.

##### Early Warning Signs
- Arrest rates for specific demographic groups are >= 20% higher than the city average.
- Public complaints related to discriminatory policing increase by >= 50% within the first 3 months.
- Internal audits reveal that bias detection rates are < 80% for certain demographic groups.

##### Tripwires
- Arrest rates for minority communities exceed city average by >= 30%
- Public trust scores in targeted communities drop below 50%
- Bias detection rate falls below 70% for any demographic group

##### Response Playbook
- Contain: Immediately halt AI-driven policing in areas with high bias indicators.
- Assess: Conduct a comprehensive ethical data audit to identify and correct biases in training data and algorithms.
- Respond: Retrain AI algorithms using diverse datasets and implement enhanced bias mitigation techniques.


**STOP RULE:** Bias cannot be effectively mitigated, and discriminatory policing persists after 6 months of retraining efforts.

---

#### FM2 - The Robot Rebellion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's over-reliance on Unitree robots, without sufficient testing in real-world conditions, led to a series of technical malfunctions that crippled the entire system. The robots, designed for controlled environments, proved unreliable in Brussels' unpredictable weather and crowded streets. Navigation systems failed due to GPS interference and sensor limitations, causing robots to wander off course, collide with pedestrians, and block traffic. Communication networks were disrupted by signal congestion and cyberattacks, leaving robots unresponsive to commands and vulnerable to manipulation. The lack of adequate maintenance and repair infrastructure further exacerbated the problem, as malfunctioning robots remained out of service for extended periods, leading to a significant reduction in law enforcement effectiveness. The situation culminated in a city-wide system failure during a major public event, resulting in chaos and widespread panic.

##### Early Warning Signs
- Robot operational downtime exceeds 10% per month.
- Maintenance requests increase by >= 40% within the first 2 months.
- Navigation errors and communication failures are reported in >= 15% of robot deployments.

##### Tripwires
- Robot operational downtime exceeds 15% per month
- Critical system failure occurs during a major public event
- Spare parts inventory falls below 50% of required levels

##### Response Playbook
- Contain: Immediately remove all robots from active duty and initiate a system-wide diagnostic check.
- Assess: Conduct a thorough technical review to identify the root causes of the malfunctions and vulnerabilities.
- Respond: Implement hardware and software upgrades, enhance security protocols, and establish a more robust maintenance and repair program.


**STOP RULE:** Technical malfunctions persist, and robot operational downtime remains above 20% after 3 months of corrective actions.

---

#### FM3 - The Regulatory Riot

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's failure to anticipate changes in the EU regulatory landscape led to a legal and political firestorm that ultimately shut down the entire initiative. New regulations on AI and data privacy, enacted in response to growing public concerns, imposed strict limitations on the robots' capabilities and data collection practices. The project, designed under the assumption of a stable regulatory environment, was unable to adapt to these changes, rendering its core functionalities illegal and its data processing practices non-compliant. This triggered a wave of legal challenges from human rights organizations and privacy advocates, resulting in court orders that halted robot deployments and imposed hefty fines. The political backlash was equally severe, as public officials distanced themselves from the project and funding was withdrawn. The project, once hailed as a technological triumph, became a symbol of regulatory overreach and ethical negligence.

##### Early Warning Signs
- EU regulatory bodies announce plans to introduce stricter regulations on AI and data privacy.
- Legal challenges related to human rights and data privacy increase by >= 30% within the first 6 months.
- Public officials express concerns about the project's compliance with ethical and legal standards.

##### Tripwires
- New EU regulations are enacted that significantly restrict the project's scope
- Legal challenges result in court orders halting robot deployments
- Public officials withdraw their support for the project

##### Response Playbook
- Contain: Immediately suspend all data collection activities and limit robot functionalities to comply with new regulations.
- Assess: Conduct a comprehensive legal review to assess the project's compliance with the revised regulatory framework.
- Respond: Revise the project plan to align with new regulations, potentially requiring significant modifications to robot capabilities and data processing practices.


**STOP RULE:** The project cannot be revised to comply with new EU regulations without fundamentally altering its core objectives and reducing its effectiveness by >= 50%.

---

#### FM4 - The Bias Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Finance Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied heavily on pre-existing crime statistics to train the robots' AI. These statistics, however, reflected historical biases in policing, leading the robots to disproportionately target specific demographic groups. This resulted in a surge of complaints, lawsuits, and negative media coverage. The city faced mounting legal fees and settlements, quickly depleting the project's budget. Public trust plummeted, leading to widespread protests and calls for the project's cancellation. The cost of addressing the bias issues, including retraining the AI and compensating victims, far exceeded the initial budget, rendering the project financially unsustainable.

##### Early Warning Signs
- Bias detection rates in initial AI training < 80%
- Disproportionate arrest rates (>= 20% difference) for specific demographic groups in pilot areas
- Negative sentiment on social media regarding robot bias increases by >= 40% within the first month of deployment

##### Tripwires
- Legal fees exceed EUR 500,000 within the first 6 months
- Public approval rating for the project falls below 30%
- Settlements related to biased policing exceed EUR 1,000,000

##### Response Playbook
- Contain: Immediately halt deployment in areas with high bias indicators.
- Assess: Conduct a comprehensive audit of the AI training data and algorithms.
- Respond: Develop and implement a revised ethical programming strategy with independent oversight.


**STOP RULE:** Legal settlements related to biased policing exceed EUR 5,000,000, or public approval falls below 20%.

---

#### FM5 - The Gridlock Gamble

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumed the Unitree robots were technically capable of navigating Brussels' complex urban environment. However, the robots struggled with narrow streets, uneven sidewalks, and unexpected obstacles like construction zones and parked vehicles. This led to frequent breakdowns, traffic congestion, and delays in responding to emergencies. The maintenance team was overwhelmed, and spare parts were difficult to obtain, further exacerbating the problem. The robots' limited battery life and charging infrastructure also proved inadequate, leaving many robots stranded and unable to perform their duties. The project became a logistical nightmare, with robots constantly malfunctioning and disrupting the flow of city life.

##### Early Warning Signs
- Robot operational downtime exceeds 10% within the first month
- Maintenance requests exceed capacity by >= 25%
- Average robot response time to incidents > 15 minutes

##### Tripwires
- Robot navigation failure rate exceeds 20%
- Spare parts inventory falls below 50% of required levels
- Average robot battery life < 4 hours

##### Response Playbook
- Contain: Reduce robot deployment density in congested areas.
- Assess: Conduct a thorough assessment of robot performance in various urban environments.
- Respond: Modify robot navigation algorithms, improve maintenance procedures, and expand charging infrastructure.


**STOP RULE:** Robot operational downtime exceeds 25% for two consecutive months, or navigation failure rate exceeds 30%.

---

#### FM6 - The Power Drain Panic

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Public Relations and Community Engagement Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project failed to anticipate the public's reaction to the robots' energy consumption. As electricity prices soared due to geopolitical instability and increased demand, citizens accused the project of wasting resources and contributing to climate change. Activist groups launched campaigns against the robots, highlighting their carbon footprint and questioning the project's sustainability. Public trust plummeted, and the city council faced mounting pressure to shut down the project. The robots became symbols of environmental irresponsibility, undermining the project's legitimacy and leading to widespread public opposition.

##### Early Warning Signs
- Electricity prices increase by >= 20% within the first quarter
- Negative media coverage focusing on robot energy consumption increases by >= 50%
- Public protests against robot energy use occur in >= 3 locations

##### Tripwires
- Electricity costs exceed 10% of the total operating budget
- Public opinion polls show > 60% disapproval of robot energy consumption
- Activist groups file legal challenges against the project's environmental impact

##### Response Playbook
- Contain: Implement energy-saving measures, such as reducing robot patrol hours.
- Assess: Conduct a comprehensive environmental impact assessment.
- Respond: Transition to renewable energy sources, launch a public awareness campaign highlighting the project's environmental benefits, and engage with activist groups to address their concerns.


**STOP RULE:** Electricity costs exceed 20% of the total operating budget, or public opinion polls show > 70% disapproval of robot energy consumption.

---

#### FM7 - The Gridlock Gamble

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Brussels' narrow streets and limited charging infrastructure prove inadequate for 500 robots.
Robots obstruct traffic and pedestrian flow, leading to public frustration and complaints.
Inadequate charging stations result in frequent robot downtime and reduced patrol coverage.
Emergency services are hindered by robot congestion, increasing response times.
Project faces logistical nightmares and escalating operational costs.

##### Early Warning Signs
- Robot deployment causes a >= 15% increase in traffic congestion in key areas.
- Robot operational downtime due to battery depletion exceeds 20%.
- Emergency service response times increase by >= 10% in robot patrol zones.

##### Tripwires
- Average street congestion increases by >= 20% after robot deployment.
- Robot battery life averages < 6 hours per charge.
- Number of public complaints about robot obstruction exceeds 50 per week.

##### Response Playbook
- Contain: Immediately reduce the number of deployed robots by 50% to alleviate congestion.
- Assess: Conduct a comprehensive review of robot deployment routes and charging infrastructure.
- Respond: Redesign deployment routes to avoid congested areas and invest in additional charging stations.


**STOP RULE:** Street congestion remains >= 10% higher than pre-deployment levels after 3 months of mitigation efforts.

---

#### FM8 - The Babel Bot Breakdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Public Relations and Community Engagement Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Robots struggle to understand Brussels' linguistic diversity.
Misunderstandings lead to incorrect interventions and public distrust.
Minority language speakers feel targeted and discriminated against.
Public perception plummets, fueling protests and vandalism.
Project loses social license and faces widespread opposition.

##### Early Warning Signs
- Public trust scores among minority language speakers drop below 50%.
- Number of complaints related to robot misinterpretations increases by >= 25%.
- Social media sentiment analysis reveals a >= 20% increase in negative comments about robot bias.

##### Tripwires
- Public trust score among minority language speakers <= 40%.
- Number of complaints related to robot misinterpretations >= 100 per week.
- Negative social media sentiment towards robots >= 60%.

##### Response Playbook
- Contain: Immediately suspend robot patrols in linguistically diverse neighborhoods.
- Assess: Conduct a thorough review of AI training data and language processing capabilities.
- Respond: Retrain AI algorithms with more diverse linguistic data and implement human oversight for complex interactions.


**STOP RULE:** Public trust among minority language speakers remains < 50% after 6 months of mitigation efforts.

---

#### FM9 - The Weathered Warriors' Woes

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Finance Team
- **Risk Level:** HIGH 12/25 (Likelihood 4/5 × Impact 3/5)

##### Failure Story
Brussels' unpredictable weather cripples robot operations.
Rain, snow, and extreme temperatures cause frequent malfunctions and downtime.
Maintenance costs skyrocket due to weather-related repairs.
Reduced robot availability undermines crime reduction efforts.
Project faces budget overruns and fails to meet performance targets.

##### Early Warning Signs
- Robot maintenance costs increase by >= 30% due to weather-related repairs.
- Robot operational downtime during adverse weather exceeds 30%.
- Crime rates in robot patrol zones increase by >= 10% during periods of adverse weather.

##### Tripwires
- Average monthly robot maintenance costs >= EUR 2000 per robot.
- Robot operational downtime during adverse weather >= 40%.
- Crime rates in robot patrol zones increase >= 15% during adverse weather.

##### Response Playbook
- Contain: Immediately withdraw robots from service during periods of heavy rain, snow, or extreme temperatures.
- Assess: Conduct a thorough review of robot weatherproofing and maintenance protocols.
- Respond: Invest in robot upgrades to improve weather resistance and develop a weather-dependent deployment schedule.


**STOP RULE:** Robot maintenance costs remain >= EUR 1500 per robot per month after 6 months of mitigation efforts.
