**Budget Request Exceeding PMO Authority (EUR 250,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and vote based on strategic alignment and budget availability. Project Sponsor has deciding vote in case of tie.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight due to potential impact on overall project budget and scope.
Negative Consequences: Potential budget overruns, project delays, or scope reduction if not approved.

**Critical Risk Materialization (e.g., Legal Challenge Halting Deployment)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the risk, review mitigation options, and decide on a course of action. May involve external legal counsel.
Rationale: Materialization of a critical risk threatens project viability and requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project halt, significant financial losses, reputational damage, and potential legal penalties if not addressed promptly.

**PMO Deadlock on Ethical Programming Strategy**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee reviews the differing viewpoints, consults with relevant experts, and makes a recommendation based on ethical principles and compliance requirements. Dissenting opinions are documented and escalated to the Project Steering Committee.
Rationale: Disagreement on ethical programming impacts fairness, public trust, and legal compliance, necessitating independent ethical review.
Negative Consequences: Algorithmic bias, discriminatory policing, erosion of public trust, and potential legal challenges if not resolved ethically.

**Proposed Major Scope Change (e.g., Altering Terminal Judgement Protocol)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed change, assesses its impact on project objectives, budget, timeline, and risks, and makes a decision based on strategic alignment and feasibility. Requires unanimous approval if ethical concerns are raised.
Rationale: Significant scope changes impact project objectives, resource allocation, and strategic alignment, requiring high-level oversight and approval.
Negative Consequences: Project failure, budget overruns, delays, and misalignment with strategic goals if not properly managed.

**Reported Ethical Concern Regarding Robot Behavior**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigates the complaint, reviews relevant data and protocols, and makes a recommendation for corrective action. May involve halting robot operations pending investigation.
Rationale: Ethical violations undermine public trust, legal compliance, and the project's legitimacy, requiring independent investigation and remediation.
Negative Consequences: Reputational damage, legal penalties, public outcry, and erosion of trust in law enforcement if not addressed promptly and effectively.