This plan involves money.

## Currencies

- **EUR:** Primary currency for Brussels and the EU.
- **CNY:** Relevant for purchasing robots from China (Unitree).

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. CNY will be needed for purchasing robots from China. Exchange rate fluctuations should be monitored, and hedging strategies may be considered.