
## Audit - Corruption Risks

- Bribery of city officials to expedite permits and approvals for robot deployment.
- Kickbacks from Unitree Robotics in exchange for exclusive procurement contracts, potentially overlooking better or more ethical alternatives.
- Conflicts of interest involving project team members with financial ties to Unitree Robotics or other suppliers.
- Misuse of confidential project information for personal gain, such as insider trading based on deployment locations or technology specifications.
- Trading favors with regulatory bodies to bypass stringent ethical or safety reviews of the robots' programming and deployment protocols.

## Audit - Misallocation Risks

- Misuse of project budget for personal expenses or unauthorized activities by project managers or team members.
- Double spending on robot maintenance contracts by awarding multiple contracts for the same services.
- Inefficient allocation of resources to public relations campaigns while neglecting critical technical development or ethical programming.
- Unauthorized use of robots for purposes outside of law enforcement, such as private security or demonstrations without proper authorization.
- Poor record-keeping and documentation of project expenses, making it difficult to track spending and identify potential misuse.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, focusing on procurement processes, contract management, and expense reports. Responsibility: Internal Audit Team.
- Perform annual external audits of the project's compliance with GDPR and other relevant regulations. Responsibility: Independent Audit Firm.
- Establish a contract review threshold of EUR 50,000, requiring independent legal review for all contracts exceeding this amount. Responsibility: Legal Department.
- Implement a multi-level expense approval workflow, requiring approval from multiple managers for expenses exceeding EUR 1,000. Responsibility: Finance Department.
- Conduct periodic compliance checks of the robots' programming and judgement protocols to ensure adherence to ethical guidelines and legal requirements. Responsibility: Ethics Review Board.

## Audit - Transparency Measures

- Create a public-facing dashboard displaying project progress, budget expenditures, and key performance indicators (KPIs) related to crime reduction and public safety.
- Publish minutes of oversight committee meetings, including discussions on ethical considerations, risk assessments, and regulatory compliance.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations within the project. Anonymity should be guaranteed.
- Make publicly available the documented selection criteria for major decisions, such as vendor selection and technology choices.
- Publish regular reports on the robots' performance, including data on arrests, sentencing, and any incidents of malfunction or bias.