### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this high-risk, high-impact project. Given the ethical and societal implications of deploying autonomous police robots with the power of 'Terminal Judgement', a strong strategic oversight body is crucial to ensure alignment with organizational values and manage strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (above EUR 250,000).
- Oversee risk management and mitigation strategies.
- Ensure alignment with organizational strategy and values.
- Approve Phase 2 (EU) rollout based on Phase 1 performance and ethical considerations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office (PMO).

**Membership:**

- Chief Technology Officer (CTO)
- Chief Legal Officer (CLO)
- Chief Ethics Officer (CEO)
- Representative from Brussels City Government
- Independent Ethics Expert (External)
- Project Sponsor (Senior Executive)

**Decision Rights:** Strategic decisions related to project scope, budget (above EUR 250,000), timeline, and strategic risks. Approval of Phase 2 rollout.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Project Sponsor has the deciding vote. Ethical concerns raised by the Chief Ethics Officer or Independent Ethics Expert require unanimous approval to proceed.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of key risks and mitigation strategies.
- Discussion of strategic issues and challenges.
- Approval of major changes to project scope, budget, or timeline.
- Review of ethical considerations and compliance with regulations.
- Feedback from the Ethics & Compliance Committee.

**Escalation Path:** CEO or Board of Directors for issues exceeding the Steering Committee's authority or unresolved ethical concerns.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project. Given the project's complexity and the need for efficient resource allocation and risk management, a dedicated PMO is essential for ensuring smooth operations and adherence to project plans.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track project progress.
- Identify and manage project risks and issues.
- Coordinate project activities across different teams.
- Report project status to the Project Steering Committee.
- Manage contracts and procurement processes (below EUR 250,000).
- Ensure adherence to project management methodologies and standards.

**Initial Setup Actions:**

- Establish project management methodologies and standards.
- Develop project communication plan.
- Set up project tracking and reporting systems.
- Recruit project team members.

**Membership:**

- Project Manager
- Project Coordinator
- Technical Lead
- Legal Representative
- Finance Representative
- Communications Representative

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management (below EUR 250,000).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the relevant team members. Unresolved conflicts are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of project budget and expenses.
- Coordination of project activities.
- Preparation of reports for the Project Steering Committee.

**Escalation Path:** Project Steering Committee for issues exceeding the PMO's authority or unresolved conflicts.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides specialized input and assurance on ethical and compliance aspects of the project. Given the significant ethical and legal risks associated with deploying autonomous police robots with the power of 'Terminal Judgement', a dedicated ethics and compliance committee is crucial for ensuring responsible and ethical implementation.

**Responsibilities:**

- Review and approve ethical programming and judgement protocols.
- Monitor compliance with GDPR and other relevant regulations.
- Conduct ethical impact assessments.
- Provide guidance on ethical issues and dilemmas.
- Investigate ethical complaints and concerns.
- Ensure adherence to ethical AI standards.
- Oversee data privacy and security measures.
- Review and approve data collection and usage policies.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines and standards.
- Establish a process for handling ethical complaints.

**Membership:**

- Chief Ethics Officer (CEO)
- Chief Legal Officer (CLO)
- Data Protection Officer (DPO)
- Independent Ethics Expert (External)
- Representative from a Civil Liberties Organization (External)
- AI Ethics Specialist

**Decision Rights:** Decisions related to ethical programming, judgement protocols, data privacy, and compliance with regulations. Authority to halt project activities if ethical or compliance concerns are not adequately addressed.

**Decision Mechanism:** Decisions made by majority vote. Ethical concerns raised by the Chief Ethics Officer, Independent Ethics Expert, or Civil Liberties Representative require unanimous approval to proceed. Dissenting opinions are documented and escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of ethical programming and judgement protocols.
- Review of data privacy and security measures.
- Discussion of ethical issues and dilemmas.
- Review of compliance with GDPR and other regulations.
- Investigation of ethical complaints and concerns.
- Updates on relevant legal and ethical developments.

**Escalation Path:** Project Steering Committee or CEO for unresolved ethical concerns or compliance violations.