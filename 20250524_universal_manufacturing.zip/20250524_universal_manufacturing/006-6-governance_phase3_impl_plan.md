### 1. Project Sponsor (e.g., CEO or Board) designates an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Project Approved
- Project Sponsor Identified

### 2. Interim Chair of the Project Steering Committee drafts initial Terms of Reference (ToR) for the Project Steering Committee, based on the defined responsibilities.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Appointment of Interim Chair

### 3. Circulate Draft SteerCo ToR v0.1 for review by nominated members (Chief Technology Officer, Chief Financial Officer, Head of Research and Development, Independent External Advisor, Project Director).

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Collate and incorporate feedback on the Draft SteerCo ToR to produce v0.2.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback Received

### 5. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 6. Project Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 7. Project Sponsor formally confirms the Project Steering Committee membership (Chief Technology Officer, Chief Financial Officer, Head of Research and Development, Independent External Advisor, Project Director).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment of SteerCo Chair

### 8. Project Steering Committee Chair schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Membership Confirmed
- Appointment of SteerCo Chair

### 9. PMO Director drafts initial PMO structure, staffing plan, project management methodologies, reporting requirements, and communication protocols based on defined responsibilities.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PMO Structure and Plan v0.1

**Dependencies:**

- Project Approved

### 10. Circulate Draft PMO Structure and Plan v0.1 for review by Project Managers (for each location/workstream), Project Controller, Risk Manager, and IT Lead.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft PMO Structure and Plan v0.1 circulated for review

**Dependencies:**

- Draft PMO Structure and Plan v0.1
- Project Managers, Project Controller, Risk Manager, and IT Lead Identified

### 11. Collate and incorporate feedback on the Draft PMO Structure and Plan to produce v0.2.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft PMO Structure and Plan v0.2
- Feedback Summary

**Dependencies:**

- Draft PMO Structure and Plan v0.1 circulated for review
- Feedback Received

### 12. Project Steering Committee approves the PMO Structure and Plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Approved PMO Structure and Plan v1.0

**Dependencies:**

- Draft PMO Structure and Plan v0.2
- SteerCo Kick-off Meeting held

### 13. PMO Director establishes PMO structure and staffing, develops project management methodologies and tools, defines reporting requirements and communication protocols, and sets up project tracking systems.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- PMO Established
- Project Management Methodologies and Tools Defined
- Reporting Requirements and Communication Protocols Defined
- Project Tracking Systems Set Up

**Dependencies:**

- Approved PMO Structure and Plan v1.0

### 14. PMO Director schedules and facilitates the initial PMO kick-off meeting.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- PMO Established

### 15. Chief Engineer identifies and recruits technical experts for the Technical Advisory Group (Material Science Expert, Manufacturing Process Expert, System Integration Expert, External Technical Consultant).

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of TAG Nominees

**Dependencies:**

- Project Approved

### 16. Chief Engineer defines the scope of the Technical Advisory Group, establishes meeting schedule and communication protocols, and develops technical review processes.

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.1

**Dependencies:**

- List of TAG Nominees

### 17. Circulate Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.1 for review by nominated members (Material Science Expert, Manufacturing Process Expert, System Integration Expert, External Technical Consultant).

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.1 circulated for review

**Dependencies:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.1
- Nominated Members List Available

### 18. Collate and incorporate feedback on the Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes to produce v0.2.

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.2
- Feedback Summary

**Dependencies:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.1 circulated for review
- Feedback Received

### 19. Project Steering Committee approves the TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v1.0

**Dependencies:**

- Draft TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v0.2
- SteerCo Kick-off Meeting held

### 20. Chief Engineer formally confirms the Technical Advisory Group membership (Material Science Expert, Manufacturing Process Expert, System Integration Expert, External Technical Consultant).

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved TAG Scope, Meeting Schedule, Communication Protocols, and Technical Review Processes v1.0

### 21. Chief Engineer schedules and facilitates the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- TAG Membership Confirmed

### 22. Legal Counsel and Compliance Officer develop a code of ethics and compliance policies for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Code of Ethics and Compliance Policies v0.1

**Dependencies:**

- Project Approved

### 23. Legal Counsel and Compliance Officer establish reporting mechanisms for ethical concerns and compliance violations, and appoint a Data Protection Officer (DPO).

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Reporting Mechanisms for Ethical Concerns and Compliance Violations v0.1
- DPO Appointed

**Dependencies:**

- Draft Code of Ethics and Compliance Policies v0.1

### 24. Legal Counsel and Compliance Officer define investigation procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Investigation Procedures v0.1

**Dependencies:**

- Draft Reporting Mechanisms for Ethical Concerns and Compliance Violations v0.1

### 25. Circulate Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.1 for review by nominated members (Data Protection Officer, Human Resources Director, Independent Ethics Advisor).

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.1 circulated for review

**Dependencies:**

- Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.1
- Nominated Members List Available

### 26. Collate and incorporate feedback on the Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures to produce v0.2.

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.2
- Feedback Summary

**Dependencies:**

- Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.1 circulated for review
- Feedback Received

### 27. Project Steering Committee approves the Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v1.0

**Dependencies:**

- Draft Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v0.2
- SteerCo Kick-off Meeting held

### 28. Legal Counsel and Compliance Officer formally confirm the Ethics & Compliance Committee membership (Data Protection Officer, Human Resources Director, Independent Ethics Advisor).

**Responsible Body/Role:** Legal Counsel, Compliance Officer

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved Code of Ethics and Compliance Policies, Reporting Mechanisms, and Investigation Procedures v1.0

### 29. Legal Counsel schedules and facilitates the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Membership Confirmed

### 30. Communications Director identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Project Approved

### 31. Communications Director develops a stakeholder engagement plan, establishes communication channels, and defines roles and responsibilities for stakeholder engagement.

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.1

**Dependencies:**

- List of Key Stakeholders

### 32. Circulate Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.1 for review by nominated members (Community Relations Manager, Investor Relations Manager, Government Relations Manager, Project Manager Representative).

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.1 circulated for review

**Dependencies:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.1
- Nominated Members List Available

### 33. Collate and incorporate feedback on the Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities to produce v0.2.

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.2
- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.1 circulated for review
- Feedback Received

### 34. Project Steering Committee approves the Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v1.0

**Dependencies:**

- Draft Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v0.2
- SteerCo Kick-off Meeting held

### 35. Communications Director formally confirms the Stakeholder Engagement Group membership (Community Relations Manager, Investor Relations Manager, Government Relations Manager, Project Manager Representative).

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved Stakeholder Engagement Plan, Communication Channels, and Roles & Responsibilities v1.0

### 36. Communications Director schedules and facilitates the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Communications Director

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Membership Confirmed