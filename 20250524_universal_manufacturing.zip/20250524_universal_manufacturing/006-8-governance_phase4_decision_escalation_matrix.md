**Budget Request Exceeding PMO Authority (EUR 10 million)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for uncontrolled budget overruns and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., major cyberattack)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Significant project delays, financial losses, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Vote
Rationale: Requires higher-level arbitration to ensure project progress and alignment with strategic goals.
Negative Consequences: Delays in procurement, potential for suboptimal vendor selection, and internal conflicts.

**Proposed Major Scope Change (impacting project goals)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval based on Impact Assessment
Rationale: Requires strategic review and approval due to potential impact on project objectives, budget, and timeline.
Negative Consequences: Project scope creep, budget overruns, and failure to meet original objectives.

**Reported Ethical Concern (e.g., conflict of interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical infeasibility identified by the Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of alternative technical approaches and potential scope adjustments.
Rationale: Requires strategic decision-making regarding project scope, budget, and timeline in light of technical limitations.
Negative Consequences: Project delays, increased costs, and potential failure to achieve technical objectives.