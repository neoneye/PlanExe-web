
## Audit - Corruption Risks

- Bribery of regulatory officials to expedite permits for factory locations in Switzerland, Netherlands, and Germany.
- Kickbacks from suppliers of basic industrial feedstock in exchange for favorable contract terms.
- Conflicts of interest involving project personnel with undisclosed financial ties to companies providing manufacturing equipment.
- Nepotism in hiring practices, leading to unqualified personnel in key roles.
- Misuse of confidential project information for personal gain, such as insider trading related to technology advancements.

## Audit - Misallocation Risks

- Inflated invoices from contractors involved in infrastructure development near CERN, ASML, and Zeiss.
- Double spending on R&D activities due to poor coordination between research teams.
- Inefficient allocation of resources to non-critical activities, such as excessive spending on travel and entertainment.
- Unauthorized use of project assets, such as manufacturing equipment, for personal projects.
- Misreporting of project progress to justify continued funding, despite significant delays or technical challenges.

## Audit - Procedures

- Quarterly internal audits of financial records, focusing on R&D expenditures and infrastructure costs, conducted by an independent internal audit team.
- Annual external audits of compliance with EU environmental and safety regulations, performed by a certified auditing firm.
- Regular review of contracts with suppliers and contractors, with a threshold of EUR 1 million, to identify potential conflicts of interest and ensure fair pricing.
- Expense report audits, with a focus on travel and entertainment expenses, to verify compliance with company policies and prevent misuse of funds.
- Periodic compliance checks on data management practices to ensure adherence to GDPR and prevent data breaches, conducted by a data privacy officer.

## Audit - Transparency Measures

- Publicly accessible project progress dashboard, updated monthly, displaying key milestones, budget expenditures, and risk assessments.
- Publication of minutes from ethics committee meetings, addressing compliance with ethical guidelines and conflict of interest disclosures.
- Implementation of a whistleblower mechanism, allowing employees and stakeholders to report suspected fraud or misconduct anonymously.
- Public access to environmental impact assessment reports, demonstrating commitment to sustainability and environmental responsibility.
- Documented selection criteria for major decisions, such as vendor selection and technology choices, ensuring fairness and objectivity.