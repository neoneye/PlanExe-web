This plan involves money.

## Currencies

- **EUR:** The project budget is specified in EUR, and the project is located in Europe.
- **CHF:** Switzerland (Geneva/CERN) is a potential location.
- **EUR:** The Netherlands (Veldhoven/ASML) is a potential location and uses EUR.
- **EUR:** Germany (Jena/Zeiss) is a potential location and uses EUR.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local currencies (CHF) may be used for local transactions in Switzerland. No additional international risk management is needed within the Eurozone.