This plan involves money.

## Currencies

- **USD:** The project is based in the USA, specifically Newark, California, and will involve significant manufacturing and operational costs.

**Primary currency:** USD

**Currency strategy:** The project will use USD for all transactions. No additional international risk management is needed.