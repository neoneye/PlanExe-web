### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by CEO, CTO, CFO, Manufacturing Manager, Regulatory Affairs Manager, and the designated Independent External Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback
- Draft SteerCo ToR v0.1

### 4. CEO formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. CEO confirms membership of the Project Steering Committee (CEO, CTO, CFO, Manufacturing Manager, Regulatory Affairs Manager, Independent External Advisor).

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Email
- Appointment Confirmation Email

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, budget, and governance structure.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 8. Project Manager establishes the Project Management Office (PMO) and defines project management methodology and standards.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Methodology Document
- Project Templates and Tools

**Dependencies:**

- Project Plan Approved

### 9. Project Manager recruits and trains project managers and the Project Coordinator for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Staff Onboarded

**Dependencies:**

- Project Management Methodology Document

### 10. Project Manager defines project reporting requirements for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- PMO Staff Onboarded

### 11. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Project Reporting Requirements Document

### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 13. Chief Technology Officer (CTO) defines the scope of technical expertise required for the Technical Advisory Group.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Expertise Scope Document

**Dependencies:**

- Project Plan Approved

### 14. Chief Technology Officer (CTO) recruits and onboards Senior Scientists, Senior Engineers, and External Technical Consultants for the Technical Advisory Group.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Technical Advisory Group Members Onboarded

**Dependencies:**

- Technical Expertise Scope Document

### 15. Chief Technology Officer (CTO) establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Protocols

**Dependencies:**

- Technical Advisory Group Members Onboarded

### 16. Chief Technology Officer (CTO) schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Technical Advisory Group Communication Protocols

### 17. Hold the initial Technical Advisory Group kick-off meeting to review initial technical designs.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 18. Regulatory Affairs Manager and Legal Counsel develop a code of ethics for the Ethics & Compliance Committee.

**Responsible Body/Role:** Regulatory Affairs Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Code of Ethics

**Dependencies:**

- Project Plan Approved

### 19. Regulatory Affairs Manager and Legal Counsel establish compliance policies and procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Compliance Policies and Procedures

**Dependencies:**

- Draft Code of Ethics

### 20. Regulatory Affairs Manager recruits and trains compliance officers for the Ethics & Compliance Committee.

**Responsible Body/Role:** Regulatory Affairs Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Compliance Officers Onboarded

**Dependencies:**

- Draft Compliance Policies and Procedures

### 21. Regulatory Affairs Manager and Legal Counsel establish a confidential reporting mechanism for ethical concerns for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confidential Reporting Mechanism Established

**Dependencies:**

- Compliance Officers Onboarded

### 22. CEO confirms membership of the Ethics & Compliance Committee (Regulatory Affairs Manager, Legal Counsel, Data Security Officer, Quality Assurance Manager, Independent Ethics Advisor).

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Confidential Reporting Mechanism Established

### 23. Regulatory Affairs Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Regulatory Affairs Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Email

### 24. Hold the initial Ethics & Compliance Committee kick-off meeting to review compliance reports and ethical concerns.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda