**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, impacting project profitability and financial stability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Action Plan Approval
Rationale: The PMO cannot handle the risk with existing resources or mitigation plans, requiring strategic intervention and resource allocation.
Negative Consequences: Project delays, increased costs, or project failure due to unmitigated risks.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision
Rationale: The PMO cannot reach a consensus on a key operational decision, requiring higher-level arbitration to avoid project delays.
Negative Consequences: Project delays, suboptimal vendor selection, and potential cost overruns.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: A significant change to the project scope requires strategic alignment and approval due to its potential impact on budget, timeline, and resources.
Negative Consequences: Scope creep, budget overruns, project delays, and misalignment with business objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Design Impairing Device Functionality**
Escalation Level: Chief Technology Officer
Approval Process: CTO Review and Decision
Rationale: Technical Advisory Group cannot resolve a design issue impacting device performance, requiring CTO's expertise.
Negative Consequences: Compromised device functionality, project delays, and potential product failure.