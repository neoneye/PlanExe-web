This plan involves money.

## Currencies

- **EUR:** The project is EU-wide and the budget is specified in EUR.
- **RON:** Romania is a potential location for data centers and research facilities.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local currencies may be used for local transactions. No additional international risk management is needed.