
## Audit - Corruption Risks

- Bribery of EU officials to secure favorable regulations or funding for the project.
- Kickbacks from surveillance tech vendors in exchange for awarding contracts.
- Conflicts of interest involving project team members with financial ties to companies providing services or technology.
- Misuse of privileged information about citizen scores for personal gain or to benefit associates.
- Nepotism in hiring, favoring unqualified candidates who are connected to project leaders, potentially compromising project integrity.

## Audit - Misallocation Risks

- Inflated contracts with surveillance technology providers, diverting funds for personal enrichment.
- Double-billing for services rendered by contractors or consultants.
- Inefficient allocation of resources to experimentation facilities, prioritizing controversial research over essential data security measures.
- Unauthorized use of project assets (e.g., data processing centers) for personal or external commercial activities.
- Misreporting project progress to secure continued funding, despite significant delays or failures.

## Audit - Procedures

- Periodic internal audits of financial transactions, focusing on contracts with surveillance technology vendors and experimentation facilities (quarterly).
- Post-project external audit to assess the overall effectiveness and efficiency of the project, including compliance with ethical guidelines (post-project).
- Regular review of contracts with surveillance tech vendors, with a threshold of €1M for mandatory independent review (monthly).
- Expense workflow audits to ensure compliance with budget allocations and prevent misuse of funds (monthly).
- Compliance checks to ensure adherence to GDPR and other relevant regulations, including data anonymization and informed consent procedures (quarterly).

## Audit - Transparency Measures

- Public dashboard displaying overall project budget, expenditures, and key milestones, excluding sensitive data related to individual citizen scores (monthly).
- Published minutes of meetings of the ethics review board, redacting sensitive information to protect privacy (quarterly).
- Whistleblower mechanism with protection against retaliation, allowing individuals to report suspected corruption or ethical violations anonymously (ongoing).
- Public access to the project's data protection policy and compliance reports, excluding sensitive information (ongoing).
- Documented selection criteria for major decisions, such as vendor selection and experimentation protocols, available upon request (ongoing).