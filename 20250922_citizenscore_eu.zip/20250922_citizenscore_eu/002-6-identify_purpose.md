**Purpose:** business

**Purpose Detailed:** Societal control and modification of behavior through a scoring system with rewards and punishments, impacting healthcare, lifestyle, and experimentation on low-scoring individuals.

**Topic:** EU-wide citizen scoring system