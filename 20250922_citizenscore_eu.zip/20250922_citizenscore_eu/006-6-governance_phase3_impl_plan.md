### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior representatives from the European Commission, Independent ethics expert, Independent legal expert, Senior Project Manager, Representative from the Data Protection Office, Representative from a major EU member state government).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager revises SteerCo ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2

**Dependencies:**

- Feedback Summary

### 4. Project Sponsor approves final Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. Project Sponsor formally appoints Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Sponsor formally appoints Steering Committee Vice-Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 7. Project Sponsor formally confirms Steering Committee membership.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Steering Committee Chair Appointed
- Steering Committee Vice-Chair Appointed

### 8. Project Manager schedules initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 9. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 10. Project Manager establishes PMO structure and defines roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Role Descriptions

**Dependencies:**


### 11. Project Manager develops initial Project Management Plan.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Project Management Plan v0.1

**Dependencies:**

- PMO Structure Document

### 12. Project Manager implements project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Draft Project Management Plan v0.1

### 13. Project Manager defines communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Tracking System

### 14. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Protocols Document

### 15. Project Manager drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Approved SteerCo ToR v1.0

### 16. Circulate Draft Ethics and Compliance Committee ToR for review by potential members (Independent ethics expert, Independent legal expert, Representative from the Data Protection Office, Representative from a civil society organization focused on privacy rights, Representative from the European Data Protection Supervisor (EDPS)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1
- Potential Members List Available

### 17. Project Manager revises Ethics and Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.2

**Dependencies:**

- Feedback Summary

### 18. Project Steering Committee approves final Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Approved Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.2

### 19. Project Steering Committee appoints Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0

### 20. Project Steering Committee confirms Ethics and Compliance Committee membership.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0
- Ethics and Compliance Committee Chair Appointed

### 21. Project Manager schedules initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 22. Hold initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 23. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Approved SteerCo ToR v1.0

### 24. Circulate Draft Technical Advisory Group ToR for review by potential members (Independent cybersecurity expert, Independent AI expert, Senior Software Engineer, Senior Data Scientist, Representative from a leading technology research institution).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Potential Members List Available

### 25. Project Manager revises Technical Advisory Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.2

**Dependencies:**

- Feedback Summary

### 26. Project Steering Committee approves final Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Draft Technical Advisory Group ToR v0.2

### 27. Project Steering Committee appoints Technical Advisory Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 28. Project Steering Committee confirms Technical Advisory Group membership.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0
- Technical Advisory Group Chair Appointed

### 29. Project Manager schedules initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 30. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda