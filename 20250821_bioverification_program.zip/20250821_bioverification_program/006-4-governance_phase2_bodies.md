### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for the project, given its global scale, significant budget, and potential legal and reputational risks.  Critical for making key strategic decisions and ensuring alignment with World Athletics' overall objectives.

**Responsibilities:**

- Provide strategic direction and guidance to the project team.
- Approve key project milestones and deliverables.
- Approve budget allocations and expenditures exceeding $500,000.
- Monitor project progress against strategic goals and objectives.
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve changes to project scope, budget, or timeline exceeding 10%.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson and define roles and responsibilities.
- Establish a communication protocol with the Project Management Office (PMO).
- Review and approve the initial project plan and budget.

**Membership:**

- World Athletics President (or designated representative)
- World Athletics Chief Operating Officer (or designated representative)
- Independent Legal Expert (external)
- Independent Financial Expert (external)
- Athlete Representative (appointed by World Athletics Athletes' Commission)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key risks. Approval of expenditures exceeding $500,000.  Approval of changes to project scope, budget, or timeline exceeding 10%.

**Decision Mechanism:** Decisions made by majority vote. In the event of a tie, the World Athletics President (or designated representative) has the deciding vote.  Any decision impacting athlete welfare requires a unanimous vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions or escalations.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion and approval of budget allocations and expenditures.
- Review of risk management reports and mitigation strategies.
- Discussion and resolution of strategic issues and conflicts.
- Approval of changes to project scope, budget, or timeline.
- Review of compliance reports and audit findings.

**Escalation Path:** World Athletics Executive Board for issues exceeding the Steering Committee's authority or unresolved conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Ensures effective day-to-day management and execution of the project, given its complexity and global scope. Provides centralized coordination, monitoring, and reporting to the Project Steering Committee.

**Responsibilities:**

- Develop and maintain the project plan, including timelines, budgets, and resource allocation.
- Manage day-to-day project activities and track progress against milestones.
- Identify and manage project risks and issues.
- Coordinate communication and collaboration among project stakeholders.
- Prepare regular project status reports for the Project Steering Committee.
- Manage project budget and expenditures within approved limits (under $500,000).
- Ensure compliance with project policies and procedures.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Define roles and responsibilities for project team members.
- Develop a communication plan for project stakeholders.
- Establish a risk management framework.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager
- Technical Lead
- Data Protection Officer
- Communications Officer
- Regional Coordinators (representatives from key regions)

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the PMO team.  Major disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, with ad-hoc meetings as needed for urgent issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of project risks and issues.
- Review of budget and expenditures.
- Coordination of project activities.
- Preparation of project status reports.
- Review of action items from previous meetings.

**Escalation Path:** Project Steering Committee for issues exceeding the PMO's authority or unresolved conflicts.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical and compliance aspects of the project, given the sensitive nature of athlete data, potential for conflicts of interest, and the need to ensure fairness and transparency.  Crucial for maintaining the integrity and credibility of the program.

**Responsibilities:**

- Oversee compliance with GDPR and other relevant regulations.
- Review and approve ethical guidelines and policies for the project.
- Investigate allegations of ethical violations or misconduct.
- Provide guidance on conflict of interest management.
- Monitor the fairness and transparency of the appeals process.
- Ensure cultural sensitivity in testing protocols and communication.
- Review and approve data security protocols and incident response plans.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson and define roles and responsibilities.
- Establish a communication protocol with the PMO and Project Steering Committee.
- Develop a process for receiving and investigating complaints.
- Establish a framework for assessing and mitigating ethical risks.

**Membership:**

- Independent Ethics Expert (external)
- Independent Legal Expert (external, different from Steering Committee)
- Data Protection Officer
- Athlete Representative (appointed by World Athletics Athletes' Commission, different from Steering Committee)
- Representative from World Athletics Medical and Anti-Doping Commission

**Decision Rights:** Recommendations on ethical and compliance matters, including data privacy, conflict of interest, and fairness.  Authority to halt project activities if ethical or compliance violations are identified.

**Decision Mechanism:** Decisions made by majority vote. In the event of a tie, the Independent Ethics Expert has the deciding vote. Any decision impacting athlete welfare requires a unanimous vote.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for urgent issues or investigations.

**Typical Agenda Items:**

- Review of compliance reports and audit findings.
- Discussion of ethical issues and concerns.
- Review of data security protocols and incident response plans.
- Investigation of alleged ethical violations or misconduct.
- Review of the fairness and transparency of the appeals process.
- Discussion of cultural sensitivity issues.

**Escalation Path:** World Athletics Executive Board for issues exceeding the Committee's authority or unresolved conflicts.