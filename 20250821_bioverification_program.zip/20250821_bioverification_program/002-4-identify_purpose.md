**Purpose:** business

**Purpose Detailed:** Implementation of a mandatory biological verification program for female athletes in World Athletics sanctioned events, including hormonal analysis, genetic screening, and physical examinations, with a focus on regulatory compliance and data management.

**Topic:** Global Biological Verification Program for Female Athletes