This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD.
- **CHF:** Switzerland is the location of World Athletics Headquarters.
- **EUR:** Data centers are located within the European Union.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. CHF may be needed for expenses related to the headquarters in Switzerland. EUR may be needed for data center expenses within the EU. Exchange rates should be monitored to mitigate risks.