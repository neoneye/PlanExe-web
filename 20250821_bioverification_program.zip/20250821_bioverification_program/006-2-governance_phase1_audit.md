
## Audit - Corruption Risks

- Bribery of endocrinologists to falsify physical examination results to favor certain athletes.
- Kickbacks from genetic screening kit suppliers in exchange for exclusive contracts.
- Conflicts of interest involving project personnel with financial ties to testing facilities or equipment vendors.
- Nepotism in the selection of regional testing centers, leading to substandard facilities or compromised testing integrity.
- Misuse of confidential athlete data for betting or other illicit purposes by individuals with database access.
- Trading favors with member federations in exchange for expedited program implementation or relaxed compliance standards.

## Audit - Misallocation Risks

- Inflated invoices from testing facilities or equipment vendors, with the excess funds diverted for personal use.
- Double-billing for testing services, claiming reimbursement from both World Athletics and individual federations.
- Inefficient allocation of resources to regions with limited athlete participation, neglecting areas with higher testing demand.
- Unauthorized use of program funds for unrelated expenses, such as travel or entertainment for project personnel.
- Poor record-keeping and inadequate documentation of expenses, making it difficult to track and verify expenditures.
- Misreporting progress on program implementation to justify continued funding, despite delays or shortcomings.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on procurement processes, vendor payments, and expense reports. Responsibility: Internal Audit Team.
- Perform annual external audits of the program's financial statements and compliance with GDPR and World Athletics regulations. Responsibility: Independent Audit Firm.
- Implement a contract review process with pre-defined thresholds for legal and financial scrutiny of vendor agreements. Responsibility: Legal Counsel and Finance Department.
- Establish a workflow for expense approvals with clearly defined authorization levels and supporting documentation requirements. Responsibility: Finance Department.
- Conduct periodic compliance checks of testing protocols and data handling procedures at regional testing centers. Responsibility: Compliance Officer.
- Implement a data security audit trail to monitor access to athlete biological passport data and detect unauthorized access attempts. Responsibility: Data Security Team.

## Audit - Transparency Measures

- Publish a quarterly progress dashboard on the World Athletics website, tracking key milestones, budget expenditures, and program reach. Type: Interactive dashboard with drill-down capabilities.
- Publish minutes of key meetings of the program's steering committee, including decisions related to resource allocation, vendor selection, and policy changes. Governing body: Program Steering Committee.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with protection against retaliation. Responsibility: Ethics Officer.
- Make relevant program policies and reports publicly accessible on the World Athletics website, including the program's charter, risk assessment, and audit reports.
- Document and publish the selection criteria for major decisions, such as the selection of testing facilities, equipment vendors, and data management systems. Responsibility: Procurement Department.
- Create a secure online portal for athletes to access their test results and eligibility status, promoting transparency and empowering athletes to monitor their own data.