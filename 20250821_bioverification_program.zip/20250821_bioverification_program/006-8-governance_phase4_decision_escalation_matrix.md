**Budget Request Exceeding PMO Authority ($500,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's approved financial limit, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for budget overruns, project delays, or reduced scope if not addressed.

**Critical Risk Materialization (e.g., Major Data Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval of revised mitigation plan
Rationale: Materialization of a critical risk threatens project success and requires strategic decisions and resource allocation beyond the PMO's authority.
Negative Consequences: Project failure, legal penalties, reputational damage, and financial losses if not managed effectively.

**PMO Deadlock on Vendor Selection (Conflicting Proposals)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of proposals and selection by vote
Rationale: Inability to reach consensus within the PMO necessitates a higher-level decision to ensure project progress and alignment with strategic goals.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor if not resolved.

**Proposed Major Scope Change (Exceeding 10% of Original Scope)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval of scope change request
Rationale: Significant changes to the project scope impact strategic objectives, budget, and timeline, requiring approval from the Steering Committee.
Negative Consequences: Project failure, budget overruns, and misalignment with strategic goals if not properly managed.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust if not addressed impartially.

**Cultural Insensitivity Complaints**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee review and recommendation of corrective actions
Rationale: Ensures culturally appropriate testing protocols and communication strategies are in place, preventing alienation of athletes and federations.
Negative Consequences: Decreased athlete participation, legal challenges, and reputational damage.