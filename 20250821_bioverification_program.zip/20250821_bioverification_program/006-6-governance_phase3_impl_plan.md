### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by World Athletics President (or designated representative), World Athletics Chief Operating Officer (or designated representative), Independent Legal Expert (external), Independent Financial Expert (external), and Athlete Representative (appointed by World Athletics Athletes' Commission).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Draft SteerCo ToR v0.1

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on the Draft SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Circulation Email
- Feedback from nominated members

### 4. World Athletics President formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** World Athletics President

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. World Athletics President formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** World Athletics President

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager formally confirms Project Steering Committee membership with all appointed members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 9. Project Manager establishes project management processes and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Processes Document
- List of Project Management Tools

**Dependencies:**

- Project Start

### 10. Project Manager defines roles and responsibilities for project team members within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Management Processes Document

### 11. Project Manager develops a communication plan for project stakeholders for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Roles and Responsibilities Matrix

### 12. Project Manager establishes a risk management framework for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Management Framework

**Dependencies:**

- Communication Plan

### 13. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Risk Management Framework

### 14. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Project Tracking System
- Reporting Templates

### 15. Hold the initial Project Management Office (PMO) kick-off meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 16. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Approved SteerCo ToR v1.0

### 17. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by the Data Protection Officer and Representative from World Athletics Medical and Anti-Doping Commission.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Circulation Email
- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 18. Project Manager consolidates feedback on the Draft Ethics & Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Circulation Email
- Feedback from nominated members

### 19. World Athletics President formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** World Athletics President

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.2

### 20. World Athletics President formally appoints the Ethics & Compliance Committee Chair (Independent Ethics Expert).

**Responsible Body/Role:** World Athletics President

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 21. Project Manager formally confirms Ethics & Compliance Committee membership with all appointed members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 22. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 23. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda