This plan involves money.

## Currencies

- **CNY:** For expenses related to hosting the event in Beijing, China.
- **JPY:** For expenses related to hosting the event in Tokyo, Japan.
- **USD:** For expenses related to hosting the event in Boston, USA. Also useful as a stable currency for international budgeting and reporting.

**Primary currency:** USD

**Currency strategy:** Given the international scope of the Robot Olympics, USD will be used for consolidated budgeting and reporting. Local currencies (CNY, JPY) will be used for local transactions within China and Japan, respectively. Exchange rate fluctuations should be monitored, and hedging strategies may be considered to mitigate risks.