This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and international transactions as specified in the plan.
- **MHL:** Local currency of the Marshall Islands, where the facility is located, for local expenses.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. Local currency (MHL) may be used for local transactions. Currency risks should be monitored, and hedging strategies may be considered.