### 1. Project Director drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Director identifies and invites nominated members for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Project Start

### 3. Circulate Draft SteerCo ToR v0.1 for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Project Director consolidates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members

### 5. VIP Consortium formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** VIP Consortium

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. VIP Consortium formally appoints the remaining members of the Project Steering Committee.

**Responsible Body/Role:** VIP Consortium

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Email

### 7. Project Steering Committee Chair schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Agenda
- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final SteerCo ToR v1.0

### 8. Project Steering Committee reviews and approves the project's overall strategy and key milestones.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Strategy
- Approved Key Milestones

**Dependencies:**

- SteerCo Kick-off Meeting Minutes with Action Items

### 9. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start

### 10. Project Manager identifies and assigns initial members to the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Members List

**Dependencies:**

- Draft PMO ToR v0.1

### 11. Circulate Draft PMO ToR v0.1 for review by assigned PMO members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1
- Review Feedback from PMO Members

**Dependencies:**

- Draft PMO ToR v0.1
- PMO Members List

### 12. Project Manager consolidates feedback and finalizes the Project Management Office (PMO) Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Review Feedback from PMO Members

### 13. Project Manager holds PMO Kick-off Meeting & assigns initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Agenda
- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Final PMO ToR v1.0
- PMO Members List

### 14. Project Management Office (PMO) develops and maintains project plans, schedules, and budgets.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Initial Project Plan
- Project Schedule
- Project Budget

**Dependencies:**

- PMO Kick-off Meeting Minutes with Action Items
- Approved Project Strategy

### 15. Project Director drafts initial Terms of Reference (ToR) for the Ethical Oversight Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethical Oversight Committee ToR v0.1

**Dependencies:**

- Project Start

### 16. Project Director identifies and invites nominated members for the Ethical Oversight Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List (Ethical Oversight Committee)

**Dependencies:**

- Draft Ethical Oversight Committee ToR v0.1

### 17. Circulate Draft Ethical Oversight Committee ToR v0.1 for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Ethical Oversight Committee ToR v0.1
- Review Feedback from Nominated Members (Ethical Oversight Committee)

**Dependencies:**

- Draft Ethical Oversight Committee ToR v0.1
- Nominated Members List (Ethical Oversight Committee)

### 18. Project Director consolidates feedback and finalizes the Ethical Oversight Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final Ethical Oversight Committee ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members (Ethical Oversight Committee)

### 19. Project Steering Committee formally appoints the Chair of the Ethical Oversight Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email (Ethical Oversight Committee Chair)

**Dependencies:**

- Final Ethical Oversight Committee ToR v1.0
- Nominated Members List (Ethical Oversight Committee)

### 20. Project Steering Committee formally appoints the remaining members of the Ethical Oversight Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails (Ethical Oversight Committee Members)

**Dependencies:**

- Final Ethical Oversight Committee ToR v1.0
- Appointment Confirmation Email (Ethical Oversight Committee Chair)

### 21. Ethical Oversight Committee Chair schedules and facilitates the initial Ethical Oversight Committee kick-off meeting.

**Responsible Body/Role:** Ethical Oversight Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Ethical Oversight Committee Kick-off Meeting Agenda
- Ethical Oversight Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails (Ethical Oversight Committee Members)
- Final Ethical Oversight Committee ToR v1.0

### 22. Ethical Oversight Committee reviews and approves ethical protocols for all project activities.

**Responsible Body/Role:** Ethical Oversight Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Ethical Protocols

**Dependencies:**

- Ethical Oversight Committee Kick-off Meeting Minutes with Action Items

### 23. Project Director drafts initial Terms of Reference (ToR) for the Security Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Security Committee ToR v0.1

**Dependencies:**

- Project Start

### 24. Project Director identifies and invites nominated members for the Security Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List (Security Committee)

**Dependencies:**

- Draft Security Committee ToR v0.1

### 25. Circulate Draft Security Committee ToR v0.1 for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Security Committee ToR v0.1
- Review Feedback from Nominated Members (Security Committee)

**Dependencies:**

- Draft Security Committee ToR v0.1
- Nominated Members List (Security Committee)

### 26. Project Director consolidates feedback and finalizes the Security Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final Security Committee ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members (Security Committee)

### 27. Project Steering Committee formally appoints the Chair of the Security Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email (Security Committee Chair)

**Dependencies:**

- Final Security Committee ToR v1.0
- Nominated Members List (Security Committee)

### 28. Project Steering Committee formally appoints the remaining members of the Security Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails (Security Committee Members)

**Dependencies:**

- Final Security Committee ToR v1.0
- Appointment Confirmation Email (Security Committee Chair)

### 29. Security Committee Chair schedules and facilitates the initial Security Committee kick-off meeting.

**Responsible Body/Role:** Security Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Security Committee Kick-off Meeting Agenda
- Security Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails (Security Committee Members)
- Final Security Committee ToR v1.0

### 30. Security Committee conducts a comprehensive security risk assessment.

**Responsible Body/Role:** Security Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Comprehensive Security Risk Assessment

**Dependencies:**

- Security Committee Kick-off Meeting Minutes with Action Items

### 31. Project Director drafts initial Terms of Reference (ToR) for the Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 32. Project Director identifies and invites nominated members for the Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List (Compliance Committee)

**Dependencies:**

- Draft Compliance Committee ToR v0.1

### 33. Circulate Draft Compliance Committee ToR v0.1 for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Compliance Committee ToR v0.1
- Review Feedback from Nominated Members (Compliance Committee)

**Dependencies:**

- Draft Compliance Committee ToR v0.1
- Nominated Members List (Compliance Committee)

### 34. Project Director consolidates feedback and finalizes the Compliance Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members (Compliance Committee)

### 35. Project Steering Committee formally appoints the Chair of the Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email (Compliance Committee Chair)

**Dependencies:**

- Final Compliance Committee ToR v1.0
- Nominated Members List (Compliance Committee)

### 36. Project Steering Committee formally appoints the remaining members of the Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails (Compliance Committee Members)

**Dependencies:**

- Final Compliance Committee ToR v1.0
- Appointment Confirmation Email (Compliance Committee Chair)

### 37. Compliance Committee Chair schedules and facilitates the initial Compliance Committee kick-off meeting.

**Responsible Body/Role:** Compliance Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Compliance Committee Kick-off Meeting Agenda
- Compliance Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails (Compliance Committee Members)
- Final Compliance Committee ToR v1.0

### 38. Compliance Committee conducts a comprehensive legal and regulatory review.

**Responsible Body/Role:** Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Comprehensive Legal and Regulatory Review

**Dependencies:**

- Compliance Committee Kick-off Meeting Minutes with Action Items