
## Audit - Corruption Risks

- Bribery of local officials in the Marshall Islands or other potential host countries to secure permits and approvals for the off-shore facility.
- Kickbacks from construction companies or suppliers of medical equipment in exchange for awarding contracts.
- Conflicts of interest involving VIP consortium members who may have financial stakes in companies providing services to the project.
- Misuse of confidential information regarding agnate genetics or VIP health data for personal gain or competitive advantage.
- Nepotism in hiring practices, favoring relatives or associates of VIPs or project leaders, potentially compromising the quality of staff.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use.
- Double-billing for services or materials, creating fictitious expenses to siphon off funds.
- Inefficient allocation of resources, such as overspending on security while underfunding critical medical research.
- Unauthorized use of project assets, such as using the facility's resources for personal medical treatments for staff or their families.
- Misreporting project progress or results to justify continued funding, even if milestones are not being met.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on procurement, payroll, and expense reimbursements.
- Engage an independent external auditor to perform an annual review of the project's financial statements and compliance with relevant regulations.
- Establish a threshold for contract review (e.g., $500,000) requiring independent legal and financial review before execution.
- Implement a robust expense workflow with multiple levels of approval and detailed documentation requirements.
- Conduct periodic compliance checks to ensure adherence to ethical guidelines, environmental regulations, and security protocols.

## Audit - Transparency Measures

- Create a project progress dashboard accessible to the VIP consortium, displaying key milestones, budget expenditures, and risk assessments.
- Publish minutes of key meetings of the project's governing bodies (e.g., ethics review board, security committee) on a secure online portal.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with protection against retaliation.
- Make relevant project policies and reports (e.g., environmental impact assessments, security protocols) publicly available, subject to redaction of sensitive information.
- Document the selection criteria and justification for all major decisions, including vendor selection and strategic choices, and make this information available for internal review.