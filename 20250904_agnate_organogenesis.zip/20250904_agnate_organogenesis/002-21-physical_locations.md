This plan implies one or more physical locations.

## Requirements for physical locations

- Self-sustaining
- Off-shore
- Near the Marshall Islands
- Capacity for 2000 individuals (1500 agnates and 500 operational staff)
- Secure location

## Location 1
Marshall Islands

Atoll near Kwajalein

Uninhabited atoll within 200 nautical miles of Kwajalein Atoll

**Rationale**: Proximity to the Marshall Islands as specified in the plan, while maintaining operational secrecy on an uninhabited atoll. Kwajalein offers existing infrastructure and logistical support.

## Location 2
Kiribati

Remote atoll in the Phoenix Islands

One of the uninhabited atolls within the Phoenix Islands Protected Area

**Rationale**: The Phoenix Islands offer a remote location with limited accessibility, aiding in secrecy. Kiribati has stable governance and is relatively close to the Marshall Islands.

## Location 3
Federated States of Micronesia

Remote island in the Caroline Islands

One of the outer islands in Yap State

**Rationale**: The Caroline Islands offer a degree of isolation and are within the Micronesia region, providing a balance between remoteness and accessibility. Yap State has a relatively small population and limited external traffic.

## Location Summary
The suggested locations near the Marshall Islands, Kiribati, and the Federated States of Micronesia offer the required off-shore, self-sustaining environment with capacity for 2000 individuals, while also providing the necessary security and isolation for the facility's operations.