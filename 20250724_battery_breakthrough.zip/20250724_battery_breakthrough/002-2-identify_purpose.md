**Purpose:** business

**Purpose Detailed:** Invention of a high-performance battery with specific energy density targets, with a focus on technological advancement rather than market dominance.

**Topic:** Next-generation rechargeable battery invention