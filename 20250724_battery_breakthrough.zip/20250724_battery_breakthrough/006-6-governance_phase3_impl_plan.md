### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by nominated members (CTO, CFO, VP R&D, Independent Board Member, Project Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft Core Team ToR for review by nominated members (Project Manager, Lead Scientist, Lead Electrochemist, Lead Engineer, Compliance Officer, Key Technicians).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Core Team ToR

**Dependencies:**

- Draft Core Team ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft TAG ToR for review by nominated members (External expert in battery chemistry, External expert in materials science, External expert in battery manufacturing, Lead Scientist, Lead Electrochemist, Lead Engineer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft ECC ToR for review by nominated members (Compliance Officer, Legal Counsel, Environmental Health and Safety (EHS) Manager, Independent Ethics Advisor, Data Protection Officer (DPO)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1
- Nominated Members List Available

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 10. Project Manager finalizes the Core Project Team Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary on Core Team ToR

### 11. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 12. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 13. Project Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Sponsor formally confirms membership of the Project Steering Committee (CTO, CFO, VP R&D, Independent Board Member, Project Director).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 15. Project Manager formally confirms membership of the Core Project Team (Project Manager, Lead Scientist, Lead Electrochemist, Lead Engineer, Compliance Officer, Key Technicians).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Core Team ToR v1.0

### 16. Project Manager formally confirms membership of the Technical Advisory Group (External expert in battery chemistry, External expert in materials science, External expert in battery manufacturing, Lead Scientist, Lead Electrochemist, Lead Engineer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 17. Project Manager formally confirms membership of the Ethics & Compliance Committee (Compliance Officer, Legal Counsel, Environmental Health and Safety (EHS) Manager, Independent Ethics Advisor, Data Protection Officer (DPO)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 18. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of SteerCo Chair
- Membership Confirmation Email
- Final SteerCo ToR v1.0

### 19. Hold initial Core Project Team Kick-off Meeting.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final Core Team ToR v1.0

### 20. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final TAG ToR v1.0

### 21. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final ECC ToR v1.0