This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and the location is in the United States.

**Primary currency:** USD

**Currency strategy:** The project is based in the USA, and the budget is in USD. All transactions will be in USD, so no additional international risk management is needed.