This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** Constructing a roundabout is *inherently* a physical project. It requires land surveying, material procurement (concrete, asphalt, etc.), heavy machinery operation, and on-site construction work. The location in Hungary *unequivocally* implies a physical location.