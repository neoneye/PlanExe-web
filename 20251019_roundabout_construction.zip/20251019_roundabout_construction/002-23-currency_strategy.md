This plan involves money.

## Currencies

- **EUR:** The project is located in Hungary, and the budget is specified in EUR, making it the primary currency for all transactions.

**Primary currency:** EUR

**Currency strategy:** The local currency (EUR) will be used for all transactions, with no additional international risk management needed as the project is confined to Hungary.