<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Change management plan incomplete

**Domain:** Human Stability

**Issues:**

- <code>CHANGE_MGMT_GAPS</code>: Change plan v1 (communications, training, adoption KPIs)

**Acceptance Tests:**

  - Communications calendar attached
  - Training modules outlined
  - Adoption KPIs baselined

**Artifacts Required:**

  - Change\_Plan\_v1\.pdf

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 21 days


### B2: Contingency too low

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Tests:**

  - \>=10% contingency approved
  - Monte Carlo risk workbook attached

**Artifacts Required:**

  - Budget\_v2\.pdf
  - Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: Waste management plan missing

**Domain:** Ecological Integrity

**Issues:**

- <code>WASTE_MANAGEMENT_GAPS</code>: Waste management plan v1 (types, handling, compliance)

**Acceptance Tests:**

  - Waste types identified
  - Handling procedures documented
  - Compliance requirements listed

**Artifacts Required:**

  - Waste\_Mgmt\_Plan\_v1\.pdf

**Owner:** Environmental Lead


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B4: License registry incomplete

**Domain:** Rights & Legality

**Issues:**

- <code>LICENSE_GAPS</code>: License registry (source, terms, expiry)

**Acceptance Tests:**

  - License IDs captured
  - Terms and expiry dates listed
  - Owners assigned

**Artifacts Required:**

  - License\_Registry\.xlsx

**Owner:** Legal


**Rough Order of Magnitude (ROM):** LOW cost, 7 days

