A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The geotechnical survey will reveal soil conditions suitable for standard roundabout construction techniques without requiring costly ground improvements. | Expedite the comprehensive geotechnical investigation, including deep soil borings and in-situ testing, at multiple points across the construction site. | The geotechnical report indicates widespread unstable soil conditions requiring extensive and expensive ground stabilization measures (e.g., piling, soil replacement). |
| A2 | The project will secure the necessary 70% funding from government grants within the anticipated timeframe. | Submit grant applications to identified programs and actively engage with relevant government agencies to gauge the likelihood of funding approval. | Official communication from government agencies indicates that grant funding is unlikely to be approved due to budget constraints or project prioritization changes. |
| A3 | The local community will generally support the roundabout project and its construction, accepting temporary disruptions in exchange for long-term benefits. | Conduct a comprehensive community survey and hold public forums to gauge local sentiment and identify potential sources of opposition. | Survey results and public forum attendance reveal significant and widespread community opposition to the project, citing concerns about noise, traffic, or environmental impact. |
| A4 | The existing utility infrastructure (water, gas, electricity, telecom) at the roundabout location is accurately mapped and will not require significant and costly relocation during construction. | Conduct a comprehensive utility survey, including potholing and ground-penetrating radar, to verify the location and depth of all existing utilities. | The utility survey reveals significant discrepancies in existing maps, requiring extensive and costly relocation of major utility lines (e.g., high-pressure gas mains, high-voltage power cables). |
| A5 | The selected construction methodology will not encounter unforeseen delays due to equipment malfunctions, labor shortages, or unexpected site conditions (e.g., buried obstructions, contaminated soil). | Conduct a thorough site assessment, including historical records review and environmental testing, and develop a detailed construction schedule with built-in buffers for potential delays. | The construction schedule is significantly delayed (e.g., by more than 30 days) due to repeated equipment breakdowns, difficulty securing skilled labor, or the discovery of unforeseen site conditions requiring remediation. |
| A6 | The roundabout design will effectively manage current and projected traffic volumes, preventing congestion and maintaining acceptable levels of service (LOS) during peak hours. | Conduct a detailed traffic simulation study, incorporating current and projected traffic data, to evaluate the roundabout's performance under various traffic scenarios. | The traffic simulation study reveals that the roundabout design will result in unacceptable levels of congestion (e.g., LOS E or F) during peak hours, requiring significant redesign or alternative traffic management solutions. |
| A7 | The local supply chain for construction materials (concrete, asphalt, steel) will remain stable and reliable throughout the project, with no significant disruptions or price fluctuations. | Secure preliminary agreements with multiple suppliers for key materials, including fixed-price contracts and guaranteed delivery schedules. Monitor market trends and industry reports for potential supply chain disruptions. | A major supplier declares bankruptcy or experiences a significant production disruption, leading to material shortages and price increases exceeding 15%. |
| A8 | The project team will maintain effective communication and collaboration throughout the project lifecycle, preventing misunderstandings, conflicts, and delays. | Implement a comprehensive communication plan, including regular team meetings, progress reports, and a centralized document management system. Conduct periodic team-building activities to foster collaboration and trust. | Significant communication breakdowns occur within the project team, leading to critical errors, missed deadlines, or unresolved conflicts that delay the project by more than 30 days. |
| A9 | The local political climate will remain supportive of the roundabout project, with no significant changes in government policies or priorities that could jeopardize funding or approvals. | Maintain regular communication with local political leaders and government officials to monitor their support for the project and address any emerging concerns. Actively participate in local community events to build relationships and garner public support. | A new political administration takes office and announces a shift in priorities, resulting in the cancellation or significant reduction of funding for the roundabout project. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Funding Fiasco | Process/Financial | A2 | Funding and Grants Administrator | CRITICAL (20/25) |
| FM2 | The Shifting Sands Debacle | Technical/Logistical | A1 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Community Backlash Catastrophe | Market/Human | A3 | Community Liaison | MEDIUM (8/25) |
| FM4 | The Utility Relocation Nightmare | Process/Financial | A4 | Head of Engineering | CRITICAL (15/25) |
| FM5 | The Construction Chaos Catastrophe | Technical/Logistical | A5 | Construction Foreman | CRITICAL (16/25) |
| FM6 | The Traffic Gridlock Gamble | Market/Human | A6 | Civil Engineer | MEDIUM (8/25) |
| FM7 | The Material Shortage Meltdown | Technical/Logistical | A7 | Procurement Specialist | CRITICAL (15/25) |
| FM8 | The Communication Breakdown Debacle | Process/Financial | A8 | Project Manager | CRITICAL (16/25) |
| FM9 | The Political Winds of Doom | Market/Human | A9 | Community Liaison | HIGH (10/25) |


### Failure Modes

#### FM1 - The Funding Fiasco

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Funding and Grants Administrator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
*   Over-reliance on government grants as the primary funding source.
*   Failure to secure sufficient grant funding due to increased competition or budget cuts.
*   Lack of a robust contingency plan to address funding shortfalls.
*   Inadequate exploration of alternative funding mechanisms, such as public-private partnerships or private investment.
*   Resulting project delays, scope reductions, or complete termination due to financial constraints.

##### Early Warning Signs
- Grant application rejection notices received.
- Government agencies announce budget cuts affecting infrastructure projects.
- Delays in loan approval processes.

##### Tripwires
- Government grant approval <= 50% of requested amount.
- Loan interest rates >= 8%.
- Alternative funding sources not identified within 60 days.

##### Response Playbook
- Contain: Immediately halt all non-essential project expenditures.
- Assess: Conduct a thorough review of the project budget and identify potential cost-saving measures.
- Respond: Explore alternative funding options, such as private investment or scaling back the project scope.


**STOP RULE:** Total secured funding falls below 75% of the total project budget after 9 months.

---

#### FM2 - The Shifting Sands Debacle

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
*   Inadequate geotechnical investigation leading to unforeseen soil conditions.
*   Discovery of unstable soil requiring extensive ground improvement techniques (e.g., piling, soil replacement).
*   Significant cost overruns associated with ground improvement.
*   Delays in construction due to the need for specialized equipment and expertise.
*   Potential structural instability of the roundabout if ground improvement is not properly executed.

##### Early Warning Signs
- Initial soil borings reveal inconsistent soil density.
- Geotechnical engineer recommends further, more detailed testing.
- Contractors submit change orders for additional excavation and soil stabilization.

##### Tripwires
- Geotechnical report indicates bearing capacity < 150 kPa at 2 meters depth.
- Required ground improvement costs exceed 15% of the original construction budget.
- Construction delays due to soil stabilization exceed 60 days.

##### Response Playbook
- Contain: Immediately halt all construction activities in the affected area.
- Assess: Conduct a thorough re-evaluation of the geotechnical report and explore alternative foundation designs.
- Respond: Negotiate with contractors to minimize cost overruns and expedite the ground improvement process.


**STOP RULE:** Required ground improvement costs exceed 30% of the original construction budget, rendering the project financially unviable.

---

#### FM3 - The Community Backlash Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Community Liaison
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
*   Failure to adequately engage with the local community and address their concerns.
*   Widespread community opposition to the project due to perceived negative impacts (e.g., noise, traffic, environmental concerns).
*   Protests and legal challenges leading to project delays and increased costs.
*   Damage to the project's reputation and loss of public trust.
*   Political pressure to abandon or significantly alter the project.

##### Early Warning Signs
- Low attendance at public forums and community meetings.
- Negative comments and complaints on social media and local news outlets.
- Formation of organized opposition groups.

##### Tripwires
- Community satisfaction score (based on surveys) <= 60%.
- Number of formal complaints received >= 25.
- Local petition against the project gains >= 500 signatures.

##### Response Playbook
- Contain: Immediately suspend all non-essential construction activities that are causing community disruption.
- Assess: Conduct a thorough review of the community engagement plan and identify areas for improvement.
- Respond: Implement enhanced community outreach efforts, including one-on-one meetings with key stakeholders and revisions to the project design to address community concerns.


**STOP RULE:** Irreversible legal injunction obtained by community groups halts construction indefinitely.

---

#### FM4 - The Utility Relocation Nightmare

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
*   Inaccurate utility maps leading to unforeseen conflicts during excavation.
*   Discovery of undocumented or mislocated utility lines requiring emergency relocation.
*   Significant cost overruns associated with utility relocation, exceeding the contingency budget.
*   Delays in construction due to the need for specialized equipment and coordination with utility companies.
*   Potential damage to existing utilities, resulting in service disruptions and additional costs.

##### Early Warning Signs
- Inconsistent information from different utility companies.
- Evidence of previous utility work in the area without proper documentation.
- Contractor reports difficulty locating utility lines during initial excavation.

##### Tripwires
- Utility relocation costs exceed 10% of the original construction budget.
- Construction delays due to utility relocation exceed 45 days.
- Damage to a major utility line results in a service disruption affecting more than 100 customers.

##### Response Playbook
- Contain: Immediately halt all excavation activities in the affected area.
- Assess: Conduct a thorough investigation to determine the extent of the utility conflict and develop a relocation plan.
- Respond: Negotiate with utility companies to expedite the relocation process and minimize service disruptions.


**STOP RULE:** Utility relocation costs exceed 25% of the original construction budget, rendering the project financially unviable.

---

#### FM5 - The Construction Chaos Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Construction Foreman
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
*   Unreliable construction equipment leading to frequent breakdowns and delays.
*   Shortage of skilled labor due to competing projects or unforeseen circumstances.
*   Discovery of unexpected site conditions, such as buried obstructions or contaminated soil, requiring remediation.
*   Ineffective project management and coordination, resulting in scheduling conflicts and inefficiencies.
*   Failure to meet critical milestones, leading to overall project delays and cost overruns.

##### Early Warning Signs
- Repeated equipment malfunctions and downtime.
- Difficulty securing qualified subcontractors and skilled labor.
- Discovery of unexpected materials or conditions during excavation.

##### Tripwires
- Construction schedule falls behind by more than 15%.
- Equipment downtime exceeds 10% of scheduled operating hours.
- Remediation costs for contaminated soil exceed 5% of the original construction budget.

##### Response Playbook
- Contain: Immediately implement backup plans for equipment and labor.
- Assess: Conduct a thorough review of the construction schedule and identify critical path activities.
- Respond: Negotiate with subcontractors to expedite the work and implement alternative construction methods to mitigate delays.


**STOP RULE:** Construction schedule falls behind by more than 30% due to a combination of equipment malfunctions, labor shortages, and unforeseen site conditions.

---

#### FM6 - The Traffic Gridlock Gamble

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Civil Engineer
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
*   Inaccurate traffic projections leading to an undersized or poorly designed roundabout.
*   Increased traffic volumes due to unexpected regional growth or development.
*   Congestion and delays during peak hours, negating the intended benefits of the roundabout.
*   Negative public perception and complaints about traffic flow.
*   Potential need for costly redesign or alternative traffic management solutions.

##### Early Warning Signs
- Real-time traffic data indicates increasing congestion at the intersection.
- Local residents and businesses express concerns about traffic flow after the roundabout opens.
- Traffic simulation models predict unacceptable levels of service during peak hours.

##### Tripwires
- Level of Service (LOS) at the roundabout during peak hours degrades to E or F.
- Average travel time through the intersection increases by more than 10% after the roundabout opens.
- Number of accidents at the roundabout increases compared to pre-construction levels.

##### Response Playbook
- Contain: Immediately implement temporary traffic management measures to alleviate congestion.
- Assess: Conduct a thorough review of the traffic data and identify the root causes of the congestion.
- Respond: Implement design modifications to improve traffic flow, such as adjusting lane configurations or signal timing.


**STOP RULE:** Traffic congestion at the roundabout consistently exceeds acceptable levels (LOS D or worse) despite implemented mitigation measures, requiring a major redesign or alternative traffic management solution.

---

#### FM7 - The Material Shortage Meltdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Procurement Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
*   Reliance on a limited number of suppliers for critical construction materials.
*   Disruptions in the local supply chain due to unforeseen events (e.g., natural disasters, transportation strikes, supplier bankruptcies).
*   Significant price increases for construction materials, exceeding the contingency budget.
*   Delays in construction due to material shortages, requiring alternative sourcing or project rescheduling.
*   Potential use of substandard materials to meet budget constraints, compromising the roundabout's structural integrity.

##### Early Warning Signs
- Suppliers announce production slowdowns or delivery delays.
- Prices for key construction materials begin to rise sharply.
- Local news reports indicate supply chain disruptions in the region.

##### Tripwires
- Delivery of critical materials delayed by more than 30 days.
- Prices for key construction materials increase by more than 20%.
- Alternative material suppliers cannot be identified within 15 days.

##### Response Playbook
- Contain: Immediately explore alternative material sources and negotiate with existing suppliers to expedite deliveries.
- Assess: Conduct a thorough review of the material procurement plan and identify critical dependencies.
- Respond: Implement value engineering measures to reduce material consumption and explore alternative construction methods.


**STOP RULE:** Critical material shortages persist for more than 60 days, rendering the project schedule unachievable and increasing costs beyond the contingency budget.

---

#### FM8 - The Communication Breakdown Debacle

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
*   Lack of clear communication channels and protocols within the project team.
*   Misunderstandings and conflicts between team members due to poor communication.
*   Failure to share critical information in a timely manner, leading to errors and delays.
*   Inadequate documentation and record-keeping, resulting in confusion and accountability issues.
*   Ineffective project management and coordination, leading to overall project delays and cost overruns.

##### Early Warning Signs
- Frequent misunderstandings and miscommunications between team members.
- Delays in responding to emails and phone calls.
- Incomplete or inaccurate project documentation.

##### Tripwires
- Critical project milestones are missed due to communication errors.
- Number of unresolved conflicts within the project team exceeds 3.
- Response time to critical inquiries exceeds 48 hours.

##### Response Playbook
- Contain: Immediately implement mandatory daily team meetings to improve communication and coordination.
- Assess: Conduct a thorough review of the communication plan and identify areas for improvement.
- Respond: Provide additional training to team members on effective communication and conflict resolution techniques.


**STOP RULE:** Critical communication breakdowns persist despite implemented mitigation measures, leading to a projected cost overrun exceeding 15% of the original budget.

---

#### FM9 - The Political Winds of Doom

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Liaison
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
*   Changes in local government leadership or political priorities.
*   Loss of political support for the roundabout project due to shifting public opinion or competing priorities.
*   Cancellation or reduction of government funding for the project.
*   Increased regulatory scrutiny or permitting delays due to political interference.
*   Damage to the project's reputation and loss of public trust.

##### Early Warning Signs
- Local political leaders express reservations about the project.
- Local news outlets publish negative articles about the project's cost or impact.
- Government agencies delay or deny permit approvals.

##### Tripwires
- Local government announces a review of the project's funding allocation.
- A key political supporter of the project loses their election.
- New regulations are introduced that significantly increase the project's compliance costs.

##### Response Playbook
- Contain: Immediately engage with local political leaders and government officials to reaffirm the project's benefits and address their concerns.
- Assess: Conduct a thorough review of the project's political support and identify potential vulnerabilities.
- Respond: Implement a public relations campaign to highlight the project's positive impacts and garner community support.


**STOP RULE:** Government funding for the project is officially cancelled or reduced by more than 50% due to political changes.
