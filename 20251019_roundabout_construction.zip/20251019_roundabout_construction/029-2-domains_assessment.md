<div class="domains-grid">
  <!-- Green Domain Card -->
  <div class="domain-card domain-card--green domain-card--count-zero" role="status" aria-labelledby="domains-green-title">
    <div class="domain-card__header">
      <div class="domain-card__left">
        <span class="domain-card__icon" aria-hidden="true">✔</span>
        <span id="domains-green-title" class="domain-card__status-name">GREEN</span>
      </div>
      <span class="domain-card__count">0 domains</span>
    </div>
    <div class="domain-card__body">
      <p>Good to go. You have solid evidence and no open critical unknowns. Proceed. Any remaining tasks are minor polish.</p>
    </div>
  </div>

  <!-- Yellow Domain Card -->
  <div class="domain-card domain-card--yellow " role="status" aria-labelledby="domains-yellow-title">
    <div class="domain-card__header">
      <div class="domain-card__left">
        <span class="domain-card__icon" aria-hidden="true">!</span>
        <span id="domains-yellow-title" class="domain-card__status-name">YELLOW</span>
      </div>
      <span class="domain-card__count">4 domains</span>
    </div>
    <div class="domain-card__body">
      <p>Conditionally ready; key risks/unknowns remain. There’s promise, but you’re missing proof on key points or see non-fatal risks. Proceed with caution and a focused checklist.</p>
    </div>
  </div>

  <!-- Red Domain Card -->
  <div class="domain-card domain-card--red domain-card--count-zero" role="status" aria-labelledby="domains-red-title">
    <div class="domain-card__header">
      <div class="domain-card__left">
        <span class="domain-card__icon" aria-hidden="true">✖</span>
        <span id="domains-red-title" class="domain-card__status-name">RED</span>
      </div>
      <span class="domain-card__count">0 domains</span>
    </div>
    <div class="domain-card__body">
      <p>Not ready; fix blockers before proceeding. There’s a concrete blocker or negative evidence (legal, technical, economic) that stops execution until fixed. Pause or pivot.</p>
    </div>
  </div>

  <!-- Gray Domain Card -->
  <div class="domain-card domain-card--gray domain-card--count-zero" role="status" aria-labelledby="domains-gray-title">
    <div class="domain-card__header">
      <div class="domain-card__left">
        <span class="domain-card__icon" aria-hidden="true">?</span>
        <span id="domains-gray-title" class="domain-card__status-name">GRAY</span>
      </div>
      <span class="domain-card__count">0 domains</span>
    </div>
    <div class="domain-card__body">
      <p>Unknown / unassessed. You don’t have enough information to judge. Don’t guess—add a “first measurement” task to get out of uncertainty.</p>
    </div>
  </div>
</div>




### Legend: How to Read the Scores

Each domain’s health is scored on a 1–5 scale across three key metrics. Higher scores are better.

| Metric | Strong Negative (1) | Weak Negative (2) | Neutral (3) | Weak Positive (4) | Strong Positive (5) |
|--------|--------------------|-------------------|-------------|-------------------|---------------------|
| **Evidence** | No/contradictory evidence; claims only | Anecdotes/unstable drafts | Inconclusive; limited data | Internal tests/pilot support | Independent, reproducible validation; monitored |
| **Risk** | Severe exposure; blockers/unknowns | Major exposure; mitigations not in place | Moderate; mitigations planned/in progress | Low residual risk; mitigations in place | Minimal residual risk; contingencies tested |
| **Fit** | Conflicts with constraints/strategy | Low alignment; major trade-offs | Mixed/unclear alignment | Good alignment; minor trade-offs | Strong alignment; directly reinforces strategy |

### Domain: Human Stability

**Status**: YELLOW — driven by evidence (talent unknown).

**Metrics**: evidence=2, risk=3, fit=3

**Issues:**

- <code>CHANGE_MGMT_GAPS</code>: Change plan v1 (communications, training, adoption KPIs)
- <code>TALENT_UNKNOWN</code>: Talent market scan report (availability, salary ranges, channels)

**Evidence Needed:**

- Change plan v1 (communications, training, adoption KPIs) — acceptance criteria: communications calendar, training modules, and baseline adoption KPIs documented with exec sponsor approval.
- Stakeholder map + skills gap snapshot — acceptance criteria: top 20 stakeholders include influence/interest scores, critical role gaps quantified, and HR lead sign-off captured.


### Domain: Economic Resilience

**Status**: YELLOW — driven by evidence (unit econ).

**Metrics**: evidence=2, risk=3, fit=3

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook
- <code>UNIT_ECON_UNKNOWN</code>: Unit economics model v1 + sensitivity table (key drivers)

**Evidence Needed:**

- Assumption ledger v1 + sensitivity table — acceptance criteria: ledger lists top 10 assumptions with owners and rationale, sensitivity table shows +/-20% scenario impact, and file stored in shared workspace.
- Unit economics model v1 + sensitivity table (key drivers) — acceptance criteria: model includes CAC, LTV, gross margin, sensitivity table covers +/-20% price and COGS, and CFO sign-off attached.


### Domain: Ecological Integrity

**Status**: YELLOW — driven by fit (waste management).

**Metrics**: evidence=3, risk=3, fit=2

**Issues:**

- <code>CLIMATE_UNQUANTIFIED</code>: Climate exposure maps (2030/2040/2050) + site vulnerability memo
- <code>WASTE_MANAGEMENT_GAPS</code>: Waste management plan v1 (types, handling, compliance)

**Evidence Needed:**

- Cloud carbon estimate v1 (regions/services) — acceptance criteria: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard.
- Environmental baseline note (scope, metrics) — acceptance criteria: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign-off.


### Domain: Rights & Legality

**Status**: YELLOW — driven by fit (ethics vague).

**Metrics**: evidence=3, risk=3, fit=2

**Issues:**

- <code>LICENSE_GAPS</code>: License registry (source, terms, expiry)
- <code>ETHICS_VAGUE</code>: Normative Charter v1.0 with auditable rules & dissent logging

**Evidence Needed:**

- Licenses & permits inventory + gaps list — acceptance criteria: inventory captures license IDs, terms, expiry, owners, gaps flagged with remediation owners, and legal review logged.
- Regulatory mapping v1 + open questions list — acceptance criteria: applicable regulations by jurisdiction linked to control owners, open questions assigned with due dates, and compliance counsel acknowledged.

