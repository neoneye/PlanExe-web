**Purpose:** business

**Purpose Detailed:** Infrastructure project, resource management, public welfare

**Topic:** Construction of a roundabout