**Budget Request Exceeding PMO Authority (over 50,000 EUR)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and vote based on alignment with project goals and budget availability.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential budget overruns, project delays, and misalignment with strategic objectives.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee assessment of the risk impact and approval of additional resource allocation.
Rationale: Requires strategic decision-making and potential reallocation of resources beyond the PMO's control.
Negative Consequences: Project delays, increased costs, and potential project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of vendor proposals and selection based on pre-defined criteria.
Rationale: Requires a higher-level decision to resolve the disagreement and ensure project progress.
Negative Consequences: Project delays, potential selection of a suboptimal vendor, and internal conflicts.

**Proposed Major Scope Change (exceeding 10% of original budget or 1 month delay)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval based on impact assessment and strategic alignment.
Rationale: Significant scope changes impact the project's strategic objectives and require higher-level approval.
Negative Consequences: Budget overruns, project delays, and misalignment with strategic objectives.

**Reported Ethical Concern or Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigation, review of evidence, and recommendation of appropriate action.
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Unresolved Stakeholder Grievance**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the grievance and proposed resolution, potentially involving mediation or negotiation.
Rationale: Indicates a significant breakdown in stakeholder relations that requires strategic intervention.
Negative Consequences: Project delays, negative publicity, and potential legal challenges.