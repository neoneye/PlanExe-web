### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start

### 3. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 4. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start

### 5. Circulate Draft SteerCo ToR for review by nominated members (Senior Management Representative, Head of Engineering, Head of Finance, Community Representative, Legal Counsel).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft PMO ToR for review by nominated members (Project Manager, Civil Engineer, Construction Supervisor, Procurement Officer, Quality Assurance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Legal Counsel, Compliance Officer, Environmental Officer, Community Representative, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Community Liaison Officer, Public Relations Officer, Representative from Local Businesses, Representative from Local Residents, Environmental Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 9. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary from SteerCo Members

### 10. Project Manager finalizes the Terms of Reference for the Project Management Office (PMO) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary from PMO Members

### 11. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary from Ethics & Compliance Committee Members

### 12. Project Manager finalizes the Terms of Reference for the Stakeholder Engagement Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary from Stakeholder Engagement Group Members

### 13. Senior Management formally appoints the Chairperson of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Steering Committee Chairperson schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chairperson

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 15. Hold initial Project Steering Committee kick-off meeting to review ToR, confirm membership, and discuss initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 16. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final PMO ToR v1.0

### 17. Hold initial Project Management Office (PMO) kick-off meeting to review ToR, confirm membership, and assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Final PMO ToR v1.0

### 18. Legal Counsel (Chairperson) schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 19. Hold initial Ethics & Compliance Committee kick-off meeting to review ToR, confirm membership, and discuss initial compliance risk assessment.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Final Ethics & Compliance Committee ToR v1.0

### 20. Community Liaison Officer (Chairperson) schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 21. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, confirm membership, and develop initial stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Final Stakeholder Engagement Group ToR v1.0