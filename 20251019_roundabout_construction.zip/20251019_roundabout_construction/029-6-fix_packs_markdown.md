<p class="section-subtitle">Bundled tasks that reduce risk and move domains toward green.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>

### FP1: Address Missing Management Plans

**Priority:** High

**Blockers:** <code>B1</code>, <code>B3</code>

### FP2: Complete License Registry Documentation

**Priority:** Medium

**Blockers:** <code>B4</code>