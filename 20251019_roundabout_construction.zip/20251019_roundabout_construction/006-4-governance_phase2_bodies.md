### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the roundabout construction project, ensuring alignment with organizational goals and effective resource allocation, given the project's budget and potential community impact.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance to the Project Management Office.
- Monitor project progress against key performance indicators (KPIs).
- Approve major changes to project scope, budget, or timeline (exceeding 10% of original budget or 1 month delay).
- Oversee risk management and mitigation strategies.
- Ensure alignment with strategic objectives and stakeholder expectations.
- Resolve escalated issues from the Project Management Office or other governance bodies.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define escalation procedures.
- Review and approve initial project plan.

**Membership:**

- Senior Management Representative (Chairperson)
- Head of Engineering
- Head of Finance
- Community Representative (Independent)
- Legal Counsel

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and risk management. Approval of changes exceeding 10% of the original budget or causing a delay of more than 1 month.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chairperson has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion of key risks and mitigation strategies.
- Approval of change requests.
- Review of financial performance.
- Stakeholder feedback and engagement updates.
- Review of compliance reports.

**Escalation Path:** Escalate to the CEO for unresolved issues or strategic disagreements.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the roundabout construction project, ensuring adherence to the project plan, budget, and timeline. Provides operational risk management and support to the project team.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and track expenses.
- Monitor project progress and identify potential delays or issues.
- Coordinate project activities and resources.
- Manage operational risks and implement mitigation strategies.
- Prepare and distribute project reports.
- Facilitate communication among project stakeholders.
- Ensure compliance with relevant regulations and standards.
- Manage contracts with suppliers and contractors (below 50,000 EUR).

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop project plan and budget.
- Assemble project team.
- Set up project communication channels.
- Define roles and responsibilities.

**Membership:**

- Project Manager
- Civil Engineer
- Construction Supervisor
- Procurement Officer
- Quality Assurance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within the approved budget and timeline. Contract approvals below 50,000 EUR.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the project team. Major disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current issues and risks.
- Review of budget and expenses.
- Coordination of project activities.
- Update on stakeholder communication.
- Review of quality control reports.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic guidance.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations, including GDPR, environmental regulations, and anti-corruption laws, given the project's potential impact on the community and environment.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with relevant regulations and standards.
- Investigate reports of ethical violations or non-compliance.
- Provide training on ethics and compliance to project team members.
- Ensure compliance with GDPR and data privacy regulations.
- Oversee environmental compliance and sustainability initiatives.
- Review and approve contracts to ensure compliance with ethical standards and anti-corruption laws.
- Conduct regular audits to assess compliance with ethical and regulatory requirements.

**Initial Setup Actions:**

- Develop ethics and compliance policy.
- Establish reporting mechanisms for ethical violations.
- Conduct initial risk assessment.
- Define audit procedures.
- Establish a data protection impact assessment (DPIA) process.

**Membership:**

- Legal Counsel (Chairperson)
- Compliance Officer
- Environmental Officer
- Community Representative (Independent)
- Data Protection Officer

**Decision Rights:** Decisions related to ethics and compliance matters, including investigations, disciplinary actions, and policy changes. Approval of contracts exceeding 100,000 EUR from a compliance perspective.

**Decision Mechanism:** Decisions made by majority vote. The Chairperson has the casting vote in case of a tie. Dissenting opinions are recorded.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Update on regulatory changes.
- Review of contracts and agreements.
- Training and awareness programs.
- Audit findings and recommendations.
- Review of data protection impact assessments (DPIAs).

**Escalation Path:** Escalate to the CEO and the Project Steering Committee for unresolved ethical or compliance issues.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates communication and collaboration with stakeholders, ensuring their concerns are addressed and their feedback is incorporated into the project, given the project's potential impact on the local community.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and feedback.
- Provide project updates to stakeholders.
- Facilitate community meetings and workshops.
- Manage communication channels with stakeholders.
- Monitor stakeholder satisfaction and address any issues.
- Ensure that stakeholder feedback is considered in project decision-making.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop stakeholder engagement plan.
- Establish communication channels.
- Set up feedback mechanisms.
- Define roles and responsibilities.

**Membership:**

- Community Liaison Officer (Chairperson)
- Public Relations Officer
- Representative from Local Businesses
- Representative from Local Residents
- Environmental Officer

**Decision Rights:** Recommendations on stakeholder engagement strategies and communication plans. Decisions on how to address stakeholder concerns within the approved project budget.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns.
- Update on project progress.
- Planning of community engagement activities.
- Review of communication materials.
- Monitoring of stakeholder satisfaction.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved stakeholder issues or strategic disagreements.