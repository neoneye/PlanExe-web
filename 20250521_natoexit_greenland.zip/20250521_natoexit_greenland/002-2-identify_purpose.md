**Purpose:** business

**Purpose Detailed:** Geopolitical strategy, military operation, and signaling of US autonomy to NATO.

**Topic:** US seizure of Nuuk, Greenland