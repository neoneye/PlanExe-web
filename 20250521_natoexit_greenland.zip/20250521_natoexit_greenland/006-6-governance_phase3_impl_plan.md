### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior Representative, National Security Council; Director, Central Intelligence Agency; Secretary of Defense; Secretary of State; Chairman of the Joint Chiefs of Staff; Director, Inter-agency Greenland & Strategic Realignment Task Force).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Representative, National Security Council, formally appointed as Steering Committee Chair.

**Responsible Body/Role:** National Security Council

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee members formally confirmed.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment of Chair
- Final SteerCo ToR v1.0

### 6. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final SteerCo ToR v1.0

### 7. Project Steering Committee approves initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Budget

**Dependencies:**

- Meeting Minutes with Action Items

### 8. Project Manager establishes PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Org Chart
- Staffing Plan

**Dependencies:**

- Project Start
- Project Plan Approved

### 9. Project Manager develops project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Org Chart

### 10. Project Manager defines project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 11. Project Manager establishes risk management framework.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Risk Management Framework Document

**Dependencies:**

- Project Reporting Requirements Document

### 12. Project Manager sets up project communication channels.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Risk Management Framework Document

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Plan
- PMO Org Chart

### 14. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 15. Circulate Draft Ethics & Compliance Committee ToR for review by Department of Justice and Department of State (Human Rights Division).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 16. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Independent Legal Counsel appointed as Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 18. Ethics & Compliance Committee members formally confirmed.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment of Chair
- Final Ethics & Compliance Committee ToR v1.0

### 19. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Independent Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final Ethics & Compliance Committee ToR v1.0

### 20. Ethics & Compliance Committee develops code of ethics.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Code of Ethics

**Dependencies:**

- Meeting Minutes with Action Items

### 21. Ethics & Compliance Committee establishes reporting procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Procedures Document

**Dependencies:**

- Code of Ethics

### 22. Ethics & Compliance Committee sets up whistleblower hotline.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Whistleblower Hotline Details

**Dependencies:**

- Reporting Procedures Document

### 23. Project Manager drafts initial Stakeholder Engagement Plan.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 24. Circulate Draft Stakeholder Engagement Plan for review by Department of State (Public Diplomacy).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1

### 25. Project Manager finalizes the Stakeholder Engagement Plan based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Plan v1.0

**Dependencies:**

- Feedback Summary

### 26. Communications Manager appointed as Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Plan v1.0

### 27. Stakeholder Engagement Group members formally confirmed.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment of Chair
- Final Stakeholder Engagement Plan v1.0

### 28. Hold initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final Stakeholder Engagement Plan v1.0

### 29. Stakeholder Engagement Group identifies key stakeholders.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Meeting Minutes with Action Items

### 30. Stakeholder Engagement Group establishes communication channels.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**

- List of Key Stakeholders

### 31. Stakeholder Engagement Group sets up feedback mechanisms.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Mechanisms Established

**Dependencies:**

- Communication Channels Established

### 32. Stakeholder Engagement Group develops public relations strategy.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Public Relations Strategy Document

**Dependencies:**

- Feedback Mechanisms Established