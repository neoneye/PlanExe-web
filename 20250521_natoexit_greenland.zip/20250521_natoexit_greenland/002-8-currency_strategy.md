This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and large-scale operations.
- **DKK:** Local currency of Greenland; needed for local transactions and potential payments.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting due to the scale and nature of the operation. DKK may be used for local transactions. Exchange rate fluctuations should be monitored, but given the scale of the operation, hedging is unlikely to be necessary.