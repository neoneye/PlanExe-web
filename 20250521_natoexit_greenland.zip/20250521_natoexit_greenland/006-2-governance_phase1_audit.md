
## Audit - Corruption Risks

- Bribery of Greenlandic officials or contractors to expedite approvals or overlook substandard work.
- Kickbacks from suppliers of goods and services (e.g., construction, logistics) in exchange for inflated contracts.
- Conflicts of interest involving US administrators awarding contracts to companies in which they have a personal financial stake.
- Misuse of classified information for personal gain, such as insider trading based on knowledge of infrastructure projects.
- Nepotism in hiring practices for the PAA, favoring unqualified relatives or friends for positions of power and influence.

## Audit - Misallocation Risks

- Inflated invoices from contractors providing services to the PAA, with the excess funds diverted for unauthorized purposes.
- Double-billing for services rendered, with both the US government and Greenlandic entities being charged for the same work.
- Inefficient allocation of resources, such as overspending on security measures while neglecting essential services like healthcare or education.
- Unauthorized use of US military assets (vehicles, equipment) for personal or commercial purposes by personnel involved in the operation.
- Misreporting of project progress or results to justify continued funding, even if the operation is failing to achieve its objectives.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions related to the Greenland operation, focusing on procurement, contracting, and expense reimbursements. Responsibility: Inspector General's Office.
- Implement a mandatory ethics training program for all US personnel involved in the operation, emphasizing the importance of integrity and compliance with anti-corruption laws. Frequency: Annually.
- Establish a whistleblower hotline for reporting suspected fraud, corruption, or other misconduct, with guaranteed anonymity and protection from retaliation. Responsibility: Independent legal counsel.
- Perform regular compliance checks to ensure adherence to environmental protocols and regulations, including waste management, pollution control, and wildlife protection. Frequency: Monthly. Responsibility: Environmental Compliance Officer.
- Conduct a post-project external audit by an independent accounting firm to assess the overall effectiveness of financial controls and identify any instances of fraud or mismanagement. Responsibility: Inter-agency Greenland & Strategic Realignment Task Force.

## Audit - Transparency Measures

- Publish a monthly dashboard on a secure, but accessible, website detailing project expenditures, key performance indicators (KPIs), and progress towards strategic objectives. Access restricted to authorized personnel.
- Document and publish minutes of all meetings of the Inter-agency Greenland & Strategic Realignment Task Force, redacting classified information as necessary. Publication: Monthly.
- Establish a clear and documented selection criteria for all major contracts and vendors, ensuring fairness and transparency in the procurement process. Publication: On request.
- Implement a robust expense reporting workflow with multiple levels of approval and mandatory documentation for all expenditures. Responsibility: PAA Finance Department.
- Make relevant policies and reports related to the Greenland operation publicly accessible, subject to national security considerations. Publication: On request.