**Budget Request Exceeding PMO Authority ($5 million USD)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight due to the significant financial impact.
Negative Consequences: Potential for budget overruns, project delays, and failure to meet strategic objectives.

**Critical Risk Materialization (e.g., Military Conflict with Denmark/NATO)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion & Recommendation to President
Rationale: Represents a significant threat to the project's success and has major geopolitical implications requiring high-level strategic guidance.
Negative Consequences: Project failure, international condemnation, military conflict, and damage to US interests.

**PMO Deadlock on Operational Decision**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision
Rationale: Inability to reach a consensus within the PMO on a key operational decision is impeding project progress and requires resolution at a higher level.
Negative Consequences: Project delays, inefficiencies, and potential for suboptimal outcomes.

**Proposed Major Scope Change (e.g., Expanding Area of Control)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Represents a significant deviation from the original project plan and requires strategic reassessment and approval.
Negative Consequences: Budget overruns, project delays, increased risks, and potential for failure to meet strategic objectives.

**Reported Ethical Concern (e.g., Human Rights Violation)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee and Attorney General
Rationale: Requires independent review and investigation to ensure compliance with ethical standards and legal requirements.
Negative Consequences: Legal penalties, reputational damage, international condemnation, and project shutdown.

**Whistleblower Report with Allegations of Serious Misconduct**
Escalation Level: Ethics & Compliance Committee
Approval Process: Independent Investigation, Report to Steering Committee and Attorney General
Rationale: To ensure impartial investigation and appropriate action regarding potential violations of ethical or legal standards.
Negative Consequences: Legal repercussions, reputational damage, loss of public trust, and potential project termination.