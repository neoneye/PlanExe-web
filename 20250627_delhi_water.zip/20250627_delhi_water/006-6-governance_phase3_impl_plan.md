### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 6. Circulate Draft SteerCo ToR for review by Senior Management Representative, Head of Engineering, Head of Finance, Head of Sustainability, and the Independent External Advisor (Environmental Engineering).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1

### 7. Circulate Draft PMO ToR for review by Project Engineers, Finance Officer, Procurement Officer, Risk Manager, and Communications Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 8. Circulate Draft TAG ToR for review by Senior Environmental Engineer, AWP Technology Specialist, Water Quality Expert, Infrastructure Integration Specialist, Independent External Advisor (AWP Technology), and Project Engineer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1

### 9. Circulate Draft ECC ToR for review by Legal Counsel, Compliance Officer, Internal Auditor, HR Representative, Independent External Advisor (Ethics and Compliance), and Community Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1

### 10. Circulate Draft SEG ToR for review by Communications Officer, Community Liaison Officer, Environmental Specialist, Social Impact Assessment Specialist, Local Community Representative, and Government Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SEG ToR

**Dependencies:**

- Draft SEG ToR v0.1

### 11. Project Manager finalizes the Project Steering Committee Terms of Reference based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 12. Project Manager finalizes the Project Management Office (PMO) Terms of Reference based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 13. Project Manager finalizes the Technical Advisory Group Terms of Reference based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 14. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 15. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary on SEG ToR

### 16. Senior Management Representative formally appointed as Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Senior Environmental Engineer formally appointed as Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 18. Legal Counsel formally appointed as Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 19. Communications Officer formally appointed as Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0

### 20. Project Manager formally appointed as PMO Lead.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 21. Project Manager schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of SteerCo Chair
- Final SteerCo ToR v1.0

### 22. Project Manager schedules and facilitates the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of PMO Lead
- Final PMO ToR v1.0

### 23. Project Manager schedules and facilitates the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of TAG Chair
- Final TAG ToR v1.0

### 24. Project Manager schedules and facilitates the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of ECC Chair
- Final ECC ToR v1.0

### 25. Project Manager schedules and facilitates the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SEG Kick-off Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment of SEG Chair
- Final SEG ToR v1.0

### 26. The Project Steering Committee reviews and approves the overall project strategy and objectives.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Strategy and Objectives

**Dependencies:**

- SteerCo Kick-off Meeting
- Final SteerCo ToR v1.0

### 27. The Project Management Office (PMO) develops and maintains project plans, schedules, and budgets.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Plans
- Project Schedules
- Project Budgets

**Dependencies:**

- PMO Kick-off Meeting
- Final PMO ToR v1.0
- Approved Project Strategy and Objectives

### 28. The Technical Advisory Group reviews and approves technical designs and specifications for the AWP technology.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Technical Designs and Specifications

**Dependencies:**

- TAG Kick-off Meeting
- Final TAG ToR v1.0

### 29. The Ethics & Compliance Committee develops and implements ethics and compliance policies and procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Ethics and Compliance Policies and Procedures

**Dependencies:**

- ECC Kick-off Meeting
- Final ECC ToR v1.0

### 30. The Stakeholder Engagement Group develops and implements a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan

**Dependencies:**

- SEG Kick-off Meeting
- Final SEG ToR v1.0