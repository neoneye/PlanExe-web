**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority ($5 million limit). Requires strategic review and approval due to significant financial impact.
Negative Consequences: Potential budget overrun, project delays, reduced scope, or need for additional funding.

**Critical Risk Materialization Requiring Strategic Intervention**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: The PMO cannot manage the risk with existing resources or authority. Requires strategic-level decision-making and resource allocation.
Negative Consequences: Project failure, significant delays, financial losses, reputational damage, or environmental harm.

**PMO Deadlock on Vendor Selection for AWP Components**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation
Rationale: Requires independent technical expertise to resolve the deadlock and ensure the selection aligns with project goals and technical specifications.
Negative Consequences: Selection of a suboptimal vendor, delays in procurement, increased costs, or compromised AWP system performance.

**Proposed Major Scope Change Affecting Project Objectives**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: The change significantly alters the project's objectives, timeline, or budget. Requires strategic alignment and approval.
Negative Consequences: Project misalignment with strategic goals, budget overruns, delays, or reduced project benefits.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation
Rationale: Requires independent investigation and assessment to ensure ethical conduct and compliance with relevant laws and regulations.
Negative Consequences: Legal penalties, fines, reputational damage, loss of stakeholder trust, or project suspension.

**Community Opposition Causing Project Delays**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Stakeholder Engagement Plan
Rationale: Requires strategic intervention to address community concerns and mitigate social risks.
Negative Consequences: Project delays, increased costs, reputational damage, or legal challenges.