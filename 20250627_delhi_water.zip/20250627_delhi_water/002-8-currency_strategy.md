This plan involves money.

## Currencies

- **INR:** Local currency for expenses within Delhi, India, including labor, local materials, and operational costs.
- **USD:** The project budget is specified in USD, and it is advisable to use USD for budgeting, reporting, and potentially for major equipment purchases to mitigate currency fluctuation risks.

**Primary currency:** USD

**Currency strategy:** Given the significant project budget and the potential for currency fluctuations, it is recommended to use USD for budgeting and reporting. While INR will be necessary for local transactions, hedging strategies should be considered to mitigate risks associated with exchange rate volatility. For significant projects, the primary currency must be USD.