This plan involves money.

## Currencies

- **CHF:** Switzerland is a potential location for safe houses.
- **GBP:** The United Kingdom, specifically London, is a potential location for safe houses.
- **EUR:** Germany, specifically Berlin, is a potential location for safe houses.
- **USD:** For international budgeting and potential transactions in other countries.

**Primary currency:** USD

**Currency strategy:** Given the international scope and potential for operations in multiple countries, USD is recommended for consolidated budgeting and reporting. Local currencies (CHF, GBP, EUR) may be used for local transactions. Hedging against exchange rate fluctuations may be necessary.