### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Circulate Draft SteerCo ToR v0.1 for review by Senior Management Representative, Legal Counsel, Head of Operations, Head of Finance, and Independent Ethics Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 sent for review
- Nominated Members List Available

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Collate and address feedback on Draft SteerCo ToR v0.1 and produce Draft SteerCo ToR v0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 sent for review
- Feedback Received

### 4. Senior Management formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2
- Feedback Summary

### 5. Senior Management Representative formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager, in consultation with the Steering Committee Chair, confirms the membership of the Project Steering Committee (Senior Management Representative, Legal Counsel, Head of Operations, Head of Finance, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SteerCo Membership List
- Approved SteerCo ToR v1.0

### 8. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 9. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start

### 10. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Project Start

### 11. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Tools Setup and Configuration

**Dependencies:**

- Project Start

### 12. Project Manager develops a detailed work breakdown structure for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Work Breakdown Structure Document

**Dependencies:**

- Project Start

### 13. Project Manager establishes risk management processes for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Risk Management Processes Document

**Dependencies:**

- Project Start

### 14. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Kick-off Meeting Invitation

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocols Document
- Project Management Tools Setup and Configuration
- Detailed Work Breakdown Structure Document
- Risk Management Processes Document

### 15. Hold the initial Core Project Team kick-off meeting to review project goals, roles, responsibilities, and initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Core Project Team Kick-off Meeting Invitation

### 16. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Approved SteerCo ToR v1.0

### 17. Circulate Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel, Senior Management Representative, and External Compliance Expert.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 sent for review

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 18. Collate and address feedback on Draft Ethics & Compliance Committee ToR v0.1 and produce Draft Ethics & Compliance Committee ToR v0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1 sent for review
- Feedback Received

### 19. Senior Management formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.2
- Feedback Summary

### 20. Senior Management Representative formally appoints the Independent Ethics Advisor as the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 21. Project Manager, in consultation with the Ethics & Compliance Committee Chair, confirms the membership of the Ethics & Compliance Committee (Legal Counsel, Senior Management Representative, External Compliance Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Appointment Confirmation Email

### 22. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List
- Approved Ethics & Compliance Committee ToR v1.0

### 23. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, ethical guidelines, and compliance policies.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation