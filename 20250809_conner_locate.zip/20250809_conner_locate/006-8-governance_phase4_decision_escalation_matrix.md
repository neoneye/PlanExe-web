**Budget Request Exceeding PMO Authority ($50,000 USD)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the Core Project Team's approved budget limit, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overrun, project delays, reduced operational capabilities.

**Critical Risk Materialization (Compromise of Cover Identities or Data Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk threatens mission success and personnel safety, requiring immediate strategic intervention and resource reallocation.
Negative Consequences: Mission failure, harm to personnel, legal repercussions, significant financial losses.

**PMO Deadlock on Vendor Selection (e.g., Surveillance Equipment)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Mediation and Vote
Rationale: Disagreement within the Core Project Team hinders progress and requires impartial resolution at a higher level to ensure optimal resource allocation.
Negative Consequences: Project delays, suboptimal resource allocation, potential compromise of operational security.

**Proposed Major Scope Change (e.g., Expanding Area of Operation)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope impact resource allocation, timelines, and strategic objectives, requiring Steering Committee approval.
Negative Consequences: Project delays, budget overruns, increased operational risks, potential mission failure.

**Reported Ethical Concern (e.g., Potential Violation of Data Privacy Laws)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Executive Leadership Team
Rationale: Ethical breaches can lead to legal repercussions, reputational damage, and compromise of the mission's integrity, requiring independent review and action.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, potential mission failure.

**Unresolved Ethical or Compliance Issue**
Escalation Level: Executive Leadership Team
Approval Process: Executive Leadership Team Review and Decision
Rationale: The Ethics & Compliance Committee has been unable to resolve an ethical or compliance issue, requiring a higher level of authority to make a final determination.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, potential mission failure.