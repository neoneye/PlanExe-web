- **Status:** RED
- **Recommendation:** <code>HOLD</code>, Do not proceed \- resolve blockers first

### Summary of Critical Issues by Domain
| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Rights & Legality | RED | LICENSE\_GAPS, PERMIT\_COMPLEXITY |
| Technical Feasibility | RED | UTILITY\_INFRA\_GAP |
| Ecological Integrity | GRAY | Evidence needed: Environmental baseline note \(scope, metrics\) — acceptance criteria: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign\-off\., Cloud carbon estimate v1 \(regions/services\) — acceptance criteria: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard\. |

### Go/No-Go Criteria
<p class="section-subtitle">Must be met to proceed.</p>
- \>=10% contingency approved
- Monte Carlo risk workbook attached