| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Rights & Legality | RED | LICENSE\_GAPS, PERMIT\_COMPLEXITY |
| Technical Feasibility | RED | UTILITY\_INFRA\_GAP |
| Ecological Integrity | GRAY | Evidence needed: Environmental baseline note \(scope, metrics\) — acceptance criteria: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign\-off\., Cloud carbon estimate v1 \(regions/services\) — acceptance criteria: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard\. |