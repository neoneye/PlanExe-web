This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and potential international transactions.
- **RUB:** Potential expenses in Russia if Siberia location is chosen.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting. If the project requires operations in Russia, RUB may be needed for local transactions. Exchange rate fluctuations should be monitored.