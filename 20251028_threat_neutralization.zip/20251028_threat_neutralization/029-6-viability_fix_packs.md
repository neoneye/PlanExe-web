<p class="section-subtitle">Bundled actions that reduce risk and move domains toward GREEN.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>

### FP1: Address Human Resource and Training Deficiencies

**Priority:** High

**Blockers:** <code>B1</code>, <code>B5</code>

### FP2: Resolve Legal Licensing and Compliance Issues

**Priority:** Immediate

**Blockers:** <code>B3</code>

### FP3: Mitigate Utility Infrastructure Capacity Limitations

**Priority:** Medium

**Blockers:** <code>B4</code>