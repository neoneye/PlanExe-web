<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Skills gap unaddressed

**Domain:** Human Stability

**Issues:**

- <code>TALENT_UNKNOWN</code>: Talent market scan report (availability, salary ranges, channels)
- <code>TRAINING_GAPS</code>: Training needs assessment + skill gap analysis report

**Acceptance Criteria:**

- Skills gap analysis complete
- Training plan approved by HR

**Artifacts Required:**

- SkillsGapAnalysis\.pdf
- TrainingPlan\_v1\.pdf

**Owner:** HR


**Rough Order of Magnitude (ROM):** MEDIUM cost, 30 days


### B2: Contingency too low

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Criteria:**

- \>=10% contingency approved
- Monte Carlo risk workbook attached

**Artifacts Required:**

- Budget\_v2\.pdf
- Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: License gaps exist

**Domain:** Rights & Legality

**Issues:**

- <code>LICENSE_GAPS</code>: License registry (source, terms, expiry)

**Acceptance Criteria:**

- All licenses identified
- Gaps remediated

**Artifacts Required:**

- LicenseRegistry\.xlsx
- GapsRemediation\.pdf

**Owner:** Legal


**Rough Order of Magnitude (ROM):** MEDIUM cost, 45 days


### B4: Utility infrastructure gap

**Domain:** Technical Feasibility

**Issues:**

- <code>UTILITY_INFRA_GAP</code>: Utility capacity and infrastructure study (load analysis, upgrade plan, utility confirmation)

**Acceptance Criteria:**

- Utility capacity study complete
- Upgrade plan approved

**Artifacts Required:**

- UtilityStudy\.pdf
- UpgradePlan\.pdf

**Owner:** Engineering Lead


**Rough Order of Magnitude (ROM):** HIGH cost, 90 days


### B5: PMO absent

**Domain:** Program Delivery

**Issues:**

- <code>PMO_ABSENT</code>: PMO charter + governance cadence (steering, risk, change boards)
- <code>CRITICAL_PATH_UNKNOWN</code>: Integrated master schedule (CPM) with logic ties and baseline

**Acceptance Criteria:**

- PMO charter defined
- Integrated master schedule created

**Artifacts Required:**

- PMO\_Charter\.pdf
- MasterSchedule\.mpp

**Owner:** Program Manager


**Rough Order of Magnitude (ROM):** LOW cost, 7 days

