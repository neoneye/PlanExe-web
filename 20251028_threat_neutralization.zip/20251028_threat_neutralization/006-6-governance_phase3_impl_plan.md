### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Team Leader circulates Draft SteerCo ToR v0.1 for review by nominated members (Team Leader, External Advisor (Project Management Expert), Weapons Specialist, Intelligence Gatherer).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Team Leader incorporates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members

### 4. Team Leader formally appoints the Project Steering Committee Chair (Team Leader).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Team Leader confirms membership of the Project Steering Committee (Team Leader, External Advisor (Project Management Expert), Weapons Specialist, Intelligence Gatherer).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Schedule initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Email

### 7. Hold initial Project Steering Committee kick-off meeting to review project goals, scope, and governance structure.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 8. Team Leader defines roles and responsibilities for each Core Project Team member (Team Leader, Weapons Specialist, Intelligence Gatherer, Tactical Coordinator).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Document

**Dependencies:**


### 9. Team Leader establishes communication protocols and reporting procedures for the Core Project Team.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**


### 10. Team Leader sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management System Access
- Project Schedule

**Dependencies:**


### 11. Team Leader develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**


### 12. Team Leader establishes a risk register and mitigation plan for the Core Project Team.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Risk Register
- Risk Mitigation Plan

**Dependencies:**


### 13. Schedule initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Roles and Responsibilities Document
- Communication Protocols Document
- Project Management System Access
- Detailed Project Schedule
- Risk Register
- Risk Mitigation Plan

### 14. Hold initial Core Project Team kick-off meeting to review project plan, roles, and responsibilities.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 15. Team Leader drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 16. Team Leader circulates Draft Ethics & Compliance Committee ToR v0.1 for review by nominated members (External Advisor (Legal Expert), Team Leader, Intelligence Gatherer, External Advisor (AI Ethics Expert)).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 17. Team Leader incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference (ToR).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members

### 18. Team Leader formally appoints the Ethics & Compliance Committee Chair (External Advisor (Legal Expert)).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 19. Team Leader confirms membership of the Ethics & Compliance Committee (External Advisor (Legal Expert), Team Leader, Intelligence Gatherer, External Advisor (AI Ethics Expert)).

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 20. Schedule initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Team Leader

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Email

### 21. Hold initial Ethics & Compliance Committee kick-off meeting to review project plan, ethical considerations, and compliance requirements.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Ethical Guidelines

**Dependencies:**

- Meeting Invitation