This plan involves money.

## Currencies

- **EUR:** The project budget and operational costs are specified in EUR, and the organization will be banking in EUR.
- **CHF:** The organization is based in Switzerland, and some local expenses may be incurred in CHF.
- **USD:** As a stable international currency, USD can be used for budgeting and reporting, and for international transactions.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. CHF may be used for local Swiss transactions. Consider hedging against CHF/EUR exchange rate fluctuations. USD can be used for international transactions and as a stable reference currency.