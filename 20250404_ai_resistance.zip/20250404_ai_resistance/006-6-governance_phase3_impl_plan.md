### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Executive Director, Head of Fundraising, Head of Communications, Technical Advisor, Legal Counsel).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor formally appoints the Executive Director of the Anti-AI Movement as the Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager formally invites nominated members to the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Email

### 6. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 9. Circulate Draft PMO ToR for review by nominated members (Project Manager, Technical Lead, Finance/Operations Lead, Communications Lead, Legal/Compliance Liaison).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 10. Project Manager finalizes the Project Management Office (PMO) ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Manager formally invites nominated members to the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Final PMO ToR v1.0

### 12. Schedule the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 13. Hold the initial Project Management Office (PMO) kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 15. Circulate Draft Technical Advisory Group ToR for review by nominated members (Technical Lead, Cybersecurity Expert, Software Architect, Data Privacy Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 16. Project Manager finalizes the Technical Advisory Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Manager formally invites nominated members to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 18. Schedule the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 19. Hold the initial Technical Advisory Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 21. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Legal/Compliance Liaison, Ethics Officer, Data Protection Officer, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 22. Project Manager finalizes the Ethics & Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Project Manager formally invites nominated members to the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 24. Schedule the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 25. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 26. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 27. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Communications Lead, Community Manager, Public Relations Officer, Representative from Labor Unions, Representative from AI Research Community).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 28. Project Manager finalizes the Stakeholder Engagement Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 29. Project Manager formally invites nominated members to the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 30. Schedule the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 31. Hold the initial Stakeholder Engagement Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda