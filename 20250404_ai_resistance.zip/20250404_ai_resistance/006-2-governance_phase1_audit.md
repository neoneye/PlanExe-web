
## Audit - Corruption Risks

- Bribery of Swiss officials to expedite the 'Verein' establishment or circumvent regulatory hurdles.
- Kickbacks from vendors selected for platform development or hosting services.
- Conflicts of interest in vendor selection, where staff members have undisclosed financial ties to chosen suppliers.
- Misuse of confidential information regarding fundraising strategies or donor information for personal gain.
- Nepotism in hiring core staff or awarding contracts, favoring unqualified individuals based on personal relationships.

## Audit - Misallocation Risks

- Inflated invoices from vendors providing services such as legal counsel, platform development, or marketing.
- Double-billing for expenses related to travel, accommodation, or office supplies.
- Use of project funds for personal expenses disguised as legitimate business costs.
- Inefficient allocation of budget towards non-essential activities, such as excessive marketing spend or lavish office setup.
- Misreporting of project progress to justify continued funding, despite delays or lack of tangible results.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on vendor payments, expense reports, and bank reconciliations (responsibility: Finance/Operations Lead and external auditor).
- Perform regular security audits of the online platform to identify and address vulnerabilities (responsibility: Technical Lead and external cybersecurity firm).
- Review all contracts with vendors and service providers to ensure fair pricing and compliance with procurement policies (responsibility: Legal/Compliance Liaison and Project Management).
- Implement a whistleblower mechanism for reporting suspected fraud or misconduct, with clear procedures for investigation and resolution (responsibility: Legal/Compliance Liaison).
- Conduct a post-project external audit to assess the overall effectiveness of the project and identify areas for improvement (responsibility: External auditor).

## Audit - Transparency Measures

- Publish a project progress dashboard on the online platform, showing key milestones, budget utilization, and fundraising progress (responsibility: Project Management and Communications Lead).
- Publish minutes of key meetings of the core team, focusing on major decisions related to budget allocation, vendor selection, and strategic direction (responsibility: Project Management).
- Develop and publicize a clear conflict-of-interest policy for all staff and volunteers (responsibility: Legal/Compliance Liaison).
- Make the 'Verein's' financial reports available to donors and the public, subject to reasonable privacy considerations (responsibility: Finance/Operations Lead).
- Establish a clear and accessible process for stakeholders to provide feedback and raise concerns about the project (responsibility: Communications Lead).