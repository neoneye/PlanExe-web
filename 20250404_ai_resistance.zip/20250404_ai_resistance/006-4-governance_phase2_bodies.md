### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and ensures alignment with the overall goals of the anti-AI movement. Given the project's international scope, financial investment, and potential impact, a steering committee is crucial for high-level decision-making and risk management.

**Responsibilities:**

- Approve the project plan and any major deviations.
- Approve the annual budget and any budget revisions exceeding €50,000.
- Monitor project progress against key milestones and performance indicators.
- Identify and address strategic risks and issues.
- Approve key partnerships and collaborations.
- Ensure alignment with the overall strategic goals of the anti-AI movement.

**Initial Setup Actions:**

- Define the committee's terms of reference.
- Appoint the committee chair.
- Establish the meeting schedule and communication protocols.
- Review the project plan and risk assessment.
- Approve the initial budget.

**Membership:**

- Executive Director of the Anti-AI Movement (Chair)
- Head of Fundraising
- Head of Communications
- Technical Advisor (Independent)
- Legal Counsel (Independent)

**Decision Rights:** Strategic decisions related to project scope, budget (above €50,000), timeline, and key partnerships. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Executive Director (Chair) has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and issues.
- Review of financial performance.
- Approval of budget revisions.
- Approval of key partnerships.
- Strategic updates from the Project Management Office.

**Escalation Path:** Executive Director of the Anti-AI Movement
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring that it stays on track and within budget. Given the complexity of the project, a PMO is essential for effective coordination and communication.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage the project budget and track expenses.
- Monitor project progress and identify potential delays or issues.
- Coordinate the activities of the project team.
- Communicate project status to stakeholders.
- Manage project risks and issues.
- Ensure compliance with project governance policies and procedures.

**Initial Setup Actions:**

- Establish the PMO's organizational structure.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.
- Onboard project team members.

**Membership:**

- Project Manager (Head of PMO)
- Technical Lead/Platform Management
- Finance/Operations Lead
- Communications Lead
- Legal/Compliance Liaison

**Decision Rights:** Operational decisions related to project execution, budget management (below €50,000), and resource allocation. Approval of minor changes to the project plan.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the project team. In the event of a disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and issues.
- Review of financial performance.
- Action item tracking.
- Resource allocation.
- Communication updates.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert advice on technical aspects of the project, ensuring that the online platform is secure, reliable, and scalable. Given the importance of the platform to the project's success, a technical advisory group is essential for mitigating technical risks.

**Responsibilities:**

- Provide technical guidance on the development of the online platform.
- Review the platform's architecture and design.
- Assess the platform's security vulnerabilities.
- Recommend technical solutions to address project challenges.
- Evaluate new technologies and trends.
- Ensure the platform meets performance and scalability requirements.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the group's terms of reference.
- Establish the meeting schedule and communication protocols.
- Review the platform's architecture and design.
- Assess the platform's security vulnerabilities.

**Membership:**

- Technical Lead/Platform Management
- Cybersecurity Expert (Independent)
- Software Architect (Independent)
- Data Privacy Expert (Independent)

**Decision Rights:** Technical recommendations related to platform development, security, and scalability. Approval of major changes to the platform's architecture or design.

**Decision Mechanism:** Decisions are made by consensus. In the event of a disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of platform development progress.
- Discussion of technical risks and issues.
- Assessment of platform security vulnerabilities.
- Evaluation of new technologies and trends.
- Recommendations for technical solutions.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures that the project complies with all relevant ethical standards, legal regulations (including GDPR and Swiss law), and internal policies. Given the sensitive nature of the project and its potential impact on individuals and society, an ethics and compliance committee is essential for maintaining trust and credibility.

**Responsibilities:**

- Develop and maintain a code of ethics for the project.
- Ensure compliance with all relevant legal regulations, including GDPR and Swiss law.
- Review project activities for ethical concerns.
- Investigate and resolve ethical complaints.
- Provide training on ethical standards and compliance requirements.
- Monitor compliance with internal policies and procedures.

**Initial Setup Actions:**

- Develop a code of ethics for the project.
- Identify all relevant legal regulations and compliance requirements.
- Establish the committee's terms of reference.
- Establish the meeting schedule and communication protocols.
- Develop a process for investigating and resolving ethical complaints.

**Membership:**

- Legal/Compliance Liaison
- Ethics Officer (Independent)
- Data Protection Officer (Independent)
- Community Representative (Independent)

**Decision Rights:** Decisions related to ethical standards, legal compliance, and internal policies. Approval of major changes to the code of ethics or compliance program.

**Decision Mechanism:** Decisions are made by consensus. In the event of a disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of ethical concerns.
- Discussion of legal and regulatory updates.
- Review of compliance with internal policies and procedures.
- Investigation of ethical complaints.
- Training on ethical standards and compliance requirements.

**Escalation Path:** Project Steering Committee
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates communication and collaboration with key stakeholders, including AI researchers, policymakers, the public, and labor unions. Given the importance of stakeholder support to the project's success, a stakeholder engagement group is essential for building relationships and managing expectations.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Identify and prioritize key stakeholders.
- Communicate project updates to stakeholders.
- Solicit feedback from stakeholders.
- Address stakeholder concerns.
- Build relationships with stakeholders.
- Organize stakeholder events.

**Initial Setup Actions:**

- Develop a stakeholder engagement plan.
- Identify and prioritize key stakeholders.
- Establish the group's terms of reference.
- Establish the meeting schedule and communication protocols.
- Develop communication materials for stakeholders.

**Membership:**

- Communications Lead
- Community Manager
- Public Relations Officer
- Representative from Labor Unions (External)
- Representative from AI Research Community (External)

**Decision Rights:** Decisions related to stakeholder engagement strategies, communication materials, and stakeholder events. Approval of major changes to the stakeholder engagement plan.

**Decision Mechanism:** Decisions are made by consensus. In the event of a disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder feedback.
- Development of communication materials.
- Planning of stakeholder events.
- Identification of new stakeholders.

**Escalation Path:** Project Steering Committee