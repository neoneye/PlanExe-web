This plan involves money.

## Currencies

- **DKK:** Local currency for project operations in Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.