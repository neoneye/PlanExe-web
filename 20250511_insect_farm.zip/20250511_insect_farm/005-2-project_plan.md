**Goal Statement:** Establish a pilot House Cricket (Acheta domesticus) farm in Western Jutland, Denmark, for food-grade human consumption within 7 months.

## SMART Criteria

- **Specific:** Establish a pilot farm for House Cricket (Acheta domesticus) in Western Jutland, Denmark, utilizing controlled environment agriculture for food-grade human consumption.
- **Measurable:** The successful establishment of the pilot farm will be measured by the commencement of cricket production and the collection of operational data within 7 months.
- **Achievable:** The goal is achievable given the available resources, including a budget of 1 million DKK, personnel, and the potential for municipal support in Western Jutland, Denmark.
- **Relevant:** This goal is relevant as it addresses the need for sustainable food sources and aims to gather essential operational data for scaling insect protein production in Northern Europe.
- **Time-bound:** The goal should be achieved within 7 months.

## Dependencies

- Secure a physical location in Western Jutland, Denmark.
- Obtain necessary permits for insect farming from Danish authorities.
- Establish a reliable supply chain for cricket feed.
- Secure partnerships with local restaurants/retailers.

## Resources Required

- Rearing containers
- Climate control equipment
- Harvesting tools
- Computerized monitoring system
- Cricket feed

## Related Goals

- Scale insect protein production in Northern Europe
- Increase consumer acceptance of insect-based food products
- Promote sustainable food sources

## Tags

- insect farming
- controlled environment agriculture
- sustainable food
- Denmark
- pilot project

## Risk Assessment and Mitigation Strategies


### Key Risks

- Regulatory hurdles and permitting delays
- Technical challenges with the CEA system
- Financial constraints and potential cost overruns
- Negative consumer perception of insect-based food products
- Disruptions in the supply chain for cricket feed

### Diverse Risks

- Operational risks
- Systematic risks
- Business risks

### Mitigation Plans

- Engage with Danish authorities early to secure consultations and identify potential roadblocks.
- Thoroughly test the CEA system before full-scale operation and implement monitoring and control systems.
- Develop a detailed budget with contingency funds and explore additional funding sources.
- Conduct market research and develop targeted marketing campaigns to build consumer acceptance.
- Identify multiple suppliers for cricket feed and maintain buffer stocks.

## Stakeholder Analysis


### Primary Stakeholders

- Project Manager
- Farm Technician
- Marketing Assistant

### Secondary Stakeholders

- Danish Veterinary and Food Administration
- Local communities in Western Jutland
- Potential customers (restaurants, retailers)
- Cricket feed suppliers

### Engagement Strategies

- Provide regular project updates and progress reports to primary stakeholders.
- Engage with the Danish Veterinary and Food Administration to ensure compliance with regulations.
- Conduct public forums and market research to engage with local communities and potential customers.
- Establish clear communication channels with cricket feed suppliers to ensure a consistent supply.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Permits from the Danish Veterinary and Food Administration for insect farming
- Food safety certifications
- Environmental permits for waste management

### Compliance Standards

- Danish food safety regulations
- Animal welfare standards
- Environmental regulations

### Regulatory Bodies

- Danish Veterinary and Food Administration

### Compliance Actions

- Conduct a legal review to identify all relevant Danish regulations and food safety standards.
- Engage with the Danish Veterinary and Food Administration (DVFA) to obtain guidance.
- Develop a detailed compliance plan.
- Document all compliance activities.