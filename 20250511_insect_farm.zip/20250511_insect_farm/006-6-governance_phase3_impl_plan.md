### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Senior Management reviews and provides feedback on the draft SteerCo ToR.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 5. Legal Counsel reviews and provides feedback on the draft Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 6. Senior Management reviews and provides feedback on the draft Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group ToR Feedback

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR Feedback

### 8. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Ethics & Compliance Committee ToR Feedback

### 9. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Stakeholder Engagement Group ToR Feedback

### 10. Senior Management formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Chair Appointment Confirmation

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Senior Management formally appoints the Food Safety Specialist as the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Chair Appointment Confirmation

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 12. Senior Management formally appoints the Marketing Assistant as the Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Chair Appointment Confirmation

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 13. Project Manager, in consultation with Senior Management, confirms the membership of the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Membership Confirmation

**Dependencies:**

- SteerCo Chair Appointment Confirmation
- Final SteerCo ToR v1.0

### 14. Project Manager, in consultation with Legal Counsel, confirms the membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Membership Confirmation

**Dependencies:**

- Ethics & Compliance Committee Chair Appointment Confirmation
- Final Ethics & Compliance Committee ToR v1.0

### 15. Project Manager, in consultation with Senior Management, confirms the membership of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Membership Confirmation

**Dependencies:**

- Stakeholder Engagement Group Chair Appointment Confirmation
- Final Stakeholder Engagement Group ToR v1.0

### 16. Project Manager schedules the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- SteerCo Membership Confirmation

### 17. Project Manager schedules the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Ethics & Compliance Committee Membership Confirmation

### 18. Project Manager schedules the initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

**Dependencies:**

- Stakeholder Engagement Group Membership Confirmation

### 19. Hold the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 20. Hold the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 21. Hold the initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

### 22. Establish project management processes and templates.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project management processes
- Project templates

**Dependencies:**


### 23. Define roles and responsibilities within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO roles and responsibilities document

**Dependencies:**

- Project management processes

### 24. Set up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project tracking system
- Reporting templates

**Dependencies:**

- PMO roles and responsibilities document

### 25. Develop communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO communication plan

**Dependencies:**

- Project tracking system

### 26. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- PMO communication plan