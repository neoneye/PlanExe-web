### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and ensures alignment with organizational goals, given the project's innovative nature and potential impact on scaling insect protein production.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key performance indicators (KPIs).
- Approve major changes to project scope, budget, or timeline (above 100,000 DKK).
- Oversee risk management and mitigation strategies.
- Resolve strategic issues and conflicts.
- Ensure alignment with organizational strategy and objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review project plan and risk assessment.

**Membership:**

- Senior Management Representative (Chair)
- Project Manager
- Finance Director
- Marketing Director
- Independent External Advisor (AgTech/Food Innovation)

**Decision Rights:** Strategic decisions related to project scope, budget (above 100,000 DKK), timeline, and risk management.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion of strategic risks and mitigation strategies.
- Approval of budget changes or scope modifications (above 100,000 DKK).
- Review of stakeholder engagement activities.
- Updates on regulatory compliance.

**Escalation Path:** CEO
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Ensures efficient project execution, manages day-to-day operations, and provides support to the Project Manager, given the project's complexity and tight timeline.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget (below 100,000 DKK) and resources.
- Track project progress and report to the Steering Committee.
- Identify and manage operational risks.
- Coordinate project activities and communication.
- Ensure adherence to project management standards and best practices.
- Manage day-to-day operational decisions.

**Initial Setup Actions:**

- Establish project management processes and templates.
- Define roles and responsibilities.
- Set up project tracking and reporting systems.
- Develop communication plan.

**Membership:**

- Project Manager (Chair)
- Farm Technician
- Marketing Assistant
- Data Analyst

**Decision Rights:** Operational decisions related to project execution, resource allocation (below 100,000 DKK), and risk management.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Unresolved issues are escalated to the Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of operational risks and mitigation strategies.
- Allocation of resources.
- Coordination of project activities.
- Review of data collection and analysis.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, regulatory compliance, and adherence to food safety standards, given the project's focus on human consumption and potential ethical concerns related to insect farming.

**Responsibilities:**

- Oversee compliance with Danish food safety regulations.
- Ensure adherence to ethical standards and best practices.
- Monitor environmental performance and waste management.
- Address ethical concerns related to insect farming.
- Ensure compliance with GDPR and data privacy regulations.
- Review and approve marketing materials to ensure accuracy and ethical messaging.
- Implement and manage the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a compliance plan.
- Establish ethical guidelines.
- Set up a reporting mechanism for ethical concerns.
- Review relevant regulations and standards.

**Membership:**

- Food Safety Specialist (Chair)
- Legal Counsel
- Environmental Officer
- Independent Ethics Advisor
- Data Protection Officer

**Decision Rights:** Decisions related to ethical conduct, regulatory compliance, and food safety standards.

**Decision Mechanism:** Decisions made by majority vote, with the Food Safety Specialist having the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of compliance with Danish food safety regulations.
- Discussion of ethical concerns.
- Review of environmental performance.
- Updates on regulatory changes.
- Review of whistleblower reports.

**Escalation Path:** CEO and Legal Counsel
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates communication and collaboration with key stakeholders, including local communities, potential customers, and industry partners, given the project's reliance on consumer acceptance and external partnerships.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct public forums and market research.
- Partner with chefs and food bloggers.
- Establish relationships with industry partners.
- Manage communication with local communities.
- Gather feedback from potential customers.
- Address stakeholder concerns and complaints.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication plan.
- Establish communication channels.
- Schedule initial meetings with stakeholders.

**Membership:**

- Marketing Assistant (Chair)
- Project Manager
- Community Representative
- Industry Partner Representative

**Decision Rights:** Decisions related to stakeholder engagement activities and communication strategies.

**Decision Mechanism:** Decisions made by consensus, with the Marketing Assistant facilitating the discussion. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder feedback.
- Planning of public forums and market research.
- Coordination of communication with stakeholders.
- Updates on project progress.

**Escalation Path:** Project Steering Committee