## Suggestion 1 - EntoFarm - Insect Production System

EntoFarm is a research project focused on developing an automated insect production system for Black Soldier Fly larvae (BSFL) in Denmark. The project aims to optimize rearing conditions, improve resource efficiency, and ensure high-quality insect protein production. It involves collaboration between universities, research institutions, and industry partners.

### Success Metrics

Optimized rearing conditions for BSFL.
Improved resource efficiency (feed, energy, water).
High-quality insect protein production.
Development of an automated insect production system.
Publication of research findings in scientific journals.

### Risks and Challenges Faced

Maintaining stable rearing conditions in a controlled environment.
Optimizing feed composition for BSFL growth.
Preventing disease outbreaks and ensuring biosecurity.
Scaling up production from laboratory to industrial scale.
Securing funding for research and development.

### Where to Find More Information

https://www.researchgate.net/project/EntoFarm-Insect-Production-System
https://orbit.dtu.dk/en/projects/entofarm-insect-production-system

### Actionable Steps

Contact DTU Food (Technical University of Denmark) to inquire about the project and potential collaboration opportunities. Email: food@food.dtu.dk
Reach out to project researchers via ResearchGate to request information and insights. Look for publications by project members.
Network with industry partners involved in the project through LinkedIn to explore potential partnerships.

### Rationale for Suggestion

This project is highly relevant due to its focus on insect farming in Denmark, its emphasis on controlled environment agriculture, and its aim to optimize production processes. It provides valuable insights into the technical and operational challenges of insect farming in a Northern European context. The project's focus on BSFL is different from the user's focus on house crickets, but the CEA and automation aspects are highly relevant.
## Suggestion 2 - InnovaFeed Insect Farm

InnovaFeed operates a large-scale insect farm in Gouzeaucourt, France, producing insect protein for animal feed. The facility utilizes a highly automated and sustainable production process, focusing on Black Soldier Fly larvae. The project demonstrates the feasibility of large-scale insect farming and provides valuable insights into operational efficiency and sustainability.

### Success Metrics

High production volume of insect protein.
Efficient resource utilization (feed, energy, water).
Sustainable production process with minimal environmental impact.
Successful commercialization of insect protein products.
Securing funding for expansion and further development.

### Risks and Challenges Faced

Scaling up production to industrial levels.
Maintaining consistent product quality and safety.
Optimizing the rearing environment for BSFL.
Managing waste and minimizing environmental impact.
Securing regulatory approvals for insect protein products.

### Where to Find More Information

https://www.innovafood.com/
https://www.youtube.com/watch?v=ryjGf9mIVkc

### Actionable Steps

Contact InnovaFeed through their website to inquire about their production processes and best practices. Email contact form available on their website.
Research publications and articles about InnovaFeed's operations to gain insights into their technology and business model.
Attend industry conferences and events where InnovaFeed representatives may be present to network and learn more about their experiences.

### Rationale for Suggestion

While located in France, InnovaFeed's project is relevant due to its large scale and focus on efficient, sustainable insect protein production. It provides a benchmark for the user's pilot project and offers insights into the challenges and opportunities of scaling insect farming. Although the geographical context is different, the operational and technological aspects are highly applicable.
## Suggestion 3 - Aspire Food Group Cricket Production Facility

Aspire Food Group operates a cricket production facility in London, Ontario, Canada. This facility focuses on producing crickets for human consumption, utilizing advanced automation and data-driven optimization. The project aims to demonstrate the viability of cricket farming as a sustainable and scalable food source.

### Success Metrics

High cricket production yields.
Efficient resource utilization.
Successful commercialization of cricket-based food products.
Positive consumer feedback and market acceptance.
Adherence to food safety standards and regulations.

### Risks and Challenges Faced

Optimizing rearing conditions for cricket growth and health.
Maintaining consistent product quality and safety.
Automating harvesting and processing operations.
Building consumer acceptance of cricket-based food products.
Securing regulatory approvals for cricket farming and food products.

### Where to Find More Information

https://www.aspirefg.com/
https://www.youtube.com/watch?v=e2gCjJnd-nk

### Actionable Steps

Contact Aspire Food Group through their website to inquire about their production processes and best practices. Use the contact form available on their website.
Research publications and articles about Aspire Food Group's operations to gain insights into their technology and business model.
Follow Aspire Food Group on social media to stay updated on their latest developments and initiatives.

### Rationale for Suggestion

This project is relevant due to its focus on cricket farming for human consumption and its emphasis on automation and data-driven optimization. It provides valuable insights into the challenges and opportunities of building consumer acceptance for insect-based food products. While geographically distant, the focus on crickets and human consumption makes it highly relevant.

## Summary

Based on the provided project plan for establishing a pilot house cricket farm in Western Jutland, Denmark, the following projects are recommended as references. These projects offer insights into controlled environment agriculture, insect farming, and sustainable food production, with a focus on overcoming regulatory, technical, and market acceptance challenges.