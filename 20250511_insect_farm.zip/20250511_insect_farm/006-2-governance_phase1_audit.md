
## Audit - Corruption Risks

- Bribery of Danish Veterinary and Food Administration officials to expedite permits or overlook non-compliance issues.
- Conflicts of interest in the selection of cricket feed suppliers, favoring suppliers with personal connections over those offering the best value.
- Kickbacks from equipment suppliers in exchange for inflated contracts or preferential treatment.
- Misuse of project funds for personal expenses disguised as legitimate business costs.
- Trading favors with local restaurants/retailers for preferential partnerships, potentially compromising quality or ethical standards.

## Audit - Misallocation Risks

- Overspending on facility setup or equipment without proper justification or competitive bidding.
- Inefficient allocation of personnel time, with employees focusing on less critical tasks at the expense of production optimization.
- Unauthorized use of project assets, such as vehicles or equipment, for personal purposes.
- Poor record-keeping of feed consumption and cricket growth, hindering data analysis and optimization efforts.
- Misreporting of production progress or financial results to secure continued funding or positive stakeholder perception.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, including expense reports, invoices, and bank statements, to detect any irregularities.
- Perform periodic reviews of contracts with suppliers and partners to ensure fair pricing and compliance with ethical standards.
- Implement a workflow for expense approvals, requiring multiple levels of authorization for significant expenditures.
- Conduct regular compliance checks to ensure adherence to Danish food safety regulations and environmental standards, with documentation of findings.
- Engage an external auditor to conduct a post-project audit to assess overall project performance, financial management, and compliance with regulations.

## Audit - Transparency Measures

- Establish a project progress dashboard accessible to stakeholders, displaying key performance indicators such as cricket production volume, mortality rates, and financial performance.
- Publish minutes of key project meetings, including discussions on budget allocations, risk assessments, and regulatory compliance, on a secure online platform.
- Implement a whistleblower mechanism allowing employees and stakeholders to report suspected fraud, corruption, or ethical violations anonymously.
- Make relevant project policies and reports, such as the waste management plan and environmental impact assessment, publicly available on the project website.
- Document the selection criteria and rationale for major decisions, such as vendor selection and technology choices, to ensure transparency and accountability.