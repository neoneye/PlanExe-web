**Budget Request Exceeding PMO Authority (100,000 DKK)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review due to potential impact on overall project budget and ROI.
Negative Consequences: Potential budget overrun, project delays, or reduced project scope.

**Critical Risk Materialization (e.g., Regulatory Permit Denial)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval of revised mitigation plan
Rationale: Materialization of a critical risk threatens project viability and requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, potential legal penalties, or project cancellation.

**PMO Deadlock on Vendor Selection (Conflicting Proposals)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of proposals and selection by vote
Rationale: Inability of the PMO to reach a consensus on a key vendor selection necessitates higher-level arbitration to ensure project progress.
Negative Consequences: Project delays, suboptimal vendor selection, or increased costs.

**Proposed Major Scope Change (e.g., Altering Production Methods)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval based on impact assessment
Rationale: Significant changes to the project scope require strategic alignment and assessment of potential impacts on budget, timeline, and project goals.
Negative Consequences: Project delays, budget overruns, failure to meet project goals, or misalignment with organizational strategy.

**Reported Ethical Concern (e.g., Violation of Food Safety Standards)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to CEO and Legal Counsel
Rationale: Ethical violations require independent review and potential corrective action to ensure compliance and maintain project integrity.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, or project cancellation.

**Stakeholder Engagement Group cannot resolve Community Objections**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of objections and proposed solutions, followed by vote.
Rationale: Unresolved community objections can significantly impact project success and require strategic intervention and resource allocation.
Negative Consequences: Project delays, reputational damage, loss of community support, or project cancellation.