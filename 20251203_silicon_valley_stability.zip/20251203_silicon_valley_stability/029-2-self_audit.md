Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on social and economic issues related to AI-driven unemployment, which are not physics-related.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (stability framework) + market (Silicon Valley) + tech/process (AI-driven unrest management) + policy (multi-agency coordination) without independent evidence at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Lead / Validation Report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions strategic concepts like 'Economic Support Model' and 'Information Control Policy' without defining their business-level mechanism-of-action, owner, or measurable outcomes. The plan lacks one-pagers defining these strategic concepts.

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining the mechanism-of-action, identifying an owner, and establishing measurable outcomes. Due: 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, social, operational, etc.) and proposes mitigation strategies. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Information Control Policy could undermine trust" but doesn't map the cascade.

**Mitigation**: Risk Management Team: Expand the risk register to explicitly map risk cascades and second-order effects for each identified risk. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. There is no mention of permit lead times or a schedule of required approvals. The plan does not identify which permits are needed.

**Mitigation**: Project Manager: Create a permit/approval matrix with required permits, lead times, and dependencies. Due: 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a $1.5 billion budget but does not specify the funding sources, their status (LOI/term sheet/closed), the draw schedule, or the runway length. The plan does not include a financing plan listing sources/status, draw schedule, and covenants.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources, their status, draw schedule, covenants, and runway length. Due: 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a $1.5B budget but lacks vendor quotes or scale-appropriate benchmarks normalized by area. There is no cost per m²/ft² calculation or comparison to similar projects. The plan does not include vendor quotes or normalized per-area cost benchmarks.

**Mitigation**: CFO: Obtain ≥3 vendor quotes, normalize costs per m²/ft², benchmark against similar projects, and adjust the budget or de-scope. Due: 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., unemployment increases) as single numbers without providing a range or discussing alternative scenarios. For example, the goal statement mentions "AI-driven workforce displacement reaching 15%+ mass unemployment" without a sensitivity analysis.

**Mitigation**: Project Team: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the AI-driven unemployment projection. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. The plan does not include any engineering artifacts.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Emergency Powers Declaration" and "Permits for temporary resource centers" without providing evidence that these are obtainable or have been applied for. The plan does not include evidence of application or approval for these permits.

**Mitigation**: Legal Team: Obtain evidence of application or approval for the Emergency Powers Declaration and permits for temporary resource centers. Due: 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the "Economic Support Model" is mentioned as a key deliverable, but the plan lacks specific, verifiable qualities or acceptance criteria. The plan does not include SMART acceptance criteria for the Economic Support Model.

**Mitigation**: Economic Support Program Manager: Define SMART criteria for the Economic Support Model, including a KPI for program participation rate (e.g., 80% of eligible workers enrolled) by Q1 2026.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan bans technologies like Blockchain, VR/AR, DAO, GDPR, Digital ID, UBI, and Universal Basic Services. It does not appear to directly support the core project goals of preventing unrest and protecting civil liberties.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of each banned technology, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 60 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the 'Inter-Agency Liaison Coordinator' role, but the plan does not include evidence that this role is fillable. The plan does not include a talent market assessment for this role.

**Mitigation**: HR Team: Conduct a talent market assessment for the Inter-Agency Liaison Coordinator role, including salary benchmarks and candidate availability, to validate the feasibility of filling this critical role within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Emergency Powers Declaration" and "Permits for temporary resource centers" without providing evidence that these are obtainable or have been applied for. The plan does not include evidence of application or approval for these permits.

**Mitigation**: Legal Team: Obtain evidence of application or approval for the Emergency Powers Declaration and permits for temporary resource centers. Due: 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions economic support mechanisms and retraining programs, but lacks a detailed strategy for long-term funding beyond the initial $1.5 billion. The plan does not include a long-term funding strategy.

**Mitigation**: CFO: Develop an operational sustainability plan including a long-term funding strategy, maintenance schedule, and technology roadmap. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies physical locations (Silicon Valley, EOC, convention center, community centers) but lacks evidence of zoning compliance, occupancy limits, or fire load assessments. The plan does not include zoning compliance reports.

**Mitigation**: Facilities Team: Conduct a fatal-flaw screen of identified physical locations, including zoning compliance, occupancy limits, and fire load assessments. Due: 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions reliance on external vendors but lacks details on SLAs, geographic distribution, or tested failover plans. "Reliance on external vendors. Disruptions could hinder response, no geographical distribution plan."

**Mitigation**: Supply Chain Risk Analyst: Secure SLAs with key vendors, diversify suppliers, develop tested failover plans, and create a geographical distribution plan. Due: 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Economic Support Model and Community Engagement Approach have conflicting incentives. Economic Support aims for efficient resource allocation, while Community Engagement prioritizes community-led initiatives, potentially leading to disagreements on resource distribution.

**Mitigation**: Project Lead: Define a shared OKR for the Economic Support Model and Community Engagement Approach focused on a measurable outcome like 'Increase community resilience score by 10% by Q4 2027'.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board to the project plan. Due: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (reliance on retraining, undefined metrics, inter-agency cooperation) that are strongly coupled. Failure in inter-agency governance (Operational Risk) can cascade into Financial Risk (misallocation) and Social Risk (undermined trust).

**Mitigation**: Project Lead: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO‑GO/contingency thresholds. Due: 90 days.