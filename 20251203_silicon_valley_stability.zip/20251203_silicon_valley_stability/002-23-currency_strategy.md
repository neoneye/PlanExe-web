This plan involves money.

## Currencies

- **USD:** The project is based in Silicon Valley, California, USA.

**Primary currency:** USD

**Currency strategy:** The project is local to the USA, so USD will be used for all transactions. No additional international risk management is needed.