A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Economic Support Model will be effectively implemented across all demographics. | Conduct a pilot program with diverse demographic groups and measure participation rates. | Participation rates vary significantly (more than 20%) across different demographic groups. |
| A2 | The Technology Deployment Approach will be accepted by the public without significant resistance. | Conduct a public opinion survey on the proposed technology deployment approach. | More than 40% of respondents express strong concerns about privacy or civil liberties. |
| A3 | The Inter-Agency Governance Structure will facilitate efficient and effective decision-making during a crisis. | Conduct a tabletop exercise simulating a major unrest event and observe inter-agency coordination. | Significant delays (more than 2 hours) in decision-making or conflicting actions between agencies occur during the exercise. |
| A4 | Displaced workers will be willing and able to relocate to areas with available jobs. | Survey displaced workers regarding their willingness to relocate and identify potential barriers. | Less than 50% of displaced workers express willingness to relocate, or significant barriers (e.g., family ties, housing costs) are identified. |
| A5 | Community organizations will be willing and able to effectively partner with government agencies. | Conduct outreach to key community organizations and assess their willingness to participate in the project. | Key community organizations decline to participate or express significant concerns about partnering with government agencies. |
| A6 | The supply chain for essential resources (e.g., food, water, medical supplies) will remain stable during periods of unrest. | Conduct a stress test of the supply chain by simulating a major disruption and assessing its ability to meet demand. | Significant shortages (more than 20%) of essential resources are identified during the stress test. |
| A7 | The public will accurately interpret and respond to official communications during times of unrest. | Test public comprehension of sample emergency communications through surveys and focus groups. | More than 30% of participants misinterpret key information or express confusion about the instructions. |
| A8 | Existing emergency shelters and facilities will be adequate to house displaced individuals during unrest. | Conduct a capacity assessment of existing emergency shelters and compare it to projected displacement numbers. | Existing shelters can accommodate less than 70% of projected displaced individuals. |
| A9 | AI companies will be willing to share data and expertise to aid in predicting and managing unrest. | Engage with major AI companies to assess their willingness to share relevant data and expertise. | Major AI companies decline to share data or expertise, citing proprietary concerns or legal restrictions. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Bureaucratic Black Hole | Process/Financial | A1 | Economic Support Program Manager | CRITICAL (16/25) |
| FM2 | The Panopticon Panic | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Gridlock Gamble | Market/Human | A3 | Inter-Agency Liaison Coordinator | CRITICAL (15/25) |
| FM4 | The Exodus Enigma | Market/Human | A4 | Economic Support Program Manager | CRITICAL (16/25) |
| FM5 | The Alliance Aversion | Market/Human | A5 | Community Engagement Specialist | CRITICAL (15/25) |
| FM6 | The Supply Chain Siege | Technical/Logistical | A6 | Supply Chain Risk Analyst | HIGH (10/25) |
| FM7 | The Babel Breakdown | Market/Human | A7 | Communication and Information Dissemination Manager | CRITICAL (16/25) |
| FM8 | The Shelter Shortfall | Technical/Logistical | A8 | Resource Allocation Program Manager | CRITICAL (15/25) |
| FM9 | The Data Desertion | Process/Financial | A9 | Inter-Agency Liaison Coordinator | HIGH (12/25) |


### Failure Modes

#### FM1 - The Bureaucratic Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Economic Support Program Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The Economic Support Model, designed to provide retraining and financial assistance, becomes mired in bureaucratic processes. Key contributing factors include:
*   Complex application procedures disproportionately affect low-income individuals.
*   Lack of multilingual support hinders access for non-English speakers.
*   Insufficient outreach to marginalized communities results in low participation rates.
*   The result is that funds allocated for economic support are not effectively distributed, leading to increased economic hardship and social unrest.

##### Early Warning Signs
- Application processing times exceed 30 days.
- Less than 10% of eligible individuals from marginalized communities have applied for assistance.
- The call center abandonment rate exceeds 15%.

##### Tripwires
- Application approval rate <= 50% after 60 days.
- Funds disbursed to marginalized communities <= 20% of allocated budget.
- Average time to resolve applicant inquiries >= 7 days.

##### Response Playbook
- Contain: Immediately simplify application procedures and provide multilingual support.
- Assess: Conduct a comprehensive review of the application process to identify bottlenecks.
- Respond: Implement targeted outreach programs to marginalized communities and streamline the application process.


**STOP RULE:** Economic Support Model fails to disburse at least 75% of allocated funds within the first year.

---

#### FM2 - The Panopticon Panic

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Technology Deployment Approach, intended to enhance situational awareness, backfires due to public backlash. Key contributing factors include:
*   Deployment of facial recognition technology triggers widespread privacy concerns.
*   Lack of transparency regarding data collection and usage erodes public trust.
*   Algorithmic bias in predictive policing leads to discriminatory outcomes.
*   The result is that the public actively resists the technology, leading to protests and civil disobedience, rendering the system ineffective.

##### Early Warning Signs
- Online petitions against the technology deployment gain significant traction (over 10,000 signatures).
- Civil rights organizations file lawsuits challenging the legality of the technology.
- Social media sentiment analysis indicates a sharp increase in negative sentiment towards the technology.

##### Tripwires
- Public approval rating of technology <= 30% based on independent polls.
- Number of legal challenges filed by civil rights organizations >= 3.
- False positive rate of facial recognition system >= 5%.

##### Response Playbook
- Contain: Immediately suspend the use of facial recognition technology and review data privacy policies.
- Assess: Conduct a comprehensive review of the technology deployment approach to address privacy concerns.
- Respond: Implement enhanced transparency measures, including public disclosure of data collection and usage practices, and establish an independent oversight board.


**STOP RULE:** Legal injunction prohibits the use of key surveillance technologies.

---

#### FM3 - The Gridlock Gamble

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Inter-Agency Liaison Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Inter-Agency Governance Structure, designed to facilitate efficient decision-making, collapses under pressure during a major unrest event. Key contributing factors include:
*   Conflicting priorities between agencies lead to delayed responses.
*   Lack of clear lines of authority results in confusion and inaction.
*   Communication breakdowns hinder coordination and information sharing.
*   The result is that the response to the unrest is slow and uncoordinated, leading to escalation and widespread damage.

##### Early Warning Signs
- Inter-agency communication response times exceed 1 hour during simulated events.
- Conflicting directives are issued by different agencies during simulated events.
- Key decision-making positions remain unfilled for more than 2 weeks.

##### Tripwires
- Average decision-making time during simulated unrest >= 3 hours.
- Number of conflicting directives issued by different agencies >= 2 during a single event.
- Key personnel vacancies within the Inter-Agency Task Force >= 20%.

##### Response Playbook
- Contain: Immediately activate a pre-defined chain of command and establish clear communication channels.
- Assess: Conduct a rapid assessment of the governance structure to identify bottlenecks and communication breakdowns.
- Respond: Implement emergency protocols to streamline decision-making and improve inter-agency coordination, including assigning a single incident commander with overall authority.


**STOP RULE:** Multiple (3 or more) major incidents of unrest occur due to failures in inter-agency coordination.

---

#### FM4 - The Exodus Enigma

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Economic Support Program Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The plan assumes displaced workers will readily relocate for new job opportunities, but this proves false. Key contributing factors include:
*   Strong family and community ties prevent many from leaving Silicon Valley.
*   High housing costs in other tech hubs deter relocation, even with job offers.
*   Lack of financial resources to cover moving expenses and initial living costs elsewhere.
*   The result is that retraining programs in Silicon Valley fail to translate into actual employment, as workers are unwilling or unable to move to where the jobs are, leading to continued unemployment and social unrest.

##### Early Warning Signs
- Retraining program graduates decline job offers requiring relocation at a rate exceeding 60%.
- Housing costs in potential relocation areas increase by more than 15% within a year.
- Applications for relocation assistance programs remain consistently low (less than 20% of eligible workers).

##### Tripwires
- Relocation rate of retrained workers <= 25% after 1 year.
- Average cost of housing in target relocation areas >= $3000/month.
- Relocation assistance applications <= 10% of eligible workers.

##### Response Playbook
- Contain: Immediately offer enhanced relocation assistance packages, including subsidized housing and job placement support in new locations.
- Assess: Conduct a survey to understand the specific barriers preventing relocation and identify potential solutions.
- Respond: Partner with companies in other regions to create remote work opportunities and reduce the need for relocation.


**STOP RULE:** Relocation rate of retrained workers remains below 10% after implementing enhanced assistance programs.

---

#### FM5 - The Alliance Aversion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Community Engagement Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The plan relies on strong partnerships with community organizations, but these partnerships fail to materialize. Key contributing factors include:
*   Historical distrust of government agencies among community leaders.
*   Conflicting agendas and priorities between government and community groups.
*   Concerns about government control and potential co-option of community initiatives.
*   The result is that community engagement efforts are ineffective, leading to a lack of trust and cooperation, hindering the plan's ability to address the needs of the affected population.

##### Early Warning Signs
- Key community organizations decline invitations to participate in advisory boards.
- Public statements from community leaders express skepticism or opposition to the plan.
- Attendance at community forums remains consistently low (less than 50 participants).

##### Tripwires
- Participation rate of community organizations in key initiatives <= 30%.
- Negative sentiment towards the plan expressed by community leaders >= 50% in public forums.
- Community forum attendance <= 25% of target population.

##### Response Playbook
- Contain: Immediately initiate dialogue with skeptical community leaders to address their concerns and build trust.
- Assess: Conduct a review of the community engagement strategy to identify areas for improvement and address potential conflicts of interest.
- Respond: Empower community-led initiatives and provide resources without imposing government control, demonstrating a commitment to genuine partnership.


**STOP RULE:** Major community organizations publicly withdraw their support for the plan.

---

#### FM6 - The Supply Chain Siege

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Supply Chain Risk Analyst
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The plan assumes a stable supply chain for essential resources, but this assumption is shattered during a major unrest event. Key contributing factors include:
*   Road closures and transportation disruptions prevent the delivery of food, water, and medical supplies.
*   Panic buying and hoarding deplete available resources, creating artificial shortages.
*   Cyberattacks target logistics and distribution systems, disrupting supply chain operations.
*   The result is that essential resources become scarce, leading to increased desperation and further escalating the unrest.

##### Early Warning Signs
- Transportation routes are disrupted due to protests or road closures.
- Reports of panic buying and hoarding increase significantly.
- Cybersecurity alerts indicate potential threats to logistics and distribution systems.

##### Tripwires
- Availability of essential resources (food, water, medical supplies) decreases by >= 40% in affected areas.
- Transportation routes are blocked for >= 24 hours.
- Cyberattacks targeting logistics systems increase by >= 50%.

##### Response Playbook
- Contain: Immediately activate emergency supply routes and coordinate with law enforcement to ensure safe passage of essential resources.
- Assess: Conduct a rapid assessment of the supply chain to identify bottlenecks and potential vulnerabilities.
- Respond: Implement rationing measures to ensure equitable distribution of available resources and deploy cybersecurity countermeasures to protect logistics systems.


**STOP RULE:** Widespread shortages of essential resources persist for more than 72 hours despite emergency measures.

---

#### FM7 - The Babel Breakdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Communication and Information Dissemination Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The plan relies on clear and effective communication to the public, but this fails due to misinterpretations and confusion. Key contributing factors include:
*   Complex language and jargon used in official communications.
*   Lack of culturally sensitive messaging for diverse communities.
*   Spread of misinformation and rumors that contradict official information.
*   The result is that the public fails to understand or follow instructions, leading to panic, disorganization, and increased unrest.

##### Early Warning Signs
- Social media sentiment analysis indicates widespread confusion and misinterpretation of official communications.
- Call centers receive a surge of inquiries seeking clarification on emergency instructions.
- Compliance with evacuation orders or other directives remains consistently low (less than 60%).

##### Tripwires
- Comprehension rate of official communications <= 70% based on public surveys.
- Call center inquiry volume related to communication clarification >= 50% increase.
- Compliance rate with emergency directives <= 50%.

##### Response Playbook
- Contain: Immediately simplify official communications and translate them into multiple languages.
- Assess: Conduct a rapid assessment of communication effectiveness through surveys and focus groups.
- Respond: Implement targeted communication campaigns to address specific areas of confusion and counter misinformation, using trusted community messengers.


**STOP RULE:** Widespread misinterpretation of official communications leads to significant casualties or property damage.

---

#### FM8 - The Shelter Shortfall

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Resource Allocation Program Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The plan assumes adequate emergency shelter capacity, but this proves false during a major unrest event. Key contributing factors include:
*   Existing shelters are located in areas inaccessible due to transportation disruptions.
*   Shelters lack sufficient resources (e.g., food, water, medical supplies) to support displaced individuals.
*   Shelters are not equipped to accommodate individuals with disabilities or other special needs.
*   The result is that many displaced individuals are left without adequate shelter, leading to increased hardship, health risks, and potential for further unrest.

##### Early Warning Signs
- Capacity of existing shelters is consistently below 80% during simulated displacement events.
- Reports of overcrowding and resource shortages at existing shelters increase significantly.
- Accessibility audits reveal significant barriers for individuals with disabilities at existing shelters.

##### Tripwires
- Shelter capacity utilization rate >= 95% during a simulated event.
- Resource shortages (food, water, medical supplies) reported at >= 50% of shelters.
- Accessibility complaints from individuals with disabilities >= 10% of shelter occupants.

##### Response Playbook
- Contain: Immediately identify and secure additional shelter locations, including community centers and schools.
- Assess: Conduct a rapid assessment of shelter capacity and resource needs, prioritizing vulnerable populations.
- Respond: Deploy mobile resource units to provide food, water, medical supplies, and accessibility support to underserved shelters and unsheltered individuals.


**STOP RULE:** Significant numbers of displaced individuals (more than 500) remain without adequate shelter for more than 24 hours.

---

#### FM9 - The Data Desertion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Inter-Agency Liaison Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The plan relies on data and expertise from AI companies to predict and manage unrest, but these companies are unwilling to share. Key contributing factors include:
*   Concerns about protecting proprietary data and algorithms.
*   Legal restrictions and liability concerns related to data sharing.
*   Lack of trust in government agencies to protect sensitive information.
*   The result is that the plan lacks the data-driven insights needed to effectively predict and respond to unrest, leading to delayed interventions and inefficient resource allocation.

##### Early Warning Signs
- Major AI companies decline invitations to participate in data-sharing initiatives.
- Legal challenges are filed against data-sharing agreements with government agencies.
- Internal memos from AI companies express concerns about data privacy and security risks.

##### Tripwires
- Participation rate of major AI companies in data-sharing initiatives <= 25%.
- Legal challenges filed against data-sharing agreements >= 2.
- Internal data privacy concerns raised by AI company employees >= 10% based on internal surveys.

##### Response Playbook
- Contain: Immediately explore alternative data sources and predictive modeling techniques.
- Assess: Conduct a review of data-sharing agreements to address legal and proprietary concerns.
- Respond: Offer incentives for data sharing, such as liability protection and recognition for contributing to public safety, and establish secure data enclaves to protect proprietary information.


**STOP RULE:** The plan lacks sufficient data to effectively predict and respond to unrest, rendering key interventions ineffective.
