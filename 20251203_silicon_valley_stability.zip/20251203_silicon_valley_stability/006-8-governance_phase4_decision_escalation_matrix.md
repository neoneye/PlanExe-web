**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, delays in project implementation, and failure to meet strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: The PMO cannot handle the risk with existing resources or approved plans, requiring strategic guidance and resource allocation from the Steering Committee.
Negative Consequences: Project failure, significant delays, reputational damage, and potential harm to stakeholders.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO is unable to reach a consensus on a critical vendor, requiring impartial arbitration and a decision at a higher level to avoid delays.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A significant change to the project scope impacts strategic objectives, budget, and timeline, requiring Steering Committee approval.
Negative Consequences: Project misalignment with strategic goals, budget overruns, and delays in project completion.

**Reported Ethical Concern**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review and investigation to ensure adherence to ethical standards and legal requirements.
Negative Consequences: Legal penalties, reputational damage, and erosion of public trust.

**Stakeholder Engagement Group disagreement with PMO on community outreach strategy**
Escalation Level: Project Management Office
Approval Process: Project Manager reviews recommendations and makes final decision, consulting with Steering Committee if necessary.
Rationale: Ensures community concerns are addressed while maintaining project alignment and efficiency.
Negative Consequences: Reduced community participation, increased social division, and project delays.

**Ethics and Compliance Committee identifies a significant ethical breach or compliance failure**
Escalation Level: Governor of California
Approval Process: Governor reviews the findings and determines appropriate action, potentially including halting project activities.
Rationale: Ensures the highest level of accountability and oversight for critical ethical and compliance issues.
Negative Consequences: Severe legal penalties, significant reputational damage, and loss of public trust.