### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Governor's Office, CalOES, Department of Justice, National Guard, Silicon Valley Local Government, Civil Liberties Expert, Risk Management Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Incorporate feedback and finalize the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback Received

### 4. Senior Sponsor (Governor's Office) formally appoints Project Steering Committee Chair (Representative from the Governor's Office).

**Responsible Body/Role:** Governor's Office

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- SteerCo Chair Appointed

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee Chair confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Governor's Office

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email
- SteerCo Members Confirmed

**Dependencies:**

- SteerCo Chair Appointed
- Final SteerCo ToR v1.0

### 6. Schedule and hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Confirmed
- Final SteerCo ToR v1.0

### 7. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 8. Circulate Draft Ethics and Compliance Committee ToR for review by nominated members (Legal Counsel, Representative from the California Department of Justice, Independent Expert in Civil Liberties, Independent Expert in Data Privacy, Representative from a Community Organization, Project Manager or Designee).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 9. Incorporate feedback and finalize the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0
- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1 circulated for review
- Feedback Received

### 10. Senior Sponsor (Governor's Office) formally appoints Ethics and Compliance Committee Chair (Legal Counsel).

**Responsible Body/Role:** Governor's Office

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Ethics and Compliance Committee Chair Appointed

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 11. Ethics and Compliance Committee Chair confirms membership of the Ethics and Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email
- Ethics and Compliance Committee Members Confirmed

**Dependencies:**

- Ethics and Compliance Committee Chair Appointed
- Final Ethics and Compliance Committee ToR v1.0

### 12. Schedule and hold the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Minutes with Action Items

**Dependencies:**

- Ethics and Compliance Committee Members Confirmed
- Final Ethics and Compliance Committee ToR v1.0

### 13. Project Manager establishes the PMO team and defines roles and responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Team Established
- Roles and Responsibilities Defined

**Dependencies:**

- Project Start
- Project Plan Approved

### 14. Project Manager develops project management templates and processes.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Processes

**Dependencies:**

- PMO Team Established

### 15. Project Manager sets up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting System

**Dependencies:**

- Project Management Templates
- Project Management Processes

### 16. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Established
- Project Tracking System
- Reporting System

### 17. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 18. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Stakeholder Engagement Coordinator, Representative from a Community Organization, Representative from a Displaced Workers Advocacy Group, Representative from an AI Company, Communications Officer (PMO), Representative from Local Government).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 19. Incorporate feedback and finalize the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0
- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1 circulated for review
- Feedback Received

### 20. Senior Sponsor (Governor's Office) formally appoints Stakeholder Engagement Group Chair (Stakeholder Engagement Coordinator).

**Responsible Body/Role:** Governor's Office

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Stakeholder Engagement Group Chair Appointed

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 21. Stakeholder Engagement Group Chair confirms membership of the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Coordinator

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email
- Stakeholder Engagement Group Members Confirmed

**Dependencies:**

- Stakeholder Engagement Group Chair Appointed
- Final Stakeholder Engagement Group ToR v1.0

### 22. Schedule and hold the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Members Confirmed
- Final Stakeholder Engagement Group ToR v1.0

### 23. Following the initial kick-off meeting, the Project Steering Committee begins regular quarterly meetings.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Month 3 (and ongoing quarterly)

**Key Outputs/Deliverables:**

- Meeting Agendas
- Meeting Minutes with Action Items

**Dependencies:**

- Project Steering Committee Initial Kick-off Meeting

### 24. Following the initial kick-off meeting, the Ethics and Compliance Committee begins regular monthly meetings.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Month 2 (and ongoing monthly)

**Key Outputs/Deliverables:**

- Meeting Agendas
- Meeting Minutes with Action Items

**Dependencies:**

- Ethics and Compliance Committee Initial Kick-off Meeting

### 25. Following the initial kick-off meeting, the Stakeholder Engagement Group begins regular bi-weekly meetings.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 7 (and ongoing bi-weekly)

**Key Outputs/Deliverables:**

- Meeting Agendas
- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Initial Kick-off Meeting