### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 3. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start

### 4. Circulate Draft SteerCo ToR for review by Senior Management Representative, Finance Director, Marketing Director, Legal Counsel, and Independent External Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Senior Management Representative Identified
- Finance Director Identified
- Marketing Director Identified
- Legal Counsel Identified
- Independent External Advisor Identified

### 5. Circulate Draft Ethics & Compliance Committee ToR for review by Legal Counsel, Compliance Officer, Internal Audit Representative, HR Representative, and Independent External Ethics Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Legal Counsel Identified
- Compliance Officer Identified
- Internal Audit Representative Identified
- HR Representative Identified
- Independent External Ethics Advisor Identified

### 6. Circulate Draft Technical Advisory Group ToR for review by Senior Technician, Electrical Engineer, Automation System Vendor Representative, Building Inspector, and Independent External Technical Consultant.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Senior Technician Identified
- Electrical Engineer Identified
- Automation System Vendor Representative Identified
- Building Inspector Identified
- Independent External Technical Consultant Identified

### 7. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary from SteerCo ToR Review

### 8. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary from Ethics & Compliance Committee ToR Review

### 9. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary from Technical Advisory Group ToR Review

### 10. Senior Management Representative formally appointed as Chairperson of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Legal Counsel formally appointed as Chairperson of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 12. Senior Technician formally appointed as Chairperson of the Technical Advisory Group.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 13. Formally establish the Project Steering Committee with confirmed membership (Senior Management Representative, Finance Director, Marketing Director, Legal Counsel, Project Manager, Independent External Advisor).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment of SteerCo Chairperson
- All SteerCo Members Identified

### 14. Formally establish the Ethics & Compliance Committee with confirmed membership (Legal Counsel, Compliance Officer, Internal Audit Representative, HR Representative, Independent External Ethics Advisor).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Appointment of Ethics & Compliance Committee Chairperson
- All Ethics & Compliance Committee Members Identified

### 15. Formally establish the Technical Advisory Group with confirmed membership (Senior Technician, Electrical Engineer, Automation System Vendor Representative, Building Inspector, Independent External Technical Consultant).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Appointment of Technical Advisory Group Chairperson
- All Technical Advisory Group Members Identified

### 16. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Established
- SteerCo ToR Approved

### 17. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Established
- Ethics & Compliance Committee ToR Approved

### 18. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Established
- Technical Advisory Group ToR Approved

### 19. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Start

### 20. PMO develops project management methodology.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Methodology Document

**Dependencies:**

- PMO Kick-off Meeting

### 21. PMO develops project plan template.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Plan Template

**Dependencies:**

- PMO Kick-off Meeting

### 22. PMO sets up project tracking system.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System Established

**Dependencies:**

- PMO Kick-off Meeting

### 23. PMO defines communication protocols.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- PMO Kick-off Meeting