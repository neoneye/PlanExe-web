
## Audit - Corruption Risks

- Bribery of local officials to expedite permits and licenses.
- Kickbacks from construction companies in exchange for awarding contracts.
- Conflicts of interest if project team members have undisclosed relationships with suppliers or contractors.
- Misuse of inside information regarding location selection for personal gain.
- Trading favors with NetEase representatives to gain preferential treatment or access to resources.

## Audit - Misallocation Risks

- Inflated construction costs due to collusion with contractors.
- Unnecessary or overpriced equipment purchases.
- Marketing budget used for personal expenses or unrelated activities.
- Operational reserve funds diverted for unauthorized purposes.
- Double billing or fraudulent invoices from suppliers.

## Audit - Procedures

- Conduct periodic internal audits of financial records, focusing on procurement and expense reports (quarterly).
- Implement a robust contract review process with independent legal oversight for all major contracts (construction, licensing, supply).
- Perform background checks on key personnel involved in procurement and vendor selection (pre-employment and annually).
- Establish a whistleblower mechanism for reporting suspected fraud or corruption (ongoing).
- Conduct a post-project external audit to assess overall financial management and compliance (post-project).

## Audit - Transparency Measures

- Publish a project budget dashboard showing planned vs. actual spending (monthly).
- Document and publish the selection criteria for all major vendors and contractors (pre-selection).
- Maintain detailed records of all project-related expenses and make them available for internal review (ongoing).
- Publish minutes of key project meetings, including discussions on budget, risks, and compliance (monthly).
- Establish a clear and accessible policy on conflicts of interest for all project team members (pre-project).