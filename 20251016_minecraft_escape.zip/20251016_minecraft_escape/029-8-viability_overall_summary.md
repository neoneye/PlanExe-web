- Status: RED
- Confidence: Low
- Recommendation: PROCEED\_WITH\_CAUTION

## Concerns Affecting Viability
| Domain | Status | Reasoning Codes |
|--------|--------|-----------------|
| Rights & Legality | RED | LICENSE\_GAPS, INFOSEC\_GAPS |
| Ecological Integrity | GRAY | Evidence needed: Environmental baseline note \(scope, metrics\) — acceptance criteria: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign\-off\., Cloud carbon estimate v1 \(regions/services\) — acceptance criteria: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard\. |
| Human Stability | YELLOW | TRAINING\_GAPS, TALENT\_UNKNOWN |

## What Flips to GO
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Scope and metrics defined
- Measurement methods documented