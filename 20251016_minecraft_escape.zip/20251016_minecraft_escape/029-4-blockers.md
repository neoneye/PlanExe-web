### B1: Training gaps exist

**Domain:** HumanStability


**Reason Codes:** TRAINING_GAPS, TALENT_UNKNOWN


**Acceptance Tests:**

  - Training needs assessment complete
  - Skills gap analysis report published

**Artifacts Required:**

  - TrainingNeeds\.pdf
  - SkillsGap\.xlsx

**Owner:** HR


**ROM:** MEDIUM cost, 30 days


### B2: Contingency too low

**Domain:** EconomicResilience


**Reason Codes:** CONTINGENCY_LOW


**Acceptance Tests:**

  - \>=10% contingency approved
  - Monte Carlo risk workbook attached

**Artifacts Required:**

  - Budget\_v2\.pdf
  - Risk\_MC\.xlsx

**Owner:** PMO


**ROM:** LOW cost, 14 days


### B3: License gaps exist

**Domain:** Rights_Legality


**Reason Codes:** LICENSE_GAPS


**Acceptance Tests:**

  - License registry complete
  - Gaps list includes remediation owners

**Artifacts Required:**

  - License\_Registry\.xlsx
  - Gaps\_List\.docx

**Owner:** Legal


**ROM:** MEDIUM cost, 45 days


### B4: InfoSec gaps exist

**Domain:** Rights_Legality


**Reason Codes:** INFOSEC_GAPS


**Acceptance Tests:**

  - Threat model covers all STRIDE categories
  - Controls mapped to CIS/NIST

**Artifacts Required:**

  - ThreatModel\.vsdx
  - ControlMapping\.xlsx

**Owner:** Security Architect


**ROM:** HIGH cost, 60 days


### B5: Environmental baseline undefined

**Domain:** EcologicalIntegrity


**Reason Codes:** CLIMATE_UNQUANTIFIED


**Acceptance Tests:**

  - Scope and metrics defined
  - Measurement methods documented

**Artifacts Required:**

  - Env\_Baseline\_v1\.docx

**Owner:** Sustainability Lead


**ROM:** LOW cost, 7 days

