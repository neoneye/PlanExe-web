**Budget Request Exceeding PMO Authority (>¥200,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and impact on overall project profitability.

**Critical Risk Materialization (e.g., Brand License Violation)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and decision, potentially involving legal counsel and Executive Leadership Team.
Rationale: Materialization of a critical risk threatens project viability and requires immediate strategic intervention.
Negative Consequences: Project termination, significant financial losses, legal penalties, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of vendor proposals and selection based on strategic alignment and value.
Rationale: Inability to reach consensus within the PMO necessitates higher-level arbitration to ensure timely progress.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change (e.g., Adding a new room)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and approval based on impact to budget, timeline, and strategic objectives.
Rationale: Significant scope changes impact project resources and require strategic alignment and approval.
Negative Consequences: Budget overruns, project delays, and misalignment with original project goals.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigation and recommendation, potentially leading to disciplinary action or policy changes.
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Design Change impacting Safety**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of Technical Advisory Group recommendation, potentially involving external safety consultants.
Rationale: Safety concerns require a higher level of scrutiny and decision-making authority.
Negative Consequences: Accidents, injuries, legal liabilities, and reputational damage.