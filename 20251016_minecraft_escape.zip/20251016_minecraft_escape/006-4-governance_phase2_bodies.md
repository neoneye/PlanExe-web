### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and ensures alignment with overall business objectives, given the project's budget, brand licensing implications, and potential impact on the company's reputation.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance to the Project Management Office.
- Monitor project progress against key performance indicators (KPIs).
- Approve major changes to project scope, budget, or timeline (above ¥200,000).
- Oversee risk management and mitigation strategies for strategic risks.
- Ensure compliance with brand licensing agreement.
- Resolve escalated issues from the Project Management Office or other governance bodies.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Define escalation procedures.

**Membership:**

- Senior Management Representative (Chairperson)
- Finance Director
- Marketing Director
- Legal Counsel
- Project Manager
- Independent External Advisor (Escape Room Industry)

**Decision Rights:** Strategic decisions related to project scope, budget (above ¥200,000), timeline, and risk management. Approval of major changes to project direction.

**Decision Mechanism:** Decisions made by majority vote. Chairperson has tie-breaking vote. Dissenting opinions are documented in meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review project progress against KPIs.
- Review and approve budget variances.
- Review and approve changes to project scope or timeline.
- Review and approve risk management plans.
- Discuss and resolve escalated issues.
- Brand licensing compliance review.

**Escalation Path:** Executive Leadership Team
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to budget, timeline, and quality standards. Essential for coordinating the various workstreams and managing operational risks.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget (below ¥200,000) and track expenses.
- Monitor project progress and identify potential delays or issues.
- Coordinate project team activities.
- Manage operational risks and implement mitigation strategies.
- Prepare and distribute project status reports.
- Escalate issues to the Project Steering Committee as needed.
- Ensure compliance with internal policies and procedures.

**Initial Setup Actions:**

- Establish project management methodology.
- Develop project plan template.
- Set up project tracking system.
- Define communication protocols.

**Membership:**

- Project Manager (Head of PMO)
- Construction Manager
- Escape Room Designer
- Marketing Manager
- Technician

**Decision Rights:** Operational decisions related to project execution, budget management (below ¥200,000), and resource allocation within approved project plan.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the project team. Unresolved disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review project progress against plan.
- Identify and resolve project issues.
- Review and approve budget requests.
- Review and update risk register.
- Plan upcoming activities.
- Discuss resource allocation.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws, regulations, and licensing agreements, given the potential for corruption risks, brand licensing violations, and data privacy concerns (GDPR implications for customer data).

**Responsibilities:**

- Oversee compliance with all applicable laws, regulations, and licensing agreements.
- Develop and implement ethics and compliance policies and procedures.
- Conduct regular audits to identify and address potential compliance issues.
- Investigate reports of ethical violations or non-compliance.
- Provide training to project team members on ethics and compliance matters.
- Ensure compliance with GDPR and other data privacy regulations.
- Review and approve all marketing materials to ensure compliance with advertising regulations.
- Monitor and address potential conflicts of interest.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule.
- Develop ethics and compliance policies.
- Establish reporting mechanisms for ethical violations.

**Membership:**

- Legal Counsel (Chairperson)
- Compliance Officer
- Internal Audit Representative
- HR Representative
- Independent External Ethics Advisor

**Decision Rights:** Decisions related to ethics and compliance matters, including investigations, disciplinary actions, and policy changes. Authority to halt project activities if ethical or compliance violations are identified.

**Decision Mechanism:** Decisions made by majority vote. Chairperson has tie-breaking vote. Dissenting opinions are documented in meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review compliance with applicable laws, regulations, and licensing agreements.
- Review and approve ethics and compliance policies and procedures.
- Review audit findings and implement corrective actions.
- Investigate reports of ethical violations or non-compliance.
- Review and approve marketing materials.
- Discuss and address potential conflicts of interest.
- GDPR compliance review.

**Escalation Path:** Executive Leadership Team
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical guidance on the design, construction, and operation of the escape room, ensuring the technical feasibility, safety, and reliability of the semi-automated systems.

**Responsibilities:**

- Provide technical expertise on the design and construction of the escape room.
- Evaluate the technical feasibility and safety of the semi-automated systems.
- Review and approve technical specifications for equipment and materials.
- Provide guidance on troubleshooting and resolving technical issues.
- Ensure compliance with building and electrical codes.
- Advise on maintenance and repair procedures.
- Assess the impact of technical changes on project budget and timeline.
- Ensure the security of the automated systems.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Identify and recruit technical experts.
- Establish communication protocols.
- Define scope of technical review.

**Membership:**

- Senior Technician (Chairperson)
- Electrical Engineer
- Automation System Vendor Representative
- Building Inspector
- Independent External Technical Consultant (Escape Room Technology)

**Decision Rights:** Technical decisions related to the design, construction, and operation of the escape room. Authority to recommend changes to technical specifications to ensure safety and reliability.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Senior Technician makes the final decision, in consultation with the Project Manager.

**Meeting Cadence:** As needed, but at least monthly during construction and commissioning.

**Typical Agenda Items:**

- Review technical specifications for equipment and materials.
- Evaluate the technical feasibility and safety of the semi-automated systems.
- Discuss and resolve technical issues.
- Review and approve changes to technical specifications.
- Assess the impact of technical changes on project budget and timeline.
- Review maintenance and repair procedures.
- Security assessment of automated systems.

**Escalation Path:** Project Steering Committee