This plan involves money.

## Currencies

- **CNY:** Local currency for all operational expenses, rent, salaries, and ticket sales in Shanghai.

**Primary currency:** CNY

**Currency strategy:** The Chinese Yuan (CNY) will be used for all transactions. No international currency risk management is needed as the project is entirely local.