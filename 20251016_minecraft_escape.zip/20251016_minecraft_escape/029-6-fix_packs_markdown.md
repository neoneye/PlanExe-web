### FP0: Pre-Commit Gate
- Priority: Immediate
- Blockers:
  - B2
  - B5

### FP1: Address Human Stability Training Deficiencies
- Priority: High
- Blockers:
  - B1

### FP2: Remediate Rights and Legality Gaps
- Priority: Immediate
- Blockers:
  - B3
  - B4