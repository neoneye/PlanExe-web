## Suggestion 1 - e.Deorbit Mission (Clean Space Initiative)

The e.Deorbit mission, part of the European Space Agency's (ESA) Clean Space initiative, aimed to develop and demonstrate the technology for capturing and safely de-orbiting a large piece of space debris. The mission concept involved a dedicated spacecraft equipped with a robotic arm to grapple a defunct satellite and then use its own propulsion system to guide both itself and the debris into the Earth's atmosphere for a controlled re-entry. The project was initiated in the early 2010s but was later re-scoped and evolved into other initiatives.

### Success Metrics

Technology Readiness Levels (TRL) advancement for debris capture technologies.
Development of autonomous rendezvous and docking capabilities.
Demonstration of controlled de-orbiting techniques.
Advancement of space situational awareness (SSA) technologies.

### Risks and Challenges Faced

Technical complexity of rendezvous and capture in a dynamic space environment: Overcome through extensive simulations and testing of robotic arm technologies.
High development costs and funding constraints: Addressed through phased development and international collaboration.
Regulatory and legal uncertainties surrounding active debris removal: Mitigated through engagement with international bodies and development of best practices.
Dual-use concerns related to the technology: Addressed through transparency and adherence to international guidelines.

### Where to Find More Information

ESA Clean Space Initiative: https://www.esa.int/Our_Activities/Space_Engineering_Technology/Clean_Space
e.Deorbit Mission Overview: (Search ESA website for e.Deorbit publications and reports)

### Actionable Steps

Contact the ESA Clean Space Office for detailed technical reports and lessons learned. Email: cleanspace@esa.int
Review publications and presentations from ESA conferences related to space debris removal. Search ESA's publication database.
Connect with engineers and scientists involved in the e.Deorbit project via LinkedIn to gain insights into the technical challenges and solutions.

### Rationale for Suggestion

The e.Deorbit mission is highly relevant as it directly addresses the challenge of active space debris removal using robotic capture techniques, which aligns with the user's project. It provides valuable insights into the technical, regulatory, and financial challenges associated with such a mission. Although the original mission concept was not fully realized, the technology development and lessons learned are directly applicable.
## Suggestion 2 - RemoveDEBRIS Mission

RemoveDEBRIS was an EU-funded research project led by the Surrey Space Centre at the University of Surrey. Launched in 2018, the mission aimed to demonstrate several active debris removal (ADR) technologies in low Earth orbit. These technologies included a net capture system, a harpoon capture system, a drag sail for de-orbiting, and vision-based navigation for rendezvous and docking. The mission successfully demonstrated multiple debris removal techniques.

### Success Metrics

Successful deployment and testing of the net capture system.
Successful deployment and testing of the harpoon capture system.
Successful deployment of the drag sail for de-orbiting.
Demonstration of vision-based navigation for rendezvous and docking.

### Risks and Challenges Faced

Ensuring the safety of the demonstration activities in orbit: Addressed through rigorous testing and simulations.
Achieving accurate rendezvous and capture with non-cooperative targets: Mitigated through advanced sensor technology and control algorithms.
Managing the complexity of multiple technology demonstrations on a single mission: Overcome through careful planning and execution.
Securing funding and international collaboration: Achieved through EU funding and partnerships with multiple organizations.

### Where to Find More Information

RemoveDEBRIS Project Website: (Search for the official RemoveDEBRIS project website via the University of Surrey)
Publications and Reports from the Surrey Space Centre: https://www.surrey.ac.uk/surrey-space-centre
EU CORDIS Database: Search for RemoveDEBRIS project details on the CORDIS website (https://cordis.europa.eu/)

### Actionable Steps

Contact the Surrey Space Centre at the University of Surrey for detailed technical reports and data from the RemoveDEBRIS mission. Email: ssc@surrey.ac.uk
Review publications and presentations from conferences related to space debris removal featuring the RemoveDEBRIS project.
Connect with researchers and engineers involved in the RemoveDEBRIS project via LinkedIn to gain insights into the technical challenges and solutions.

### Rationale for Suggestion

RemoveDEBRIS is highly relevant because it successfully demonstrated multiple active debris removal technologies in orbit, including net and harpoon capture, which are directly applicable to the user's project. It provides valuable practical experience and lessons learned in the deployment and operation of debris removal systems. The project's focus on multiple technologies also aligns with the user's plan to utilize a suite of proven technologies.
## Suggestion 3 - JPOD (Japanese picosatellite deployer)

The Japanese Experiment Module (JEM) Small Satellite Orbital Deployer (J-SSOD), nicknamed JPOD, is a satellite deployment system developed by JAXA and utilized on the International Space Station (ISS). It allows for the deployment of small satellites, including CubeSats, into orbit from the ISS. While not directly involved in debris removal, it provides a framework for the safe and controlled deployment of objects in space, which is relevant to the deployment of debris removal technologies.

### Success Metrics

Number of successful satellite deployments.
Accuracy of orbital insertion for deployed satellites.
Reliability of the deployment mechanism.
Safety of deployment operations for the ISS and crew.

### Risks and Challenges Faced

Ensuring the safety of satellite deployments from the ISS: Addressed through rigorous safety reviews and procedures.
Achieving accurate orbital insertion for deployed satellites: Mitigated through precise deployment mechanisms and trajectory calculations.
Managing the logistics of satellite integration and deployment: Overcome through careful planning and coordination with ISS partners.
Addressing potential interference with other satellites: Mitigated through coordination with space traffic management authorities.

### Where to Find More Information

JAXA J-SSOD/JPOD Information: (Search JAXA's official website for information on J-SSOD/JPOD)
ISS Program Documentation: Search NASA's website for documentation related to the ISS and its utilization for satellite deployment.

### Actionable Steps

Contact JAXA for detailed technical information on the J-SSOD/JPOD system and its deployment procedures. Email: inquire@jaxa.jp
Review publications and presentations from conferences related to small satellite deployment featuring the J-SSOD/JPOD system.
Connect with engineers and scientists involved in the J-SSOD/JPOD project via LinkedIn to gain insights into the technical challenges and solutions.

### Rationale for Suggestion

While not directly related to debris removal, JPOD provides a valuable reference for the safe and controlled deployment of objects in space, which is a critical aspect of deploying debris removal technologies. It demonstrates JAXA's expertise in space deployment systems and highlights the importance of safety and coordination in space operations. Given JAXA's involvement in the user's project, understanding JPOD's operational model is beneficial.

## Summary

The user is planning a large-scale, 15-year, $20 billion international initiative to remove space debris from low Earth orbit, involving NASA, ESA, JAXA, and ISRO, but excluding Roscosmos and CNSA. The project will utilize robotic capture and laser mitigation technologies. The following are reference projects to help inform the planning and execution of this initiative.