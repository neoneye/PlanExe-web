**Purpose:** business

**Purpose Detailed:** Large-scale international space debris removal project with societal and economic benefits, involving multiple space agencies and commercial stakeholders.

**Topic:** Space debris removal initiative