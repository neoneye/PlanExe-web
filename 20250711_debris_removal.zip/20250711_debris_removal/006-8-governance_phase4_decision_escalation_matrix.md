**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO lacks the resources or authority to effectively mitigate the risk, requiring strategic intervention.
Negative Consequences: Project delays, increased costs, or mission failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Vote
Rationale: The PMO cannot reach a consensus, requiring a higher-level decision to avoid delays.
Negative Consequences: Project delays and potential cost increases.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significantly alters the project's objectives and requires strategic alignment.
Negative Consequences: Project failure to meet original objectives, budget overruns, and stakeholder dissatisfaction.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Heads of Agencies
Rationale: Requires independent review and potential disciplinary action to maintain ethical standards.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Unresolved Technical Disagreement**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on TAG Input
Rationale: Technical Advisory Group cannot reach consensus, requiring strategic direction.
Negative Consequences: Implementation of technically unsound or unsafe solutions.