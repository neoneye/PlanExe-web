### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Circulate Draft SteerCo ToR for review by senior representatives from NASA, ESA, JAXA, ISRO, and key commercial stakeholders.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior representatives from NASA, ESA, JAXA, and ISRO formally nominate members for the Project Steering Committee.

**Responsible Body/Role:** NASA, ESA, JAXA, and ISRO Senior Representatives

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Senior Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Nominated Members List

### 6. Project Manager formally confirms Project Steering Committee membership with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email
- Nominated Members List

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation List

### 8. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 9. Project Steering Committee approves the project strategy and objectives.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Project Strategy and Objectives

**Dependencies:**

- Meeting Minutes with Action Items

### 10. Project Manager drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**


### 11. Project Manager finalizes the Project Management Office (PMO) Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Draft PMO ToR v0.1

### 12. Project Manager appoints PMO staff (Deputy Project Manager, Finance Manager, Risk Manager, Communications Manager, Technical Leads, Contract Management Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Staff List

**Dependencies:**

- Final PMO ToR v1.0

### 13. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- PMO Staff List

### 14. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 15. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**


### 16. Circulate Draft TAG ToR for review by technical experts from NASA, ESA, JAXA, ISRO, and commercial stakeholders.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 17. Project Manager incorporates feedback and finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Project Manager, in consultation with NASA, ESA, JAXA, and ISRO, identifies and recruits qualified technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Membership List

**Dependencies:**

- Final TAG ToR v1.0

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- TAG Membership List

### 20. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 21. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**


### 22. Circulate Draft ECC ToR for review by legal experts specializing in international space law and ethics, and representatives from each participating space agency's ethics and compliance departments.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 23. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Project Manager, in consultation with legal experts and space agencies, identifies and recruits qualified members for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- ECC Membership List

**Dependencies:**

- Final ECC ToR v1.0

### 25. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- ECC Membership List

### 26. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 27. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**


### 28. Circulate Draft SEG ToR for review by representatives from each participating space agency's communications and public affairs departments, and independent experts in stakeholder engagement and public relations.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1

### 29. Project Manager incorporates feedback and finalizes the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 30. Project Manager, in consultation with space agencies and PR experts, identifies and recruits qualified members for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- SEG Membership List

**Dependencies:**

- Final SEG ToR v1.0

### 31. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- SEG Membership List

### 32. Hold the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda