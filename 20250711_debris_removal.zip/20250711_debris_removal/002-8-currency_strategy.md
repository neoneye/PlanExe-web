This plan involves money.

## Currencies

- **USD:** NASA headquarters are in the USA, and the project is initially budgeted in USD.
- **EUR:** ESA headquarters are in France, and the Guiana Space Centre is a key location.
- **JPY:** JAXA headquarters are in Japan, and the Tanegashima Space Center is a key location.
- **INR:** ISRO headquarters are in India, and there may be some project activities there.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. EUR, JPY, and INR may be used for local transactions within Europe, Japan, and India, respectively. Hedging strategies should be considered to mitigate exchange rate fluctuations between USD, EUR, JPY, and INR.