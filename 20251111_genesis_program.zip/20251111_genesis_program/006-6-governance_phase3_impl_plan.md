### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Committee ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 5. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 6. Circulate Draft SteerCo ToR for review by nominated members (Director of National Population Strategy, Chief Legal Counsel, Chief Financial Officer, Chief Technology Officer, Director of Public Relations, Independent Ethics Advisor, Representative from the Department of Health and Human Services).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by nominated members (PMO Director, Project Managers, Project Coordinators, Risk Manager, Budget Analyst).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft Ethics Committee ToR for review by nominated members (Independent Ethics Expert, Legal Counsel, Medical Ethicist, Data Privacy Expert, Representative from a civil liberties organization, Representative from the Department of Justice).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics Committee ToR v0.1
- Nominated Members List Available

### 9. Circulate Draft Technical Advisory Group ToR for review by nominated members (Chief Technology Officer, AI Expert, Genetic Engineering Expert, Data Security Expert, IVF Technology Expert, VR Technology Expert, Independent Systems Auditor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 10. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Director of Public Relations, Communications Manager, Community Liaison, Government Affairs Liaison, Representative from a civil liberties organization, Representative from a patient advocacy group).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 11. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 12. Project Manager finalizes the Terms of Reference for the Project Management Office (PMO) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft PMO ToR v0.1

### 13. Project Manager finalizes the Terms of Reference for the Ethics and Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics Committee ToR v0.1

### 14. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.1

### 15. Project Manager finalizes the Terms of Reference for the Stakeholder Engagement Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Stakeholder Engagement Group ToR v0.1

### 16. Senior Sponsor formally appoints the Director of National Population Strategy as the Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Senior Sponsor formally appoints the PMO Director.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 18. Senior Sponsor formally appoints the Independent Ethics Expert as the Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Committee ToR v1.0

### 19. Senior Sponsor formally appoints the Chief Technology Officer as the Technical Advisory Group Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 20. Senior Sponsor formally appoints the Director of Public Relations as the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 21. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 22. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final PMO ToR v1.0

### 23. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics Committee ToR v1.0

### 24. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 25. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final Stakeholder Engagement Group ToR v1.0

### 26. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 27. Hold initial Project Management Office (PMO) kick-off meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 28. Hold initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 29. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 30. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda