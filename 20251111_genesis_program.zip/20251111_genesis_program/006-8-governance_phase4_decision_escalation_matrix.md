**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's financial approval limit of $1 million USD, requiring strategic oversight.
Negative Consequences: Potential budget overruns and impact on other project areas if not properly reviewed.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: Materialization of a critical risk (e.g., legal challenge, widespread public unrest) requires strategic decision-making and resource allocation beyond the PMO's authority.
Negative Consequences: Project delays, increased costs, and potential project failure if the risk is not effectively managed.

**PMO Deadlock on Resource Allocation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Mediation and Decision
Rationale: Disagreement within the PMO on resource allocation requires resolution at a higher level to ensure project alignment.
Negative Consequences: Delays in project execution and inefficient resource utilization if the deadlock is not resolved.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant changes to the project scope (e.g., altering the target population percentage) require strategic approval due to potential impact on project goals and resources.
Negative Consequences: Project misalignment with strategic objectives and potential budget overruns if scope changes are not properly managed.

**Reported Ethical Concern**
Escalation Level: Ethics and Compliance Committee, then Project Steering Committee if unresolved
Approval Process: Ethics Committee Investigation & Recommendation, followed by Steering Committee Decision if needed
Rationale: Allegations of ethical violations (e.g., data privacy breaches, coercion) require independent review and potential corrective action to maintain public trust and legal compliance. If the Ethics and Compliance Committee cannot resolve the issue, it escalates to the Project Steering Committee.
Negative Consequences: Reputational damage, legal penalties, and internal dissent if ethical concerns are not addressed promptly and effectively.

**Technical Failure Impacting Project Timeline by More Than 2 Weeks**
Escalation Level: Technical Advisory Group, then Project Steering Committee if unresolved
Approval Process: Technical Advisory Group Review and Recommendation, followed by Steering Committee Decision if needed
Rationale: Technical failures that significantly impact the project timeline require expert technical advice and potential adjustments to project plans. If the Technical Advisory Group cannot resolve the issue, it escalates to the Project Steering Committee.
Negative Consequences: Project delays, increased costs, and potential project failure if technical issues are not effectively managed.