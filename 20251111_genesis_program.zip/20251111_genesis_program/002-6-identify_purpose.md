**Purpose:** business

**Purpose Detailed:** Societal-scale population management and genetic engineering initiative.

**Topic:** Government-mandated reproduction program to address declining birth rates.