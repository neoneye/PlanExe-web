This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and large-scale transactions within the United States.

**Primary currency:** USD

**Currency strategy:** The project will use USD for all transactions. No additional international risk management is needed as the project is contained within the United States.