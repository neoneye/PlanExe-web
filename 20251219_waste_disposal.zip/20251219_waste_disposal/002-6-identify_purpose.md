**Purpose:** business

**Purpose Detailed:** Discreet and illegal disposal of biohazardous waste for an unspecified commercial or research entity.

**Topic:** Illegal toxic waste disposal