**Budget Request Exceeding Core Project Team Authority ($500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote, with Sponsor tie-breaker
Rationale: Exceeds the financial authority delegated to the Core Project Team, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for uncontrolled spending, budget overruns, and project financial instability.

**Critical Risk Materialization (e.g., Law Enforcement Intervention)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the situation and determine the appropriate course of action, potentially including project shutdown.
Rationale: Represents a significant threat to the project's viability and requires immediate strategic decision-making and resource allocation beyond the Core Project Team's capabilities.
Negative Consequences: Project shutdown, legal prosecution, reputational damage, and financial losses.

**PMO Deadlock on Disposal Method Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the competing proposals, considers the strategic implications, and votes to select the disposal method.
Rationale: Disagreement within the Core Project Team on a key strategic decision requires resolution by the higher-level governance body responsible for overall project direction.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal disposal method.

**Proposed Major Scope Change (e.g., New Mineshaft Location)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed change, assesses its impact on the project's budget, timeline, and risk profile, and approves or rejects the change.
Rationale: Significant changes to the project's scope require strategic review and approval to ensure alignment with overall project objectives and resource constraints.
Negative Consequences: Project delays, budget overruns, increased risks, and potential project failure.

**Reported Ethical Concern (e.g., Potential Bribery)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigates the report, gathers evidence, and makes a recommendation to the Project Steering Committee regarding appropriate action, potentially including halting the project.
Rationale: Ethical violations require independent review and investigation to ensure compliance with ethical standards and legal requirements.
Negative Consequences: Legal penalties, reputational damage, and project shutdown.

**Ethics & Compliance Committee recommends halting the project due to severe ethical violations.**
Escalation Level: Senior Executive Management
Approval Process: Senior Executive Management reviews the Ethics & Compliance Committee's recommendation and makes a final decision on whether to halt the project.
Rationale: The decision to halt a project due to ethical violations has significant strategic and financial implications, requiring approval from the highest level of management.
Negative Consequences: Continued ethical violations, legal penalties, reputational damage, and potential criminal charges.