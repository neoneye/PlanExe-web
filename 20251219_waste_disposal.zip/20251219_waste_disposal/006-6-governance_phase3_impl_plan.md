### 1. Project Sponsor drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start Date
- Project Sponsor Identified

### 2. Project Sponsor shares Draft SteerCo ToR with Legal Counsel, Security Advisor, and Environmental Risk Consultant for review and feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Feedback from Legal Counsel
- Feedback from Security Advisor
- Feedback from Environmental Risk Consultant

**Dependencies:**

- Draft SteerCo ToR v0.1
- Legal Counsel Identified
- Security Advisor Identified
- Environmental Risk Consultant Identified

### 3. Project Sponsor incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback from Legal Counsel, Security Advisor, and Environmental Risk Consultant
- Draft SteerCo ToR v0.1

### 4. Project Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email to SteerCo Chair

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints the remaining members of the Project Steering Committee (Legal Counsel, Security Advisor, Environmental Risk Consultant, Project Manager).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails to SteerCo Members

**Dependencies:**

- Final SteerCo ToR v1.0
- SteerCo Chair Appointed

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- SteerCo Members Appointed
- Final SteerCo ToR v1.0

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, Terms of Reference, and establish communication protocols.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan
- Communication Protocols Defined

**Dependencies:**

- SteerCo Kick-off Meeting Invitation Sent
- Project Plan Drafted

### 8. Project Manager defines team roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start Date

### 9. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 10. Project Manager develops the initial project schedule.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Initial Project Schedule

**Dependencies:**

- Core Project Team Communication Protocols Document

### 11. Project Manager sets up the project tracking system.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System Established

**Dependencies:**

- Initial Project Schedule

### 12. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Kick-off Meeting Invitation

**Dependencies:**

- Project Tracking System Established

### 13. Hold the initial Core Project Team kick-off meeting to review roles, responsibilities, communication protocols, and project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Project Schedule

**Dependencies:**

- Core Project Team Kick-off Meeting Invitation Sent

### 14. Project Sponsor drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start Date

### 15. Project Sponsor shares Draft Ethics & Compliance Committee ToR with Legal Counsel, Environmental Risk Consultant, and Compliance Officer for review and feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1
- Feedback from Legal Counsel
- Feedback from Environmental Risk Consultant
- Feedback from Compliance Officer

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Legal Counsel Identified
- Environmental Risk Consultant Identified
- Compliance Officer Identified

### 16. Project Sponsor incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback from Legal Counsel, Environmental Risk Consultant, and Compliance Officer
- Draft Ethics & Compliance Committee ToR v0.1

### 17. Project Sponsor formally appoints the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email to Ethics & Compliance Committee Chair

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 18. Project Sponsor formally appoints the remaining members of the Ethics & Compliance Committee (Legal Counsel, Environmental Risk Consultant, Compliance Officer, Project Manager, Security Lead).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails to Ethics & Compliance Committee Members

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Ethics & Compliance Committee Chair Appointed

### 19. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Ethics & Compliance Committee Members Appointed
- Final Ethics & Compliance Committee ToR v1.0

### 20. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, Terms of Reference, and establish ethical guidelines for the project.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan
- Ethical Guidelines Defined

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation Sent
- Project Plan Drafted

### 21. Ethics & Compliance Committee develops the whistleblower mechanism.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Whistleblower Mechanism Defined

**Dependencies:**

- Ethics & Compliance Committee Established
- Ethical Guidelines Defined