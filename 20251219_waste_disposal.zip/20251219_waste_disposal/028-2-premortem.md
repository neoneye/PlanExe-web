A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The remoteness of the disposal sites will be sufficient to prevent unwanted attention from law enforcement or nosy locals. | Deploy a drone with a high-resolution camera to survey the area surrounding a potential disposal site for a full day, noting any human activity or signs of surveillance. | The drone footage reveals more than 3 instances of human activity (vehicles, hikers, dwellings) within a 5-mile radius of the site during the observation period. |
| A2 | The team's existing expertise in logistics and security is sufficient to handle all unforeseen challenges during waste transportation and disposal. | Present the team with three realistic but unexpected scenarios (e.g., vehicle breakdown, sudden road closure, discovery of a previously unknown mineshaft hazard) and assess their proposed solutions against pre-defined criteria for speed, cost, and security. | The team fails to provide viable solutions for at least two of the three scenarios within the allotted time (2 hours per scenario), or the proposed solutions exceed pre-defined cost or security thresholds. |
| A3 | Local Nevada communities will remain unaware and uninterested in the project's activities. | Conduct discreet social media monitoring and online forum searches for mentions of unusual activity (e.g., increased truck traffic, strange odors, unusual personnel) near potential disposal sites. | The social media monitoring reveals more than 5 posts or comments expressing concern or suspicion about activities near potential disposal sites within a one-week period. |
| A4 | The BSL-3 waste will remain stable and not undergo unexpected chemical or biological reactions during transportation and disposal. | Subject a representative sample of the BSL-3 waste to simulated transportation conditions (temperature fluctuations, vibrations) and monitor for any signs of degradation, gas release, or unexpected reactions over a 72-hour period. | The waste sample exhibits significant degradation (e.g., >10% change in composition), releases hazardous gases, or undergoes an unexpected exothermic reaction during the simulation. |
| A5 | The chosen mineshafts are geologically stable enough to contain the waste indefinitely without risk of collapse or significant shifting. | Conduct a detailed 3D laser scan of the interior of a representative mineshaft and compare it to historical survey data (if available) to identify any signs of structural instability or recent geological activity. | The laser scan reveals significant structural weaknesses (e.g., large cracks, unstable rock formations) or evidence of recent geological activity (e.g., rockfalls, shifting ground) within the mineshaft. |
| A6 | The team members will remain loyal and committed to the project, even under pressure or in the face of ethical concerns. | Administer a confidential psychological assessment to all team members to evaluate their risk tolerance, ethical values, and susceptibility to pressure. | The psychological assessment reveals that at least two team members exhibit a high level of risk aversion, strong ethical concerns, or a high susceptibility to pressure, suggesting a potential for dissent or whistleblowing. |
| A7 | The client is the sole decision-maker and will consistently approve all necessary actions and funding requests without significant delays or interference. | Establish a clear communication protocol with the client, including pre-defined response times for critical decisions. Monitor the client's adherence to these response times over a two-week period during a simulated crisis scenario. | The client fails to respond to at least two critical decision requests within the pre-defined response time, or introduces significant changes to the proposed actions without adequate justification. |
| A8 | The abandoned mineshafts are structurally similar and disposal methods can be standardized across all selected sites. | Conduct preliminary structural surveys of at least three different potential mineshaft locations, focusing on dimensions, stability, and accessibility. Compare the survey results to identify any significant variations. | The structural surveys reveal significant variations (e.g., >20% difference in dimensions, presence of unstable areas in one site but not others) that would require significantly different disposal methods or equipment at different sites. |
| A9 | There will be no unexpected changes in Nevada state or federal environmental regulations that could impact the legality or feasibility of the project. | Engage a legal expert specializing in Nevada environmental law to continuously monitor relevant legislation and regulatory updates for any proposed changes that could affect the project. | The legal expert identifies a proposed change in Nevada state or federal environmental regulations that would significantly increase the cost of the project (e.g., by >10%) or render the chosen disposal method illegal. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Spotlight Surprise | Process/Financial | A1 | Project Lead | CRITICAL (20/25) |
| FM2 | The Mineshaft Mishap | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Whispers of Mina | Market/Human | A3 | Community Relations Lead | CRITICAL (15/25) |
| FM4 | The Toxic Time Bomb | Process/Financial | A4 | Project Lead | CRITICAL (15/25) |
| FM5 | The Earth's Revenge | Technical/Logistical | A5 | Head of Engineering | CRITICAL (20/25) |
| FM6 | The Price of Silence | Market/Human | A6 | Security & Counter-Intelligence Officer | HIGH (10/25) |
| FM7 | The Bureaucratic Black Hole | Process/Financial | A7 | Project Lead | CRITICAL (15/25) |
| FM8 | The Mineshaft Mismatch | Technical/Logistical | A8 | Head of Engineering | CRITICAL (20/25) |
| FM9 | The Regulatory Earthquake | Market/Human | A9 | Legal Counsel | HIGH (10/25) |


### Failure Modes

#### FM1 - The Spotlight Surprise

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on remote locations backfires when a group of amateur geocachers stumbles upon the disposal site. They document the operation on social media, attracting local news coverage. The increased scrutiny leads to a regulatory investigation, halting the project and triggering significant legal and remediation costs. The 'Consolidator's Shield' approach proves inadequate, as the limited budget cannot cover the unexpected expenses. The client, facing mounting legal fees and reputational damage, withdraws funding, leaving the project bankrupt and unfinished. The lack of a robust crisis communication plan exacerbates the situation, leading to further negative publicity and financial losses. The team's failure to anticipate and mitigate the risk of discovery by civilians proves to be a fatal flaw.

##### Early Warning Signs
- Increased activity on local hiking and geocaching forums mentioning the area around the disposal site.
- Local news outlets begin reporting on increased truck traffic in the area.
- Unexplained visits from local law enforcement to the area.

##### Tripwires
- Local news reports >= 2 within 7 days mentioning unusual activity near the disposal site.
- Geocaching forum posts >= 10 within 7 days mentioning the disposal site.
- Website traffic to the shell corporation's website increases by >= 500% in a week.

##### Response Playbook
- Contain: Immediately halt all disposal operations and secure the site.
- Assess: Determine the extent of the exposure and potential legal and financial ramifications.
- Respond: Engage legal counsel and develop a crisis communication strategy to mitigate the damage.


**STOP RULE:** Legal fees and potential fines exceed 75% of the remaining project budget.

---

#### FM2 - The Mineshaft Mishap

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
During the disposal process, a critical piece of equipment malfunctions, causing a significant delay. The team, lacking the necessary expertise and backup equipment, attempts a makeshift repair. This leads to a catastrophic accident, resulting in a spill of toxic waste within the mineshaft. The contamination spreads rapidly, rendering the site unusable and posing a significant environmental hazard. The 'Consolidator's Shield' approach proves disastrous, as the limited budget cannot cover the cost of remediation. The team's failure to anticipate and mitigate technical risks leads to a complete project failure and potential legal liabilities.

##### Early Warning Signs
- Equipment failure rates increase by 25% compared to manufacturer specifications.
- Delays in transportation or disposal operations exceed 48 hours.
- The team requests additional funding for equipment repairs or replacements.

##### Tripwires
- Equipment downtime exceeds 72 hours.
- Contamination levels in the mineshaft exceed EPA safety standards by >= 20%.
- The team requests emergency funding exceeding $500,000 for remediation.

##### Response Playbook
- Contain: Immediately halt all disposal operations and isolate the contaminated area.
- Assess: Determine the extent of the contamination and develop a remediation plan.
- Respond: Engage environmental remediation specialists and secure additional funding for cleanup efforts.


**STOP RULE:** The cost of environmental remediation exceeds $5 million.

---

#### FM3 - The Whispers of Mina

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Community Relations Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite efforts to maintain secrecy, rumors begin to circulate within the small town of Mina, Nevada, about unusual activities near the abandoned mines. A local resident, concerned about potential environmental hazards, starts an online petition and contacts a local investigative journalist. The journalist publishes a series of articles exposing the project, leading to public outrage and a swift response from regulatory agencies. The 'Consolidator's Shield' approach proves ineffective, as the limited resources cannot counter the negative publicity. The client, facing intense public scrutiny and legal pressure, abandons the project, leaving the team to face the consequences. The failure to anticipate and manage community relations leads to a complete project failure and significant reputational damage.

##### Early Warning Signs
- Increased mentions of unusual activity near the mines on local social media groups.
- Local residents begin organizing protests or demonstrations.
- Inquiries from local journalists about the project or related activities.

##### Tripwires
- Online petition signatures exceed 500 within 7 days.
- Local news articles >= 3 within 14 days mentioning the project or related activities.
- Attendance at community meetings discussing the project exceeds 50 people.

##### Response Playbook
- Contain: Immediately halt all disposal operations and initiate a crisis communication plan.
- Assess: Determine the extent of the public awareness and potential reputational damage.
- Respond: Engage public relations specialists and develop a strategy to address community concerns and mitigate negative publicity.


**STOP RULE:** The client's reputation is deemed irreparably damaged, leading to their withdrawal from the project.

---

#### FM4 - The Toxic Time Bomb

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team, confident in their disposal method, dumps the BSL-3 waste into the mineshaft. Unbeknownst to them, the waste undergoes an unexpected chemical reaction due to the unique combination of materials present in the mineshaft and the waste itself. This reaction generates a highly toxic gas that slowly seeps out of the mineshaft over time. Years later, local residents begin experiencing unexplained health problems. A public health investigation reveals the source of the contamination, leading to a massive lawsuit and significant financial liabilities for the client and the team. The 'Consolidator's Shield' provides no protection against the long-term consequences of the chemical reaction.

##### Early Warning Signs
- Unexplained corrosion or damage to waste containers during storage or transportation.
- Reports of unusual odors or fumes emanating from the disposal site.
- Increased levels of unexplained illnesses or health complaints in nearby communities.

##### Tripwires
- Gas detectors at the mineshaft entrance register levels of toxic gases exceeding OSHA limits by >= 10%.
- Local hospital reports a 20% increase in respiratory illnesses within a 30-day period.
- The shell corporation's insurance premiums increase by >= 50% due to increased risk assessment.

##### Response Playbook
- Contain: Immediately seal the mineshaft and implement air filtration systems in nearby areas.
- Assess: Conduct a comprehensive environmental assessment to determine the extent of the contamination.
- Respond: Engage public health officials and develop a plan to address the health concerns of local residents.


**STOP RULE:** The cost of mitigating the health crisis exceeds $8 million.

---

#### FM5 - The Earth's Revenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The team, ignoring warning signs of instability, chooses a mineshaft for disposal. Months after the operation is completed, a minor earthquake triggers a collapse within the mineshaft. The collapse breaches the waste containers, releasing the toxic materials into the surrounding groundwater. The contamination spreads rapidly, impacting local water sources and ecosystems. The 'Consolidator's Shield' proves useless, as the environmental damage is too extensive to conceal. The team's failure to properly assess the geological risks leads to a major environmental disaster and significant legal repercussions.

##### Early Warning Signs
- Increased seismic activity in the region near the disposal site.
- Reports of ground tremors or shifting earth near the mineshaft.
- Water samples from nearby wells show elevated levels of contaminants.

##### Tripwires
- A magnitude 3.0 or greater earthquake occurs within 10 miles of the disposal site.
- Groundwater contamination levels exceed EPA limits by >= 50%.
- The mineshaft entrance shows visible signs of collapse or subsidence.

##### Response Playbook
- Contain: Immediately implement emergency containment measures to prevent further groundwater contamination.
- Assess: Conduct a comprehensive geological survey to assess the extent of the damage and the stability of the surrounding area.
- Respond: Engage environmental remediation specialists and secure additional funding for cleanup efforts.


**STOP RULE:** The cost of containing the groundwater contamination exceeds $6 million.

---

#### FM6 - The Price of Silence

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Security & Counter-Intelligence Officer
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
A key member of the disposal team, burdened by guilt and ethical concerns, decides to expose the operation. They leak sensitive information to a whistleblower organization, providing irrefutable evidence of the illegal activities. The whistleblower organization publishes the information, triggering a massive public outcry and a full-scale investigation by law enforcement. The 'Consolidator's Shield' crumbles, as the team's attempts to maintain secrecy are overwhelmed by the public exposure. The client, facing overwhelming legal and reputational damage, abandons the project, leaving the remaining team members to face the consequences. The failure to address the ethical concerns of the team leads to a complete project failure and significant legal liabilities.

##### Early Warning Signs
- A team member exhibits signs of stress, anxiety, or depression.
- A team member requests a transfer to a different project or expresses a desire to leave the company.
- Unexplained absences or changes in behavior among team members.

##### Tripwires
- A team member contacts a lawyer specializing in whistleblower cases.
- Sensitive project documents are found to be missing or copied.
- A team member expresses strong ethical objections to the project's activities during a team meeting.

##### Response Playbook
- Contain: Immediately assess the extent of the information leak and identify the source.
- Assess: Determine the potential legal and reputational ramifications of the exposure.
- Respond: Engage legal counsel and develop a crisis communication strategy to mitigate the damage.


**STOP RULE:** The whistleblower provides evidence to law enforcement that directly implicates the client in the illegal activities.

---

#### FM7 - The Bureaucratic Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Project Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team encounters a critical logistical challenge requiring immediate funding approval. However, the client, preoccupied with other matters and exhibiting a pattern of delayed responses, fails to provide timely authorization. The delay cascades through the project, causing missed deadlines, increased costs due to idle equipment and personnel, and ultimately jeopardizing the entire operation. The 'Consolidator's Shield' budget, already stretched thin, cannot absorb the unexpected expenses. The project grinds to a halt, mired in bureaucratic inertia and financial disarray. The lack of timely decision-making from the client proves to be a fatal bottleneck.

##### Early Warning Signs
- Client response times to critical requests consistently exceed pre-defined deadlines.
- The client introduces frequent changes to approved plans or budgets without adequate justification.
- The project experiences delays due to lack of client approval on necessary actions.

##### Tripwires
- Client response time to critical funding requests exceeds 72 hours.
- The project experiences a delay of >= 7 days due to lack of client approval.
- The client rejects a funding request that is deemed essential by the project team.

##### Response Playbook
- Contain: Escalate the issue to a higher-level contact within the client's organization.
- Assess: Determine the root cause of the client's delays and identify potential solutions.
- Respond: Renegotiate the communication protocol with the client, establishing clear expectations and consequences for non-compliance.


**STOP RULE:** The client's consistent failure to provide timely approvals results in a critical deadline being missed, jeopardizing the project's overall feasibility.

---

#### FM8 - The Mineshaft Mismatch

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The team, assuming standardized disposal methods, prepares a single set of equipment and procedures for all selected mineshafts. However, upon arriving at the second disposal site, they discover that the mineshaft's dimensions and structural integrity are significantly different from the first. The equipment is incompatible, and the planned procedures are unsafe. The team is forced to improvise, leading to delays, increased risks, and potential environmental contamination. The 'Consolidator's Shield' budget cannot cover the cost of acquiring specialized equipment for each site. The project spirals into a logistical nightmare, highlighting the dangers of assuming uniformity in unpredictable environments.

##### Early Warning Signs
- Preliminary site surveys reveal significant variations in mineshaft dimensions or structural integrity.
- The team encounters difficulties adapting the standard disposal procedures to the second site.
- Equipment malfunctions or failures increase due to incompatibility with the mineshaft environment.

##### Tripwires
- The team is unable to safely access the second disposal site using the standard equipment.
- The cost of adapting the standard disposal procedures to the second site exceeds $500,000.
- The project experiences a delay of >= 14 days due to the mineshaft mismatch.

##### Response Playbook
- Contain: Immediately halt all disposal operations at the second site and reassess the suitability of the chosen methods.
- Assess: Conduct a detailed site-specific assessment to determine the necessary equipment and procedures.
- Respond: Acquire specialized equipment or develop alternative disposal methods tailored to the unique characteristics of the second site.


**STOP RULE:** The cost of adapting the disposal methods to the unique characteristics of each mineshaft exceeds $1 million.

---

#### FM9 - The Regulatory Earthquake

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Legal Counsel
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The team, confident in their regulatory evasion strategy, proceeds with the disposal operation. However, unexpectedly, the Nevada state legislature passes a new law significantly increasing the penalties for illegal waste disposal and strengthening environmental enforcement. The team's carefully crafted evasion strategy is rendered obsolete, and the project faces immediate legal scrutiny. The 'Consolidator's Shield' provides no protection against the increased regulatory pressure. The client, facing the prospect of severe legal repercussions, withdraws funding, leaving the team to face the full force of the law. The failure to anticipate and adapt to changes in the regulatory environment proves to be a catastrophic oversight.

##### Early Warning Signs
- Increased media coverage of environmental issues and regulatory enforcement in Nevada.
- Rumors circulate about proposed changes to Nevada's environmental laws.
- The legal expert warns of potential changes in the regulatory landscape that could impact the project.

##### Tripwires
- A new Nevada state law is enacted that significantly increases the penalties for illegal waste disposal.
- The Nevada Department of Environmental Protection announces increased enforcement efforts targeting illegal waste disposal activities.
- The legal expert advises that the project's regulatory evasion strategy is no longer viable.

##### Response Playbook
- Contain: Immediately halt all disposal operations and reassess the project's legal viability.
- Assess: Conduct a thorough legal review to determine the impact of the new regulations on the project.
- Respond: Develop a revised regulatory compliance strategy or abandon the project if compliance is not feasible.


**STOP RULE:** The new regulations render the project illegal or increase the potential legal penalties to an unacceptable level.
