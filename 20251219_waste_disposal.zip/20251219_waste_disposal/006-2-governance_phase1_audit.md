
## Audit - Corruption Risks

- Bribery of local officials in Nevada to ignore illegal dumping activities or provide access to mineshafts.
- Kickbacks from contractors hired for transportation or site preparation in exchange for inflated contracts.
- Conflicts of interest where project personnel have undisclosed financial ties to suppliers or subcontractors.
- Misuse of inside information regarding regulatory inspections or law enforcement activities to evade detection.
- Trading favors with individuals in regulatory agencies to delay or obstruct investigations into the waste disposal operation.

## Audit - Misallocation Risks

- Inflated invoices from shell corporations established for plausible deniability, siphoning funds for personal gain.
- Double-billing for transportation or disposal services using falsified records.
- Inefficient allocation of resources to environmental safeguards, prioritizing cost savings over actual risk mitigation.
- Unauthorized use of project funds for personal expenses or unrelated activities.
- Misreporting of project progress or environmental impact to conceal failures or minimize scrutiny.

## Audit - Procedures

- Conduct periodic internal reviews of all financial transactions, focusing on payments to contractors and suppliers, with a threshold of $50,000 for detailed scrutiny.
- Implement a mandatory expense approval workflow requiring dual authorization for all expenditures exceeding $10,000.
- Perform unannounced site inspections to verify waste disposal practices and environmental compliance, led by an independent environmental consultant.
- Engage an external auditor to conduct a post-project audit of all financial records and operational activities.
- Review all contracts with suppliers and subcontractors to ensure fair pricing and prevent conflicts of interest, with legal counsel present.

## Audit - Transparency Measures

- Maintain a secure, internal project dashboard tracking budget expenditures, milestones achieved, and identified risks, accessible only to key project personnel.
- Document all key decisions related to site selection, transportation methods, and disposal techniques, including the rationale behind each decision.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or environmental violations, with guaranteed anonymity and protection from retaliation.
- Implement a policy requiring disclosure of any potential conflicts of interest by project personnel, with mandatory recusal from related decisions.
- Create a detailed record of all waste disposal activities, including dates, locations, and quantities disposed of, to facilitate internal monitoring and potential future investigations.