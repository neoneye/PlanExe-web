### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and approves key decisions given the high-risk, illegal nature of the project and the need to balance competing priorities (cost, security, environmental impact).

**Responsibilities:**

- Approve strategic decisions related to operational footprint, environmental impact, counter-intelligence, disposal method, and plausible deniability.
- Approve budget allocations exceeding $500,000.
- Review and approve risk mitigation strategies for key project risks (regulatory, environmental, security).
- Monitor project progress against key milestones and budget.
- Provide strategic guidance and resolve conflicts between project teams.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define decision-making protocols.

**Membership:**

- Project Sponsor (Senior Executive)
- Legal Counsel (Independent)
- Security Advisor (Independent)
- Environmental Risk Consultant (Independent)
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget (above $500,000), risk management, and key strategic choices.

**Decision Mechanism:** Majority vote, with the Project Sponsor having the tie-breaking vote. Independent members must be consulted on all decisions.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of budget performance.
- Discussion of key risks and mitigation strategies.
- Approval of strategic decisions.
- Review of audit findings and recommendations.

**Escalation Path:** Senior Executive Management
### 2. Core Project Team

**Rationale for Inclusion:** Manages day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Handles operational decisions within defined thresholds.

**Responsibilities:**

- Develop and execute project plans.
- Manage project budget within approved limits (below $500,000).
- Coordinate activities of project teams (transportation, disposal, security).
- Monitor project risks and implement mitigation strategies.
- Report project progress to the Project Steering Committee.
- Ensure compliance with safety protocols (as much as possible given the illegal nature of the project).

**Initial Setup Actions:**

- Define team roles and responsibilities.
- Establish communication protocols.
- Develop project schedule.
- Set up project tracking system.

**Membership:**

- Project Manager
- Transportation Lead
- Disposal Lead
- Security Lead
- Legal Liaison

**Decision Rights:** Operational decisions related to project execution, budget management (below $500,000), and resource allocation within approved plans.

**Decision Mechanism:** Consensus-based decision-making, with the Project Manager having the final decision-making authority in case of disagreement.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project tasks and progress.
- Discussion of project risks and issues.
- Coordination of team activities.
- Review of budget performance.
- Preparation of reports for the Project Steering Committee.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides oversight and guidance on ethical and compliance issues, particularly related to environmental regulations, legal risks, and potential corruption.  Ensures that the project, as much as possible given its illegal nature, adheres to the highest ethical standards.

**Responsibilities:**

- Review and assess ethical and compliance risks associated with the project.
- Develop and implement policies and procedures to mitigate ethical and compliance risks.
- Provide guidance to project teams on ethical and compliance issues.
- Investigate and resolve ethical and compliance violations.
- Monitor compliance with environmental regulations (as much as possible given the illegal nature).
- Oversee the whistleblower mechanism and ensure protection for whistleblowers.
- Review all contracts and financial transactions for potential corruption or fraud.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines for the project.
- Establish whistleblower mechanism.

**Membership:**

- Legal Counsel (Independent)
- Environmental Risk Consultant (Independent)
- Compliance Officer (Independent)
- Project Manager
- Security Lead

**Decision Rights:** Decisions related to ethical and compliance policies, investigations, and corrective actions.  Has the authority to halt the project if ethical or compliance violations are deemed too severe.

**Decision Mechanism:** Majority vote, with the Legal Counsel having the tie-breaking vote. Independent members must be consulted on all decisions.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of ethical and compliance risks.
- Discussion of ethical and compliance issues.
- Investigation of ethical and compliance violations.
- Review of contracts and financial transactions.
- Review of whistleblower reports.
- Monitoring of compliance with environmental regulations.

**Escalation Path:** Project Steering Committee, Senior Executive Management