This plan involves money.

## Currencies

- **USD:** The project budget is specified in US dollars.

**Primary currency:** USD

**Currency strategy:** The project budget is in USD, and all transactions should be conducted in USD. No currency exchange risk management is needed.