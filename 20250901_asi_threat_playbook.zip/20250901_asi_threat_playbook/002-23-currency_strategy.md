This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, given the project's US-based nature and DARPA funding.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed as the project is primarily US-based.