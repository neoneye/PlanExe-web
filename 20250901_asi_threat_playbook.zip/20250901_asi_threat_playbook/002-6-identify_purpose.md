**Purpose:** business

**Purpose Detailed:** Development of a threat model and strategic playbook to identify and codify methods for ASI to manipulate human society, informing the development of defensive countermeasures.

**Topic:** DARPA program for ASI threat model and strategic playbook development