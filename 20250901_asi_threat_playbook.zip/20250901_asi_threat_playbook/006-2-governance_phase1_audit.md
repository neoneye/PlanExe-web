
## Audit - Corruption Risks

- Bribery of DARPA officials to secure continued funding or favorable project reviews.
- Conflicts of interest involving project team members with financial ties to AI tool vendors or cybersecurity firms.
- Kickbacks from vendors for selecting their products or services, even if they are not the best fit for the project.
- Misuse of project information for personal gain, such as trading on vulnerabilities identified in the threat model.
- Trading favors with stakeholders, such as promising favorable research findings in exchange for political support.

## Audit - Misallocation Risks

- Misuse of budget for personal gain, such as travel expenses or lavish accommodations.
- Double spending on resources, such as paying multiple vendors for the same service.
- Inefficient allocation of resources, such as overspending on computing infrastructure while neglecting data acquisition.
- Unauthorized use of project assets, such as using high-performance computing resources for personal projects.
- Misreporting project progress or results to secure continued funding or favorable reviews.

## Audit - Procedures

- Periodic internal reviews of project finances and activities, conducted by an independent audit team within DARPA (quarterly).
- Post-project external audit by a third-party accounting firm to verify expenditures and compliance with regulations.
- Contract review thresholds for vendor selection, requiring multiple levels of approval for contracts exceeding a certain value ($100,000).
- Expense workflows with detailed documentation requirements and approval limits for all project-related expenses.
- Compliance checks to ensure adherence to data privacy regulations, human subjects research approvals, and export control licenses (annually).

## Audit - Transparency Measures

- Progress and budget dashboards accessible to DARPA officials and other key stakeholders, providing real-time updates on project status and expenditures.
- Published minutes of key meetings of the ethics review board, addressing ethical dilemmas and decisions related to the project.
- Whistleblower mechanisms for reporting suspected fraud, waste, or abuse, with protections for whistleblowers.
- Public access to relevant project policies and reports, such as the data governance plan and the communication plan.
- Documented selection criteria for major decisions and vendors, ensuring transparency in the decision-making process.