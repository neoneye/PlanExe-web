### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Kickoff

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by nominated members (DARPA Program Manager, Senior Government Representative, Independent AI Ethics Expert, Project Director, Chief Scientist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager incorporates feedback and finalizes the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Project Sponsor formally appoints the Chair of the Project Steering Committee (DARPA Program Manager).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints the remaining members of the Project Steering Committee (Senior Representative from a relevant Government Agency, Independent AI Ethics Expert, Project Director, Chief Scientist).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- SteerCo Chair Appointed

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- SteerCo Members Appointed

### 7. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Appointed
- Meeting Scheduled

### 8. Project Director defines roles and responsibilities for the Core Project Team members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Kickoff

### 9. Project Director establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 10. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Access to Project Management Tools

**Dependencies:**

- Core Project Team Communication Protocols Document

### 11. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Access to Project Management Tools

### 12. Project Director schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Detailed Project Schedule

### 13. Hold the initial Core Project Team kick-off meeting to review project goals, roles, and schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Scheduled

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Ethics Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Review Board ToR v0.1

**Dependencies:**

- Project Kickoff

### 15. Project Manager circulates Draft Ethics Review Board ToR v0.1 for review by potential members (Independent AI Ethics Expert, Legal Counsel, IRB Representative, Social Scientist, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics Review Board ToR v0.1
- Potential Members List Available

### 16. Project Manager incorporates feedback and finalizes the Terms of Reference for the Ethics Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Review Board ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Sponsor formally appoints the Chair of the Ethics Review Board (Independent AI Ethics Expert).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Review Board ToR v1.0

### 18. Project Sponsor formally appoints the remaining members of the Ethics Review Board (Legal Counsel specializing in data privacy, Representative from an Institutional Review Board (IRB), Social Scientist specializing in ethics, Community Representative).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics Review Board ToR v1.0
- Ethics Review Board Chair Appointed

### 19. Ethics Review Board Chair schedules the initial Ethics Review Board kick-off meeting.

**Responsible Body/Role:** Independent AI Ethics Expert

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Ethics Review Board Members Appointed

### 20. Hold the initial Ethics Review Board kick-off meeting to review project goals, governance structure, and ethical guidelines.

**Responsible Body/Role:** Ethics Review Board

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Ethical Guidelines

**Dependencies:**

- Ethics Review Board Members Appointed
- Meeting Scheduled

### 21. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Kickoff

### 22. Project Manager circulates Draft Technical Advisory Group ToR v0.1 for review by potential members (Leading AI Researcher, Cybersecurity Expert, Social Science Expert, Data Scientist, Chief Scientist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Potential Members List Available

### 23. Project Manager incorporates feedback and finalizes the Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Project Director formally appoints the members of the Technical Advisory Group (Leading AI Researcher, Cybersecurity Expert, Social Science Expert, Data Scientist).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 25. Chief Scientist schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Chief Scientist

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Members Appointed

### 26. Hold the initial Technical Advisory Group kick-off meeting to review project goals, technical approaches, and methodologies.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Members Appointed
- Meeting Scheduled

### 27. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Kickoff

### 28. Project Manager circulates Draft Stakeholder Engagement Group ToR v0.1 for review by potential members (Communications Lead, Representative from DARPA, Representative from a Government Agency, Representative from a Cybersecurity Firm, Public Relations Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Potential Members List Available

### 29. Project Manager incorporates feedback and finalizes the Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 30. Project Director formally appoints the members of the Stakeholder Engagement Group (Communications Lead, Representative from DARPA, Representative from a Government Agency, Representative from a Cybersecurity Firm, Public Relations Specialist).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 31. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Stakeholder Engagement Group Members Appointed

### 32. Hold the initial Stakeholder Engagement Group kick-off meeting to review project goals, stakeholder engagement plan, and communication channels.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder Engagement Group Members Appointed
- Meeting Scheduled