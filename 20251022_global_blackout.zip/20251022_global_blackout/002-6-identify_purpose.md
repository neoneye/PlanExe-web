**Purpose:** business

**Purpose Detailed:** Preventing AI from running by shutting down global electricity, a large-scale societal intervention.

**Topic:** Global Power Grid Shutdown