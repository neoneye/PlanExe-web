<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Stakeholder conflict resolution missing

**Domain:** Human Stability

**Issues:**

- <code>STAKEHOLDER_CONFLICT</code>: Stakeholder conflict resolution framework + escalation matrix

**Acceptance Criteria:**

- Stakeholder conflict resolution framework complete
- Escalation matrix documented

**Artifacts Required:**

- Stakeholder\_Map\_v1\.pdf
- Escalation\_Matrix\_v1\.pdf

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B2: Contingency too low

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Criteria:**

- \>=10% contingency approved
- Monte Carlo risk workbook attached

**Artifacts Required:**

- Budget\_v2\.pdf
- Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: Climate exposure unquantified

**Domain:** Ecological Integrity

**Issues:**

- <code>CLIMATE_UNQUANTIFIED</code>: Climate exposure maps (2030/2040/2050) + site vulnerability memo

**Acceptance Criteria:**

- Climate exposure maps created
- Site vulnerability memo attached

**Artifacts Required:**

- Climate\_Exposure\_Maps\.pdf
- Site\_Vulnerability\_Memo\.pdf

**Owner:** Sustainability Team


**Rough Order of Magnitude (ROM):** MEDIUM cost, 30 days


### B4: Ethics vague

**Domain:** Rights & Legality

**Issues:**

- <code>ETHICS_VAGUE</code>: Normative Charter v1.0 with auditable rules & dissent logging

**Acceptance Criteria:**

- Normative Charter v1\.0 complete
- Auditable rules defined
- Dissent logging implemented

**Artifacts Required:**

- Normative\_Charter\_v1\.pdf

**Owner:** Legal


**Rough Order of Magnitude (ROM):** MEDIUM cost, 45 days


### B5: Utility infrastructure gap

**Domain:** Technical Feasibility

**Issues:**

- <code>UTILITY_INFRA_GAP</code>: Utility capacity and infrastructure study (load analysis, upgrade plan, utility confirmation)

**Acceptance Criteria:**

- Utility capacity study complete
- Infrastructure upgrade plan approved
- Utility confirmation received

**Artifacts Required:**

- Utility\_Capacity\_Study\.pdf
- Infrastructure\_Upgrade\_Plan\.pdf
- Utility\_Confirmation\.pdf

**Owner:** Engineering Lead


**Rough Order of Magnitude (ROM):** HIGH cost, 60 days

