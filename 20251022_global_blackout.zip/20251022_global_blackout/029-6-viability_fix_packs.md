<p class="section-subtitle">Bundled actions that reduce risk and move domains toward GREEN.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>, <code>B4</code>

### FP1: Stakeholder Conflict Resolution and Engagement

**Priority:** High

**Blockers:** <code>B1</code>

### FP2: Quantifying and Addressing Climate Exposure Risks

**Priority:** Medium

**Blockers:** <code>B3</code>

### FP3: Addressing Utility Infrastructure Capacity Gaps

**Priority:** High

**Blockers:** <code>B5</code>