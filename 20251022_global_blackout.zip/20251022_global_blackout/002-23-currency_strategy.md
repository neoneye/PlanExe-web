This plan involves money.

## Currencies

- **USD:** For international coordination, resource allocation, and potential contractor payments.
- **CHF:** For operations in Switzerland, including potential command center costs in Zurich.
- **ISK:** For operations in Iceland, including potential operational cell costs in Reykjavik.

**Primary currency:** USD

**Currency strategy:** Due to the global nature of the project and the involvement of multiple countries, USD will be used for consolidated budgeting and reporting. Local currencies (CHF, ISK) may be used for local transactions in Switzerland and Iceland. Hedging against exchange rate fluctuations may be necessary.