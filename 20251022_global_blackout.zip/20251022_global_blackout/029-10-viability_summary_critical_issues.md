| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Human Stability | RED | GOVERNANCE\_WEAK, STAKEHOLDER\_CONFLICT, STAFF\_AVERSION |
| Ecological Integrity | RED | CLIMATE\_UNQUANTIFIED, WASTE\_MANAGEMENT\_GAPS |
| Rights & Legality | RED | ETHICS\_VAGUE, INFOSEC\_GAPS, CROSSBORDER\_RISK |