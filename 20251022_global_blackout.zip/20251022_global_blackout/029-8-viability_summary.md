- **Status:** RED
- **Recommendation:** <code>HOLD</code>, Do not proceed \- resolve blockers first

### Summary of Critical Issues by Domain
| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Human Stability | RED | GOVERNANCE\_WEAK, STAKEHOLDER\_CONFLICT, STAFF\_AVERSION |
| Ecological Integrity | RED | CLIMATE\_UNQUANTIFIED, WASTE\_MANAGEMENT\_GAPS |
| Rights & Legality | RED | ETHICS\_VAGUE, INFOSEC\_GAPS, CROSSBORDER\_RISK |

### Go/No-Go Criteria
<p class="section-subtitle">Must be met to proceed.</p>
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Normative Charter v1\.0 complete
- Auditable rules defined
- Dissent logging implemented