**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of $10 million USD, requiring strategic oversight and approval at a higher level.
Negative Consequences: Project delays, reduced scope, or cancellation due to insufficient funding.

**Critical Risk Materialization Requiring Strategic Shift**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Materialization of a critical risk (e.g., international intervention) necessitates a strategic shift in the project's approach, requiring high-level decision-making.
Negative Consequences: Project failure, international conflict, or catastrophic societal damage.

**PMO Deadlock on Ethical Violation Investigation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Recommendation to Board of Directors
Rationale: Disagreement within the Ethics and Compliance Committee on the appropriate course of action for a reported ethical violation requires independent review and resolution at a higher level.
Negative Consequences: Reputational damage, legal penalties, or loss of stakeholder trust.

**Proposed Major Scope Change Affecting Project Objectives**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: A major change to the project scope (e.g., altering the outage duration) has significant implications for the project's objectives and requires strategic alignment.
Negative Consequences: Project failure, increased societal disruption, or failure to achieve the desired AI shutdown.

**Ethical Concern Reported Directly to Core Project Team**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics and Compliance Committee Investigation & Recommendation
Rationale: Ethical concerns need independent review to ensure objectivity and compliance with ethical guidelines.
Negative Consequences: Moral injury, condemnation, loss of trust, psychological trauma.