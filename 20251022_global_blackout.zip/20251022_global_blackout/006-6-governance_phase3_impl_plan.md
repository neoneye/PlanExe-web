### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 3. Circulate Draft SteerCo ToR for review by nominated members (Senior Executive Sponsor, CTO, CSO, CRO, Legal Counsel, Independent Ethics Advisor, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1

### 4. Circulate Draft Ethics and Compliance Committee ToR for review by nominated members (Legal Counsel, Independent Ethics Advisor, Compliance Officer, Data Protection Officer, Representative from the Project Steering Committee, Representative from the Communications Team).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 5. Project Manager consolidates feedback and finalizes the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members

### 6. Project Manager consolidates feedback and finalizes the Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback from Nominated Members

### 7. Senior Executive Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 8. Senior Executive Sponsor formally appoints the members of the Project Steering Committee (CTO, CSO, CRO, Legal Counsel, Independent Ethics Advisor, Project Manager).

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0

### 9. Legal Counsel formally appoints the Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 10. Legal Counsel formally appoints the members of the Ethics and Compliance Committee (Independent Ethics Advisor, Compliance Officer, Data Protection Officer, Representative from the Project Steering Committee, Representative from the Communications Team).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 11. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 12. Hold the initial Project Steering Committee kick-off meeting to review the project charter, initial budget, and key risks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 13. Project Manager defines roles and responsibilities for Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Start

### 14. Project Manager establishes communication channels and protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Roles and Responsibilities Matrix

### 15. Project Manager develops a detailed project schedule and budget for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Schedule
- Project Budget

**Dependencies:**

- Communication Plan

### 16. Project Manager identifies and assesses initial project risks for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Risk Register

**Dependencies:**

- Project Schedule
- Project Budget

### 17. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Management System Access
- Training Materials

**Dependencies:**

- Risk Register

### 18. Hold the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Management System Access
- Training Materials

### 19. Schedule the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 20. Hold the initial Ethics and Compliance Committee kick-off meeting to review the project charter, ethical guidelines, and compliance policies.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda