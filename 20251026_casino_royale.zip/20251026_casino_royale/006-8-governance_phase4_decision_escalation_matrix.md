**Budget Request Exceeding PMO Authority ($10 million limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and majority vote, considering strategic alignment and financial impact.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight due to the potential impact on overall project budget and scope.
Negative Consequences: Potential budget overruns, project delays, and misalignment with strategic objectives if not properly reviewed and approved.

**Critical Risk Materialization (e.g., major security breach, legal challenge)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the impact, review mitigation plans, and approve necessary actions.
Rationale: Requires immediate strategic guidance and resource allocation due to the potential for significant impact on project success and stakeholder confidence.
Negative Consequences: Project failure, reputational damage, legal penalties, and loss of stakeholder trust if not addressed promptly and effectively.

**PMO Deadlock on Vendor Selection (equal votes, no consensus)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the vendor selection criteria, evaluates the competing proposals, and makes a final decision based on strategic fit and value for money.
Rationale: Requires higher-level intervention to resolve the deadlock and ensure timely progress on critical project activities.
Negative Consequences: Project delays, increased costs, and potential compromise of project quality if the vendor selection process is stalled.

**Proposed Major Scope Change (e.g., significant alteration to casino design or services)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed scope change, assesses its impact on project objectives, budget, and timeline, and approves or rejects the change based on strategic considerations.
Rationale: Requires strategic oversight to ensure that the scope change aligns with overall project goals and does not introduce unacceptable risks or costs.
Negative Consequences: Project scope creep, budget overruns, schedule delays, and misalignment with stakeholder expectations if not properly managed.

**Reported Ethical Concern (e.g., potential conflict of interest, violation of code of ethics)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics and Compliance Committee investigates the reported concern, gathers evidence, and makes a recommendation to the Project Steering Committee for appropriate action.
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with legal and regulatory requirements.
Negative Consequences: Reputational damage, legal penalties, loss of stakeholder trust, and potential project shutdown if ethical concerns are not addressed promptly and effectively.

**Stakeholder Engagement Group cannot resolve significant public opposition to the project.**
Escalation Level: Project Steering Committee
Approval Process: The Project Steering Committee will review the Stakeholder Engagement Group's efforts, assess the nature and intensity of the opposition, and determine a revised engagement strategy or potential project modifications.
Rationale: Significant public opposition can threaten the project's viability and requires strategic intervention to mitigate negative impacts.
Negative Consequences: Project delays, increased costs, reputational damage, and potential project cancellation if public opposition is not effectively addressed.