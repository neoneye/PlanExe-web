<p class="section-subtitle">Bundled actions that reduce risk and move domains toward GREEN.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>, <code>B4</code>

### FP1: Stakeholder Alignment and Dependency Mapping

**Priority:** High

**Blockers:** <code>B1</code>, <code>B5</code>

### FP2: Permitting Complexity and Legal Compliance

**Priority:** Immediate

**Blockers:** <code>B3</code>