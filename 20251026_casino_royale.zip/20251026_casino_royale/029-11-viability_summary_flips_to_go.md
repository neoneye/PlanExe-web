<p class="section-subtitle">Must be met to proceed.</p>
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Normative Charter v1\.0 created
- Auditable rules defined
- Dissent logging implemented