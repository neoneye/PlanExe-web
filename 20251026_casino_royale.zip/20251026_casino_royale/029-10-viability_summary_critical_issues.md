| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Human Stability | RED | STAKEHOLDER\_CONFLICT, GOVERNANCE\_WEAK |
| Economic Resilience | RED | CONTINGENCY\_LOW, SUPPLIER\_CONCENTRATION |
| Rights & Legality | RED | PERMIT\_COMPLEXITY, ETHICS\_VAGUE, LICENSE\_GAPS |