### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR v0.1 for review by Senior Executive Sponsor, Head of Legal and Compliance, Chief Financial Officer, Director of Public Relations, Representative from the Casino Operators, and Independent Ethics Advisor.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Executive Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with the Senior Executive Sponsor, formally confirms the Project Steering Committee membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize operating procedures, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Circulate Draft Ethics and Compliance Committee ToR v0.1 for review by Head of Legal and Compliance, Independent Ethics Advisor, Data Protection Officer, Representative from the Casino Operators (Compliance Officer), and Internal Audit Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 10. Project Manager incorporates feedback and finalizes the Ethics and Compliance Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Senior Executive Sponsor formally appoints the Head of Legal and Compliance as the Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 12. Project Manager, in consultation with the Senior Executive Sponsor, formally confirms the Ethics and Compliance Committee membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 13. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 14. Hold the initial Ethics and Compliance Committee kick-off meeting to review the project plan, finalize operating procedures, and assign initial tasks.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 16. Circulate Draft Stakeholder Engagement Group ToR v0.1 for review by Director of Public Relations, Communication Manager, Community Liaison Officer, Government Relations Officer, Representative from the Casino Operators (Marketing), and Independent Public Relations Consultant.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 17. Project Manager incorporates feedback and finalizes the Stakeholder Engagement Group Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Senior Executive Sponsor formally appoints the Director of Public Relations as the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 19. Project Manager, in consultation with the Senior Executive Sponsor, formally confirms the Stakeholder Engagement Group membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 20. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Emails

### 21. Hold the initial Stakeholder Engagement Group kick-off meeting to review the project plan, finalize operating procedures, and assign initial tasks.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 22. Establish project management processes and procedures.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Plan
- Standard Operating Procedures

**Dependencies:**

- Project Plan Approved

### 23. Develop a project communication plan.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Communication Plan

**Dependencies:**

- Establish project management processes and procedures.

### 24. Set up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Project Communication Plan

### 25. Recruit and train project team members for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Staffing Plan
- Training Materials

**Dependencies:**

- Set up project tracking and reporting systems.

### 26. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Recruit and train project team members for the PMO.

### 27. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda