<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Stakeholder conflict resolution missing

**Domain:** Human Stability

**Issues:**

- <code>STAKEHOLDER_CONFLICT</code>: Stakeholder conflict resolution framework + escalation matrix
- <code>GOVERNANCE_WEAK</code>: RACI + decision log v1 (scope: this plan)

**Acceptance Criteria:**

- Stakeholder map includes influence/interest scores
- Critical role gaps quantified
- HR lead sign\-off captured

**Artifacts Required:**

- Stakeholder\_Map\_v1\.xlsx
- Skills\_Gap\_Snapshot\_v1\.pdf

**Owner:** HR


**Rough Order of Magnitude (ROM):** LOW cost, 21 days


### B2: Contingency fund too low

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Criteria:**

- \>=10% contingency approved
- Monte Carlo risk workbook attached

**Artifacts Required:**

- Budget\_v2\.pdf
- Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: Permitting complexity unassessed

**Domain:** Rights & Legality

**Issues:**

- <code>PERMIT_COMPLEXITY</code>: Permitting complexity analysis (jurisdictions, critical path, mitigation plan)

**Acceptance Criteria:**

- Permitting complexity analysis completed
- Critical path identified
- Mitigation plan in place

**Artifacts Required:**

- Permitting\_Analysis\_v1\.pdf

**Owner:** Legal


**Rough Order of Magnitude (ROM):** MEDIUM cost, 30 days


### B4: Ethical guidelines undefined

**Domain:** Rights & Legality

**Issues:**

- <code>ETHICS_VAGUE</code>: Normative Charter v1.0 with auditable rules & dissent logging

**Acceptance Criteria:**

- Normative Charter v1\.0 created
- Auditable rules defined
- Dissent logging implemented

**Artifacts Required:**

- Normative\_Charter\_v1\.pdf

**Owner:** Ethics Committee


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B5: Dependencies unmapped

**Domain:** Program Delivery

**Issues:**

- <code>DEPENDENCIES_UNMAPPED</code>: Dependency map (internal/external) with owners and SLAs

**Acceptance Criteria:**

- Dependency map created
- Internal/external dependencies identified
- Owners and SLAs assigned

**Artifacts Required:**

- Dependency\_Map\_v1\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 7 days

