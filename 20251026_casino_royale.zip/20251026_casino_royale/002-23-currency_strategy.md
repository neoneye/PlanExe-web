This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and project funding, as the initial budget is in USD and the project is based in the USA.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. No additional international risk management is needed as the primary funding and initial operations are based in the USA.