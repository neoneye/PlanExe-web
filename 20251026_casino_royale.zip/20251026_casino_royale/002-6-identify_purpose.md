**Purpose:** business

**Purpose Detailed:** Infrastructure project with commercial and potentially societal implications, involving gambling and entertainment for world leaders.

**Topic:** Construction of a casino in the White House East Wing