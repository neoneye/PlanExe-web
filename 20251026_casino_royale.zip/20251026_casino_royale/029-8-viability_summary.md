- **Status:** RED
- **Recommendation:** <code>HOLD</code>, Do not proceed \- resolve blockers first

### Summary of Critical Issues by Domain
| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Human Stability | RED | STAKEHOLDER\_CONFLICT, GOVERNANCE\_WEAK |
| Economic Resilience | RED | CONTINGENCY\_LOW, SUPPLIER\_CONCENTRATION |
| Rights & Legality | RED | PERMIT\_COMPLEXITY, ETHICS\_VAGUE, LICENSE\_GAPS |

### Go/No-Go Criteria
<p class="section-subtitle">Must be met to proceed.</p>
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Normative Charter v1\.0 created
- Auditable rules defined
- Dissent logging implemented