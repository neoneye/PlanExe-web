### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance due to the project's high risk, high reward nature, significant ethical considerations, and potential international repercussions. Ensures alignment with overall strategic objectives and manages key stakeholder relationships.

**Responsibilities:**

- Provide strategic direction and oversight for the project.
- Approve major project milestones and deliverables.
- Approve budget revisions exceeding $10 million.
- Oversee strategic risk management and mitigation.
- Resolve conflicts escalated from lower governance bodies.
- Approve key strategic decisions related to regulatory compliance, public perception, and diplomatic relations.
- Monitor project performance against strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol.
- Define escalation paths.
- Review and approve the initial project plan.

**Membership:**

- Senior Executive Sponsor (Chair)
- Head of Legal and Compliance
- Chief Financial Officer
- Director of Public Relations
- Representative from the Casino Operators
- Independent Ethics Advisor

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key risks. Approval of budget changes exceeding $10 million. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Senior Executive Sponsor (Chair) casts the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly, or more frequently as needed during critical project phases.

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion and approval of key decisions.
- Review of risk register and mitigation plans.
- Review of financial performance and budget variances.
- Stakeholder updates and feedback.
- Escalated issues from other governance bodies.

**Escalation Path:** To the organization's CEO or Board of Directors for issues exceeding the Steering Committee's authority or unresolved conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Ensures consistent project execution, manages day-to-day operations, and monitors project performance against established metrics. Provides a central point of coordination and communication for the project team.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage day-to-day project activities.
- Monitor project progress and performance.
- Manage the project budget within approved limits.
- Identify and manage operational risks.
- Coordinate communication among project stakeholders.
- Prepare regular project status reports.
- Implement project management best practices.

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop a project communication plan.
- Set up project tracking and reporting systems.
- Recruit and train project team members.

**Membership:**

- Project Manager (Head of PMO)
- Project Coordinators
- Technical Leads
- Finance Representative
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation within approved budgets, and day-to-day problem-solving. Approval of budget changes up to $10 million.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the PMO team. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, or more frequently as needed.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Review of budget and resource utilization.
- Coordination of team activities.
- Preparation of project status reports.

**Escalation Path:** To the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic guidance.
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Addresses the significant ethical and compliance risks associated with the project, including gambling regulations, anti-corruption measures, and data privacy (GDPR). Ensures the project operates within legal and ethical boundaries.

**Responsibilities:**

- Develop and enforce a code of ethics for the project.
- Ensure compliance with all applicable laws and regulations, including gambling regulations, anti-corruption laws, and data privacy regulations (GDPR).
- Conduct regular audits to assess compliance with ethical and legal standards.
- Investigate and resolve ethical complaints and compliance violations.
- Provide training to project personnel on ethical and compliance issues.
- Advise the Project Steering Committee on ethical and compliance matters.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of ethics.
- Establish compliance monitoring procedures.
- Set up a confidential reporting mechanism for ethical concerns.
- Recruit committee members with expertise in ethics, law, and compliance.

**Membership:**

- Head of Legal and Compliance (Chair)
- Independent Ethics Advisor
- Data Protection Officer
- Representative from the Casino Operators (Compliance Officer)
- Internal Audit Representative

**Decision Rights:** Decisions related to ethical conduct, compliance with laws and regulations, and investigation of ethical complaints. Authority to halt project activities that violate ethical or legal standards.

**Decision Mechanism:** Decisions are made by majority vote. The Head of Legal and Compliance (Chair) has the authority to veto decisions that pose a significant legal or ethical risk.

**Meeting Cadence:** Quarterly, or more frequently as needed to address emerging ethical or compliance issues.

**Typical Agenda Items:**

- Review of ethical complaints and compliance violations.
- Discussion of emerging ethical and legal issues.
- Review of compliance monitoring results.
- Approval of changes to the code of ethics or compliance procedures.
- Training updates for project personnel.

**Escalation Path:** To the Project Steering Committee and, if necessary, to the organization's CEO or Board of Directors for unresolved ethical or compliance issues.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the public, government officials, and international organizations. Addresses concerns, builds support, and mitigates potential opposition to the project.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Identify and analyze key stakeholders.
- Communicate project information to stakeholders through various channels.
- Solicit feedback from stakeholders and address their concerns.
- Build relationships with key stakeholders.
- Manage public relations and media inquiries.
- Organize stakeholder meetings and events.
- Monitor public opinion and sentiment towards the project.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication plan.
- Establish communication channels.
- Recruit group members with expertise in public relations, communication, and stakeholder engagement.

**Membership:**

- Director of Public Relations (Chair)
- Communication Manager
- Community Liaison Officer
- Government Relations Officer
- Representative from the Casino Operators (Marketing)
- Independent Public Relations Consultant

**Decision Rights:** Decisions related to stakeholder communication, public relations, and community engagement. Authority to approve communication materials and organize stakeholder events.

**Decision Mechanism:** Decisions are made by the Director of Public Relations, in consultation with the Stakeholder Engagement Group. Significant issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly, or more frequently as needed to address emerging stakeholder concerns.

**Typical Agenda Items:**

- Review of stakeholder feedback and concerns.
- Discussion of communication strategies.
- Approval of communication materials.
- Planning of stakeholder events.
- Monitoring of public opinion and sentiment.
- Updates on government relations activities.

**Escalation Path:** To the Project Steering Committee for issues exceeding the Stakeholder Engagement Group's authority or requiring strategic guidance.