## Suggestion 1 - Fehmarn Belt Fixed Link

The Fehmarn Belt Fixed Link is an 18-kilometer immersed tunnel that will connect Rødbyhavn on the Danish island of Lolland with Puttgarden in northern Germany, creating a direct link between Scandinavia and Central Europe. The project includes a four-lane motorway and a double-track electrified railway. The construction started in 2020 and is expected to be completed by 2029. The total budget is approximately €7.4 billion.

### Success Metrics

Completion of the tunnel by 2029.
Reduction in travel time between Scandinavia and Central Europe.
Adherence to the budget of €7.4 billion.
Compliance with environmental regulations.

### Risks and Challenges Faced

Geotechnical challenges: The seabed conditions required extensive dredging and stabilization. This was mitigated by detailed geological surveys and ground improvement techniques.
Environmental concerns: Protecting the marine environment during construction was a major challenge. Mitigation included using specialized equipment to minimize disturbance and implementing strict monitoring programs.
Cross-border coordination: Coordinating between Danish and German authorities required clear communication and established protocols. Regular meetings and joint working groups were established.
Budget overruns: Initial budget estimates were exceeded due to unforeseen costs. This was addressed through value engineering and securing additional funding.

### Where to Find More Information

Official project website: https://femern.com/
Ramboll's project page: https://ramboll.com/projects/rf/fehmarnbelt-fixed-link
Tunnel Engineering International: https://www.tunnel-international.com/topics/fehmarnbelt-fixed-link-3374698.html

### Actionable Steps

Contact Femern A/S (the project owner) via their website for general inquiries.
Reach out to Ramboll (engineering consultant) through their contact form for technical insights.
Connect with individuals involved in the project via LinkedIn, searching for roles such as 'Project Manager Fehmarnbelt' or 'Environmental Engineer Fehmarnbelt'.

### Rationale for Suggestion

The Fehmarn Belt Fixed Link is a relevant example of a large-scale immersed tunnel project involving cross-border collaboration, significant geotechnical challenges, and environmental considerations. It provides valuable insights into project management, risk mitigation, and stakeholder engagement for a similar transoceanic tunnel project. Although geographically distant, the technical and regulatory challenges are highly relevant.
## Suggestion 2 - Hong Kong-Zhuhai-Macau Bridge (HZMB)

The Hong Kong-Zhuhai-Macau Bridge (HZMB) is a 55-kilometer bridge-tunnel system consisting of a series of bridges and tunnels, including a 6.7-kilometer submerged tunnel, that connects Hong Kong, Zhuhai, and Macau. The project was completed in 2018 with a total cost of approximately $20 billion USD. It significantly reduces travel time between the three cities and enhances economic integration.

### Success Metrics

Completion of the bridge-tunnel system in 2018.
Reduction in travel time between Hong Kong, Zhuhai, and Macau.
Improved economic integration of the Pearl River Delta region.
Adherence to safety and environmental standards.

### Risks and Challenges Faced

Technical complexity: Constructing a submerged tunnel in a busy shipping channel with soft soil conditions posed significant engineering challenges. This was addressed through advanced tunneling techniques and extensive soil improvement.
Environmental impact: Minimizing the impact on the marine environment, including the habitat of the Chinese white dolphin, was a priority. Mitigation measures included careful construction practices and the establishment of marine protected areas.
Cross-border coordination: Coordinating between three different administrative regions (Hong Kong, Zhuhai, and Macau) required extensive collaboration and agreement on standards and procedures. A joint project management authority was established.
Cost overruns: The project experienced cost overruns due to unforeseen challenges and delays. This was managed through value engineering and securing additional funding.

### Where to Find More Information

Official project website (in Chinese): http://www.hzmb.hk/
China Daily article: http://www.chinadaily.com.cn/a/201810/23/WS5bcddc6da310eff303281a9f.html
Wikipedia: https://en.wikipedia.org/wiki/Hong_Kong%E2%80%93Zhuhai%E2%80%93Macau_Bridge

### Actionable Steps

Contact the Hong Kong Highways Department for information on the project's management and construction.
Search for publications and presentations by engineers and project managers involved in the HZMB project on academic databases like IEEE Xplore or Scopus.
Connect with professionals who worked on the HZMB project via LinkedIn, focusing on roles related to tunnel engineering, environmental management, and project coordination.

### Rationale for Suggestion

The HZMB project is highly relevant due to its combination of bridge and submerged tunnel elements, its scale, and the cross-border coordination required. The challenges faced in constructing the submerged tunnel portion, particularly in a complex marine environment, offer valuable lessons for the Spain-Morocco project. While geographically distant and culturally different, the engineering and logistical challenges are comparable.
## Suggestion 3 - Channel Tunnel (Chunnel)

The Channel Tunnel is a 50.5-kilometer undersea rail tunnel connecting Folkestone, Kent, in the United Kingdom, with Coquelles, Pas-de-Calais, near Calais in northern France. It has the longest undersea portion of any tunnel in the world (37.9 km). The tunnel carries high-speed Eurostar passenger trains and Eurotunnel Shuttle vehicle transport. It was opened in 1994 and cost approximately £9 billion (equivalent to about €12 billion today).

### Success Metrics

Completion of the tunnel in 1994.
Establishment of high-speed rail service between London and Paris.
Significant reduction in travel time between the UK and continental Europe.
Safe and reliable operation of the tunnel for over 25 years.

### Risks and Challenges Faced

Geological challenges: Variable geological conditions, including chalk marl and clay, required different tunneling techniques. This was addressed through extensive geological surveys and the use of tunnel boring machines (TBMs) adapted to different soil types.
Water ingress: Preventing water ingress into the tunnel was a major challenge. This was mitigated through the use of watertight linings and grouting techniques.
Cross-border coordination: Coordinating between British and French authorities required extensive collaboration and agreement on standards and procedures. A joint project management organization was established.
Financial risks: The project faced significant financial risks due to cost overruns and lower-than-expected traffic volumes. This was managed through debt restructuring and improved operational efficiency.

### Where to Find More Information

Official Eurotunnel website: https://www.eurotunnel.com/
ICE Virtual Library: https://www.icevirtuallibrary.com/doi/book/10.1680/chan.1300001
Wikipedia: https://en.wikipedia.org/wiki/Channel_Tunnel

### Actionable Steps

Contact Eurotunnel for information on the tunnel's construction and operation.
Consult the archives of the Institution of Civil Engineers (ICE) for technical papers and reports on the project.
Search for publications and presentations by engineers and project managers involved in the Channel Tunnel project on academic databases like Scopus or Web of Science.

### Rationale for Suggestion

The Channel Tunnel is a classic example of a large-scale undersea tunnel project that faced significant technical, financial, and political challenges. Its success in connecting two countries and operating for over two decades provides valuable lessons for the Spain-Morocco project. The cross-border coordination and geological challenges are particularly relevant. While the construction techniques have evolved since the Chunnel was built, the fundamental principles and challenges remain similar.

## Summary

The user is planning a large-scale, 20-year infrastructure project to construct a submerged tunnel between Spain and Morocco. The project involves significant technical, financial, and geopolitical risks. The following are recommendations for similar projects that can provide insights and guidance.