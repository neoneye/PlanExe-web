This plan involves money.

## Currencies

- **EUR:** The project is budgeted in EUR and spans multiple European countries.
- **MAD:** Local currency for transactions within Morocco.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. MAD may be used for local transactions within Morocco. Currency exchange rates should be monitored, and hedging strategies may be considered to mitigate risks from exchange rate fluctuations.