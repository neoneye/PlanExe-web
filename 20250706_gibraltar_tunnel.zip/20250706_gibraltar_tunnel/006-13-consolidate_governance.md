# Governance Audit


## Audit - Corruption Risks

- Bribery of government officials in Spain or Morocco to expedite permit approvals or influence regulatory decisions.
- Kickbacks from construction companies in exchange for being awarded contracts.
- Conflicts of interest involving project managers or government officials with financial ties to suppliers or contractors.
- Misuse of confidential project information for personal gain, such as insider trading related to land acquisition or material procurement.
- Nepotism in hiring practices, favoring unqualified relatives or friends for key project positions.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, leading to overpayment for goods and services.
- Double-billing for the same expenses or services.
- Use of project funds for unauthorized purposes, such as personal travel or entertainment.
- Inefficient allocation of resources, such as overspending on certain project phases while neglecting others.
- Poor record-keeping and documentation, making it difficult to track project expenses and identify potential misuse of funds.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, focusing on procurement processes, contract management, and expense reporting.
- Engage an external auditor to perform an annual review of project activities and compliance with regulations.
- Implement a system for tracking and verifying all project expenses, including receipts and supporting documentation.
- Establish a contract review board to scrutinize all major contracts and ensure they are awarded fairly and transparently.
- Conduct regular site visits to monitor construction progress and verify that materials are being used efficiently and effectively.

## Audit - Transparency Measures

- Create a public-facing project dashboard that tracks key milestones, budget expenditures, and environmental impact data.
- Publish minutes of key project meetings, including those of the steering committee and technical review board.
- Establish a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution.
- Make project policies and reports, including environmental impact assessments and risk management plans, publicly accessible online.
- Document the selection criteria for major decisions, such as vendor selection and technology choices, and make this information available to stakeholders.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this large-scale, high-risk, and politically sensitive infrastructure project. Ensures alignment with strategic goals and manages significant risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (above €50 million).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve key stakeholder engagement strategies.
- Ensure alignment with the overall organizational strategy.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Secretary.
- Establish meeting schedule and communication protocols.
- Review and approve initial project plan and budget.
- Define escalation thresholds and procedures.

**Membership:**

- CEO/Executive Sponsor
- Chief Financial Officer
- Chief Engineering Officer
- Representative from Spanish Government (Ministry of Transport)
- Representative from Moroccan Government (Ministry of Equipment, Transport and Logistics)
- Independent Infrastructure Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above €50 million), timeline, and risk management. Approval of major project milestones and deliverables.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Executive Sponsor has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and mitigation strategies.
- Approval of budget revisions and change requests (above €50 million).
- Review of stakeholder engagement activities.
- Updates on regulatory and compliance matters.
- Review of audit reports and recommendations.

**Escalation Path:** To the Board of Directors for issues exceeding the Steering Committee's authority or unresolved conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized operational management, coordination, and support for the project. Ensures consistent application of project management methodologies and standards.

**Responsibilities:**

- Develop and maintain project management plans.
- Monitor project progress and performance.
- Manage project budget and resources (below €50 million).
- Coordinate project activities across different teams.
- Identify and manage project risks and issues.
- Track and report on project status.
- Ensure compliance with project management standards and procedures.
- Manage day-to-day stakeholder communication.
- Implement and maintain project documentation and knowledge management systems.

**Initial Setup Actions:**

- Establish PMO structure and roles.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.
- Recruit and train PMO staff.

**Membership:**

- Project Manager
- Project Controller
- Risk Manager
- Communications Manager
- Technical Leads (various disciplines)

**Decision Rights:** Operational decisions related to project execution, resource allocation (below €50 million), and risk management within defined thresholds. Approval of minor project changes.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Issues requiring strategic decisions are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and issues.
- Review of budget and resource utilization.
- Coordination of project activities.
- Review of project documentation.
- Action item tracking.

**Escalation Path:** To the Project Steering Committee for issues exceeding the PMO's authority or unresolved conflicts.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on critical engineering and construction aspects of the project. Ensures technical feasibility and safety.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance on construction methods and materials.
- Assess technical risks and recommend mitigation strategies.
- Monitor construction quality and compliance with technical standards.
- Advise on the selection of technologies and equipment.
- Conduct independent technical audits.
- Review and approve geotechnical surveys and seismic risk assessments.
- Ensure adherence to relevant engineering codes and standards.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define scope of expertise and responsibilities.
- Establish communication protocols.
- Review initial project designs and specifications.
- Develop technical review checklists.

**Membership:**

- Geotechnical Engineer
- Structural Engineer
- Marine Engineer
- Tunneling Expert
- Materials Scientist
- Independent Engineering Consultant
- Cybersecurity Expert

**Decision Rights:** Technical approval of designs, specifications, and construction methods. Recommendations on technical risk mitigation strategies. Approval of technical deviations from approved plans.

**Decision Mechanism:** Decisions made by consensus of the technical experts. In case of disagreement, an independent engineering consultant provides a final recommendation.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical risks and mitigation strategies.
- Review of construction progress and quality.
- Updates on new technologies and materials.
- Review of geotechnical surveys and seismic risk assessments.
- Discussion of cybersecurity risks and mitigation strategies.

**Escalation Path:** To the Project Steering Committee for unresolved technical issues or significant deviations from approved plans.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws, regulations, and ethical standards. Mitigates risks related to corruption, fraud, and non-compliance.

**Responsibilities:**

- Develop and implement ethics and compliance policies.
- Monitor compliance with laws, regulations, and ethical standards.
- Investigate allegations of fraud, corruption, and non-compliance.
- Provide training on ethics and compliance.
- Conduct regular compliance audits.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee the whistleblower mechanism.
- Review and approve contracts for compliance with ethical standards.

**Initial Setup Actions:**

- Develop ethics and compliance policies.
- Establish reporting mechanisms for suspected violations.
- Recruit committee members.
- Develop a compliance training program.
- Establish a data privacy compliance framework.

**Membership:**

- Legal Counsel
- Compliance Officer
- Internal Auditor
- Representative from Human Resources
- Independent Ethics Advisor
- Data Protection Officer

**Decision Rights:** Decisions related to ethics and compliance policies, investigations, and disciplinary actions. Approval of compliance training programs. Approval of data privacy policies.

**Decision Mechanism:** Decisions made by majority vote. The Independent Ethics Advisor provides a final recommendation in case of a tie or significant disagreement.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for compliance issues.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethics and compliance issues.
- Review of investigations and disciplinary actions.
- Updates on laws and regulations.
- Review of compliance training programs.
- Review of data privacy policies and procedures.

**Escalation Path:** To the Board of Directors for significant ethics or compliance violations or unresolved issues.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including local communities, environmental groups, and regulatory bodies. Ensures transparency and addresses stakeholder concerns.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Provide regular updates on project progress.
- Manage media relations.
- Organize community forums and meetings.
- Monitor stakeholder sentiment.
- Ensure transparency in project decision-making.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Recruit group members.
- Develop a grievance mechanism.

**Membership:**

- Communications Manager
- Community Liaison Officer
- Environmental Specialist
- Representative from Spanish Government
- Representative from Moroccan Government
- Independent Stakeholder Representative

**Decision Rights:** Decisions related to stakeholder engagement strategies, communication plans, and grievance resolution. Recommendations on community benefits programs.

**Decision Mechanism:** Decisions made by consensus. The Independent Stakeholder Representative provides a final recommendation in case of disagreement.

**Meeting Cadence:** Monthly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Updates on project progress.
- Review of communication plans.
- Planning of community forums and meetings.
- Monitoring of stakeholder sentiment.

**Escalation Path:** To the Project Steering Committee for unresolved stakeholder issues or significant opposition to the project.

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (CEO/Executive Sponsor, CFO, Chief Engineering Officer, Representatives from Spanish and Moroccan Governments, Independent Infrastructure Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager revises SteerCo ToR based on feedback and submits to CEO/Executive Sponsor for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Revised SteerCo ToR v0.2

**Dependencies:**

- Feedback Summary

### 4. CEO/Executive Sponsor approves the final Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Revised SteerCo ToR v0.2

### 5. Senior Sponsor formally appoints Steering Committee Chair.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Steering Committee members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Steering Committee Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Steering Committee Membership List

### 8. Hold initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 9. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 10. Circulate Draft Technical Advisory Group ToR for review by potential members (Geotechnical Engineer, Structural Engineer, Marine Engineer, Tunneling Expert, Materials Scientist, Independent Engineering Consultant, Cybersecurity Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Potential Members List Available

### 11. Project Manager revises Technical Advisory Group ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Revised Technical Advisory Group ToR v0.2

**Dependencies:**

- Feedback Summary

### 12. Project Steering Committee approves the final Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Revised Technical Advisory Group ToR v0.2

### 13. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Technical Advisory Group members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 14. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Technical Advisory Group Membership List

### 15. Hold initial Technical Advisory Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 16. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 17. Circulate Draft Ethics & Compliance Committee ToR for review by potential members (Legal Counsel, Compliance Officer, Internal Auditor, Representative from Human Resources, Independent Ethics Advisor, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Potential Members List Available

### 18. Project Manager revises Ethics & Compliance Committee ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Revised Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Feedback Summary

### 19. Project Steering Committee approves the final Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Revised Ethics & Compliance Committee ToR v0.2

### 20. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Ethics & Compliance Committee members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 21. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 22. Hold initial Ethics & Compliance Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 23. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 24. Circulate Draft Stakeholder Engagement Group ToR for review by potential members (Communications Manager, Community Liaison Officer, Environmental Specialist, Representatives from Spanish and Moroccan Governments, Independent Stakeholder Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Potential Members List Available

### 25. Project Manager revises Stakeholder Engagement Group ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Revised Stakeholder Engagement Group ToR v0.2

**Dependencies:**

- Feedback Summary

### 26. Project Steering Committee approves the final Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Revised Stakeholder Engagement Group ToR v0.2

### 27. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Stakeholder Engagement Group members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Confirmed Stakeholder Engagement Group Membership List

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 28. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Stakeholder Engagement Group Membership List

### 29. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 30. Establish PMO structure and roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Role Descriptions

**Dependencies:**

- Project Plan Approved

### 31. Develop project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Document

### 32. Define project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 33. Establish communication protocols.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 34. Recruit and train PMO staff.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Staff List
- Training Records

**Dependencies:**

- Communication Protocols Document

### 35. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staff List

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority (€50 million)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential for uncontrolled cost overruns and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., Geopolitical Instability)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Approval of Mitigation Plan
Rationale: Strategic impact on project viability and requires high-level decision-making.
Negative Consequences: Project delays, increased costs, or project cancellation.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Vote
Rationale: Requires higher-level arbitration to ensure project progress.
Negative Consequences: Delays in procurement and potential impact on project timeline.

**Proposed Major Scope Change (e.g., Altering Tunnel Route)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant impact on project budget, timeline, and strategic objectives.
Negative Consequences: Budget overruns, schedule delays, and misalignment with strategic goals.

**Reported Ethical Concern (e.g., Bribery Allegation)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to the Board of Directors
Rationale: Requires independent review and potential disciplinary action.
Negative Consequences: Legal penalties, reputational damage, and project disruption.

**Unresolved Stakeholder Opposition**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Strategy and Approval of Revised Approach
Rationale: Significant opposition could lead to project delays or cancellation.
Negative Consequences: Project delays, increased costs, and reputational damage.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Monthly Progress Reports

**Frequency:** Monthly

**Responsible Role:** PMO

**Adaptation Process:** PMO analyzes KPI data and proposes corrective actions or plan adjustments via Change Request to Steering Committee.

**Adaptation Trigger:** KPI deviates >10% from baseline or target.

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Risk Management Software

**Frequency:** Bi-weekly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk mitigation plan updated by Risk Manager, reviewed by PMO, and approved by Steering Committee if significant changes are required.

**Adaptation Trigger:** New critical risk identified, existing risk likelihood or impact increases significantly, or mitigation plan proves ineffective.

### 3. Financial Performance Monitoring
**Monitoring Tools/Platforms:**

  - Budget Tracking Spreadsheet
  - Financial Accounting System
  - Earned Value Management (EVM) Reports

**Frequency:** Monthly

**Responsible Role:** Project Controller

**Adaptation Process:** Project Controller identifies variances and proposes corrective actions to PMO. Significant budget adjustments require Steering Committee approval.

**Adaptation Trigger:** Cost variance exceeds 5% of budget, or projected cost at completion exceeds approved budget.

### 4. Regulatory Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Compliance Checklist
  - Permit Tracking System
  - Audit Reports

**Frequency:** Quarterly

**Responsible Role:** Ethics & Compliance Committee

**Adaptation Process:** Ethics & Compliance Committee reviews compliance status and recommends corrective actions. Legal Counsel implements necessary changes.

**Adaptation Trigger:** Audit finding requires action, new regulation is introduced, or compliance violation is reported.

### 5. Stakeholder Feedback Analysis
**Monitoring Tools/Platforms:**

  - Survey Platform
  - Stakeholder Communication Log
  - Community Forum Feedback

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement Group

**Adaptation Process:** Stakeholder Engagement Group analyzes feedback and adjusts communication strategies or project plans to address concerns. Significant changes require Steering Committee approval.

**Adaptation Trigger:** Negative feedback trend identified, significant stakeholder opposition arises, or communication strategy proves ineffective.

### 6. Geopolitical Risk Monitoring
**Monitoring Tools/Platforms:**

  - Political Risk Assessment Reports
  - News and Media Monitoring
  - Government Relations Communication Logs

**Frequency:** Monthly

**Responsible Role:** Project Steering Committee

**Adaptation Process:** Steering Committee reviews geopolitical risks and adjusts project strategy or risk mitigation plans as needed. May involve renegotiating agreements with governments or securing political risk insurance.

**Adaptation Trigger:** Significant political instability in Spain or Morocco, change in government policy affecting the project, or increased cross-border tensions.

### 7. Cybersecurity Threat Monitoring
**Monitoring Tools/Platforms:**

  - Cybersecurity Threat Intelligence Feeds
  - Security Information and Event Management (SIEM) System
  - Vulnerability Scan Reports

**Frequency:** Weekly

**Responsible Role:** Cybersecurity Expert

**Adaptation Process:** Cybersecurity Expert identifies and mitigates cybersecurity threats. Implements security patches and updates cybersecurity protocols. Escalates critical threats to the Technical Advisory Group and Steering Committee.

**Adaptation Trigger:** Detection of a cybersecurity threat, vulnerability identified, or security incident occurs.

### 8. Long-Term Operational and Maintenance Cost Review
**Monitoring Tools/Platforms:**

  - Life-Cycle Cost Analysis
  - Maintenance Budget Projections
  - Asset Management System

**Frequency:** Annually

**Responsible Role:** Chief Engineering Officer

**Adaptation Process:** Chief Engineering Officer reviews long-term operational and maintenance costs and adjusts budget projections and maintenance plans as needed. Significant budget increases require Steering Committee approval.

**Adaptation Trigger:** Significant increase in projected maintenance costs, identification of unforeseen maintenance challenges, or need for specialized expertise.

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses the defined governance bodies. The Escalation Matrix aligns with the governance hierarchy. Monitoring roles are assigned to existing bodies/roles. Overall, the components show good internal consistency.
3. Point 3: Potential Gaps / Areas for Enhancement: The role of the CEO/Executive Sponsor, while identified as having the deciding vote in the Project Steering Committee, lacks specific detail regarding their ongoing responsibilities beyond this. Their active involvement in risk oversight and strategic adaptation should be clarified.
4. Point 4: Potential Gaps / Areas for Enhancement: The Ethics & Compliance Committee's responsibilities are well-defined, but the process for whistleblower investigations, including protection of whistleblowers and escalation of findings, needs more detail. A clear, documented process is crucial.
5. Point 5: Potential Gaps / Areas for Enhancement: The Stakeholder Engagement Group's adaptation process mentions adjusting communication strategies, but lacks detail on how conflicting stakeholder interests will be managed and prioritized. A framework for balancing competing demands is needed.
6. Point 6: Potential Gaps / Areas for Enhancement: The Technical Advisory Group includes a Cybersecurity Expert, but the integration of cybersecurity considerations into the project's design and construction phases is not explicitly detailed in the Technical Advisory Group's responsibilities. Proactive security measures should be emphasized.
7. Point 7: Potential Gaps / Areas for Enhancement: The adaptation triggers in the Monitoring Progress plan are mostly quantitative (e.g., 10% deviation from KPI). Qualitative triggers, such as significant negative media coverage or a major geopolitical shift, should also be included to allow for more proactive adaptation.

## Tough Questions

1. What is the current probability-weighted forecast for project completion within the 20-year timeframe, considering potential regulatory delays and technical challenges?
2. Show evidence of a verified process for ensuring compliance with all applicable environmental regulations in both Spain and Morocco.
3. What specific contingency plans are in place to address a potential cost overrun exceeding 15% of the initial €40 billion budget?
4. How will the project ensure the long-term operational and maintenance costs remain within acceptable limits, given the potential for unforeseen technical challenges and environmental factors?
5. What are the specific, measurable targets for stakeholder satisfaction, and how will the project address any negative feedback or concerns?
6. What are the specific criteria and process for selecting and vetting international investors to ensure alignment with the project's ethical and sustainability goals?
7. What is the detailed cybersecurity incident response plan, including roles, responsibilities, and communication protocols, and how frequently is it tested?
8. What are the specific, pre-defined triggers that would necessitate a formal review of the project's strategic alignment with the long-term geopolitical landscape between Spain and Morocco?

## Summary

The governance framework establishes a multi-layered oversight structure with clear responsibilities for strategic direction, operational management, technical expertise, ethical compliance, and stakeholder engagement. The framework emphasizes proactive risk management and adaptation through regular monitoring and defined escalation paths. Key strengths lie in the inclusion of independent expertise and dedicated committees for ethics and compliance, and stakeholder engagement. The framework's focus is on ensuring project success through robust oversight, proactive risk mitigation, and ethical conduct.