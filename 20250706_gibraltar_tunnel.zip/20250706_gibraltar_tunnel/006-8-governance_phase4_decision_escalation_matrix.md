**Budget Request Exceeding PMO Authority (€50 million)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential for uncontrolled cost overruns and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., Geopolitical Instability)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Approval of Mitigation Plan
Rationale: Strategic impact on project viability and requires high-level decision-making.
Negative Consequences: Project delays, increased costs, or project cancellation.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Vote
Rationale: Requires higher-level arbitration to ensure project progress.
Negative Consequences: Delays in procurement and potential impact on project timeline.

**Proposed Major Scope Change (e.g., Altering Tunnel Route)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant impact on project budget, timeline, and strategic objectives.
Negative Consequences: Budget overruns, schedule delays, and misalignment with strategic goals.

**Reported Ethical Concern (e.g., Bribery Allegation)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to the Board of Directors
Rationale: Requires independent review and potential disciplinary action.
Negative Consequences: Legal penalties, reputational damage, and project disruption.

**Unresolved Stakeholder Opposition**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Strategy and Approval of Revised Approach
Rationale: Significant opposition could lead to project delays or cancellation.
Negative Consequences: Project delays, increased costs, and reputational damage.