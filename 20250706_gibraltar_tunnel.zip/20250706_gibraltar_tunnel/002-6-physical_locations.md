This plan implies one or more physical locations.

## Requirements for physical locations

- Deep-sea construction capabilities
- Proximity to the Strait of Gibraltar
- Access to concrete and other construction materials
- Suitable seabed conditions for anchoring
- Minimal seismic activity

## Location 1
Spain and Morocco

Strait of Gibraltar

Underwater, 100 meters below sea level

**Rationale**: The project explicitly requires a submerged tunnel connecting Spain and Morocco through the Strait of Gibraltar at a depth of 100 meters.

## Location 2
Spain

Southern Coast of Spain

Port of Algeciras

**Rationale**: The Port of Algeciras provides existing infrastructure and access to the Strait of Gibraltar, facilitating the transport of materials and personnel for the tunnel construction.

## Location 3
Morocco

Northern Coast of Morocco

Port of Tangier

**Rationale**: The Port of Tangier offers similar advantages on the Moroccan side, including proximity to the Strait and established port facilities for supporting the project.

## Location Summary
The primary location is the Strait of Gibraltar, 100 meters below sea level. The ports of Algeciras (Spain) and Tangier (Morocco) are suggested as logistical hubs for construction and material transport.