### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (CEO/Executive Sponsor, CFO, Chief Engineering Officer, Representatives from Spanish and Moroccan Governments, Independent Infrastructure Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager revises SteerCo ToR based on feedback and submits to CEO/Executive Sponsor for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Revised SteerCo ToR v0.2

**Dependencies:**

- Feedback Summary

### 4. CEO/Executive Sponsor approves the final Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Revised SteerCo ToR v0.2

### 5. Senior Sponsor formally appoints Steering Committee Chair.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Steering Committee members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Steering Committee Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Steering Committee Membership List

### 8. Hold initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 9. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 10. Circulate Draft Technical Advisory Group ToR for review by potential members (Geotechnical Engineer, Structural Engineer, Marine Engineer, Tunneling Expert, Materials Scientist, Independent Engineering Consultant, Cybersecurity Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Potential Members List Available

### 11. Project Manager revises Technical Advisory Group ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Revised Technical Advisory Group ToR v0.2

**Dependencies:**

- Feedback Summary

### 12. Project Steering Committee approves the final Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Revised Technical Advisory Group ToR v0.2

### 13. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Technical Advisory Group members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 14. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Technical Advisory Group Membership List

### 15. Hold initial Technical Advisory Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 16. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 17. Circulate Draft Ethics & Compliance Committee ToR for review by potential members (Legal Counsel, Compliance Officer, Internal Auditor, Representative from Human Resources, Independent Ethics Advisor, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Potential Members List Available

### 18. Project Manager revises Ethics & Compliance Committee ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Revised Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Feedback Summary

### 19. Project Steering Committee approves the final Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Revised Ethics & Compliance Committee ToR v0.2

### 20. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Ethics & Compliance Committee members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 21. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 22. Hold initial Ethics & Compliance Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 23. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 24. Circulate Draft Stakeholder Engagement Group ToR for review by potential members (Communications Manager, Community Liaison Officer, Environmental Specialist, Representatives from Spanish and Moroccan Governments, Independent Stakeholder Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Potential Members List Available

### 25. Project Manager revises Stakeholder Engagement Group ToR based on feedback and submits to Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Revised Stakeholder Engagement Group ToR v0.2

**Dependencies:**

- Feedback Summary

### 26. Project Steering Committee approves the final Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Revised Stakeholder Engagement Group ToR v0.2

### 27. Project Manager, in consultation with the Steering Committee Chair, identifies and confirms all Stakeholder Engagement Group members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Confirmed Stakeholder Engagement Group Membership List

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 28. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Stakeholder Engagement Group Membership List

### 29. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 30. Establish PMO structure and roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Role Descriptions

**Dependencies:**

- Project Plan Approved

### 31. Develop project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Document

### 32. Define project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 33. Establish communication protocols.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 34. Recruit and train PMO staff.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Staff List
- Training Records

**Dependencies:**

- Communication Protocols Document

### 35. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staff List