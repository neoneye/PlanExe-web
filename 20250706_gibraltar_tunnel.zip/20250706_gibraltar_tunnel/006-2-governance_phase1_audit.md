
## Audit - Corruption Risks

- Bribery of government officials in Spain or Morocco to expedite permit approvals or influence regulatory decisions.
- Kickbacks from construction companies in exchange for being awarded contracts.
- Conflicts of interest involving project managers or government officials with financial ties to suppliers or contractors.
- Misuse of confidential project information for personal gain, such as insider trading related to land acquisition or material procurement.
- Nepotism in hiring practices, favoring unqualified relatives or friends for key project positions.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, leading to overpayment for goods and services.
- Double-billing for the same expenses or services.
- Use of project funds for unauthorized purposes, such as personal travel or entertainment.
- Inefficient allocation of resources, such as overspending on certain project phases while neglecting others.
- Poor record-keeping and documentation, making it difficult to track project expenses and identify potential misuse of funds.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, focusing on procurement processes, contract management, and expense reporting.
- Engage an external auditor to perform an annual review of project activities and compliance with regulations.
- Implement a system for tracking and verifying all project expenses, including receipts and supporting documentation.
- Establish a contract review board to scrutinize all major contracts and ensure they are awarded fairly and transparently.
- Conduct regular site visits to monitor construction progress and verify that materials are being used efficiently and effectively.

## Audit - Transparency Measures

- Create a public-facing project dashboard that tracks key milestones, budget expenditures, and environmental impact data.
- Publish minutes of key project meetings, including those of the steering committee and technical review board.
- Establish a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution.
- Make project policies and reports, including environmental impact assessments and risk management plans, publicly accessible online.
- Document the selection criteria for major decisions, such as vendor selection and technology choices, and make this information available to stakeholders.