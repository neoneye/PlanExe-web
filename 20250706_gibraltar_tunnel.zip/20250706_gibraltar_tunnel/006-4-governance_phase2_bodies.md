### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this large-scale, high-risk, and politically sensitive infrastructure project. Ensures alignment with strategic goals and manages significant risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (above €50 million).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve key stakeholder engagement strategies.
- Ensure alignment with the overall organizational strategy.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Secretary.
- Establish meeting schedule and communication protocols.
- Review and approve initial project plan and budget.
- Define escalation thresholds and procedures.

**Membership:**

- CEO/Executive Sponsor
- Chief Financial Officer
- Chief Engineering Officer
- Representative from Spanish Government (Ministry of Transport)
- Representative from Moroccan Government (Ministry of Equipment, Transport and Logistics)
- Independent Infrastructure Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above €50 million), timeline, and risk management. Approval of major project milestones and deliverables.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Executive Sponsor has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and mitigation strategies.
- Approval of budget revisions and change requests (above €50 million).
- Review of stakeholder engagement activities.
- Updates on regulatory and compliance matters.
- Review of audit reports and recommendations.

**Escalation Path:** To the Board of Directors for issues exceeding the Steering Committee's authority or unresolved conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized operational management, coordination, and support for the project. Ensures consistent application of project management methodologies and standards.

**Responsibilities:**

- Develop and maintain project management plans.
- Monitor project progress and performance.
- Manage project budget and resources (below €50 million).
- Coordinate project activities across different teams.
- Identify and manage project risks and issues.
- Track and report on project status.
- Ensure compliance with project management standards and procedures.
- Manage day-to-day stakeholder communication.
- Implement and maintain project documentation and knowledge management systems.

**Initial Setup Actions:**

- Establish PMO structure and roles.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.
- Recruit and train PMO staff.

**Membership:**

- Project Manager
- Project Controller
- Risk Manager
- Communications Manager
- Technical Leads (various disciplines)

**Decision Rights:** Operational decisions related to project execution, resource allocation (below €50 million), and risk management within defined thresholds. Approval of minor project changes.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Issues requiring strategic decisions are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and issues.
- Review of budget and resource utilization.
- Coordination of project activities.
- Review of project documentation.
- Action item tracking.

**Escalation Path:** To the Project Steering Committee for issues exceeding the PMO's authority or unresolved conflicts.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on critical engineering and construction aspects of the project. Ensures technical feasibility and safety.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance on construction methods and materials.
- Assess technical risks and recommend mitigation strategies.
- Monitor construction quality and compliance with technical standards.
- Advise on the selection of technologies and equipment.
- Conduct independent technical audits.
- Review and approve geotechnical surveys and seismic risk assessments.
- Ensure adherence to relevant engineering codes and standards.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define scope of expertise and responsibilities.
- Establish communication protocols.
- Review initial project designs and specifications.
- Develop technical review checklists.

**Membership:**

- Geotechnical Engineer
- Structural Engineer
- Marine Engineer
- Tunneling Expert
- Materials Scientist
- Independent Engineering Consultant
- Cybersecurity Expert

**Decision Rights:** Technical approval of designs, specifications, and construction methods. Recommendations on technical risk mitigation strategies. Approval of technical deviations from approved plans.

**Decision Mechanism:** Decisions made by consensus of the technical experts. In case of disagreement, an independent engineering consultant provides a final recommendation.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical risks and mitigation strategies.
- Review of construction progress and quality.
- Updates on new technologies and materials.
- Review of geotechnical surveys and seismic risk assessments.
- Discussion of cybersecurity risks and mitigation strategies.

**Escalation Path:** To the Project Steering Committee for unresolved technical issues or significant deviations from approved plans.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws, regulations, and ethical standards. Mitigates risks related to corruption, fraud, and non-compliance.

**Responsibilities:**

- Develop and implement ethics and compliance policies.
- Monitor compliance with laws, regulations, and ethical standards.
- Investigate allegations of fraud, corruption, and non-compliance.
- Provide training on ethics and compliance.
- Conduct regular compliance audits.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee the whistleblower mechanism.
- Review and approve contracts for compliance with ethical standards.

**Initial Setup Actions:**

- Develop ethics and compliance policies.
- Establish reporting mechanisms for suspected violations.
- Recruit committee members.
- Develop a compliance training program.
- Establish a data privacy compliance framework.

**Membership:**

- Legal Counsel
- Compliance Officer
- Internal Auditor
- Representative from Human Resources
- Independent Ethics Advisor
- Data Protection Officer

**Decision Rights:** Decisions related to ethics and compliance policies, investigations, and disciplinary actions. Approval of compliance training programs. Approval of data privacy policies.

**Decision Mechanism:** Decisions made by majority vote. The Independent Ethics Advisor provides a final recommendation in case of a tie or significant disagreement.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for compliance issues.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethics and compliance issues.
- Review of investigations and disciplinary actions.
- Updates on laws and regulations.
- Review of compliance training programs.
- Review of data privacy policies and procedures.

**Escalation Path:** To the Board of Directors for significant ethics or compliance violations or unresolved issues.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including local communities, environmental groups, and regulatory bodies. Ensures transparency and addresses stakeholder concerns.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Provide regular updates on project progress.
- Manage media relations.
- Organize community forums and meetings.
- Monitor stakeholder sentiment.
- Ensure transparency in project decision-making.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Recruit group members.
- Develop a grievance mechanism.

**Membership:**

- Communications Manager
- Community Liaison Officer
- Environmental Specialist
- Representative from Spanish Government
- Representative from Moroccan Government
- Independent Stakeholder Representative

**Decision Rights:** Decisions related to stakeholder engagement strategies, communication plans, and grievance resolution. Recommendations on community benefits programs.

**Decision Mechanism:** Decisions made by consensus. The Independent Stakeholder Representative provides a final recommendation in case of disagreement.

**Meeting Cadence:** Monthly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Updates on project progress.
- Review of communication plans.
- Planning of community forums and meetings.
- Monitoring of stakeholder sentiment.

**Escalation Path:** To the Project Steering Committee for unresolved stakeholder issues or significant opposition to the project.