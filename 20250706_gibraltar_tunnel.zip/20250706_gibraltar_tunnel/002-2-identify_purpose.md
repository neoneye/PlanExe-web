**Purpose:** business

**Purpose Detailed:** Infrastructure project for high-speed rail traffic between Spain and Morocco.

**Topic:** Spain-Morocco Transoceanic Tunnel