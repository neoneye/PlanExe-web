**Purpose:** business

**Purpose Detailed:** Societal initiative to enforce a legal restriction on social media usage by minors, funded by penalties.

**Topic:** EU-wide enforcement of social media blackout for under-15s through unannounced inspections.