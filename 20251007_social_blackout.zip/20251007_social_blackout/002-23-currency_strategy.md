This plan involves money.

## Currencies

- **EUR:** The project spans multiple European countries.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting while local currencies may still be used for local transactions.