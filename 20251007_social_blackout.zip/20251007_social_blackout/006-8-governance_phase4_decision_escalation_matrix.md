**Budget Request Exceeding PMO Authority (€250,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and majority vote based on strategic alignment and budget availability.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for budget overruns, project delays, or misalignment with strategic objectives.

**Critical Risk Materialization (e.g., Legal Injunction)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the impact, review mitigation options, and approve a revised course of action.
Rationale: Materialization of a critical risk threatens project viability and requires strategic intervention.
Negative Consequences: Project halt, significant financial losses, and reputational damage.

**PMO Deadlock on Inspection Resource Allocation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the conflicting proposals, considers strategic priorities, and makes a final decision on resource allocation.
Rationale: Internal disagreement within the PMO prevents efficient project execution and requires higher-level resolution.
Negative Consequences: Delays in inspection activities, inconsistent enforcement, and inefficient resource utilization.

**Proposed Major Scope Change (e.g., Expanding Target Demographic)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee assesses the strategic implications, legal ramifications, and resource requirements of the proposed change, and approves or rejects the change.
Rationale: Significant scope changes impact project objectives, budget, and timeline, requiring strategic approval.
Negative Consequences: Project scope creep, budget overruns, and misalignment with strategic objectives.

**Reported Ethical Concern Involving Inspection Team Misconduct**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics and Compliance Committee investigates the complaint, reviews evidence, and recommends corrective actions or disciplinary measures.
Rationale: Ensures independent review and appropriate action in response to potential ethical violations.
Negative Consequences: Erosion of public trust, legal challenges, and reputational damage.

**Legal Review Board cannot agree on the legal defense strategy**
Escalation Level: Project Steering Committee
Approval Process: The Project Steering Committee will review the different legal opinions and make a final decision based on the best course of action for the project, considering legal risks and project goals.
Rationale: A disagreement among legal experts requires a higher authority to make a decision that aligns with the project's strategic objectives and legal compliance.
Negative Consequences: Inadequate legal defense, increased risk of legal challenges, and potential project delays or termination.