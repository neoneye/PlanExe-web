### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior Representative from the EU Commission, Director of Digital Policy, Director of Justice and Home Affairs, Independent Legal Expert, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager incorporates feedback and finalizes the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Representative from the EU Commission formally appointed as Steering Committee Chairperson.

**Responsible Body/Role:** EU Commissioner responsible for Digital Policy

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints remaining Steering Committee members (Director of Digital Policy, Director of Justice and Home Affairs, Independent Legal Expert, Independent Ethics Advisor).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Manager schedules initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All SteerCo Members Appointed

### 7. Hold initial Project Steering Committee kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 8. Project Manager drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 9. Circulate Draft Ethics and Compliance Committee ToR for review by nominated members (Independent Ethics Advisor, Data Protection Officer, Legal Counsel, Representative from a human rights organization, Representative from a consumer protection organization).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1
- Nominated Members List Available

### 10. Project Manager incorporates feedback and finalizes the Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Independent Ethics Advisor formally appointed as Ethics and Compliance Committee Chairperson.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 12. Project Steering Committee formally appoints remaining Ethics and Compliance Committee members (Data Protection Officer, Legal Counsel, Representative from a human rights organization, Representative from a consumer protection organization).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 13. Project Manager schedules initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All Ethics and Compliance Committee Members Appointed

### 14. Hold initial Ethics and Compliance Committee kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 15. Project Manager drafts initial Terms of Reference for the Legal Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Legal Review Board ToR v0.1

**Dependencies:**

- Project Plan Approved

### 16. Circulate Draft Legal Review Board ToR for review by nominated members (Senior Legal Counsel, External Legal Expert specializing in EU law, Representative from the EU Commission's Legal Service, Data Protection Officer, Representative from each EU member state's legal team).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Legal Review Board ToR v0.1
- Nominated Members List Available

### 17. Project Manager incorporates feedback and finalizes the Terms of Reference for the Legal Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Legal Review Board ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Senior Legal Counsel formally appointed as Legal Review Board Chairperson.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Legal Review Board ToR v1.0

### 19. Project Steering Committee formally appoints remaining Legal Review Board members (External Legal Expert specializing in EU law, Representative from the EU Commission's Legal Service, Data Protection Officer, Representative from each EU member state's legal team).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Legal Review Board ToR v1.0

### 20. Project Manager schedules initial Legal Review Board kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All Legal Review Board Members Appointed

### 21. Hold initial Legal Review Board kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Legal Review Board

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 22. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 23. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Communications Officer, Representative from a parent organization, Representative from a youth organization, Representative from a school or educational institution, Representative from a technology company, Representative from the EU Commission's Public Relations department).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 24. Project Manager incorporates feedback and finalizes the Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 25. Communications Officer formally appointed as Stakeholder Engagement Group Chairperson.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 26. Project Steering Committee formally appoints remaining Stakeholder Engagement Group members (Representative from a parent organization, Representative from a youth organization, Representative from a school or educational institution, Representative from a technology company, Representative from the EU Commission's Public Relations department).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 27. Project Manager schedules initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All Stakeholder Engagement Group Members Appointed

### 28. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 29. Establish PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- PMO Org Chart
- Job Descriptions

**Dependencies:**

- Project Plan Approved

### 30. Develop project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Plan Template
- Risk Register Template
- Issue Log Template

**Dependencies:**

- PMO Org Chart

### 31. Define project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Reporting Schedule
- Reporting Templates

**Dependencies:**

- Project Steering Committee ToR Approved

### 32. Set up project communication channels.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Plan
- Distribution Lists

**Dependencies:**

- Reporting Requirements Defined

### 33. Project Manager schedules initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- PMO Structure Established

### 34. Hold initial PMO kick-off meeting to review project plan, roles, and responsibilities.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent