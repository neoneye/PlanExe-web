**Budget Request Exceeding PMO Authority ($10M Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and vote based on strategic alignment and budget impact.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential budget overruns, project delays, and compromised project scope.

**Critical Risk Materialization (e.g., Major Cyberattack)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the impact and approve a revised mitigation plan.
Rationale: The PMO lacks the authority to address risks with strategic implications.
Negative Consequences: Significant financial losses, reputational damage, and project disruption.

**PMO Deadlock on Shipyard Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the competing proposals and makes a final decision based on strategic priorities (cost, quality, timeline).
Rationale: Inability to agree on a critical vendor impacts project timeline and budget.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change (e.g., Significant Design Modification)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed change, assesses its impact on budget, timeline, and strategic objectives, and approves or rejects the change.
Rationale: Scope changes impact project objectives and require strategic alignment.
Negative Consequences: Scope creep, budget overruns, project delays, and compromised project deliverables.

**Reported Ethical Concern (e.g., Bribery Allegation)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigates the allegation, gathers evidence, and makes a recommendation to the Project Steering Committee.
Rationale: Requires independent review and investigation to ensure ethical conduct.
Negative Consequences: Legal penalties, reputational damage, and project disruption.

**Technical Advisory Group Veto of Technology Integration**
Escalation Level: Project Steering Committee
Approval Process: The Project Steering Committee will review the TAG's concerns, the proposed technology, and weigh the risks and benefits before making a final decision.
Rationale: The TAG has veto power on technical decisions posing significant risk, but the Steering Committee has final authority.
Negative Consequences: Technical failures, security vulnerabilities, and project delays.