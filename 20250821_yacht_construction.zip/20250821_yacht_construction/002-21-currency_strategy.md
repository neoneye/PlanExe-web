This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and large transactions.
- **SGD:** Potential currency for local expenses if Singapore is chosen as the shipyard location.
- **CNY:** Potential currency for local expenses if Shanghai, China is chosen as the shipyard location.
- **AED:** Potential currency for local expenses if Dubai, UAE is chosen as the shipyard location.

**Primary currency:** USD

**Currency strategy:** USD will be used for the primary budget and large transactions. Local currencies (SGD, CNY, AED) may be used for local expenses depending on the shipyard location. Hedging strategies should be considered to mitigate exchange rate fluctuations.