
## Audit - Corruption Risks

- Bribery of shipyard officials to overlook substandard work or expedite timelines.
- Kickbacks from suppliers in exchange for selecting them, even if their materials are overpriced or of lower quality.
- Conflicts of interest where project team members have undisclosed financial ties to suppliers or contractors.
- Misuse of inside information to benefit personally from procurement decisions or contract negotiations.
- Trading favors with regulatory bodies to expedite permits or overlook compliance issues related to the flag of convenience.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors, with the excess funds diverted for personal use.
- Double billing for services or materials, creating fictitious expenses.
- Using project funds for personal travel, entertainment, or other non-project-related expenses.
- Inefficient allocation of resources, such as overstaffing or purchasing unnecessary equipment.
- Misreporting project progress to justify continued funding, even if milestones are not being met.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on procurement, contract management, and expense reports. Responsibility: Internal Audit Department.
- Implement a mandatory ethics training program for all project team members, covering anti-corruption policies and reporting procedures. Frequency: Annually.
- Establish a whistleblower hotline for reporting suspected fraud or corruption, with guaranteed anonymity and protection from retaliation. Responsibility: Legal Counsel.
- Perform regular due diligence on all suppliers and contractors, including background checks and verification of their financial stability and ethical practices. Frequency: Before contract award and annually thereafter.
- Engage an external auditor to conduct a comprehensive review of the project's finances, compliance, and risk management practices upon project completion. Responsibility: Owner/Investor.

## Audit - Transparency Measures

- Establish a project website or dashboard providing real-time updates on project progress, budget expenditures, and key decisions. Publicly accessible.
- Publish minutes of key project meetings, including those of the project steering committee and risk management committee. Accessible to stakeholders.
- Implement a clear and documented process for vendor selection, including evaluation criteria and scoring, to ensure fairness and transparency. Publicly available upon request.
- Establish a policy requiring disclosure of any potential conflicts of interest by project team members. Publicly available.
- Create a whistleblower mechanism allowing anonymous reporting of suspected wrongdoing, with clear procedures for investigation and resolution. Publicly available.