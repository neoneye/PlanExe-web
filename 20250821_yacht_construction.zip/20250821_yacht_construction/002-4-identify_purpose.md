**Purpose:** business

**Purpose Detailed:** Building a luxury yacht to serve as a mobile residence and business headquarters, primarily for tax and legal optimization.

**Topic:** Construction of a luxury expedition yacht for business and personal use.