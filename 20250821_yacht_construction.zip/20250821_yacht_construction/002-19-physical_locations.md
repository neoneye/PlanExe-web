This plan implies one or more physical locations.

## Requirements for physical locations

- Deep water access
- Large construction area
- Skilled labor force
- Proximity to supply chains
- Free trade zone benefits

## Location 1
Singapore

Jurong

Jurong Port or Jurong Industrial Estate

**Rationale**: Singapore has a world-class shipbuilding industry, a skilled workforce, and a strategic location with excellent access to global supply chains. Jurong offers established infrastructure and free trade zone benefits.

## Location 2
China

Shanghai

Waigaoqiao Shipbuilding or Jiangnan Shipyard

**Rationale**: Shanghai boasts significant shipbuilding capacity, competitive pricing, and access to a vast industrial base. Waigaoqiao and Jiangnan are major shipyards with experience in large vessel construction.

## Location 3
United Arab Emirates

Dubai

Dubai Maritime City

**Rationale**: Dubai Maritime City offers a dedicated zone for maritime activities, including shipbuilding and repair. The UAE provides a stable political environment and access to skilled labor.

## Location Summary
Singapore (Jurong) offers a world-class shipbuilding industry and strategic location. Shanghai (Waigaoqiao or Jiangnan Shipyard) provides significant shipbuilding capacity and competitive pricing. Dubai Maritime City (UAE) offers a dedicated maritime zone and a stable political environment, making each location suitable for constructing the luxury expedition yacht.