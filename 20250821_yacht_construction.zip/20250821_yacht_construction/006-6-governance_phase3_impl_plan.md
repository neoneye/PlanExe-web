### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Owner, Legal Counsel, Financial Advisor, Independent Maritime Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager incorporates feedback and finalizes the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Review Feedback from Nominated Members

### 4. Senior Sponsor (Owner) formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Owner

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with the Owner (Chair), schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to review the ToR, confirm membership, and agree on initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed SteerCo Membership

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 7. Project Manager drafts initial PMO structure, roles, project management templates, reporting procedures, and communication protocols.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Structure and Procedures v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 8. Project Steering Committee reviews and approves the PMO structure, roles, project management templates, reporting procedures, and communication protocols.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PMO Structure and Procedures v1.0

**Dependencies:**

- Draft PMO Structure and Procedures v0.1
- Confirmed SteerCo Membership

### 9. Project Manager (Head of PMO) establishes the PMO team by assigning roles to the Project Architect, Lead Engineer, Supply Chain Manager, Technology Specialist, and Quality Control Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Team Established
- Role Assignments Communicated

**Dependencies:**

- Approved PMO Structure and Procedures v1.0

### 10. Project Manager schedules and holds the initial PMO kick-off meeting to review structure, procedures, and assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Established

### 11. Project Manager identifies and recruits technical experts for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of TAG Candidates

**Dependencies:**

- Project Start
- Project Plan Approved

### 12. Project Manager, in consultation with the Lead Engineer, defines the scope of technical review and establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TAG Scope of Review Document
- TAG Communication Protocols

**Dependencies:**

- List of TAG Candidates

### 13. Project Steering Committee formally appoints the members of the Technical Advisory Group (AI Specialist Consultant, Blockchain Specialist Consultant, Cybersecurity Expert Consultant, Independent Naval Architect).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Membership Confirmed
- Appointment Letters Sent

**Dependencies:**

- TAG Scope of Review Document
- TAG Communication Protocols
- Confirmed SteerCo Membership

### 14. Lead Engineer schedules and holds the initial Technical Advisory Group kick-off meeting to review scope, protocols, and initial priorities.

**Responsible Body/Role:** Lead Engineer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Minutes with Action Items

**Dependencies:**

- TAG Membership Confirmed

### 15. Legal Counsel develops a draft compliance program for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Compliance Program v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 16. Legal Counsel establishes reporting procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- ECC Reporting Procedures

**Dependencies:**

- Draft Compliance Program v0.1

### 17. Project Steering Committee formally appoints the members of the Ethics & Compliance Committee (Financial Advisor, Independent Ethics Advisor, Data Protection Officer, Environmental Officer).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- ECC Membership Confirmed
- Appointment Letters Sent

**Dependencies:**

- ECC Reporting Procedures
- Confirmed SteerCo Membership

### 18. Legal Counsel (Chair) schedules and holds the initial Ethics & Compliance Committee kick-off meeting to review the compliance program, reporting procedures, and initial priorities.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Minutes with Action Items

**Dependencies:**

- ECC Membership Confirmed

### 19. Project Manager develops a draft stakeholder engagement plan for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 20. Project Manager identifies key stakeholders and establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- List of Key Stakeholders
- Communication Channels Established

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1

### 21. Project Steering Committee formally appoints the members of the Stakeholder Engagement Group (Public Relations Consultant, Community Liaison Officer, Legal Counsel, Owner's Representative).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SEG Membership Confirmed
- Appointment Letters Sent

**Dependencies:**

- List of Key Stakeholders
- Communication Channels Established
- Confirmed SteerCo Membership

### 22. Project Manager schedules and holds the initial Stakeholder Engagement Group kick-off meeting to review the engagement plan, communication channels, and initial priorities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SEG Kick-off Meeting Minutes with Action Items

**Dependencies:**

- SEG Membership Confirmed