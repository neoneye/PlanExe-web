### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR v0.1 for review by nominated members (Billionaire Client representative, Project Director, Chief Engineer, Chief Legal Counsel, Chief Security Officer, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- SteerCo ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- SteerCo ToR v0.2

**Dependencies:**

- SteerCo ToR v0.1 circulated for review
- Feedback Received

### 4. Project Director approves the final Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2

### 5. Project Director formally appoints the Chairperson of the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- SteerCo Chairperson Appointed

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager schedules the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Scheduled

**Dependencies:**

- SteerCo Chairperson Appointed
- Approved SteerCo ToR v1.0

### 7. Hold the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- SteerCo Officially Established

**Dependencies:**

- SteerCo Kick-off Meeting Scheduled

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Circulate Draft Ethics and Compliance Committee ToR v0.1 for review by nominated members (Independent Ethics Advisor, Chief Legal Counsel, Human Resources Director, Participant Advocate, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 10. Project Manager consolidates feedback on Ethics and Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Ethics and Compliance Committee ToR v0.2

**Dependencies:**

- Ethics and Compliance Committee ToR v0.1 circulated for review
- Feedback Received

### 11. Project Director approves the final Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Ethics and Compliance Committee ToR v0.2

### 12. Project Director formally appoints the Chairperson of the Ethics and Compliance Committee (Independent Ethics Advisor).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Ethics and Compliance Committee Chairperson Appointed

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0

### 13. Project Manager schedules the initial kick-off meeting for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee Kick-off Meeting Scheduled

**Dependencies:**

- Ethics and Compliance Committee Chairperson Appointed
- Approved Ethics and Compliance Committee ToR v1.0

### 14. Hold the initial kick-off meeting for the Ethics and Compliance Committee.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Ethics and Compliance Committee Officially Established

**Dependencies:**

- Ethics and Compliance Committee Kick-off Meeting Scheduled

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 16. Circulate Draft Technical Advisory Group ToR v0.1 for review by nominated members (Chief Engineer, Structural Engineer, Mechanical Engineer, Electrical Engineer, Safety Engineer, Independent Technical Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Technical Advisory Group ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 17. Project Manager consolidates feedback on Technical Advisory Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Technical Advisory Group ToR v0.2

**Dependencies:**

- Technical Advisory Group ToR v0.1 circulated for review
- Feedback Received

### 18. Project Director approves the final Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Technical Advisory Group ToR v0.2

### 19. Project Director formally appoints the Chairperson of the Technical Advisory Group (Chief Engineer).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Technical Advisory Group Chairperson Appointed

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 20. Project Manager schedules the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Scheduled

**Dependencies:**

- Technical Advisory Group Chairperson Appointed
- Approved Technical Advisory Group ToR v1.0

### 21. Hold the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Technical Advisory Group Officially Established

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Scheduled

### 22. Project Manager drafts initial Terms of Reference (ToR) for the Risk Management Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Risk Management Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 23. Circulate Draft Risk Management Committee ToR v0.1 for review by nominated members (Risk Manager, Chief Legal Counsel, Chief Security Officer, Chief Engineer, Project Manager, Independent Risk Management Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Risk Management Committee ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft Risk Management Committee ToR v0.1

### 24. Project Manager consolidates feedback on Risk Management Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Risk Management Committee ToR v0.2

**Dependencies:**

- Risk Management Committee ToR v0.1 circulated for review
- Feedback Received

### 25. Project Director approves the final Terms of Reference for the Risk Management Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Risk Management Committee ToR v1.0

**Dependencies:**

- Risk Management Committee ToR v0.2

### 26. Project Director formally appoints the Chairperson of the Risk Management Committee (Risk Manager).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Risk Management Committee Chairperson Appointed

**Dependencies:**

- Approved Risk Management Committee ToR v1.0

### 27. Project Manager schedules the initial kick-off meeting for the Risk Management Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Management Committee Kick-off Meeting Scheduled

**Dependencies:**

- Risk Management Committee Chairperson Appointed
- Approved Risk Management Committee ToR v1.0

### 28. Hold the initial kick-off meeting for the Risk Management Committee.

**Responsible Body/Role:** Risk Management Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Risk Management Committee Officially Established

**Dependencies:**

- Risk Management Committee Kick-off Meeting Scheduled

### 29. Establish project management standards and processes for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Standards and Processes Document v1.0

**Dependencies:**

- Project Plan Approved

### 30. Develop project plans, schedules, and budgets for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Plans
- Project Schedules
- Project Budgets

**Dependencies:**

- Project Management Standards and Processes Document v1.0

### 31. Establish communication channels and reporting requirements for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Requirements Document

**Dependencies:**

- Project Plans
- Project Schedules
- Project Budgets

### 32. Recruit and train project management staff for the PMO.

**Responsible Body/Role:** Human Resources Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Staff Onboarded
- Training Records

**Dependencies:**

- Communication Plan
- Reporting Requirements Document

### 33. Implement project management software and tools for the PMO.

**Responsible Body/Role:** IT Department

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Software Installed and Configured

**Dependencies:**

- PMO Staff Onboarded

### 34. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- PMO Officially Established

**Dependencies:**

- Project Management Software Installed and Configured