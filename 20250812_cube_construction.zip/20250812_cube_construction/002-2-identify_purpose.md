**Purpose:** business

**Purpose Detailed:** Construction of a large-scale, dangerous facility for the amusement of a wealthy individual, implying a business transaction or project management context.

**Topic:** Construction and operation of a deadly amusement facility for a billionaire.