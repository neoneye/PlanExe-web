This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD.
- **RUB:** Potential construction in Siberia, Russia, may involve local transactions in RUB.
- **AED:** Potential construction in the UAE may involve local transactions in AED.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting is USD. For construction in Russia or the UAE, local transactions may be conducted in RUB or AED, respectively. Hedging against exchange rate fluctuations between USD and RUB/AED should be considered.