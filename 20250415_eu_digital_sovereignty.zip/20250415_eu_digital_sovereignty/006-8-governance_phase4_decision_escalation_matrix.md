**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and failure to meet strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Action Plan Approval
Rationale: The risk has materialized and poses a significant threat to project success, requiring strategic intervention and resource allocation.
Negative Consequences: Project failure, significant financial losses, reputational damage, and failure to achieve digital sovereignty.

**PMO Deadlock on Vendor Selection**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Consensus or Recommendation to Project Director
Rationale: The PMO cannot agree on a vendor, indicating a need for expert technical guidance to ensure the best solution is selected.
Negative Consequences: Selection of a suboptimal vendor, project delays, increased costs, and potential security vulnerabilities.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: A significant change to the project's scope requires strategic re-evaluation and approval due to potential impacts on budget, timeline, and objectives.
Negative Consequences: Project creep, budget overruns, timeline delays, and failure to deliver the intended benefits.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Project Director and/or Steering Committee
Rationale: Allegations of ethical misconduct require independent investigation and appropriate action to maintain integrity and compliance.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and project disruption.

**Disagreement between Technical Advisory Group and PMO on technical standards**
Escalation Level: Project Director
Approval Process: Project Director decision after consultation with relevant parties
Rationale: Differing opinions on technical standards can impact project execution and interoperability, requiring resolution by the Project Director.
Negative Consequences: Inconsistent implementation, integration issues, increased costs, and potential security vulnerabilities.