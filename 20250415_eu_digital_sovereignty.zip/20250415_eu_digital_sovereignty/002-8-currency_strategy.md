This plan involves money.

## Currencies

- **EUR:** Primary currency for budgeting and reporting across the European Union.
- **USD:** Potential for international transactions and comparisons.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. Local currencies may be used for local transactions within each member state. Given the scale and duration of the project, hedging strategies should be considered to mitigate against potential exchange rate fluctuations between EUR and other currencies, especially USD.