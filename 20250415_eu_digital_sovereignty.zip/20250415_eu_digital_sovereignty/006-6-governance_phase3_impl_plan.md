### 1. Project Sponsor formally appoints an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 2. Interim Chair of the Project Steering Committee drafts the initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Sponsor Identified

### 3. Circulate Draft SteerCo ToR v0.1 for review by nominated members (European Commission Representatives, EU Member State Government Representatives, Independent Industry Experts, Project Director).

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Collate feedback on Draft SteerCo ToR v0.1 and revise to create Draft SteerCo ToR v0.2.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback Received

### 5. Project Sponsor formally approves the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2
- Feedback Summary

### 6. Project Sponsor formally appoints the Chair and Vice-Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Nominated Members List Available

### 7. Formally confirm membership of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment of Chair and Vice-Chair

### 8. Project Steering Committee Chair schedules the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 9. Hold the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 10. Project Director appoints the PMO Director.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 11. PMO Director establishes the PMO structure and staffing.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Structure Document
- Staffing Plan

**Dependencies:**

- Appointment of PMO Director

### 12. PMO Director develops project management templates and tools.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Document

### 13. PMO Director defines reporting requirements and communication protocols.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Reporting Requirements Document
- Communication Protocols Document

**Dependencies:**

- Project Management Templates

### 14. PMO Director implements a project tracking system.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Tracking System

**Dependencies:**

- Reporting Requirements Document

### 15. Formally confirm membership of the Project Management Office (PMO).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- PMO Structure Document
- Staffing Plan

### 16. PMO Director schedules the initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 17. Hold the initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 18. Project Director appoints a Lead Architect to form the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 19. Lead Architect identifies and recruits technical experts for the Technical Advisory Group (Chief Technology Officer, Lead Architects, Independent Cybersecurity Experts, Representatives from European Sovereign/Private Solution Providers).

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of TAG Members

**Dependencies:**

- Appointment of Lead Architect

### 20. Lead Architect defines the scope of advisory services for the Technical Advisory Group.

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Scope of Advisory Services Document

**Dependencies:**

- List of TAG Members

### 21. Lead Architect establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Scope of Advisory Services Document

### 22. Lead Architect develops technical review checklists for the Technical Advisory Group.

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Technical Review Checklists

**Dependencies:**

- Communication Protocols Document

### 23. Formally confirm membership of the Technical Advisory Group.

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- List of TAG Members

### 24. Lead Architect schedules the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Lead Architect

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 25. Hold the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 26. Project Director appoints a Chief Compliance Officer to form the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 27. Chief Compliance Officer develops a code of ethics for the project.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Code of Ethics Document

**Dependencies:**

- Appointment of Chief Compliance Officer

### 28. Chief Compliance Officer establishes compliance policies and procedures.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Compliance Policies and Procedures Document

**Dependencies:**

- Code of Ethics Document

### 29. Chief Compliance Officer implements a whistleblower mechanism.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Whistleblower Mechanism Document

**Dependencies:**

- Compliance Policies and Procedures Document

### 30. Chief Compliance Officer develops training materials on ethics and compliance.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Ethics and Compliance Training Materials

**Dependencies:**

- Whistleblower Mechanism Document

### 31. Formally confirm membership of the Ethics & Compliance Committee (Chief Compliance Officer, Legal Counsel, Data Protection Officer, Independent Ethics Advisor, Representative from Internal Audit).

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Ethics and Compliance Training Materials

### 32. Chief Compliance Officer schedules the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 33. Hold the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 34. Project Director appoints a Communications Manager to form the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 35. Communications Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Appointment of Communications Manager

### 36. Communications Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Plan Document

**Dependencies:**

- List of Key Stakeholders

### 37. Communications Manager establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Communication Channels Document

**Dependencies:**

- Communication Plan Document

### 38. Communications Manager develops communication materials for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Communication Materials

**Dependencies:**

- Communication Channels Document

### 39. Formally confirm membership of the Stakeholder Engagement Group (Communications Manager, Public Relations Officer, Representatives from EU Member State Governments, Representatives from Industry Associations, Citizen Representatives).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Communication Materials

### 40. Communications Manager schedules the initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 41. Hold the initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda