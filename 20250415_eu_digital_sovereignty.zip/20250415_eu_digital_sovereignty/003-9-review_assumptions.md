## Domain of the expert reviewer
Project Management and Risk Assessment for Large-Scale Infrastructure Projects

## Domain-specific considerations

- Geopolitical risks and dependencies
- Regulatory compliance across multiple jurisdictions
- Technological obsolescence and lock-in
- Stakeholder alignment and communication
- Long-term operational sustainability

## Issue 1 - Unrealistic Funding Model and Disbursement Assumptions
The assumption of a 60/40 split between national and EU funding, with smooth disbursement via an EU agency, is highly optimistic. Securing firm commitments from all member states, especially given varying economic conditions and political priorities, is a significant challenge. The EU disbursement process is often bureaucratic and subject to delays. The plan lacks concrete mechanisms to address potential shortfalls or delays in national funding contributions.

**Recommendation:** 1. Conduct a detailed financial feasibility study, including sensitivity analysis, to assess the impact of potential delays or reductions in national funding.  2. Secure legally binding commitments from member states with clear penalties for non-compliance. 3. Establish a contingency fund to cover potential funding gaps. 4. Explore alternative funding sources, such as private investment or public-private partnerships, to reduce reliance on national and EU funding. 5. Negotiate a streamlined disbursement process with the EU agency, including pre-approved milestones and expedited payment mechanisms.

**Sensitivity:** A 20% shortfall in national funding (baseline: 60%) could delay project completion by 12-18 months and reduce the overall ROI by 8-12%. A 6-month delay in EU fund disbursement (baseline: immediate upon milestone completion) could increase project financing costs by €50-100 million.

## Issue 2 - Overly Optimistic Migration Timelines and Milestone Assumptions
The assumption of achieving 30% cloud migration by 2028, 50% SaaS migration by 2030, and 75% DNS/CDN migration by 2032 is ambitious, especially considering the complexity of migrating critical infrastructure and the potential for unforeseen technical challenges. The plan lacks a detailed assessment of the current state of infrastructure, the effort required for migration, and the potential for disruptions during the process. The plan also does not account for the time required for testing, validation, and user training.

**Recommendation:** 1. Conduct a thorough assessment of the current state of infrastructure, including a detailed inventory of systems, applications, and data. 2. Develop a detailed migration plan with realistic timelines and milestones, based on the assessment. 3. Implement a phased migration approach, starting with less critical systems and gradually moving to more critical ones. 4. Allocate sufficient resources for testing, validation, and user training. 5. Establish a robust monitoring and reporting system to track progress and identify potential delays.

**Sensitivity:** A 6-month delay in achieving the 2028 cloud migration milestone (baseline: 2028) could delay the overall project completion by 9-12 months and increase project costs by €30-50 billion. Underestimating the complexity of migration by 20% could increase the project timeline by 10-15%.

## Issue 3 - Insufficient Consideration of Long-Term Operational Costs and Sustainability
The plan focuses primarily on the initial migration phase and lacks a detailed assessment of the long-term operational costs and sustainability of the new infrastructure. Factors such as ongoing maintenance, security updates, energy consumption, and personnel costs are not adequately addressed. The plan also does not consider the potential for technological obsolescence and the need for future upgrades or replacements.

**Recommendation:** 1. Develop a detailed operational cost model, including all relevant cost factors, such as maintenance, security, energy, and personnel. 2. Implement energy-efficient technologies and practices to minimize energy consumption. 3. Establish a long-term funding mechanism to cover ongoing operational costs. 4. Develop a technology roadmap to address potential obsolescence and plan for future upgrades. 5. Implement a robust security monitoring and incident response system to protect against cyber threats.

**Sensitivity:** Underestimating annual operational costs by 15% (baseline: €10 billion) could reduce the project's ROI by 5-7% over a 10-year period. A failure to address technological obsolescence could require a major infrastructure overhaul every 5-7 years, adding significant costs and disruptions.

## Review conclusion
The Pan-European Digital Infrastructure Migration Program is a complex and ambitious undertaking with significant potential benefits. However, the plan contains several critical missing assumptions and unrealistic elements that could jeopardize its success. Addressing these issues through more detailed planning, realistic assumptions, and robust risk mitigation strategies is essential for achieving European digital sovereignty and resilience.