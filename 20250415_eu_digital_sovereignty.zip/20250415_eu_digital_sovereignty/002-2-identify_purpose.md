**Purpose:** business

**Purpose Detailed:** Strategic program to migrate critical digital infrastructure away from US-controlled providers to achieve European digital sovereignty and resilience.

**Topic:** Pan-European Digital Infrastructure Migration Program