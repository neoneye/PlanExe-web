A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The used wire bending machine will be fully functional with readily available replacement parts. | Conduct a thorough inspection and operational test of the used wire bending machine by a qualified technician before purchase. | The inspection reveals critical mechanical flaws or obsolete components with no available replacements. |
| A2 | The local community will support the project and not raise significant objections to the factory's operation. | Hold a town hall meeting to present the project to local residents and solicit feedback. | A significant number of residents express strong opposition to the project due to concerns about noise, traffic, or environmental impact. |
| A3 | The software developer has sufficient expertise to integrate all systems, including carrier APIs and PLC controls, within the project timeline. | Have the software developer complete a proof-of-concept integration of a simplified carrier API and a basic PLC control loop. | The proof-of-concept integration fails to meet basic functionality requirements or takes significantly longer than the estimated time. |
| A4 | The cost of raw materials (wire) will remain stable and within the project's budget throughout the duration of the project. | Obtain quotes from multiple wire suppliers and analyze historical price trends for wire. | The analysis reveals significant price volatility or a projected increase in wire costs that exceeds the project's budget allocation for raw materials. |
| A5 | The chosen location will have adequate and reliable access to utilities (electricity, internet) to support the factory's operations. | Conduct a site survey to assess the capacity and reliability of the existing electrical and internet infrastructure. | The site survey reveals insufficient electrical capacity, unreliable internet connectivity, or the need for costly infrastructure upgrades. |
| A6 | The automated system will be able to handle variations in wire quality and diameter without significant downtime or manual intervention. | Run a series of tests using wire samples with varying quality and diameter to assess the system's performance and identify potential issues. | The tests reveal frequent jams, misfeeds, or inconsistent paperclip production due to variations in wire quality or diameter. |
| A7 | The project team possesses sufficient expertise in all relevant areas (mechanical engineering, software development, PLC programming, etc.) to successfully complete the project without significant external assistance. | Conduct a skills gap analysis to identify any areas where the project team lacks expertise. | The skills gap analysis reveals significant gaps in expertise that cannot be addressed through internal training or mentoring within the project timeline. |
| A8 | The demand for paperclips will remain stable and sufficient to justify the project's production capacity. | Conduct a market analysis to assess the current and projected demand for paperclips, considering factors such as competition, economic trends, and alternative products. | The market analysis reveals a declining demand for paperclips or an oversupply of paperclips in the market, making it difficult to achieve the project's production and sales targets. |
| A9 | The project will be able to secure necessary insurance coverage (property, liability, workers' compensation) at reasonable rates. | Obtain quotes from multiple insurance providers for the required coverage. | Insurance providers refuse to offer coverage or quote rates that are prohibitively expensive, making it difficult to protect the project from potential risks and liabilities. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Rusty Relic's Revenge | Technical/Logistical | A1 | Head of Engineering | CRITICAL (20/25) |
| FM2 | The Not-In-My-Backyard Backlash | Market/Human | A2 | Permitting Lead | HIGH (12/25) |
| FM3 | The Integration Inferno | Process/Financial | A3 | Software Development Lead | CRITICAL (20/25) |
| FM4 | The Wire Price Whirlwind | Process/Financial | A4 | Procurement Lead | CRITICAL (15/25) |
| FM5 | The Powerless Paperclip Palace | Technical/Logistical | A5 | Facility Manager | CRITICAL (16/25) |
| FM6 | The Fickle Filament Fiasco | Market/Human | A6 | Quality Control Manager | CRITICAL (16/25) |
| FM7 | The Expertise Evaporation | Technical/Logistical | A7 | Project Manager | CRITICAL (16/25) |
| FM8 | The Paperclip Glut | Market/Human | A8 | Sales & Marketing Lead | CRITICAL (15/25) |
| FM9 | The Uninsurable Automation | Process/Financial | A9 | Finance Lead | HIGH (10/25) |


### Failure Modes

#### FM1 - The Rusty Relic's Revenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project hinges on a used wire bending machine to save costs. However:
*   The machine, despite initial inspection, suffers a catastrophic mechanical failure shortly after commissioning.
*   Critical components are obsolete, and replacements are unavailable, halting production.
*   Attempts to reverse-engineer or fabricate parts prove costly and time-consuming.
*   The entire production line grinds to a halt, jeopardizing the project's timeline and budget.

##### Early Warning Signs
- Unexplained vibrations or unusual noises emanating from the wire bending machine.
- Increased frequency of minor breakdowns and repairs on the wire bending machine.
- Difficulty sourcing replacement parts for the wire bending machine, even for routine maintenance.

##### Tripwires
- Wire bending machine requires unscheduled maintenance >= 2 times in any 7 day period.
- Critical component replacement for the wire bending machine exceeds $5000.
- Uptime of the wire bending machine falls below 75% in any given week.

##### Response Playbook
- Contain: Immediately halt production and isolate the faulty machine.
- Assess: Conduct a thorough diagnostic assessment to determine the extent of the damage and the feasibility of repair.
- Respond: Activate the contingency plan: either source a replacement used machine (if available) or pivot to purchasing a new wire bending machine, accepting the increased cost and potential delays.


**STOP RULE:** The wire bending machine remains inoperable for more than 30 days due to lack of parts or irreparable damage.

---

#### FM2 - The Not-In-My-Backyard Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Permitting Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project team assumes community support for the factory. However:
*   Local residents, concerned about noise and truck traffic, organize a vocal opposition movement.
*   They petition the city council, demanding stricter zoning regulations and environmental impact assessments.
*   Permitting is delayed indefinitely, and the project faces mounting legal challenges.
*   Negative publicity damages the project's reputation, deterring potential investors and partners.

##### Early Warning Signs
- Formation of a local community group actively opposing the project.
- Increased media coverage highlighting potential negative impacts of the factory.
- Significant attendance and vocal opposition at city council meetings regarding the project.

##### Tripwires
- Petition against the project gains >= 100 signatures from local residents.
- City council postpones permit approval decision for >= 60 days due to community concerns.
- Local news outlets publish >= 3 negative articles about the project in a single month.

##### Response Playbook
- Contain: Immediately suspend all construction activities and public-facing communications.
- Assess: Conduct a thorough assessment of community concerns and identify potential compromises.
- Respond: Engage in proactive dialogue with community leaders, address their concerns through modifications to the project plan (e.g., noise reduction measures, traffic management plan), and offer community benefits (e.g., local job creation, community improvement projects).


**STOP RULE:** The city council denies the necessary permits due to sustained community opposition, rendering the project unviable at the current location.

---

#### FM3 - The Integration Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Software Development Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relies on a single software developer to integrate all systems. However:
*   The developer, overwhelmed by the complexity of integrating carrier APIs, PLC controls, and legacy equipment, falls behind schedule.
*   Critical integration milestones are missed, leading to cascading delays across the project.
*   The developer's code becomes buggy and unreliable, causing frequent system crashes and data errors.
*   The project spirals into a financial crisis as costs escalate due to rework and missed deadlines.

##### Early Warning Signs
- Software development progress falls behind schedule by >= 2 weeks.
- The software developer reports working consistently over 60 hours per week.
- Increase in the number of unresolved bugs and system crashes reported during testing.

##### Tripwires
- Critical software integration milestones are missed by >= 3 weeks.
- The number of unresolved high-priority bugs exceeds >= 10.
- The project budget for software development is exceeded by >= 10%.

##### Response Playbook
- Contain: Immediately freeze all new feature development and focus on stabilizing the existing codebase.
- Assess: Conduct a code review and performance audit to identify bottlenecks and areas for improvement. Assess the developer's workload and skill set.
- Respond: Bring in a contract software engineer to assist with critical integration tasks, refactor the codebase to improve maintainability, and implement automated testing to improve code quality. Consider simplifying the integration architecture or reducing the scope of automation.


**STOP RULE:** The software control system remains unstable and unreliable for more than 60 days, preventing the project from achieving its core automation goals.

---

#### FM4 - The Wire Price Whirlwind

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Procurement Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project budget assumes stable wire costs. However:
*   Unexpected global events (e.g., trade wars, supply chain disruptions) cause a sharp spike in wire prices.
*   The project's fixed-price contracts with suppliers prove inadequate to buffer the price increase.
*   The cost of raw materials skyrockets, exceeding the allocated budget and eroding profit margins.
*   The project is forced to reduce production volume or compromise on wire quality to stay afloat.

##### Early Warning Signs
- Significant fluctuations in global commodity prices, particularly for steel and copper.
- Announcements of new tariffs or trade restrictions affecting wire imports.
- Reports of supply chain disruptions affecting wire production or distribution.

##### Tripwires
- Wire prices increase by >= 15% within a 30-day period.
- Suppliers refuse to honor fixed-price contracts due to market volatility.
- The cost of raw materials exceeds 20% of the total project budget.

##### Response Playbook
- Contain: Immediately explore alternative wire suppliers and negotiate new contracts.
- Assess: Conduct a thorough cost analysis to determine the impact of the price increase on the project's profitability.
- Respond: Implement cost-saving measures, such as reducing production volume, optimizing wire usage, or exploring alternative, lower-cost wire materials. Consider hedging strategies to mitigate future price volatility.


**STOP RULE:** The cost of raw materials becomes unsustainable, rendering the project economically unviable and preventing it from achieving its ROI targets.

---

#### FM5 - The Powerless Paperclip Palace

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Facility Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes adequate utility access. However:
*   The chosen location suffers frequent power outages and unreliable internet connectivity.
*   The automated equipment requires a stable power supply and constant internet access for remote monitoring and control.
*   Power outages disrupt production, damage equipment, and corrupt data.
*   Unreliable internet connectivity hinders remote troubleshooting and support, prolonging downtime.

##### Early Warning Signs
- Frequent power outages in the surrounding area.
- Slow or intermittent internet speeds at the chosen location.
- Reports of electrical grid instability or infrastructure problems in the region.

##### Tripwires
- Power outages occur >= 3 times per month, each lasting >= 1 hour.
- Internet connectivity is lost for >= 24 hours in any given week.
- The automated equipment experiences damage or malfunctions due to power surges or voltage fluctuations.

##### Response Playbook
- Contain: Immediately install a backup generator and uninterruptible power supply (UPS) to ensure continuous power during outages.
- Assess: Conduct a thorough assessment of the electrical and internet infrastructure to identify the root causes of the problems.
- Respond: Work with the local utility company to improve power grid stability, install a dedicated high-speed internet connection, and implement surge protection measures to protect sensitive equipment. Consider relocating to a more reliable location if the problems persist.


**STOP RULE:** The utility infrastructure proves inadequate to support the factory's operations, resulting in excessive downtime and preventing it from achieving its production targets.

---

#### FM6 - The Fickle Filament Fiasco

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Quality Control Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes consistent wire quality. However:
*   Variations in wire quality and diameter cause frequent jams and misfeeds in the automated equipment.
*   The system's sensors and control algorithms are unable to adapt to these variations, leading to inconsistent paperclip production.
*   Manual intervention is required to clear jams and adjust machine settings, negating the benefits of automation.
*   Customer complaints about inconsistent paperclip quality damage the project's reputation.

##### Early Warning Signs
- Increased frequency of jams and misfeeds in the automated equipment.
- Inconsistent paperclip dimensions and quality.
- Rising number of customer complaints about defective paperclips.

##### Tripwires
- The jam rate exceeds >= 5% of total production.
- The defect rate exceeds >= 2% of total production.
- Customer complaints about paperclip quality increase by >= 10% month-over-month.

##### Response Playbook
- Contain: Immediately implement stricter quality control measures for incoming wire shipments.
- Assess: Conduct a thorough analysis of the wire samples to identify the specific variations causing the problems.
- Respond: Adjust machine settings and control algorithms to better accommodate wire variations, implement a more sophisticated sensor system to detect and reject defective wire, and work with wire suppliers to improve quality control. Consider implementing adaptive machine learning to dynamically adjust machine parameters based on real-time material property analysis.


**STOP RULE:** The automated system proves unable to handle variations in wire quality, resulting in consistently high defect rates and preventing it from achieving its quality targets.

---

#### FM7 - The Expertise Evaporation

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes sufficient internal expertise. However:
*   The team underestimates the complexity of integrating legacy equipment with modern automation systems.
*   Critical skills gaps emerge in areas such as advanced PLC programming and robotic integration.
*   Attempts to upskill the existing team prove insufficient, leading to delays and integration failures.
*   The project struggles to achieve its automation goals due to a lack of specialized knowledge.

##### Early Warning Signs
- Frequent roadblocks and unresolved technical issues during the integration phase.
- Team members express a lack of confidence in their ability to solve specific technical challenges.
- Increased reliance on online forums and external resources for troubleshooting.
- Difficulty meeting integration milestones and performance targets.

##### Tripwires
- Critical integration tasks remain incomplete for >= 4 weeks due to lack of expertise.
- The project requires >= 3 external consultants to address specific technical challenges.
- The cost of external consulting exceeds 10% of the total project budget.

##### Response Playbook
- Contain: Immediately reassess the project's technical requirements and identify the most critical skills gaps.
- Assess: Conduct a thorough search for qualified external consultants or contractors with the necessary expertise.
- Respond: Engage external experts to provide targeted support and mentoring to the project team, adjust the project scope to reduce complexity, or consider outsourcing specific tasks to specialized firms.


**STOP RULE:** The project proves unable to acquire the necessary expertise to overcome critical technical challenges, preventing it from achieving its core automation goals.

---

#### FM8 - The Paperclip Glut

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Sales & Marketing Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes stable demand for paperclips. However:
*   The market for paperclips declines due to the increasing use of digital alternatives.
*   Competitors flood the market with low-cost paperclips, driving down prices.
*   The project struggles to sell its production output, leading to inventory buildup and financial losses.
*   The automated factory becomes a white elephant, unable to generate sufficient revenue to justify its investment.

##### Early Warning Signs
- Declining sales of paperclips in the broader market.
- Increased competition from low-cost paperclip manufacturers.
- Rising inventory levels and storage costs.
- Difficulty securing contracts with major office supply retailers.

##### Tripwires
- Paperclip sales fall below 75% of projected targets for >= 3 consecutive months.
- Inventory levels exceed 50% of total production capacity.
- The project is unable to secure contracts with major office supply retailers within 6 months of commissioning.

##### Response Playbook
- Contain: Immediately reduce production volume to match declining demand.
- Assess: Conduct a thorough market analysis to identify new potential customers or alternative product applications.
- Respond: Diversify the product line to include other types of fasteners or office supplies, target niche markets with specialized paperclip designs, or explore alternative uses for the automated factory (e.g., producing small metal components for other industries).


**STOP RULE:** The project proves unable to generate sufficient revenue to cover its operating costs, rendering it economically unviable.

---

#### FM9 - The Uninsurable Automation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Finance Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes reasonable insurance rates. However:
*   Insurance providers deem the automated factory too risky due to its reliance on used equipment and complex automation systems.
*   Insurance premiums are quoted at prohibitively expensive rates, significantly increasing operating costs.
*   The project is unable to secure adequate insurance coverage, exposing it to potentially catastrophic financial losses in the event of an accident or equipment failure.
*   The project is forced to operate without insurance, creating a significant liability risk.

##### Early Warning Signs
- Difficulty obtaining insurance quotes from multiple providers.
- Insurance providers express concerns about the project's risk profile.
- Insurance premiums are significantly higher than anticipated.
- Insurance providers require extensive safety audits and risk mitigation measures.

##### Tripwires
- Insurance providers refuse to offer coverage for the automated factory.
- Insurance premiums exceed 15% of the total operating budget.
- The project is unable to secure workers' compensation insurance for its employees.

##### Response Playbook
- Contain: Immediately implement enhanced safety measures and risk mitigation protocols to reduce the project's risk profile.
- Assess: Conduct a thorough review of the project's safety procedures and equipment maintenance practices.
- Respond: Negotiate with insurance providers to secure more favorable rates, explore alternative insurance options (e.g., self-insurance), or consider modifying the project design to reduce its risk profile (e.g., replacing used equipment with new equipment).


**STOP RULE:** The project proves unable to secure adequate insurance coverage at reasonable rates, exposing it to unacceptable financial risks.
