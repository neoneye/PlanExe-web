Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project focuses on automating a paperclip factory, which does not inherently violate any laws of physics. The plan involves engineering and integration challenges, but not fundamental physics limitations.

**Mitigation**: Project Team: Document the specific physical principles and engineering constraints considered in the design to reinforce the feasibility of the project within known physical laws. Due: Within 30 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product, market, tech/process, and policy (fully automated paperclip factory) without independent evidence at comparable scale. There is no credible precedent for a fully lights-out paperclip factory.

**Mitigation**: Project Manager: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: empirical/engineering validity and legal/compliance clearance. Deliverable: Authoritative source/supervised pilot. Due: 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for strategic concepts like "automation" and "autonomous flow". The goal statement mentions "fully automated pilot paperclip factory" without defining automation.

**Mitigation**: Project Manager: Create one-pagers for 'automation' and 'autonomous flow' defining inputs→process→customer value, owners, measurable outcomes, and decision hooks. Due: 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, operational, supply chain, security, environmental, social, technical) and includes mitigation plans. However, it lacks explicit analysis of risk cascades or second-order effects. The plan does not map out how one risk event could trigger others.

**Mitigation**: Risk Manager: Develop a risk cascade diagram illustrating how initial risks (e.g., permit delays) could trigger subsequent financial, reputational, or operational issues. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes permits will take 4-6 weeks in Cleveland, but lacks any evidence or matrix to support this timeline. The plan does not include a permit/approval matrix. "Assumption: Standard building, electrical, OSHA permits. 4-6 weeks in Cleveland."

**Mitigation**: Permitting Specialist: Build a permit approval matrix with specific permits required, authoritative lead times from the Cleveland building department, and a NO-GO threshold on slip. Due: 45 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not name any funding sources, their status (LOI/term sheet/closed), the draw schedule, or runway length. The plan mentions a budget of $300,000-$500,000 but provides no details on how this will be secured.

**Mitigation**: Project Manager: Develop a dated financing plan listing funding sources, their status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the need for a detailed cost analysis. The plan lacks evidence of cost comparisons or vendor quotes to substantiate the budget. No normalization by area is provided.

**Mitigation**: Owner: Conduct a detailed cost analysis, obtain at least three vendor quotes, normalize costs per m², and adjust the budget or scope accordingly. Due: 30 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline, cost savings) as single numbers without ranges or alternative scenarios. For example, the goal statement estimates completion within 12-18 months without discussing best/worst cases.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or create best/worst/base-case scenarios for the project timeline, highlighting key drivers and potential deviations. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no specs, interface contracts, acceptance tests, integration plan, or non-functional requirements. The plan does not include these artifacts.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for all build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several claims without verifiable evidence. For example, it states the project should be completed within 12-18 months, but lacks evidence to support this claim. There is no evidence pack.

**Mitigation**: Project Manager: Create an evidence pack containing verifiable artifacts (documents, links, IDs) for all critical claims related to licenses, approvals, partnerships, and performance. Due: 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the goal statement mentions "demonstrating a working autonomous flow" without defining specific, verifiable qualities. The plan lacks SMART acceptance criteria and a KPI for 'autonomous flow'.

**Mitigation**: Project Manager: Define SMART criteria for 'autonomous flow', including a KPI for the percentage of production cycles completed without manual intervention. Due: 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Advanced API Integration' for carrier services. This feature does not appear to directly support the core project goals of demonstrating a working autonomous flow and building a pilot paperclip factory.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Advanced API Integration', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a "Software Developer (Backend Focus)" as a full-time employee to "develop the REST API, backend services, and control logic for the entire system, including integration with carrier APIs." This role is critical and likely difficult to fill.

**Mitigation**: Project Manager: Immediately engage a technical recruiter to validate the talent market for a full-time software developer with backend, API, and control system experience. Deliverable: Market scan report. Due: 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the need for permits but lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. "Assumption: Standard building, electrical, OSHA permits. 4-6 weeks in Cleveland."

**Mitigation**: Permitting Specialist: Build a permit approval matrix with specific permits required, authoritative lead times from the Cleveland building department, and a NO-GO threshold on slip. Due: 45 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions operational risks and mitigation, but lacks a comprehensive operational sustainability plan. The plan does not address long-term funding, maintenance, succession planning, or technology obsolescence. "System may not achieve target of ≤2 hr/week manual work."

**Mitigation**: Operations Lead: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies locations and requirements (15,000 sq ft, 3-phase power) but lacks evidence of zoning/land-use verification or written confirmation from authorities. It is uncertain if the existing building meets all requirements.

**Mitigation**: Permitting Specialist: Perform a fatal-flaw screen with Cleveland zoning/permitting authorities to confirm the primary location's suitability and identify any potential constraints. Due: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions UPS/FedEx APIs but lacks evidence of SLAs, redundancy, or tested failover. The plan does not include a secondary carrier or path. "Integrate backend with UPS/FedEx APIs."

**Mitigation**: Logistics Coordinator: Secure SLAs with UPS/FedEx, add a secondary carrier, and test failover procedures by Q4 2024.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states the goal is to "Build a fully automated pilot paperclip factory" and the Software Developer is incentivized to build a complex system. Finance is incentivized to minimize costs, creating a conflict.

**Mitigation**: Project Manager: Define a shared OKR for Finance and Software Development focused on ROI within budget, aligning both on cost-effective automation. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Manager. Deliverable: Schedule and process. Date: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several risks, but lacks a cross-impact analysis to surface multi-node cascades. For example, a delay in obtaining permits (Risk 1) could lead to financial overruns (Risk 4) and supply chain disruptions (Risk 6).

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 90 days.