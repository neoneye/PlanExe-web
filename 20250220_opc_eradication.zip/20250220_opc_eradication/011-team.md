# Roles

## 1. Infestation Mapping & Survey Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Specialized skill for a short-term, defined task (mapping). Likely requires specific drone equipment and expertise not readily available in-house.

**Explanation**:
Critical for accurately assessing the scope of the outbreak and guiding eradication efforts. This role ensures a comprehensive understanding of the infestation's extent.

**Consequences**:
Inaccurate or incomplete mapping leads to inefficient resource allocation, missed nests, and potential spread of the infestation.

**People Count**:
min 1, max 2, depending on the size of the area to be surveyed. A larger area requires more personnel for efficient data collection and verification.

**Typical Activities**:
Drone-based surveying, data processing, spatial analysis, GIS software operation, report generation, ground truthing, thermal imaging analysis.

**Background Story**:
Astrid Nielsen, a native of Aarhus, Denmark, holds a Master's degree in Geographic Information Systems (GIS) from Aarhus University and has five years of experience in environmental surveying and mapping. She's worked on projects ranging from coastal erosion monitoring to urban green space analysis. Astrid is highly proficient in drone operation, data processing, and spatial analysis software. Her familiarity with the Danish landscape and regulations, combined with her expertise in mapping technologies, makes her perfectly suited to lead the infestation mapping efforts for the Oak Processionary Caterpillars outbreak.

**Equipment Needs**:
Drone with high-resolution camera and thermal imaging capabilities, GPS, GIS software (e.g., ArcGIS, QGIS), laptop, surveying equipment (measuring tapes, flags), personal protective equipment (PPE) for ground truthing.

**Facility Needs**:
Office space for data processing and analysis, access to drone flight zones, vehicle for transportation to survey sites.

## 2. Eradication Team Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires significant coordination and oversight of multiple teams, suggesting a more permanent role with greater control and availability.

**Explanation**:
Responsible for the day-to-day management of eradication teams, ensuring efficient and safe operations. This role is crucial for coordinating personnel, equipment, and resources.

**Consequences**:
Uncoordinated efforts, delays in treatment, increased risk of accidents, and inefficient use of resources.

**People Count**:
min 2, max 4, depending on the number of eradication teams deployed. Each coordinator can effectively manage 2-3 teams.

**Typical Activities**:
Team management, resource allocation, scheduling, safety protocol enforcement, problem-solving, communication, equipment maintenance coordination, progress tracking.

**Background Story**:
Bjorn Christensen, born and raised in Copenhagen, has spent the last decade working for the city's parks and recreation department. He started as a groundskeeper and worked his way up to a supervisory role, managing teams responsible for tree maintenance and pest control. Bjorn has extensive experience in coordinating field operations, managing personnel, and ensuring safety compliance. His practical knowledge of tree care, combined with his leadership skills, makes him an ideal Eradication Team Coordinator, capable of efficiently managing the eradication teams on the ground.

**Equipment Needs**:
Communication devices (phone, radio), vehicle for site visits, laptop/tablet for scheduling and reporting, safety equipment (PPE), first aid kit.

**Facility Needs**:
Office space for coordination, access to field sites, meeting rooms for team briefings.

## 3. Safety & Compliance Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Critical role requiring consistent oversight and adherence to regulations, best suited for a full-time employee with a deep understanding of the organization's policies.

**Explanation**:
Ensures adherence to safety protocols, environmental regulations, and permit requirements. This role is vital for protecting personnel, the public, and the environment.

**Consequences**:
Increased risk of accidents, environmental damage, legal liabilities, and reputational damage.

**People Count**:
1

**Typical Activities**:
Safety protocol development and enforcement, environmental regulation compliance, risk assessment, permit acquisition, incident investigation, training, auditing, documentation.

**Background Story**:
Signe Rasmussen, originally from Esbjerg, Denmark, is a certified environmental safety officer with a background in chemical engineering. She has worked for several years in the industrial sector, ensuring compliance with environmental regulations and safety protocols. Signe is meticulous, detail-oriented, and deeply committed to protecting both people and the environment. Her expertise in safety regulations, risk assessment, and environmental compliance makes her the perfect Safety & Compliance Officer for this project, ensuring that all eradication activities are conducted safely and responsibly.

**Equipment Needs**:
Safety monitoring equipment (air quality monitors), PPE, laptop with access to relevant regulations and databases, incident investigation tools, auditing checklists.

**Facility Needs**:
Office space for documentation and reporting, access to field sites for inspections, training facilities.

## 4. Equipment & Logistics Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Ongoing responsibility for managing equipment and logistics throughout the project, indicating a need for a dedicated, full-time resource.

**Explanation**:
Manages the procurement, maintenance, and distribution of all equipment and supplies. This role ensures that eradication teams have the necessary tools to perform their tasks effectively.

**Consequences**:
Delays in equipment delivery, equipment shortages, equipment malfunctions, and inefficient use of resources.

**People Count**:
1

**Typical Activities**:
Procurement, inventory management, supply chain management, vendor negotiation, equipment maintenance scheduling, distribution logistics, budget management, problem-solving.

**Background Story**:
Lars Jensen, a resident of Odense, has spent his entire career in logistics and supply chain management. He previously worked for a large agricultural supply company, where he was responsible for managing the procurement, storage, and distribution of equipment and materials. Lars is highly organized, resourceful, and skilled at negotiating with suppliers. His experience in managing complex logistics operations makes him an ideal Equipment & Logistics Manager, ensuring that the eradication teams have the necessary tools and supplies to perform their tasks effectively.

**Equipment Needs**:
Inventory management software, procurement tools, communication devices (phone, email), vehicle for transportation, PPE.

**Facility Needs**:
Office space for procurement and logistics management, storage facilities for equipment and supplies, access to loading docks.

## 5. Public Communication Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent communication and relationship management with the public and media, suggesting a need for a dedicated, full-time resource.

**Explanation**:
Responsible for communicating with the public, landowners, and media. This role ensures that the public is informed about the eradication efforts and any potential risks.

**Consequences**:
Public anxiety, misinformation, lack of cooperation from landowners, and reputational damage.

**People Count**:
1

**Typical Activities**:
Public relations, media relations, community engagement, communication strategy development, press release writing, website management, social media management, crisis communication.

**Background Story**:
Mette Olsen, born and raised in Copenhagen, has a degree in communications and public relations from the University of Southern Denmark. She has worked for several years as a communications officer for various non-profit organizations, where she was responsible for developing and implementing communication strategies, managing media relations, and engaging with the public. Mette is an excellent communicator, empathetic, and skilled at building relationships. Her experience in public relations and community engagement makes her an ideal Public Communication Liaison, ensuring that the public is informed about the eradication efforts and any potential risks.

**Equipment Needs**:
Laptop, phone, camera, access to website and social media platforms, press release distribution tools.

**Facility Needs**:
Office space for communication and media relations, access to meeting rooms for press conferences, access to community forums.

## 6. Waste Disposal & Decontamination Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Critical role requiring specialized knowledge and adherence to strict protocols, best suited for a full-time employee with a deep understanding of the organization's policies.

**Explanation**:
Oversees the safe disposal of contaminated materials and the decontamination of equipment and personnel. This role is crucial for preventing the spread of toxic hairs and protecting the environment.

**Consequences**:
Secondary contamination, environmental pollution, and increased health risks.

**People Count**:
min 1, max 2, depending on the volume of waste generated. A larger infestation requires more resources for waste management.

**Typical Activities**:
Hazardous waste handling, decontamination protocol implementation, waste disposal equipment operation, environmental regulation compliance, safety protocol enforcement, site cleanup, record keeping, training.

**Background Story**:
Hans Petersen, a lifelong resident of Funen, has worked for the Odense municipal waste management department for over 15 years. He has extensive experience in handling hazardous waste, operating specialized disposal equipment, and ensuring compliance with environmental regulations. Hans is meticulous, safety-conscious, and deeply committed to protecting the environment. His expertise in waste management and decontamination protocols makes him an ideal Waste Disposal & Decontamination Specialist, ensuring that all contaminated materials are handled and disposed of safely and responsibly.

**Equipment Needs**:
Specialized waste disposal equipment, decontamination equipment (washing stations, detergents), PPE, hazardous waste handling tools, monitoring equipment.

**Facility Needs**:
Designated waste disposal site, decontamination facilities, secure storage for hazardous materials, access to transportation for waste disposal.

## 7. Data Analyst & Reporting Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent data analysis and reporting throughout the project, indicating a need for a dedicated, full-time resource.

**Explanation**:
Collects, analyzes, and reports data on eradication progress, resource utilization, and environmental impact. This role provides insights for optimizing eradication strategies and ensuring accountability.

**Consequences**:
Lack of data-driven decision-making, inability to track progress effectively, and difficulty in identifying areas for improvement.

**People Count**:
1

**Typical Activities**:
Data collection, data analysis, statistical modeling, data visualization, report writing, database management, trend analysis, performance monitoring.

**Background Story**:
Sofie Andersen, originally from Aalborg, holds a Master's degree in Statistics from the University of Copenhagen. She has worked as a data analyst for several years, specializing in environmental monitoring and resource management. Sofie is highly proficient in statistical analysis software, data visualization tools, and report writing. Her analytical skills and experience in environmental data analysis make her an ideal Data Analyst & Reporting Specialist, providing valuable insights for optimizing eradication strategies and ensuring accountability.

**Equipment Needs**:
Laptop, statistical analysis software (e.g., R, SPSS), data visualization tools, database management system, reporting software.

**Facility Needs**:
Office space for data analysis and reporting, access to databases, secure data storage.

## 8. Ecological Impact Monitor

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Specialized skill for a short-term, defined task (ecological monitoring). Likely requires specific expertise not readily available in-house.

**Explanation**:
Monitors the impact of eradication efforts on non-target species and the local ecosystem. This role ensures that eradication methods are environmentally responsible and sustainable.

**Consequences**:
Unintended harm to non-target species, disruption of the local ecosystem, and long-term environmental damage.

**People Count**:
min 1, max 2, depending on the sensitivity of the local ecosystem. More sensitive areas require more intensive monitoring.

**Typical Activities**:
Ecological surveys, biodiversity monitoring, impact assessment, data analysis, report writing, species identification, habitat assessment, environmental sampling.

**Background Story**:
Rasmus Jorgensen, hailing from the island of Bornholm, is a trained ecologist with a PhD in Environmental Science from the University of Roskilde. He has spent the last decade studying the impact of human activities on local ecosystems, with a particular focus on insect populations and biodiversity. Rasmus is highly knowledgeable about Danish flora and fauna, and he is passionate about protecting the environment. His expertise in ecological monitoring and impact assessment makes him the perfect Ecological Impact Monitor, ensuring that the eradication efforts are environmentally responsible and sustainable.

**Equipment Needs**:
Ecological survey equipment (nets, traps, cameras), species identification guides, sampling equipment, data loggers, GPS, PPE.

**Facility Needs**:
Laboratory for sample analysis, access to field sites for ecological surveys, vehicle for transportation, office space for data analysis and reporting.

---

# Omissions

## 1. Volunteer Coordinator

The plan mentions 'trained volunteers' but lacks a dedicated role to manage and coordinate them. Volunteers require onboarding, task assignment, scheduling, and ongoing support to be effective.

**Recommendation**:
Assign a current team member (perhaps the Eradication Team Coordinator or Public Communication Liaison) to dedicate a portion of their time to volunteer management. This includes creating a volunteer schedule, providing necessary training, and acting as a point of contact for questions and concerns.

## 2. First Aid/Medical Support

Given the risk of exposure to toxic hairs and potential allergic reactions, having someone with first aid training readily available is crucial. The plan mentions stockpiling antihistamines and corticosteroids, but not a trained person to administer them.

**Recommendation**:
Ensure at least one member of each Eradication Team is certified in first aid and CPR, with specific training on managing allergic reactions. This person should be responsible for administering first aid and coordinating with emergency medical services if needed.

---

# Potential Improvements

## 1. Clarify Responsibilities of Eradication Team Coordinator

The description of the Eradication Team Coordinator is broad. Specifying their responsibilities regarding communication with other roles (e.g., Safety & Compliance Officer, Equipment & Logistics Manager) will improve coordination.

**Recommendation**:
Add specific responsibilities to the Eradication Team Coordinator's description, such as 'Daily communication with the Safety & Compliance Officer regarding safety protocols' and 'Weekly meetings with the Equipment & Logistics Manager to anticipate equipment needs.'

## 2. Formalize Communication Channels

While the Public Communication Liaison is responsible for external communication, internal communication channels between team members are not explicitly defined. This can lead to delays and misunderstandings.

**Recommendation**:
Establish a clear communication protocol, specifying how different team members should communicate with each other (e.g., daily briefings, weekly progress reports, emergency contact procedures). Utilize a shared communication platform (e.g., Slack, Microsoft Teams) to facilitate information sharing.

## 3. Define Success Metrics for Each Role

While the project has overall success criteria, individual roles lack specific, measurable goals. Defining these metrics will improve accountability and performance.

**Recommendation**:
Develop key performance indicators (KPIs) for each role. For example, the Infestation Mapping & Survey Lead could be measured by the accuracy and completeness of the infestation map, while the Safety & Compliance Officer could be measured by the number of safety incidents reported.