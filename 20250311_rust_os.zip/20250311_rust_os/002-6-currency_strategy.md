This plan involves money.

## Currencies

- **USD:** Likely costs associated with hardware, software licenses, cloud services (if used), and potential collaboration tools.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. No specific international currency risk management is needed as the project is assumed to be based in the USA.