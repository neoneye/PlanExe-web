This plan implies one or more physical locations.

## Requirements for physical locations

- BSL-4+ lab
- Near Beijing
- High security
- Secrecy

## Location 1
China

Near Beijing

Existing BSL-4+ lab near Beijing

**Rationale**: The plan explicitly requires an existing BSL-4+ lab near Beijing to ensure speed and secrecy.

## Location 2
China

Beijing

Chinese Academy of Sciences, Beijing

**Rationale**: The Chinese Academy of Sciences in Beijing is a leading research institution that may have suitable facilities or be able to quickly establish them.

## Location 3
China

Tianjin

Tianjin Institute of Industrial Biotechnology, Chinese Academy of Sciences

**Rationale**: The Tianjin Institute of Industrial Biotechnology is another prominent research center near Beijing that could potentially host the project.

## Location Summary
The plan requires a BSL-4+ lab near Beijing. The Chinese Academy of Sciences in Beijing and the Tianjin Institute of Industrial Biotechnology are suggested as potential locations due to their proximity and research capabilities.