### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, given its high-risk nature, geopolitical implications, and significant budget. Ensures alignment with national strategic objectives.

**Responsibilities:**

- Approve strategic decisions (e.g., International Collaboration Strategy, Containment Protocol Rigor).
- Review and approve annual project plans and budgets exceeding $50 million.
- Monitor project progress against strategic goals.
- Oversee risk management and mitigation strategies for high-impact risks (ecological, dual-use, geopolitical).
- Resolve strategic conflicts and escalate unresolved issues.
- Approve major changes to project scope or objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Define strategic decision thresholds.

**Membership:**

- Senior Representative from the Chinese Ministry of Science and Technology (Chair)
- Lead Scientist of the Project
- Chief Financial Officer of the Consortium
- Independent Expert in Biosecurity and Dual-Use Risks
- Independent Expert in Environmental Risk Assessment

**Decision Rights:** Strategic decisions related to project scope, budget (>$50M), risk management, and strategic partnerships.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion and approval of strategic decisions.
- Review of risk management reports and mitigation plans.
- Budget review and approval.
- Stakeholder engagement updates.

**Escalation Path:** Escalate unresolved issues to the Director of the Chinese Ministry of Science and Technology.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation, risk monitoring, and adherence to project plans. Essential for a project of this scale and complexity.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets (below $50 million).
- Monitor project progress and identify potential delays or issues.
- Manage project resources and ensure efficient allocation.
- Implement risk management plans and track mitigation efforts.
- Coordinate communication between project teams and stakeholders.
- Prepare regular project status reports.
- Manage operational compliance with regulations.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management processes and templates.
- Implement project tracking and reporting systems.
- Define communication protocols.

**Membership:**

- Project Manager (Head of PMO)
- Lead Scientists from each research area
- Financial Controller
- Risk Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $50 million), and risk management within approved plans.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Conflicts resolved through discussion and consensus. If consensus cannot be reached, the Project Manager makes the final decision.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of potential delays or issues.
- Resource allocation and management.
- Risk management updates.
- Action item tracking.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Dual-Use Risk Assessment Committee

**Rationale for Inclusion:** Provides specialized assurance on the identification and mitigation of potential dual-use applications of the research, given the geopolitical sensitivity and potential for misuse.

**Responsibilities:**

- Identify potential dual-use applications of the research.
- Assess the risks associated with each dual-use application.
- Develop mitigation strategies to prevent misuse.
- Monitor research activities for potential dual-use concerns.
- Report any potential dual-use concerns to relevant authorities.
- Ensure compliance with international regulations and guidelines on dual-use research.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Develop a dual-use risk assessment framework.

**Membership:**

- Independent Expert in Biosecurity and Dual-Use Risks (Chair)
- Lead Scientist of the Project
- Representative from the Chinese Ministry of Foreign Affairs
- Representative from the Chinese Ministry of National Defense
- Ethics Board Member

**Decision Rights:** Assessment and mitigation of dual-use risks. Recommendations on research modifications or restrictions to prevent misuse.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of ongoing research activities for potential dual-use concerns.
- Assessment of new dual-use risks.
- Development and review of mitigation strategies.
- Compliance with international regulations and guidelines.
- Reporting of potential dual-use concerns.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 4. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides specialized assurance on ethical considerations and compliance with relevant regulations (including GDPR, biosafety, and environmental regulations), ensuring responsible innovation and public trust.

**Responsibilities:**

- Review research proposals for ethical concerns.
- Develop ethical guidelines for the project.
- Monitor research activities for compliance with ethical guidelines.
- Investigate and address any ethical violations.
- Ensure compliance with relevant regulations (GDPR, biosafety, environmental).
- Provide training on ethical and compliance issues.
- Oversee data privacy and security measures.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Develop ethical guidelines and compliance procedures.

**Membership:**

- Independent Ethics Expert (Chair)
- Legal Counsel
- Data Protection Officer
- Environmental Safety Officer
- Community Representative

**Decision Rights:** Ethical approval of research proposals. Enforcement of ethical guidelines and compliance procedures. Recommendations on data privacy and security measures.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research proposals for ethical concerns.
- Discussion of ethical issues and compliance matters.
- Investigation of ethical violations.
- Review of data privacy and security measures.
- Training on ethical and compliance issues.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Provides specialized input on stakeholder perspectives and ensures effective communication and engagement with the public, scientific community, and regulatory bodies, given the potential for public distrust and ethical concerns.

**Responsibilities:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and feedback.
- Communicate project progress and findings to stakeholders.
- Manage public relations and media inquiries.
- Organize public outreach events.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Group Chair.
- Establish meeting schedule and communication protocols.
- Develop a stakeholder engagement plan.

**Membership:**

- Public Relations Officer (Chair)
- Lead Scientist of the Project
- Representative from the Chinese Ministry of Foreign Affairs
- Community Representative
- Representative from the International Scientific Community

**Decision Rights:** Recommendations on stakeholder engagement strategies. Approval of public communication materials.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder engagement strategies.
- Approval of public communication materials.
- Planning of public outreach events.
- Management of public relations and media inquiries.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.