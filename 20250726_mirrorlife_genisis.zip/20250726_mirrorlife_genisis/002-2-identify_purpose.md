**Purpose:** business

**Purpose Detailed:** Large-scale synthetic biology project with geopolitical and national advantage objectives, including infrastructure development and potential dual-use applications.

**Topic:** Synthetic Biology Initiative