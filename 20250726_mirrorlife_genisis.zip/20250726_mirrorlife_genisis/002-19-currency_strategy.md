This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and it is a stable international currency suitable for large-scale projects.
- **CNY:** Local expenses within China will likely be incurred in CNY.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. CNY will be used for local transactions within China. Given the scale and duration of the project, hedging strategies against exchange rate fluctuations between USD and CNY should be considered.