### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Circulate Draft SteerCo ToR for review by Senior Representative from the Chinese Ministry of Science and Technology, Lead Scientist of the Project, Chief Financial Officer of the Consortium, Independent Expert in Biosecurity and Dual-Use Risks, and Independent Expert in Environmental Risk Assessment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes the SteerCo ToR based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Representative from the Chinese Ministry of Science and Technology formally appointed as Steering Committee Chair.

**Responsible Body/Role:** Director of the Chinese Ministry of Science and Technology

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager coordinates with the Chinese Ministry of Science and Technology, the Consortium, and independent experts to confirm the remaining Steering Committee membership: Lead Scientist of the Project, Chief Financial Officer of the Consortium, Independent Expert in Biosecurity and Dual-Use Risks, and Independent Expert in Environmental Risk Assessment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SteerCo Membership List

### 7. Hold initial Project Steering Committee kick-off meeting to review ToR, establish meeting cadence, and define initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation
- Final SteerCo ToR v1.0

### 8. Establish PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Staffing Plan

**Dependencies:**

- Project Start

### 9. Develop project management processes and templates.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Handbook
- Project Templates

**Dependencies:**

- PMO Structure Document

### 10. Implement project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Project Management Handbook

### 11. Define communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Project Management Handbook

### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Structure Document
- Project Management Handbook
- Project Tracking System
- Reporting Templates
- Communication Plan

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Dual-Use Risk Assessment Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Dual-Use Risk Assessment Committee ToR v0.1

**Dependencies:**

- Project Start

### 14. Circulate Draft Dual-Use Risk Assessment Committee ToR for review by the Chinese Ministry of Foreign Affairs, the Chinese Ministry of National Defense, and the Ethics Board Member.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Dual-Use Risk Assessment Committee ToR v0.1

### 15. Project Manager finalizes the Dual-Use Risk Assessment Committee ToR based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Dual-Use Risk Assessment Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 16. Project Steering Committee formally appoints Independent Expert in Biosecurity and Dual-Use Risks as Dual-Use Risk Assessment Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Dual-Use Risk Assessment Committee ToR v1.0
- Project Steering Committee established

### 17. Project Manager coordinates with the Chinese Ministry of Foreign Affairs, the Chinese Ministry of National Defense, and the Ethics Board to confirm the remaining Dual-Use Risk Assessment Committee membership: Lead Scientist of the Project, Representative from the Chinese Ministry of Foreign Affairs, Representative from the Chinese Ministry of National Defense, Ethics Board Member.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Confirmed Dual-Use Risk Assessment Committee Membership List

**Dependencies:**

- Appointment Confirmation Email

### 18. Project Manager schedules the initial Dual-Use Risk Assessment Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Dual-Use Risk Assessment Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Dual-Use Risk Assessment Committee Membership List

### 19. Hold initial Dual-Use Risk Assessment Committee kick-off meeting to review ToR, establish meeting cadence, and develop a dual-use risk assessment framework.

**Responsible Body/Role:** Dual-Use Risk Assessment Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Dual-Use Risk Assessment Framework

**Dependencies:**

- Dual-Use Risk Assessment Committee Kick-off Meeting Invitation
- Final Dual-Use Risk Assessment Committee ToR v1.0

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 21. Circulate Draft Ethics and Compliance Committee ToR for review by Legal Counsel, Data Protection Officer, Environmental Safety Officer, and Community Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 22. Project Manager finalizes the Ethics and Compliance Committee ToR based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Project Steering Committee formally appoints Independent Ethics Expert as Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Project Steering Committee established

### 24. Project Manager coordinates with Legal Counsel, Data Protection Officer, Environmental Safety Officer, and Community Representative to confirm the remaining Ethics and Compliance Committee membership: Legal Counsel, Data Protection Officer, Environmental Safety Officer, Community Representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Confirmed Ethics and Compliance Committee Membership List

**Dependencies:**

- Appointment Confirmation Email

### 25. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Ethics and Compliance Committee Membership List

### 26. Hold initial Ethics and Compliance Committee kick-off meeting to review ToR, establish meeting cadence, and develop ethical guidelines and compliance procedures.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Ethical Guidelines and Compliance Procedures

**Dependencies:**

- Ethics and Compliance Committee Kick-off Meeting Invitation
- Final Ethics and Compliance Committee ToR v1.0

### 27. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start

### 28. Circulate Draft Stakeholder Engagement Group ToR for review by Lead Scientist of the Project, Representative from the Chinese Ministry of Foreign Affairs, Community Representative, and Representative from the International Scientific Community.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 29. Project Manager finalizes the Stakeholder Engagement Group ToR based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 30. Project Steering Committee formally appoints Public Relations Officer as Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Project Steering Committee established

### 31. Project Manager coordinates with Lead Scientist of the Project, Representative from the Chinese Ministry of Foreign Affairs, Community Representative, and Representative from the International Scientific Community to confirm the remaining Stakeholder Engagement Group membership: Lead Scientist of the Project, Representative from the Chinese Ministry of Foreign Affairs, Community Representative, Representative from the International Scientific Community.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Confirmed Stakeholder Engagement Group Membership List

**Dependencies:**

- Appointment Confirmation Email

### 32. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Stakeholder Engagement Group Membership List

### 33. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, establish meeting cadence, and develop a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation
- Final Stakeholder Engagement Group ToR v1.0