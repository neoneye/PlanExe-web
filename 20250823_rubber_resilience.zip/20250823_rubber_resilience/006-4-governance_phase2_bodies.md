### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this large-scale, high-impact, and complex initiative. Ensures alignment with overall strategic goals and effective resource allocation.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$50 million).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve funding gate releases at Years 3/7/12/18 based on KPI achievement.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define decision-making protocols.
- Approve initial project plan and budget.

**Membership:**

- Senior representatives from public funding agencies.
- Senior representatives from private sector partners (OEMs, rubber companies).
- Independent expert in agricultural economics and risk management.
- Project Director.

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and strategic direction. Approval of major changes (>$50 million) and funding gate releases.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Independent expert provides advisory vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Discussion of key risks and mitigation strategies.
- Approval of major changes to project scope, budget, or timeline.
- Review of financial performance.
- Review of stakeholder engagement activities.
- Assessment of KPI achievement for funding gate releases.

**Escalation Path:** Escalate unresolved issues to the executive leadership of the participating public and private organizations.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Ensures efficient day-to-day execution, operational risk management, and consistent application of project management methodologies across all project workstreams.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Monitor project progress and identify potential risks and issues.
- Manage project resources and ensure efficient allocation.
- Coordinate communication and collaboration among project teams.
- Implement project management methodologies and best practices.
- Track and report on project performance against KPIs.
- Manage operational risks and implement mitigation strategies.
- Manage decisions below strategic thresholds (e.g., <$50 million).

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management methodologies and templates.
- Implement project tracking and reporting systems.
- Define roles and responsibilities for project team members.

**Membership:**

- Project Manager.
- Workstream leads (Cultivar Development, Alternative Rubber, Smallholder Adoption, Containment Protocol).
- Finance Manager.
- Risk Manager.
- Communications Manager.

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management below strategic thresholds (e.g., <$50 million).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with workstream leads. Escalation to the Project Steering Committee for issues exceeding authority.

**Meeting Cadence:** Weekly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and issues.
- Review of resource allocation and utilization.
- Coordination of communication and collaboration among project teams.
- Tracking of project performance against KPIs.
- Review of financial performance against budget.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, compliance with all relevant regulations (including GDPR and ABS), and responsible use of project resources. Addresses corruption risks and promotes transparency.

**Responsibilities:**

- Develop and implement a code of ethics for the project.
- Ensure compliance with all relevant regulations, including GDPR, ABS, and environmental regulations.
- Review and approve all contracts and agreements to ensure ethical and legal compliance.
- Investigate allegations of fraud, corruption, or ethical violations.
- Provide training and guidance to project personnel on ethical and compliance issues.
- Oversee the whistleblower mechanism and ensure protection for whistleblowers.
- Ensure compliance with data privacy regulations (GDPR) for all data collection and processing activities.
- Oversee compliance with Access and Benefit Sharing (ABS) agreements related to bio-prospecting and genomic breeding.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish whistleblower mechanism.
- Develop compliance training program.

**Membership:**

- Independent legal counsel specializing in international regulations and compliance.
- Ethics officer.
- Data Protection Officer (DPO).
- Representative from a non-governmental organization (NGO) focused on environmental or social justice.
- Representative from the Project Management Office.

**Decision Rights:** Decisions related to ethical conduct, regulatory compliance, and investigation of alleged violations. Authority to recommend corrective actions and disciplinary measures.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Independent legal counsel provides advisory vote.

**Meeting Cadence:** Bi-monthly, with ad-hoc meetings as needed for urgent issues.

**Typical Agenda Items:**

- Review of compliance with relevant regulations.
- Discussion of ethical issues and potential conflicts of interest.
- Investigation of alleged violations of the code of ethics or compliance policies.
- Review of contracts and agreements for ethical and legal compliance.
- Review of data privacy practices and compliance with GDPR.
- Review of ABS agreements and compliance with benefit-sharing provisions.
- Review of whistleblower reports and investigation findings.

**Escalation Path:** Escalate unresolved issues or serious violations to the Project Steering Committee and relevant regulatory authorities.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on all aspects of the project, including cultivar development, alternative rubber production, and SALB containment. Ensures technical feasibility and scientific rigor.

**Responsibilities:**

- Provide technical advice and guidance on cultivar development, alternative rubber production, and SALB containment.
- Review and evaluate technical proposals and research findings.
- Identify potential technical risks and recommend mitigation strategies.
- Monitor the performance of technical activities and provide feedback to project teams.
- Ensure the technical feasibility and scientific rigor of the project.
- Advise on the selection of appropriate technologies and methodologies.
- Provide independent assessment of technical progress against milestones.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Identify and recruit technical experts.
- Define areas of expertise and responsibilities.

**Membership:**

- Leading plant breeders specializing in Hevea and alternative rubber crops.
- Agronomists with expertise in tropical and arid-climate agriculture.
- Plant pathologists specializing in SALB and other rubber diseases.
- Experts in rubber processing and manufacturing.
- Representatives from research institutions and universities.

**Decision Rights:** Provides technical recommendations and guidance to the Project Steering Committee and Project Management Office. Does not have decision-making authority but its advice is strongly considered.

**Decision Mechanism:** Recommendations developed through consensus among members. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical progress against milestones.
- Discussion of technical challenges and potential solutions.
- Evaluation of technical proposals and research findings.
- Identification of potential technical risks and mitigation strategies.
- Assessment of the feasibility of new technologies and methodologies.
- Review of technical reports and publications.

**Escalation Path:** Escalate unresolved technical issues or concerns to the Project Steering Committee.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and collaboration with all stakeholders, including smallholder farmers, government agencies, private sector partners, and international organizations. Promotes transparency and addresses stakeholder concerns.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct consultations with smallholder farmers and other stakeholders.
- Establish and maintain communication channels with stakeholders.
- Provide regular updates and progress reports to stakeholders.
- Address stakeholder concerns and feedback.
- Promote transparency and accountability.
- Facilitate collaboration and partnerships among stakeholders.
- Monitor stakeholder satisfaction and identify areas for improvement.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop stakeholder engagement plan.
- Identify key stakeholders and their needs.
- Establish communication channels.

**Membership:**

- Representatives from smallholder farmer organizations.
- Representatives from government agencies.
- Representatives from private sector partners.
- Representatives from international organizations.
- Community liaison officers.
- Communications Manager.

**Decision Rights:** Advises the Project Steering Committee and Project Management Office on stakeholder engagement strategies and communication plans. Does not have decision-making authority but its advice is strongly considered.

**Decision Mechanism:** Recommendations developed through consensus among members. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical stakeholder issues.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Review of communication plans and materials.
- Planning of stakeholder consultations and events.
- Monitoring of stakeholder satisfaction.
- Identification of opportunities for collaboration and partnerships.

**Escalation Path:** Escalate unresolved stakeholder issues or concerns to the Project Steering Committee.