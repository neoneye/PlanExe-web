A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Smallholder farmers will readily adopt new rubber varieties and alternative crops if provided with adequate incentives and support. | Conduct a pilot program offering different incentive packages to a representative sample of smallholder farmers and track their adoption rates over a 6-month period. | Adoption rates remain below 30% despite the incentives. |
| A2 | The cost of producing alternative rubber will become competitive with conventional rubber over time. | Conduct a detailed cost analysis of alternative rubber production, including all direct and indirect costs, and compare it to the current cost of conventional rubber production. | The projected cost of alternative rubber production remains more than 15% higher than conventional rubber production after 5 years. |
| A3 | International cooperation will be forthcoming in adopting and enforcing the SALB Containment Protocol. | Engage with key international organizations (FAO, WTO) and rubber-producing countries to gauge their commitment to adopting and enforcing the SALB Containment Protocol. | Less than 50% of key rubber-producing countries commit to adopting the protocol within the first year. |
| A1 | The globally adopted SALB Containment Protocol will be effectively enforced across all key rubber-producing regions. | Conduct a red-team exercise simulating protocol breaches in multiple regions. | Simulated breaches lead to rapid, uncontrolled spread of SALB in multiple regions. |
| A2 | Smallholder farmers will readily adopt new rubber varieties and alternative crops if provided with adequate incentives and support. | Pilot test the proposed incentive structure with a representative sample of smallholder farmers. | Adoption rates in the pilot test remain below 30% despite the incentives. |
| A3 | The cost of producing alternative rubber will become competitive with conventional rubber over time. | Develop a detailed cost model for alternative rubber production and compare it to current Hevea production costs. | The cost model projects that alternative rubber production costs will remain more than 15% higher than Hevea within 10 years. |
| A7 | OEMs will readily accept alternative rubber even if it requires modifications to their existing manufacturing processes. | Conduct a survey and in-depth interviews with major tire manufacturers and other OEMs to assess their willingness to adapt their processes for alternative rubber. | OEMs indicate that they are unwilling to make significant changes to their manufacturing processes to accommodate alternative rubber without substantial price discounts. |
| A8 | The cost of implementing and enforcing the SALB Containment Protocol will be less than 5% of the total project budget. | Develop a detailed cost breakdown for all aspects of the SALB Containment Protocol, including personnel, equipment, training, and monitoring. | The projected cost of implementing and enforcing the SALB Containment Protocol exceeds 5% of the total project budget. |
| A9 | Smallholder farmers possess sufficient access to information and resources to make informed decisions about adopting new rubber varieties and sustainable farming practices. | Conduct a baseline survey to assess smallholder farmers' access to information, credit, training, and other essential resources. | The baseline survey reveals that a significant proportion of smallholder farmers lack access to critical information and resources needed to make informed decisions about adopting new practices. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Cost-Parity Chasm | Process/Financial | A2 | Head of Finance | CRITICAL (20/25) |
| FM2 | The Containment Collapse | Technical/Logistical | A3 | Permitting Lead | CRITICAL (15/25) |
| FM3 | The Smallholder Revolt | Market/Human | A1 | Community Liaison | HIGH (12/25) |
| FM4 | The Permitting Paralysis | Process/Financial | A1 | Permitting Lead | CRITICAL (20/25) |
| FM5 | The Guayule Gamble | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM6 | The Synthetic Surge | Market/Human | A3 | Market Analyst | HIGH (10/25) |
| FM7 | The Containment Cost Catastrophe | Process/Financial | A8 | Chief Financial Officer | CRITICAL (20/25) |
| FM8 | The OEM Adaptation Impasse | Technical/Logistical | A7 | Head of Engineering | CRITICAL (15/25) |
| FM9 | The Information Asymmetry Inferno | Market/Human | A9 | Community Engagement Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Cost-Parity Chasm

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Head of Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project hinged on alternative rubber achieving cost parity with Hevea within a reasonable timeframe. However, unforeseen challenges in processing Guayule and Russian Dandelion emerged. 

*   Initial projections underestimated the energy costs associated with extracting rubber from these alternative sources.
*   The development of efficient, scalable processing technologies proved more difficult and expensive than anticipated.
*   OEMs were unwilling to pay a premium for alternative rubber, even with its sustainability benefits, due to the higher cost.
*   The project's financial model, based on achieving cost parity by Year 7, became unsustainable as costs remained stubbornly high.
*   Private sector investment dried up as the ROI projections plummeted.
*   The project faced severe budget cuts, forcing a reduction in scope and ultimately, cancellation.

##### Early Warning Signs
- Processing costs for alternative rubber exceed initial projections by 20% after 2 years.
- OEMs refuse to sign offtake agreements at prices that cover production costs.
- Private sector investment in alternative rubber processing facilities falls short of targets by 50%.

##### Tripwires
- Alternative rubber production cost >= $2500/ton by Year 5
- OEM offtake agreements cover < 50% of projected alternative rubber production by Year 6
- Private investment < $500 million by Year 5

##### Response Playbook
- Contain: Immediately freeze all new investments in alternative rubber processing facilities.
- Assess: Conduct a thorough review of alternative rubber production costs and identify areas for cost reduction.
- Respond: Explore alternative processing technologies and negotiate with OEMs to secure higher prices or subsidies.


**STOP RULE:** Alternative rubber production costs remain > 10% higher than Hevea after Year 10.

---

#### FM2 - The Containment Collapse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The cornerstone of the project was the globally adopted SALB Containment Protocol. However, political realities undermined its implementation.

*   Key rubber-producing countries, facing economic pressures and conflicting priorities, failed to fully adopt the protocol.
*   Enforcement mechanisms were weak, and cross-border movement of infected plant material continued unabated.
*   A new, more virulent strain of SALB emerged, rendering existing control measures ineffective.
*   Outbreaks spread rapidly across Southeast Asia, decimating rubber plantations and disrupting supply chains.
*   The project's efforts to diversify rubber sources were overwhelmed by the scale of the outbreak.
*   The entire initiative was deemed a failure as SALB continued its relentless march across the globe.

##### Early Warning Signs
- Key rubber-producing countries delay or weaken their commitment to the SALB Containment Protocol.
- SALB outbreaks increase in frequency and severity despite the implementation of containment measures.
- A new, more virulent strain of SALB is identified.

##### Tripwires
- Adoption of SALB Containment Protocol by key countries <= 60% by Year 3
- SALB outbreaks increase by >= 20% YoY in key regions
- Identification of a new SALB strain with >= 30% higher virulence

##### Response Playbook
- Contain: Immediately increase surveillance and quarantine measures in affected regions.
- Assess: Conduct a rapid assessment of the effectiveness of existing containment measures and identify gaps.
- Respond: Lobby international organizations and governments to strengthen enforcement of the SALB Containment Protocol and invest in research to combat the new SALB strain.


**STOP RULE:** SALB spreads to new continents despite containment efforts after Year 5.

---

#### FM3 - The Smallholder Revolt

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Community Liaison
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's success depended on smallholder farmers adopting SALB-resistant varieties and alternative rubber crops. However, the project failed to adequately understand their needs and motivations.

*   The incentive programs were poorly designed and failed to address the specific challenges faced by smallholder farmers.
*   Farmers lacked access to credit, training, and technical assistance, hindering their ability to adopt new practices.
*   The project failed to build trust with local communities, leading to resistance and resentment.
*   Farmers perceived the project as a top-down initiative that did not respect their traditional knowledge and practices.
*   Widespread protests erupted, disrupting project activities and undermining its legitimacy.
*   The project was forced to shut down as it lost the support of the very people it was intended to help.

##### Early Warning Signs
- Smallholder farmer participation in project activities declines significantly.
- Farmers express dissatisfaction with the incentive programs and technical assistance.
- Local communities organize protests against the project.

##### Tripwires
- Smallholder participation rate <= 40% by Year 2
- Farmer satisfaction score <= 3 out of 5 on annual survey
- Number of protests >= 3 in a single year

##### Response Playbook
- Contain: Immediately suspend all project activities in affected communities.
- Assess: Conduct a thorough review of the incentive programs and community engagement strategies.
- Respond: Redesign the incentive programs based on farmer feedback and invest in building trust with local communities through participatory decision-making processes.


**STOP RULE:** Smallholder adoption rates remain below 20% after Year 5 despite revised incentive programs.

---

#### FM4 - The Permitting Paralysis

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on rapid regulatory approvals across multiple countries proves to be its undoing. 
*   Initial delays in Brazil for bio-prospecting permits cascade into a domino effect, stalling cultivar development.
*   Environmental impact assessments in Indonesia face fierce local opposition, triggering legal challenges and further delays.
*   Russian regulations on alternative crop cultivation prove to be far more restrictive than anticipated, limiting the scale of deployment.
*   The adaptive funding model, designed for agility, becomes paralyzed by the constant need to re-forecast and re-justify budget allocations due to the permitting delays.
*   Private sector partners, initially enthusiastic, grow wary of the mounting delays and begin to pull out, citing unacceptable levels of risk.

##### Early Warning Signs
- Permit approval timelines exceed initial estimates by >50% in any key region.
- Legal challenges filed against environmental impact assessments in >2 key regions.
- Private sector funding commitments decrease by >20% within the first 3 years.

##### Tripwires
- Permit delays exceed 180 days in Brazil.
- Legal challenges against EIAs sustained in Indonesia.
- Private funding falls below 70% of projected levels by Year 3.

##### Response Playbook
- Contain: Immediately halt all new project activities in regions experiencing permitting delays.
- Assess: Conduct a thorough review of the permitting landscape and identify alternative strategies.
- Respond: Shift resources to regions with more favorable regulatory environments and explore alternative technologies that require fewer permits.


**STOP RULE:** Permitting delays across key regions exceed 2 years, rendering the project economically unviable.

---

#### FM5 - The Guayule Gamble

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's bet on Guayule as a viable alternative rubber source backfires spectacularly.
*   Initial field trials in Arizona show promising yields, but large-scale cultivation proves far more challenging.
*   Water scarcity issues intensify due to climate change, driving up irrigation costs and limiting production.
*   Unexpected pest infestations decimate Guayule crops, requiring costly and environmentally damaging pesticide applications.
*   The lack of established processing infrastructure for Guayule leads to bottlenecks and quality control issues.
*   OEMs express concerns about the inconsistent quality and performance of Guayule rubber, refusing to commit to large-scale offtake agreements.

##### Early Warning Signs
- Guayule yields fall below projected levels by >30% in large-scale cultivation.
- Water costs for Guayule irrigation increase by >50% due to drought.
- OEMs express concerns about Guayule rubber quality in >2 key meetings.

##### Tripwires
- Guayule yields <= 0.5 tons/hectare in commercial farms.
- Water costs >= $500/acre-foot for Guayule irrigation.
- OEM offtake agreements cover < 50% of projected Guayule production by Year 5.

##### Response Playbook
- Contain: Immediately suspend all further investment in Guayule cultivation beyond existing pilot projects.
- Assess: Conduct a comprehensive review of Guayule production challenges and explore alternative rubber sources.
- Respond: Shift resources to Russian Dandelion and synthetic rubber alternatives, while maintaining a small Guayule research program.


**STOP RULE:** Guayule rubber fails to meet minimum OEM performance standards after 7 years of R&D.

---

#### FM6 - The Synthetic Surge

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Market Analyst
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project's efforts to promote natural and alternative rubber are undermined by a sudden surge in the competitiveness of synthetic rubber.
*   A breakthrough in synthetic rubber production technology dramatically reduces costs, making it far cheaper than natural rubber.
*   Consumers show a strong preference for the consistent quality and performance of synthetic rubber, despite its environmental drawbacks.
*   OEMs prioritize cost savings over sustainability, switching back to synthetic rubber in droves.
*   Smallholder farmers, unable to compete with the low prices of synthetic rubber, abandon their plantations, leading to social unrest and economic hardship.
*   The project's funding dries up as investors lose confidence in the long-term viability of natural rubber production.

##### Early Warning Signs
- Synthetic rubber prices fall below natural rubber prices by >20%.
- OEMs announce plans to increase synthetic rubber usage by >30%.
- Smallholder farmer participation in the project declines by >25%.

##### Tripwires
- Synthetic rubber price <= $1.00/kg.
- OEMs announce > 50% shift to synthetic rubber in annual reports.
- Smallholder participation < 50% of initial enrollment by Year 8.

##### Response Playbook
- Contain: Immediately freeze all new investments in natural rubber production and processing.
- Assess: Conduct a thorough analysis of the synthetic rubber market and identify potential niche markets for natural rubber.
- Respond: Pivot the project to focus on high-value, sustainable rubber applications and advocate for policies that level the playing field with synthetic rubber.


**STOP RULE:** Natural rubber market share falls below 10% globally, rendering the project economically unsustainable.

---

#### FM7 - The Containment Cost Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Chief Financial Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model assumed that SALB containment would be relatively inexpensive. However, the reality proved far different. 
*   Initial estimates for border controls and phytosanitary measures were drastically underestimated.
*   The need for constant monitoring and retraining of personnel added significant recurring costs.
*   Unexpected outbreaks required costly emergency response measures, further straining the budget.
*   The lack of a realistic cost model led to funds being diverted from cultivar development and smallholder support, ultimately crippling the project.

##### Early Warning Signs
- Actual costs for border inspections exceed budgeted amounts by 20% within the first year.
- Requests for additional funding for emergency outbreak response occur more than twice per year.
- The project's overall burn rate exceeds projections by 15% within the first 18 months.

##### Tripwires
- Total spending on SALB containment exceeds 7.5% of the total project budget by Year 3.
- The cost per inspection of imported rubber exceeds $500 USD.
- Emergency outbreak response costs exceed $5 million USD in any given year.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending related to SALB containment.
- Assess: Conduct a thorough review of the SALB Containment Protocol to identify areas for cost reduction and efficiency improvements.
- Respond: Renegotiate contracts with suppliers, explore alternative technologies for monitoring and detection, and seek additional funding from public and private sources.


**STOP RULE:** If the projected cost of SALB containment exceeds 10% of the total project budget, triggering a critical funding shortfall for other essential activities, the project will be cancelled.

---

#### FM8 - The OEM Adaptation Impasse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project banked on OEMs readily adopting alternative rubber. This proved disastrous. 
*   OEMs were unwilling to retool their factories or modify their tire designs to accommodate the new material.
*   Alternative rubber's performance characteristics, while promising in the lab, did not meet the stringent requirements of real-world applications.
*   The lack of OEM buy-in created a bottleneck in the supply chain, leaving vast quantities of alternative rubber unsold.
*   The project's inability to secure OEM offtake agreements led to financial losses and a loss of investor confidence.

##### Early Warning Signs
- OEMs express concerns about the performance characteristics of alternative rubber in initial testing.
- Negotiations with major tire manufacturers stall due to disagreements over pricing and quality.
- The volume of alternative rubber sold falls short of projections by 30% within the first two years of commercial production.

##### Tripwires
- Fewer than 2 major tire manufacturers sign offtake agreements for alternative rubber by Year 5.
- OEM rejection rate of alternative rubber exceeds 15% due to quality or performance issues.
- Inventory of unsold alternative rubber exceeds 50,000 tons.

##### Response Playbook
- Contain: Halt further expansion of alternative rubber production until OEM offtake agreements are secured.
- Assess: Conduct a thorough review of the performance characteristics of alternative rubber and identify areas for improvement.
- Respond: Invest in R&D to enhance the quality and performance of alternative rubber, offer incentives to OEMs for adopting the material, and explore alternative markets for the product.


**STOP RULE:** If, by Year 8, alternative rubber fails to achieve a minimum of 5% market share in the tire industry due to lack of OEM adoption, the project will pivot to focus solely on SALB-resistant Hevea cultivars.

---

#### FM9 - The Information Asymmetry Inferno

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Engagement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumed smallholders were well-informed and rational actors. This was a fatal flaw. 
*   Many farmers lacked access to reliable information about the benefits of new rubber varieties and sustainable practices.
*   Cultural barriers and distrust of authority figures hindered the adoption of new technologies.
*   The project failed to adequately address the specific needs and concerns of marginalized groups, leading to widespread resentment.
*   The lack of effective communication and engagement resulted in low adoption rates and a breakdown of trust between the project and the farming communities.

##### Early Warning Signs
- Attendance at training sessions for smallholder farmers falls below 50% of the target audience.
- Surveys reveal that a significant proportion of smallholder farmers are unaware of the project's goals and objectives.
- Rumors and misinformation about the project spread rapidly through farming communities.

##### Tripwires
- Adoption rates of SALB-resistant varieties among smallholder farmers remain below 30% by Year 5.
- Farmer satisfaction scores with project support services fall below 60% in annual surveys.
- Protests or demonstrations against the project occur in more than 3 key farming regions.

##### Response Playbook
- Contain: Immediately launch a comprehensive communication campaign to address misinformation and build trust with smallholder communities.
- Assess: Conduct a thorough assessment of smallholder farmers' information needs and communication preferences.
- Respond: Develop tailored communication strategies for different farming communities, utilize trusted local leaders and community organizations to disseminate information, and establish feedback mechanisms to address concerns and grievances.


**STOP RULE:** If, by Year 7, smallholder adoption rates remain below 20% despite significant investment in communication and support services, the project will be restructured to prioritize large-scale plantations and alternative farming models.
