**Budget Request Exceeding PMO Authority ($50 million threshold)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and vote based on strategic alignment and budget availability.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for uncontrolled spending, budget overruns, and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., failure to achieve SALB Containment Protocol)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee convenes an emergency meeting to assess the impact and approve revised mitigation strategies or contingency plans.
Rationale: Represents a significant threat to project success and requires strategic intervention.
Negative Consequences: Project failure, inability to meet objectives, and loss of stakeholder confidence.

**PMO Deadlock on Vendor Selection (e.g., disagreement on technology provider)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the competing proposals and makes a final decision based on technical merit, cost, and strategic alignment.
Rationale: Indicates a lack of consensus at the operational level and requires higher-level arbitration.
Negative Consequences: Project delays, suboptimal vendor selection, and potential for internal conflict.

**Proposed Major Scope Change (e.g., adding a new alternative rubber crop)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed change, assesses its impact on the project's objectives, budget, and timeline, and approves or rejects the change.
Rationale: Represents a significant deviation from the original project plan and requires strategic approval.
Negative Consequences: Scope creep, budget overruns, project delays, and misalignment with strategic objectives.

**Reported Ethical Concern (e.g., potential violation of Access and Benefit Sharing agreements)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigates the allegation, gathers evidence, and recommends corrective actions or disciplinary measures.
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and project cancellation.

**Technical Advisory Group cannot reach consensus on a critical technical issue (e.g., optimal breeding strategy)**
Escalation Level: Project Steering Committee
Approval Process: The Project Steering Committee reviews the dissenting opinions and makes a final decision based on strategic priorities and risk tolerance, potentially seeking external expert advice.
Rationale: Indicates a fundamental disagreement among technical experts that requires strategic guidance.
Negative Consequences: Suboptimal technical decisions, project delays, and increased risk of technical failure.