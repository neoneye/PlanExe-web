This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and it is an international project.
- **BRL:** Brazil-led bio-prospecting and genomic breeding efforts will require local transactions in BRL.
- **RUB:** Russian dandelion cultivation in Russia will involve local transactions in RUB.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting is USD. Exchange rate fluctuations should be monitored, and hedging strategies may be considered. Local currencies (BRL and RUB) will be used for in-country transactions.