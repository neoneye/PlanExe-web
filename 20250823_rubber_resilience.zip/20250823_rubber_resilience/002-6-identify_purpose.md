**Purpose:** business

**Purpose Detailed:** Large-scale public-private program focused on securing the natural rubber supply chain through disease containment, crop diversification, and smallholder adoption, with clear commercial and societal benefits.

**Topic:** De-risking global natural rubber supply from South American Leaf Blight (SALB)