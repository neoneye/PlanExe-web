## Suggestion 1 - The Sustainable Intensification of Maize-Legume Cropping Systems for Food Security in Eastern and Southern Africa (SIMLESA)

SIMLESA was a 10-year (2010-2019) initiative funded by the Australian Centre for International Agricultural Research (ACIAR) and implemented across seven countries in Eastern and Southern Africa (Ethiopia, Kenya, Tanzania, Uganda, Malawi, Mozambique, and Zimbabwe). It aimed to improve food security and livelihoods for smallholder farmers by promoting sustainable intensification practices in maize-legume cropping systems. The project focused on developing and disseminating improved crop varieties, promoting conservation agriculture techniques, and strengthening market linkages.

### Success Metrics

Increased maize and legume yields by an average of 20-30% in participating households.
Improved soil health and water use efficiency.
Enhanced farmer incomes and food security.
Development and dissemination of improved crop varieties and agronomic practices.
Strengthened capacity of national agricultural research systems.

### Risks and Challenges Faced

Drought and other climate-related shocks: Mitigated through the promotion of drought-tolerant varieties and water conservation techniques.
Limited access to inputs and markets: Addressed through the establishment of farmer groups and linkages with input suppliers and buyers.
Weak institutional capacity: Strengthened through training and mentoring of national agricultural research staff.
Policy constraints: Addressed through advocacy and engagement with policymakers.

### Where to Find More Information

ACIAR project page: [https://www.aciar.gov.au/project/lsm-2007-009](https://www.aciar.gov.au/project/lsm-2007-009)
SIMLESA project reports and publications: Search ACIAR's website or Google Scholar for SIMLESA publications.

### Actionable Steps

Contact ACIAR project managers or researchers involved in SIMLESA for insights on project design, implementation, and monitoring.
Reach out to national agricultural research institutions in the participating countries to learn about their experiences with sustainable intensification practices.
Email: Research contacts can be found via the ACIAR website or through publications.
LinkedIn: Search for researchers involved in SIMLESA.

### Rationale for Suggestion

SIMLESA provides a relevant example of a large-scale, multi-country agricultural development project focused on improving food security and livelihoods for smallholder farmers. It shares similarities with the proposed rubber project in its focus on crop diversification (maize-legume vs. Hevea-alternative rubber), sustainable intensification practices, and smallholder engagement. The challenges faced and mitigation strategies employed by SIMLESA offer valuable lessons for the rubber project, particularly in addressing climate-related risks, market access constraints, and institutional capacity building. Although geographically distant, the operational and strategic challenges are highly relevant.
## Suggestion 2 - The Cocoa & Forests Initiative (CFI)

The Cocoa & Forests Initiative (CFI) is a collective effort by the governments of Côte d’Ivoire and Ghana, leading cocoa companies, and civil society organizations to end deforestation and forest degradation in the cocoa supply chain. Launched in 2017, CFI aims to promote sustainable cocoa production, protect and restore forests, and improve the livelihoods of cocoa farmers. The initiative focuses on traceability, agroforestry, community engagement, and policy reforms.

### Success Metrics

Reduction in deforestation rates in cocoa-growing regions.
Increased adoption of agroforestry practices by cocoa farmers.
Improved traceability of cocoa beans from farm to factory.
Enhanced community participation in forest management.
Strengthened policy frameworks for sustainable cocoa production.

### Risks and Challenges Faced

Enforcement of deforestation regulations: Addressed through increased monitoring and law enforcement efforts.
Lack of traceability: Mitigated through the development and implementation of traceability systems.
Low cocoa prices: Addressed through the promotion of value-added cocoa products and diversification of farmer incomes.
Land tenure issues: Addressed through community engagement and policy reforms.

### Where to Find More Information

World Cocoa Foundation CFI page: [https://www.worldcocoafoundation.org/initiative/cocoa-forests-initiative/](https://www.worldcocoafoundation.org/initiative/cocoa-forests-initiative/)
IDH, The Sustainable Trade Initiative CFI page: [https://www.idhsustainabletrade.com/our-work/cocoa/cocoa-forests-initiative/](https://www.idhsustainabletrade.com/our-work/cocoa/cocoa-forests-initiative/)
CFI progress reports and publications: Search the websites of the World Cocoa Foundation and IDH for CFI-related materials.

### Actionable Steps

Contact the World Cocoa Foundation or IDH for insights on the CFI's governance structure, implementation strategies, and monitoring mechanisms.
Reach out to cocoa companies participating in the CFI to learn about their experiences with traceability, agroforestry, and community engagement.
Email: Contact information can be found on the websites of the World Cocoa Foundation and IDH.
LinkedIn: Search for individuals involved in the CFI from participating companies and organizations.

### Rationale for Suggestion

The CFI offers a strong parallel to the proposed rubber project due to its focus on addressing sustainability challenges in a global agricultural supply chain. Like the rubber project, CFI involves multiple stakeholders (governments, companies, farmers, civil society), aims to promote sustainable production practices, and seeks to mitigate environmental and social risks. The CFI's experience with traceability, agroforestry, and community engagement provides valuable lessons for the rubber project, particularly in ensuring smallholder participation and minimizing negative environmental impacts. The focus on policy reform and international cooperation is also relevant to the rubber project's goal of establishing a globally adopted SALB Containment Protocol. Although the crops differ, the systemic challenges and multi-stakeholder dynamics are highly comparable.
## Suggestion 3 - Rubber Research Institute of India (RRII) Research Programs

The Rubber Research Institute of India (RRII) conducts extensive research on all aspects of natural rubber production, processing, and utilization. This includes breeding and selection of high-yielding, disease-resistant rubber clones, developing sustainable agronomic practices, and improving rubber processing technologies. RRII also provides training and extension services to rubber growers in India.

### Success Metrics

Development and release of high-yielding, disease-resistant rubber clones.
Increased rubber productivity and profitability for Indian farmers.
Reduced environmental impact of rubber cultivation.
Improved rubber processing technologies.
Enhanced capacity of Indian rubber growers.

### Risks and Challenges Faced

Long breeding cycles: Addressed through the use of molecular markers and other advanced breeding techniques.
Disease outbreaks: Mitigated through the development of disease-resistant clones and integrated disease management strategies.
Climate change impacts: Addressed through the selection of climate-resilient clones and the development of water conservation techniques.
Smallholder adoption: Addressed through training and extension services.

### Where to Find More Information

Rubber Research Institute of India website: [http://rubberboard.org.in/](http://rubberboard.org.in/)
RRII research publications: Search the RRII website or Google Scholar for RRII publications.

### Actionable Steps

Contact RRII researchers for insights on rubber breeding, disease management, and sustainable agronomic practices.
Explore opportunities for collaboration with RRII on research and development activities.
Email: Contact information can be found on the RRII website.
LinkedIn: Search for researchers at the Rubber Research Institute of India.

### Rationale for Suggestion

RRII's research programs offer a valuable resource for the proposed rubber project, particularly in the areas of cultivar development and disease management. RRII's experience with breeding disease-resistant rubber clones and developing sustainable agronomic practices can inform the project's efforts to develop SALB-resistant Hevea cultivars and promote sustainable rubber production. The RRII's focus on smallholder adoption is also relevant to the project's goal of ensuring smallholder participation. While RRII's focus is primarily on Hevea, its expertise in rubber cultivation and disease management is directly applicable to the proposed project. This suggestion is included despite geographical distance due to the specific technical expertise it offers.

## Summary

Based on the provided project plan to de-risk the global natural rubber supply chain from South American Leaf Blight (SALB), I recommend the following projects as references. These projects offer insights into managing large-scale agricultural initiatives, public-private partnerships, and global supply chain diversification, with a focus on sustainability and smallholder engagement.