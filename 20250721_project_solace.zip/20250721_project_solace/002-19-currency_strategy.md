This plan involves money.

## Currencies

- **USD:** The project budget is initially defined in USD, and it is an international project.
- **CHF:** Switzerland (Geneva) is a key location for international negotiations.
- **JPY:** Japan (Tsukuba) is a key location for research and development.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. Local currencies (CHF, JPY) may be used for local transactions in Switzerland and Japan, respectively. Hedging strategies should be considered to manage exchange rate risks.