**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit delegated to the PMO, requiring strategic review and approval at a higher level.
Negative Consequences: Potential for budget overruns, impacting project financial stability and stakeholder confidence.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., Governance Protocol failure, weaponization) requires strategic reassessment and potentially significant resource reallocation.
Negative Consequences: Project failure, international conflict, environmental damage, or significant financial losses.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Decision
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates intervention from the higher authority to ensure project progress.
Negative Consequences: Project delays, increased costs, and potential for suboptimal vendor selection.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval
Rationale: Significant changes to the project scope (e.g., altering temperature reduction target) require strategic alignment and approval from the governing body.
Negative Consequences: Misalignment with project goals, increased costs, and potential for project failure.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee
Rationale: Allegations of ethical violations (e.g., bribery, conflict of interest) require independent review and potential corrective action to maintain project integrity.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Unresolved Technical Issues**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Decision based on TAG recommendations
Rationale: Unresolved technical issues from the Technical Advisory Group (TAG) require strategic direction and potential resource allocation from the governing body.
Negative Consequences: Technical failures, project delays, and potential for suboptimal technical solutions.