### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Essential for providing high-level strategic direction and oversight given the project's massive scale ($5 trillion), 30-year duration, high geopolitical risk, and the need for international consensus.

**Responsibilities:**

- Approve the overall project strategy and roadmap.
- Approve major project milestones and stage-gate transitions.
- Approve annual budgets exceeding $100 billion.
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate unresolved issues.
- Approve changes to the Global Thermostat Governance Protocol.
- Monitor and ensure alignment with the 'Builder's Foundation' strategic logic.

**Initial Setup Actions:**

- Finalize the Project Steering Committee's Terms of Reference.
- Appoint the Chair and Vice-Chair.
- Establish the meeting schedule and communication protocols.
- Define the escalation process and conflict resolution mechanisms.
- Review and approve the initial project risk register.

**Membership:**

- Senior representatives from each G20 member state (or their designated representatives).
- Chief Executive Officer (CEO) of the International Consortium.
- Chief Financial Officer (CFO) of the International Consortium.
- Independent Expert in International Law and Governance.
- Independent Expert in Climate Science and Geoengineering.

**Decision Rights:** Strategic decisions related to project scope, budget (above $100 billion), timeline, and key strategic risks. Approval of the Global Thermostat Governance Protocol and any subsequent amendments.

**Decision Mechanism:** Decisions are made by a weighted voting system, reflecting both financial contribution and climate vulnerability, as per the 'Builder's Foundation' strategic logic. A supermajority (75%) is required for major decisions. The Chair has a tie-breaking vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance and budget adherence.
- Discussion and approval of proposed changes to project scope or timeline.
- Review of strategic risks and mitigation plans.
- Updates on the Global Thermostat Governance Protocol development and ratification progress.
- Review of stakeholder engagement activities and feedback.

**Escalation Path:** Unresolved issues are escalated to the Heads of State/Government of the G20 member states.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Necessary for managing the day-to-day execution of the project, ensuring adherence to the project plan, and coordinating the activities of various workstreams given the project's complexity and scale.

**Responsibilities:**

- Develop and maintain the project management plan.
- Monitor project progress against milestones and budget.
- Manage project risks and issues.
- Coordinate communication and reporting across workstreams.
- Manage contracts and procurement.
- Ensure compliance with project policies and procedures.
- Support the Project Steering Committee with data and analysis.

**Initial Setup Actions:**

- Establish the PMO structure and staffing.
- Develop the project management plan template and guidelines.
- Implement project management tools and systems.
- Define reporting requirements and communication protocols.
- Establish risk and issue management processes.

**Membership:**

- Project Director.
- Workstream Leads (e.g., Technology Development, Launch Operations, Governance Protocol Development).
- Finance Manager.
- Risk Manager.
- Communications Manager.
- Contract Manager.

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions are made by the Project Director, in consultation with the PMO team. Issues requiring strategic direction are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of project risks and issues.
- Review of financial performance and budget adherence.
- Coordination of workstream activities.
- Review of contract and procurement activities.
- Updates on communication and stakeholder engagement.

**Escalation Path:** Unresolved issues are escalated to the Project Steering Committee.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Critical for providing expert technical advice and assurance on the design, development, and deployment of the solar sunshade, given the high technical complexity and potential for unintended consequences.

**Responsibilities:**

- Provide expert technical advice on the design and development of the solar sunshade.
- Review and assess the technical feasibility and risks of proposed technologies.
- Monitor the performance of the sunshade and identify potential issues.
- Advise on technical mitigation strategies.
- Ensure adherence to relevant technical standards and best practices.
- Review and approve technical specifications and designs.
- Assess the long-term maintenance and operational requirements of the sunshade.

**Initial Setup Actions:**

- Identify and recruit leading experts in relevant technical fields.
- Define the TAG's scope of work and responsibilities.
- Establish communication protocols and reporting requirements.
- Develop a process for reviewing and approving technical documents.
- Establish a mechanism for providing independent technical assessments.

**Membership:**

- Leading experts in materials science.
- Leading experts in space engineering.
- Leading experts in robotics and automation.
- Leading experts in climate science and geoengineering.
- Independent expert in risk assessment and mitigation.
- Independent expert in space debris management.

**Decision Rights:** Provide technical recommendations and assessments to the Project Steering Committee and PMO. Approve technical specifications and designs.

**Decision Mechanism:** Decisions are made by consensus of the TAG members. In cases where consensus cannot be reached, the Chair of the TAG has the casting vote. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical progress and challenges.
- Assessment of proposed technologies and designs.
- Discussion of technical risks and mitigation strategies.
- Review of performance data and identification of potential issues.
- Updates on relevant technical standards and best practices.
- Assessment of long-term maintenance and operational requirements.

**Escalation Path:** Unresolved technical issues are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Essential for ensuring ethical conduct, compliance with international laws and regulations, and adherence to the Global Thermostat Governance Protocol, given the project's potential for ethical dilemmas and legal challenges.

**Responsibilities:**

- Develop and maintain the project's ethics and compliance framework.
- Ensure compliance with international laws and regulations, including the Outer Space Treaty and environmental protection standards.
- Monitor adherence to the Global Thermostat Governance Protocol.
- Investigate allegations of ethical violations or non-compliance.
- Provide training on ethics and compliance to project personnel.
- Oversee the whistleblower mechanism and protect whistleblowers from retaliation.
- Ensure compliance with GDPR and other relevant data privacy regulations.
- Review and approve project policies and procedures from an ethical and compliance perspective.

**Initial Setup Actions:**

- Develop the project's ethics and compliance framework.
- Establish the ECC's Terms of Reference.
- Appoint the Chair and members of the ECC.
- Develop a process for investigating allegations of ethical violations or non-compliance.
- Establish a whistleblower mechanism and protection policy.

**Membership:**

- Independent expert in international law.
- Independent expert in ethics and governance.
- Independent expert in environmental law.
- Representative from the International Consortium's legal department.
- Representative from the International Consortium's compliance department.
- Data Protection Officer (DPO).

**Decision Rights:** Provide recommendations on ethical and compliance issues to the Project Steering Committee and PMO. Approve project policies and procedures from an ethical and compliance perspective. Mandate investigations into alleged violations.

**Decision Mechanism:** Decisions are made by consensus of the ECC members. In cases where consensus cannot be reached, the Chair of the ECC has the casting vote. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical ethical or compliance issues.

**Typical Agenda Items:**

- Review of ethical and compliance risks.
- Discussion of alleged ethical violations or non-compliance.
- Review of project policies and procedures.
- Updates on relevant laws and regulations.
- Review of whistleblower reports and investigations.
- Updates on data privacy compliance.

**Escalation Path:** Unresolved ethical or compliance issues are escalated to the Project Steering Committee.
### 5. Stakeholder Engagement Group (SEG)

**Rationale for Inclusion:** Crucial for managing relationships with diverse stakeholders, addressing public concerns, and building support for the project, given the potential for public opposition and the need for a 'social license to operate'.

**Responsibilities:**

- Develop and implement the project's stakeholder engagement plan.
- Identify and analyze key stakeholders.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and feedback.
- Communicate project progress and benefits to stakeholders.
- Manage media relations and public relations.
- Monitor public opinion and sentiment.
- Develop and implement community benefits programs.

**Initial Setup Actions:**

- Develop the project's stakeholder engagement plan.
- Identify and map key stakeholders.
- Establish communication channels and protocols.
- Develop a process for addressing stakeholder concerns and feedback.
- Establish a community benefits program.

**Membership:**

- Representative from the International Consortium's communications department.
- Representative from the International Consortium's public relations department.
- Representative from the International Consortium's community relations department.
- Independent expert in stakeholder engagement.
- Representative from a leading environmental organization.
- Representative from a community affected by the project.

**Decision Rights:** Provide recommendations on stakeholder engagement strategies to the Project Steering Committee and PMO. Approve stakeholder engagement plans and communication materials.

**Decision Mechanism:** Decisions are made by consensus of the SEG members. In cases where consensus cannot be reached, the Chair of the SEG has the casting vote. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical stakeholder engagement issues.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Review of communication materials.
- Updates on public opinion and sentiment.
- Review of community benefits programs.
- Planning for upcoming stakeholder events.

**Escalation Path:** Unresolved stakeholder engagement issues are escalated to the Project Steering Committee.