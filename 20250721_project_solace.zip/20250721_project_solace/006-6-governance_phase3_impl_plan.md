### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft PSC ToR for review by Senior Representatives from each G20 member state (or their designated representatives), CEO & CFO of the International Consortium, Independent Experts in International Law/Governance & Climate Science/Geoengineering.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee's Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor formally appoints the Chair and Vice-Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PSC ToR v1.0

### 5. Project Manager, in consultation with the appointed Chair, establishes the meeting schedule and communication protocols for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Schedule
- Communication Protocols

**Dependencies:**

- Appointment Confirmation Email

### 6. Project Manager defines the escalation process and conflict resolution mechanisms for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Escalation Process Document
- Conflict Resolution Mechanism Document

**Dependencies:**

- Meeting Schedule
- Communication Protocols

### 7. Project Manager reviews and approves the initial project risk register with the Project Steering Committee Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Initial Project Risk Register

**Dependencies:**

- Escalation Process Document
- Conflict Resolution Mechanism Document

### 8. Hold the Project Steering Committee (PSC) Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Approved Initial Project Risk Register
- Meeting Schedule
- Communication Protocols

### 9. Project Manager establishes the PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Staffing Plan

**Dependencies:**

- Project Plan Approved

### 10. Project Manager develops the project management plan template and guidelines.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Plan Template
- Project Management Guidelines

**Dependencies:**

- PMO Structure Document

### 11. Project Manager implements project management tools and systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Implemented

**Dependencies:**

- Project Management Plan Template

### 12. Project Manager defines reporting requirements and communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Reporting Requirements Document
- Communication Protocols Document

**Dependencies:**

- Project Management Tools and Systems Implemented

### 13. Project Manager establishes risk and issue management processes for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Risk Management Process Document
- Issue Management Process Document

**Dependencies:**

- Reporting Requirements Document
- Communication Protocols Document

### 14. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Risk Management Process Document
- Issue Management Process Document

### 15. Project Manager identifies and recruits leading experts in relevant technical fields for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Project Plan Approved

### 16. Project Manager defines the TAG's scope of work and responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Scope of Work Document
- TAG Responsibilities Document

**Dependencies:**

- Nominated Members List

### 17. Project Manager establishes communication protocols and reporting requirements for the TAG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Communication Protocols Document
- TAG Reporting Requirements Document

**Dependencies:**

- TAG Scope of Work Document
- TAG Responsibilities Document

### 18. Project Manager develops a process for reviewing and approving technical documents for the TAG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Document Review Process Document

**Dependencies:**

- TAG Communication Protocols Document
- TAG Reporting Requirements Document

### 19. Project Manager establishes a mechanism for providing independent technical assessments for the TAG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Independent Technical Assessment Mechanism Document

**Dependencies:**

- Technical Document Review Process Document

### 20. Project Manager formally appoints members to the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Independent Technical Assessment Mechanism Document

### 21. Hold Technical Advisory Group (TAG) Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails

### 22. Project Manager develops the project's ethics and compliance framework for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics and Compliance Framework Document

**Dependencies:**

- Project Plan Approved

### 23. Project Manager establishes the ECC's Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Terms of Reference Document

**Dependencies:**

- Ethics and Compliance Framework Document

### 24. Project Manager appoints the Chair and members of the ECC.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- ECC Terms of Reference Document

### 25. Project Manager develops a process for investigating allegations of ethical violations or non-compliance for the ECC.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Investigation Process Document

**Dependencies:**

- Appointment Confirmation Emails

### 26. Project Manager establishes a whistleblower mechanism and protection policy for the ECC.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Whistleblower Mechanism Document
- Whistleblower Protection Policy Document

**Dependencies:**

- Investigation Process Document

### 27. Hold Ethics & Compliance Committee (ECC) Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Whistleblower Mechanism Document
- Whistleblower Protection Policy Document

### 28. Project Manager develops the project's stakeholder engagement plan for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan Document

**Dependencies:**

- Project Plan Approved

### 29. Project Manager identifies and maps key stakeholders for the SEG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Stakeholder Map Document

**Dependencies:**

- Stakeholder Engagement Plan Document

### 30. Project Manager establishes communication channels and protocols for the SEG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Communication Channels Document
- Communication Protocols Document

**Dependencies:**

- Stakeholder Map Document

### 31. Project Manager develops a process for addressing stakeholder concerns and feedback for the SEG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Stakeholder Feedback Process Document

**Dependencies:**

- Communication Channels Document
- Communication Protocols Document

### 32. Project Manager establishes a community benefits program for the SEG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Community Benefits Program Document

**Dependencies:**

- Stakeholder Feedback Process Document

### 33. Project Manager formally appoints members to the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Community Benefits Program Document

### 34. Hold Stakeholder Engagement Group (SEG) Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails