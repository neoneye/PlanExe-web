This plan involves money.

## Currencies

- **EUR:** France is a key location, and the Euro is relevant for operations within Europe.
- **CAD:** Canada is a key location for relocation in the Northern Hemisphere.
- **NOK:** Norway is a key location for relocation in the Northern Hemisphere.
- **USD:** The United States is involved, and the USD is a stable international currency for large-scale projects.

**Primary currency:** USD

**Currency strategy:** Given the international scope and potential for large-scale financial transactions, USD is recommended for budgeting and reporting. EUR, CAD and NOK will be used for local transactions within Europe, Canada and Norway respectively. Currency exchange rates should be monitored and hedging strategies considered to mitigate risks from exchange fluctuations.