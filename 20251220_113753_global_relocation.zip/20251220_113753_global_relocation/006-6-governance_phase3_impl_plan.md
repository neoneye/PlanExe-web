### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by Senior Management and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Incorporate feedback and finalize the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback on Draft SteerCo ToR
- Draft SteerCo ToR v0.1

### 4. Senior Sponsor formally appoints the Chair of the Project Steering Committee (Senior Representative from the United Nations).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Chair Acceptance

**Dependencies:**

- Final SteerCo ToR v1.0
- Identification of UN Representative

### 5. Project Manager, in consultation with the Steering Committee Chair, identifies and invites nominated members to the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment of SteerCo Chair

### 6. Formally confirm Project Steering Committee membership based on acceptances.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Nominated Members List Available
- Acceptance of Invitations

### 7. Schedule and hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed SteerCo Membership List
- Final SteerCo ToR v1.0

### 8. Project Steering Committee reviews and approves the initial project risk register.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Initial Project Risk Register

**Dependencies:**

- SteerCo Kick-off Meeting Minutes with Action Items
- Initial Project Risk Register Drafted

### 9. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 10. Circulate Draft Ethics and Compliance Committee ToR for review by Senior Management and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1 circulated for review

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 11. Incorporate feedback and finalize the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback on Draft Ethics and Compliance Committee ToR
- Draft Ethics and Compliance Committee ToR v0.1

### 12. Senior Management appoints the Chair of the Ethics and Compliance Committee (Independent Legal Expert).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Chair Acceptance

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Identification of Independent Legal Expert

### 13. Project Manager, in consultation with the Ethics and Compliance Committee Chair, identifies and invites nominated members to the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Appointment of Ethics and Compliance Committee Chair

### 14. Formally confirm Ethics and Compliance Committee membership based on acceptances.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Ethics and Compliance Committee Membership List

**Dependencies:**

- Nominated Members List Available
- Acceptance of Invitations

### 15. Schedule and hold the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Ethics and Compliance Committee Membership List
- Final Ethics and Compliance Committee ToR v1.0

### 16. Ethics and Compliance Committee develops the code of ethics for the project.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Code of Ethics

**Dependencies:**

- Ethics and Compliance Committee Kick-off Meeting Minutes with Action Items

### 17. Project Manager establishes PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Defined
- PMO Staffing Plan

**Dependencies:**

- Project Plan Approved

### 18. Project Manager develops project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates and Tools

**Dependencies:**

- PMO Structure Defined

### 19. Project Manager defines project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates and Tools

### 20. Project Manager establishes communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 21. Project Manager develops risk management framework for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Risk Management Framework Document

**Dependencies:**

- PMO Communication Protocols Document

### 22. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- PMO Risk Management Framework Document
- PMO Staffing Plan

### 23. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 24. Circulate Draft Technical Advisory Group ToR for review by Senior Management and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1 circulated for review

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 25. Incorporate feedback and finalize the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback on Draft Technical Advisory Group ToR
- Draft Technical Advisory Group ToR v0.1

### 26. Project Director appoints the Chair of the Technical Advisory Group (Chief Technology Officer).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Chair Acceptance

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Identification of Chief Technology Officer

### 27. Project Manager, in consultation with the Technical Advisory Group Chair, identifies and invites nominated members to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Appointment of Technical Advisory Group Chair

### 28. Formally confirm Technical Advisory Group membership based on acceptances.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Nominated Members List Available
- Acceptance of Invitations

### 29. Schedule and hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Technical Advisory Group Membership List
- Final Technical Advisory Group ToR v1.0

### 30. Technical Advisory Group develops technical standards and guidelines.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Standards and Guidelines

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Minutes with Action Items