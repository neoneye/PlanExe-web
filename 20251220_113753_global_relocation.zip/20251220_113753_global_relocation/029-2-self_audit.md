Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on relocation, resource management, and governance, which are engineering and logistical challenges rather than violations of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (global relocation) + market (Northern Hemisphere) + tech/process (smart cities, AI logistics) + policy (new global governance) without independent evidence at comparable scale. No precedent exists for relocating a large portion of the world's population within 24 months.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Management Office / Deliverable: Validation Reports / Date: 2026-Q1


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like 'sustainable', 'equitable', and 'innovation' without defining their mechanisms of action or measurable outcomes. The plan states, "This isn't just about moving people; it's about building a **sustainable**, equitable, and technologically advanced society".

**Mitigation**: Project Management: Create one-pagers for each strategic concept, defining inputs→process→customer value, owners, measurable outcomes, and decision hooks. Due Date: 2026-Q1


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan minimizes major hazard classes. The plan identifies risks (regulatory, social, environmental, etc.) but lacks explicit analysis of cascading failures. The plan states, "Develop contingency plans to address specific risks as they emerge".

**Mitigation**: Risk Management: Expand the risk register to include cascading failure scenarios (e.g., permit delay → resource shortage → social unrest) and develop specific controls for each. Due Date: 2026-Q1


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because (a) the plan assumes international agreements and permits can be obtained within 24 months, which is unlikely, and (b) the permit/approval matrix is absent. The plan states, "Move the world citizens to the upper hemisphere within 24 months".

**Mitigation**: Legal Team: Conduct a preliminary assessment of permit approval timelines with key regulatory bodies and rebuild the critical path with authoritative permit lead times. Due Date: 2026-Q1


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan assumes $5T USD from international government (60%), private investment (30%), and philanthropic donations (10%), but lacks evidence of committed funding or term sheets.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources, their status (e.g., LOI/term sheet/closed), draw schedule, covenants, and NO-GO on missed financing gates. Due Date: 2026-Q1


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with scale-appropriate benchmarks. The plan assumes a $5 trillion USD budget, but expert reviews suggest this is significantly underestimated, potentially requiring $25-50 trillion USD. There is no per-area math or normalization.

**Mitigation**: Finance Team: Benchmark costs (≥3) for similar relocation/infrastructure projects, normalize per area (m²/ft²), obtain vendor quotes, and adjust the budget or de-scope. Due Date: 2026-Q1


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., 30% faster infrastructure build-out) as single numbers without ranges or alternative scenarios. The plan states, "Systemic: 30% faster infrastructure build-out in the North".

**Mitigation**: Project Management: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for Northern infrastructure build-out, including key drivers and assumptions. Due Date: 2026-Q1


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components (relocation centers, transportation networks, resource extraction facilities, smart city infrastructure) lack engineering artifacts. The plan mentions transportation infrastructure but lacks specs, interface contracts, acceptance tests, integration plan, and non-functional requirements.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due Date: 2026-Q2


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable evidence. For example, the plan states, "5000 sq meter facility in Nantes, France" without providing evidence of ownership, lease agreement, or site control.

**Mitigation**: Real Estate Team: Secure site control (purchase agreement, lease option) for the Nantes facility or change scope by 2026-Q1.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'new global governance structure' is mentioned without specific, verifiable qualities. The plan states, "Establish a new global governance structure" without defining its form, authority, or member states.

**Mitigation**: Legal Team: Define SMART criteria for the new global governance structure, including a KPI for member state participation (e.g., ratification by 75% of UN member states). Due Date: 2026-Q1


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Full-Scale Smart City Deployment' without a clear benefit case. This feature does not directly support the core goals of rapid relocation or basic infrastructure establishment. The plan states, "Full-Scale Smart City Deployment: Develop fully integrated smart cities".

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Full-Scale Smart City Deployment', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Owner: Chief of Infrastructure / Deliverable: Benefit Case / Date: 2026-Q1


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Chief Ethics and Social Impact Officer' to ensure ethical considerations are prioritized. This role is critical given the high ethical exposure of forced relocation. The plan states, "Ensures ethical considerations are prioritized throughout the project".

**Mitigation**: HR Team: Conduct a talent market assessment for candidates with expertise in ethics, social impact assessment, and international human rights law. Due Date: 2026-Q1


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions permits and licenses but does not map them to specific authorities or timelines. The plan states, "Secure international agreements and permits".

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) for all required permits/licenses, flagging showstoppers. Due Date: 2026-Q1


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a credible operational sustainability model. The plan states, "Ensure sustainable resource management" but lacks a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Sustainability Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due Date: 2026-Q2


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions locations (Nantes, France; Canada/Scandinavia above 53°N) without evidence of zoning analysis, site control, or capacity studies. The plan states, "5000 sq meter facility in Nantes, France".

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen for Nantes, France, and Canada/Scandinavia above 53°N, seeking written confirmation where feasible. Define fallback designs/sites and dated NO-GO thresholds tied to constraint outcomes. Due Date: 2026-Q1


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of redundancy or tested failover plans for external dependencies. The plan mentions transportation infrastructure but lacks details on backup systems or alternative routes. The plan states, "Transportation infrastructure (aircraft, ships, trains)".

**Mitigation**: Logistics Team: Secure SLAs with key vendors, add a secondary supplier/path for critical resources, and test failover procedures by 2026-Q2.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states objectives for 'efficient relocation' and 'economic productivity'. Finance is incentivized by budget adherence, while the Relocation Team is incentivized by speed, creating a conflict over resource allocation.

**Mitigation**: Project Management: Create a shared OKR (Objective and Key Results) that aligns Finance and the Relocation Team on a common outcome, such as 'Relocate X people within Y budget'. Due Date: 2026-Q1


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Management Office: Add a monthly review with KPI dashboard and a lightweight change board. Owner: PMO / Deliverable: Review Schedule and Change Control Process / Date: 2026-Q1


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a cross-impact analysis or similar artifact to show how risks interact. The 'Pioneer's Gambit' scenario exacerbates risks. A permit failure (High) could trigger resource shortages (High), leading to social unrest (High).

**Mitigation**: Risk Management: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Owner: Risk Management / Deliverable: Risk Assessment / Date: 2026-Q1