**Purpose:** business

**Purpose Detailed:** Development of a regulatory tool for energy market interventions, focusing on consequence assessment and decision-making support for a regulator, with a strong emphasis on governance, accountability, and transparency.

**Topic:** Shared Intelligence Asset MVP for energy-market regulation