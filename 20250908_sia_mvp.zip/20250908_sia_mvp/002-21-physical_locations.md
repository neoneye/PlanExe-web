This plan implies one or more physical locations.

## Requirements for physical locations

- Sovereign cloud region
- Per-tenant KMS/HSM
- Zero-trust architecture
- Insider-threat controls
- Tamper-evident signed logs
- Access to judiciary, civil society, domain scientists, security, technical auditors

## Location 1
Switzerland

Various locations in Switzerland

Specific office locations to be determined

**Rationale**: The plan explicitly states that the project will be located in Switzerland.

## Location 2
Switzerland

Zurich

Office space in Zurich with access to talent and infrastructure

**Rationale**: Zurich is a major financial and technology hub in Switzerland, offering access to skilled labor, infrastructure, and potential partners.

## Location 3
Switzerland

Geneva

Office space in Geneva with access to international organizations and legal expertise

**Rationale**: Geneva is a hub for international organizations and legal expertise, which could be beneficial for the governance and regulatory aspects of the project.

## Location Summary
The project is located in Switzerland, with specific suggestions for Zurich and Geneva due to their access to talent, infrastructure, international organizations, and legal expertise.