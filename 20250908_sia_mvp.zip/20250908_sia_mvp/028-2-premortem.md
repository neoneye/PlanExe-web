A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The regulator will actively participate in the development and testing of the Shared Intelligence Asset throughout the project lifecycle. | Schedule a joint workshop with the regulator to co-develop the initial set of requirements and success metrics. | The regulator declines to participate in the workshop or sends only junior staff without decision-making authority. |
| A2 | Effective de-identification techniques will be sufficient to protect data privacy while still allowing for meaningful analysis. | Engage a third-party cybersecurity firm to conduct a penetration test on a sample of de-identified data. | The penetration test reveals that individuals can be re-identified from the de-identified data with a high degree of accuracy. |
| A3 | The project team can effectively manage and adapt to changes in regulations or data privacy laws without significant delays or cost overruns. | Conduct a scenario planning exercise to assess the impact of a hypothetical change in data privacy regulations on the project timeline and budget. | The scenario planning exercise reveals that a change in data privacy regulations would require significant rework and delay the project by more than 3 months or increase costs by more than CHF 250,000. |
| A4 | The existing IT infrastructure of the regulator will be compatible with the Shared Intelligence Asset, allowing for seamless integration and data exchange. | Conduct a detailed assessment of the regulator's IT infrastructure, including hardware, software, and network capabilities. | The assessment reveals significant incompatibilities or limitations that would require costly upgrades or workarounds. |
| A5 | The AI models developed for the Shared Intelligence Asset will be readily accepted and trusted by regulatory staff, leading to increased adoption and improved decision-making. | Conduct a survey of regulatory staff to assess their current level of trust in AI and their willingness to rely on AI-driven insights. | The survey reveals widespread skepticism or resistance to AI among regulatory staff, indicating a need for extensive training and change management efforts. |
| A6 | The chosen cloud provider will maintain consistent pricing and service levels throughout the project lifecycle, allowing for accurate budget forecasting and reliable system performance. | Obtain a written guarantee from the cloud provider regarding pricing and service levels for the duration of the project. | The cloud provider is unwilling to provide a written guarantee, or the terms of the guarantee are deemed unacceptable due to potential cost increases or service disruptions. |
| A7 | The data scientists on the project team possess sufficient domain expertise in energy market regulation to effectively develop and validate AI models. | Administer a domain knowledge quiz to the data scientists, covering key concepts and regulations in energy market regulation. | The quiz results reveal a significant lack of domain knowledge among the data scientists, indicating a need for additional training or the recruitment of domain experts. |
| A8 | The project's chosen open-source AI libraries and tools will remain actively maintained and supported throughout the project lifecycle, ensuring access to necessary updates and security patches. | Assess the activity levels and community support for the key open-source libraries and tools used in the project, including the frequency of updates and the responsiveness of maintainers to bug reports and security vulnerabilities. | The assessment reveals that one or more of the key open-source libraries or tools are no longer actively maintained or supported, posing a risk to the project's long-term security and stability. |
| A9 | Energy companies and other stakeholders will be willing to share their data with the Shared Intelligence Asset, even if it means increased transparency into their operations. | Conduct confidential interviews with representatives from several key energy companies to gauge their willingness to share data and their concerns about transparency. | The interviews reveal significant reluctance among energy companies to share data, indicating a need for incentives or guarantees of confidentiality. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Abandonment | Process/Financial | A1 | Project Manager | CRITICAL (20/25) |
| FM2 | The De-Identification Debacle | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Regulatory Whirlwind | Market/Human | A3 | Permitting Lead | HIGH (12/25) |
| FM4 | The Integration Impasse | Process/Financial | A4 | Project Manager | CRITICAL (20/25) |
| FM5 | The AI Aversion | Market/Human | A5 | Stakeholder Engagement Manager | CRITICAL (15/25) |
| FM6 | The Cloud Cost Catastrophe | Technical/Logistical | A6 | Head of Engineering | HIGH (12/25) |
| FM7 | The Black Box Blunder | Technical/Logistical | A7 | Data Science Lead | CRITICAL (20/25) |
| FM8 | The Open-Source Orphan | Process/Financial | A8 | Head of Engineering | HIGH (12/25) |
| FM9 | The Data Drought | Market/Human | A9 | Stakeholder Engagement Manager | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Regulatory Abandonment

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's success hinges on the active participation of the regulator. If the regulator becomes disengaged, the project will lose direction and relevance. This can happen due to changes in leadership, shifting priorities, or a loss of confidence in the project's potential. Without the regulator's input, the system may not meet their actual needs, leading to low adoption rates and a waste of resources.

Specifically, the lack of regulator input early on leads to a misalignment between the system's capabilities and the regulator's actual needs. As development progresses, this misalignment becomes increasingly difficult and costly to correct. The project team spends valuable time and resources building features that the regulator doesn't find useful or relevant. The project falls behind schedule and exceeds its budget. Ultimately, the regulator withdraws its support, and the project is abandoned, leaving behind a costly and unusable system.

##### Early Warning Signs
- Regulator attendance at project meetings drops below 50%
- Feedback from the regulator becomes vague and non-committal
- The regulator fails to provide timely responses to project inquiries

##### Tripwires
- Regulator participation in key design workshops <= 25%
- Average regulator response time to critical questions >= 7 days
- Regulator formally requests a reduction in project scope by >= 20%

##### Response Playbook
- Contain: Immediately escalate concerns to senior management and the project sponsor.
- Assess: Conduct a meeting with the regulator to understand the reasons for their disengagement and identify potential solutions.
- Respond: Revise the project plan to address the regulator's concerns, potentially including a change in scope or a shift in priorities.


**STOP RULE:** The regulator formally withdraws its support for the project in writing.

---

#### FM2 - The De-Identification Debacle

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project relies on de-identification techniques to protect data privacy. If these techniques prove insufficient, the project will face significant legal and reputational risks. A data breach could expose sensitive information, leading to fines, lawsuits, and a loss of public trust.

Specifically, the project team implements de-identification techniques that are later found to be vulnerable to re-identification attacks. A malicious actor exploits these vulnerabilities to access sensitive data. The regulator is forced to disclose the breach, leading to a public outcry and a loss of confidence in the project. The project is put on hold while the team scrambles to implement more robust security measures. The delay causes the project to exceed its budget and miss its deadlines. Ultimately, the project is scaled back or cancelled altogether.

##### Early Warning Signs
- New re-identification techniques are published in academic literature
- The cost of implementing more robust de-identification techniques exceeds budget
- The performance of AI models degrades significantly after de-identification

##### Tripwires
- Independent security audit reveals a re-identification risk score >= 7 (out of 10)
- Implementation of proposed enhanced de-identification methods increases data processing time by >= 50%
- Model accuracy decreases by >= 10% after de-identification is applied

##### Response Playbook
- Contain: Immediately halt all data processing and analysis activities.
- Assess: Conduct a thorough review of the de-identification techniques and identify vulnerabilities.
- Respond: Implement more robust de-identification techniques, potentially including differential privacy or federated learning.


**STOP RULE:** The project is unable to achieve an acceptable level of data privacy while still allowing for meaningful analysis.

---

#### FM3 - The Regulatory Whirlwind

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes a relatively stable regulatory environment. However, changes in regulations or data privacy laws can disrupt the project and lead to significant delays and cost overruns. A sudden shift in the regulatory landscape can render the project's design obsolete or require costly modifications.

Specifically, a new data privacy law is enacted that requires the project to completely overhaul its data handling procedures. The project team is forced to spend months re-designing the system to comply with the new regulations. The delay causes the project to miss its deadlines and exceed its budget. Stakeholders lose confidence in the project's ability to deliver value, and the project is ultimately cancelled.

##### Early Warning Signs
- New data privacy regulations are proposed or enacted
- The regulator issues new guidance on data handling procedures
- Stakeholders express concerns about the project's compliance with evolving regulations

##### Tripwires
- New data privacy legislation is introduced that directly impacts the project's data handling procedures.
- The regulator issues a formal notice of non-compliance with existing regulations.
- Stakeholder surveys indicate that >= 30% of stakeholders are concerned about the project's compliance with evolving regulations.

##### Response Playbook
- Contain: Immediately assess the impact of the regulatory change on the project.
- Assess: Conduct a legal review to determine the specific requirements of the new regulations.
- Respond: Revise the project plan to address the regulatory change, potentially including a change in scope or a shift in priorities.


**STOP RULE:** The project is unable to comply with new regulations without a fundamental redesign that exceeds the remaining budget or timeline.

---

#### FM4 - The Integration Impasse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes seamless integration with the regulator's existing IT infrastructure. However, if the infrastructure proves incompatible, the project will face significant delays and cost overruns. This can happen due to outdated systems, proprietary software, or a lack of interoperability standards. Without proper integration, the Shared Intelligence Asset may not be able to access the necessary data or communicate effectively with other systems, limiting its functionality and value.

Specifically, the project team discovers that the regulator's data is stored in a legacy system that is incompatible with the Shared Intelligence Asset. The team is forced to develop a custom integration solution, which requires significant time and resources. The project falls behind schedule and exceeds its budget. Ultimately, the integration effort proves too complex and costly, and the project is scaled back or cancelled altogether.

##### Early Warning Signs
- The regulator's IT staff express concerns about the project's integration requirements
- The project team encounters unexpected difficulties in accessing or exchanging data with the regulator's systems
- The cost of integration exceeds initial estimates by more than 20%

##### Tripwires
- Integration testing reveals that data transfer rates are <= 50% of the required minimum.
- The cost of developing custom integration solutions exceeds CHF 200,000.
- The integration effort delays the project timeline by >= 2 months.

##### Response Playbook
- Contain: Immediately halt all integration activities and reassess the integration strategy.
- Assess: Conduct a thorough review of the regulator's IT infrastructure and identify alternative integration options.
- Respond: Revise the project plan to address the integration challenges, potentially including a change in architecture or a shift to a more compatible technology.


**STOP RULE:** The project is unable to achieve a functional level of integration with the regulator's IT infrastructure within the remaining budget and timeline.

---

#### FM5 - The AI Aversion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Stakeholder Engagement Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes that regulatory staff will readily accept and trust the AI models developed for the Shared Intelligence Asset. However, if staff are skeptical or resistant to AI, the project will fail to achieve its intended impact. This can happen due to a lack of understanding of AI, concerns about job security, or a general distrust of technology. Without staff buy-in, the Shared Intelligence Asset may be underutilized or ignored, leading to a waste of resources and a failure to improve regulatory decision-making.

Specifically, the project team deploys the Shared Intelligence Asset, but regulatory staff are reluctant to use it. They don't understand how the AI models work, and they don't trust the system's recommendations. Staff continue to rely on their existing methods, and the Shared Intelligence Asset is largely ignored. The project fails to achieve its intended impact, and stakeholders lose confidence in its value.

##### Early Warning Signs
- Regulatory staff express skepticism or resistance to AI during training sessions
- The utilization rate of the Shared Intelligence Asset is significantly lower than expected
- Feedback from regulatory staff indicates a lack of trust in the system's recommendations

##### Tripwires
- System usage by regulatory staff is <= 20% of projected levels after 3 months of deployment.
- Stakeholder surveys indicate that >= 50% of regulatory staff do not trust the system's recommendations.
- The regulator formally requests a reduction in the system's reliance on AI.

##### Response Playbook
- Contain: Immediately launch a targeted communication and training campaign to address staff concerns and build trust in AI.
- Assess: Conduct a survey to identify the specific reasons for staff skepticism or resistance.
- Respond: Revise the project plan to address staff concerns, potentially including a greater emphasis on human oversight or a shift to more explainable AI models.


**STOP RULE:** The project is unable to achieve an acceptable level of adoption and trust among regulatory staff within the remaining budget and timeline.

---

#### FM6 - The Cloud Cost Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes consistent pricing and service levels from the chosen cloud provider. However, if the provider increases prices or experiences service disruptions, the project will face significant financial and operational challenges. This can happen due to market fluctuations, changes in the provider's business strategy, or unforeseen technical issues. Without a stable and reliable cloud environment, the Shared Intelligence Asset may become too expensive to operate or experience frequent downtime, undermining its value and credibility.

Specifically, the cloud provider announces a significant price increase for the services used by the Shared Intelligence Asset. The project team is forced to cut back on resources or find alternative solutions, which compromises the system's performance and security. The regulator loses confidence in the project's long-term viability, and the project is ultimately cancelled.

##### Early Warning Signs
- The cloud provider announces a price increase for key services
- The cloud provider experiences frequent service disruptions
- The project's cloud costs exceed budget projections by more than 10%

##### Tripwires
- Cloud service costs increase by >= 15% within a 6-month period.
- System uptime falls below 99% for >= 2 consecutive months.
- The cloud provider issues a formal notice of changes to service level agreements that negatively impact the project.

##### Response Playbook
- Contain: Immediately assess the impact of the price increase or service disruption on the project.
- Assess: Conduct a cost-benefit analysis of alternative cloud providers or on-premise solutions.
- Respond: Negotiate with the cloud provider to mitigate the impact of the changes, or migrate the system to a more cost-effective or reliable environment.


**STOP RULE:** The project is unable to maintain an acceptable level of performance and reliability within the remaining budget due to cloud provider issues.

---

#### FM7 - The Black Box Blunder

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Data Science Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes sufficient domain expertise among data scientists. However, a lack of understanding of energy market regulation can lead to flawed model design and validation, resulting in inaccurate or irrelevant outputs. This can happen when data scientists misinterpret regulatory requirements, overlook key market dynamics, or fail to account for industry-specific nuances. Without proper domain knowledge, the AI models may generate recommendations that are technically sound but practically useless or even harmful.

Specifically, the data scientists, lacking sufficient understanding of energy market manipulation tactics, develop an AI model that fails to detect subtle forms of market abuse. The model generates false negatives, allowing market manipulators to exploit loopholes and harm consumers. The regulator, relying on the flawed model, fails to take appropriate action, leading to significant financial losses and reputational damage.

##### Early Warning Signs
- Data scientists struggle to understand regulatory documents or industry reports
- AI models generate outputs that contradict expert opinions or historical data
- The project team lacks a clear understanding of the regulator's decision-making processes

##### Tripwires
- Model validation reveals a false negative rate for market manipulation detection >= 10%.
- Expert review identifies >= 3 significant flaws in the model's design or assumptions.
- Data scientists require >= 2 weeks to understand and address a regulatory change.

##### Response Playbook
- Contain: Immediately halt deployment of the flawed AI model and conduct a thorough review of its design and validation.
- Assess: Engage domain experts to identify the specific areas where the data scientists lack knowledge and understanding.
- Respond: Provide targeted training to the data scientists on energy market regulation, or recruit additional domain experts to the project team.


**STOP RULE:** The project is unable to develop AI models that meet the required level of accuracy and relevance due to a lack of domain expertise.

---

#### FM8 - The Open-Source Orphan

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project relies on open-source AI libraries and tools. However, if these tools become unmaintained or unsupported, the project will face significant security and stability risks. This can happen when developers abandon projects, communities dissolve, or licensing issues arise. Without active maintenance, the open-source tools may become vulnerable to security exploits or incompatible with other systems, leading to system failures and data breaches.

Specifically, a critical security vulnerability is discovered in a key open-source AI library used by the Shared Intelligence Asset. However, the library is no longer actively maintained, and no security patch is available. The project team is forced to spend significant time and resources developing a custom patch or migrating to a different library, delaying the project timeline and increasing costs. The vulnerability is exploited by a malicious actor, leading to a data breach and significant reputational damage.

##### Early Warning Signs
- The frequency of updates to key open-source libraries decreases significantly
- The maintainers of key open-source libraries become unresponsive to bug reports or security vulnerabilities
- Alternative open-source libraries or tools emerge with stronger community support

##### Tripwires
- The last update to a key open-source library was >= 6 months ago.
- The maintainers of a key open-source library fail to respond to a critical security vulnerability report within 72 hours.
- A security audit reveals that the project is using an open-source library with known vulnerabilities.

##### Response Playbook
- Contain: Immediately isolate the vulnerable open-source library and implement temporary security measures.
- Assess: Conduct a thorough assessment of the impact of the vulnerability on the project and identify alternative libraries or tools.
- Respond: Develop a custom security patch for the vulnerable library, or migrate the project to a different library with stronger security and support.


**STOP RULE:** The project is unable to maintain a secure and stable system due to the lack of support for key open-source libraries or tools.

---

#### FM9 - The Data Drought

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Stakeholder Engagement Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes that energy companies will be willing to share their data. However, if companies are reluctant to share data due to concerns about transparency or competitive advantage, the project will face a severe data shortage. This can happen when companies fear that increased transparency will expose their business practices to scrutiny or that sharing data will give their competitors an advantage. Without sufficient data, the AI models will be less accurate and effective, limiting the project's value and impact.

Specifically, the project team approaches several key energy companies to request data sharing agreements. However, the companies are hesitant to share their data, citing concerns about confidentiality and competitive advantage. The project team is unable to obtain sufficient data to train the AI models effectively. The models generate inaccurate and unreliable recommendations, and the project fails to achieve its intended impact.

##### Early Warning Signs
- Energy companies express reluctance to sign data sharing agreements
- The project team struggles to obtain sufficient data to train the AI models
- The quality and completeness of the available data are significantly lower than expected

##### Tripwires
- The project team fails to secure data sharing agreements with >= 3 key energy companies.
- The available data covers <= 50% of the relevant energy market transactions.
- The accuracy of the AI models is significantly lower than expected due to data limitations.

##### Response Playbook
- Contain: Immediately reassess the data acquisition strategy and identify alternative data sources.
- Assess: Conduct a survey to understand the specific concerns of energy companies regarding data sharing.
- Respond: Offer incentives to energy companies to share data, such as guarantees of confidentiality or access to valuable insights from the Shared Intelligence Asset.


**STOP RULE:** The project is unable to obtain sufficient data to develop AI models that meet the required level of accuracy and relevance.
