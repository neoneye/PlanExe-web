### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee, based on the defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Defined responsibilities and membership of Project Steering Committee

### 2. Circulate Draft SteerCo ToR v0.1 for review by Senior Regulator Representative, Chief Technology Officer (or delegate), Chief Legal Officer (or delegate), and Independent External Advisor (Energy Market Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Regulator Representative formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Regulator Representative

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager coordinates with the Senior Regulator Representative, Chief Technology Officer (or delegate), Chief Legal Officer (or delegate), and Independent External Advisor (Energy Market Expert) to confirm their participation and availability.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Email

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager defines roles and responsibilities for the Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start

### 9. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 10. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Setup

**Dependencies:**

- Core Project Team Communication Protocols Document

### 11. Project Manager develops detailed project plans and schedules for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Detailed Project Plans and Schedules

**Dependencies:**

- Project Management Tools and Systems Setup

### 12. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Detailed Project Plans and Schedules

### 13. Hold the initial Core Project Team kick-off meeting to review project plans, communication protocols, and initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 14. Project Manager defines the scope of technical expertise required for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope of Expertise Document

**Dependencies:**

- Meeting Minutes with Action Items

### 15. Project Manager establishes communication channels between the Core Project Team and the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Channels Document

**Dependencies:**

- Technical Advisory Group Scope of Expertise Document

### 16. Project Manager develops technical review processes and standards for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Technical Advisory Group Review Processes and Standards Document

**Dependencies:**

- Technical Advisory Group Communication Channels Document

### 17. Project Manager identifies key technical risks and mitigation strategies for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Technical Advisory Group Risk Assessment and Mitigation Strategies Document

**Dependencies:**

- Technical Advisory Group Review Processes and Standards Document

### 18. Project Manager identifies and invites Senior Data Scientist (Independent), Senior Security Architect (Independent), and AI Ethics Expert (Independent) to join the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Technical Advisory Group Membership Invitations

**Dependencies:**

- Technical Advisory Group Risk Assessment and Mitigation Strategies Document

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Membership Invitations

### 20. Hold the initial Technical Advisory Group kick-off meeting to review the project plan, technical risks, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 21. Chief Legal Officer (or delegate) drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee, based on the defined responsibilities and membership.

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Defined responsibilities and membership of Ethics & Compliance Committee

### 22. Circulate Draft Ethics & Compliance Committee ToR v0.1 for review by Data Protection Officer (DPO), Ethics Expert (Independent), and Representative from Civil Society Organization (Independent).

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 23. Chief Legal Officer (or delegate) incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference (ToR).

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Chief Legal Officer (or delegate) formally appoints the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 25. Chief Legal Officer (or delegate) coordinates with the Data Protection Officer (DPO), Ethics Expert (Independent), and Representative from Civil Society Organization (Independent) to confirm their participation and availability.

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Appointment Confirmation Email

### 26. Chief Legal Officer (or delegate) schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Chief Legal Officer (or delegate)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 27. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, governance structure, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 28. Project Manager develops a stakeholder engagement plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan

**Dependencies:**

- Meeting Minutes with Action Items

### 29. Project Manager establishes communication channels with stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Communication Channels Document

**Dependencies:**

- Stakeholder Engagement Plan

### 30. Project Manager defines roles and responsibilities for stakeholder engagement within the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Roles and Responsibilities Document

**Dependencies:**

- Stakeholder Engagement Group Communication Channels Document

### 31. Project Manager identifies and invites Communications Manager, Representative from Consumer Advocacy Group (Independent), Representative from Energy Company (Independent), and Representative from Environmental Organization (Independent) to join the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Membership Invitations

**Dependencies:**

- Stakeholder Engagement Group Roles and Responsibilities Document

### 32. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Stakeholder Engagement Group Membership Invitations

### 33. Hold the initial Stakeholder Engagement Group kick-off meeting to review the project plan, stakeholder engagement plan, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda