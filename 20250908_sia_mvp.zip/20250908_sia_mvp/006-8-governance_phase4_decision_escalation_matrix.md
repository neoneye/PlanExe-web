**Budget Request Exceeding Core Project Team Authority (CHF 50,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the financial authority delegated to the Core Project Team and requires strategic oversight.
Negative Consequences: Potential budget overruns, scope creep, and misalignment with strategic objectives.

**Critical Risk Materialization Requiring Significant Resource Allocation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Materialization of a critical risk (e.g., regulatory change, security breach) demands immediate attention and potentially significant resource reallocation, impacting project scope, timeline, or budget.
Negative Consequences: Project failure, legal penalties, reputational damage, and financial losses.

**Technical Advisory Group Deadlock on Key Technical Design Decision**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendations and Final Decision
Rationale: Disagreement among technical experts on a critical design aspect (e.g., AI model selection, security architecture) necessitates resolution at a higher level to ensure technical feasibility and alignment with project goals.
Negative Consequences: Suboptimal technical design, increased security vulnerabilities, and reduced system performance.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Regulator's Executive Leadership Team
Rationale: Allegations of ethical misconduct or non-compliance with data privacy regulations (FADP, StromVG) require independent investigation and appropriate corrective action to maintain public trust and avoid legal penalties.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and project termination.

**Unresolved Stakeholder Concern Impeding Project Progress**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Group Recommendations and Resolution Plan
Rationale: Significant stakeholder opposition or concerns that cannot be resolved by the Stakeholder Engagement Group may jeopardize project adoption and require strategic intervention.
Negative Consequences: Reduced adoption, public protests, legal challenges, and project delays.

**Proposed Major Scope Change (e.g., Adding a New Intervention Type)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Any significant change to the project's scope impacts resources, timelines, and strategic alignment, requiring approval from the steering committee.
Negative Consequences: Budget overrun, project delays, and misalignment with strategic objectives.