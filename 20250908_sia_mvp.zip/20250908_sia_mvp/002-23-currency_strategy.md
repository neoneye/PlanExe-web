This plan involves money.

## Currencies

- **CHF:** The project budget is defined in Swiss Francs, and the project is located in Switzerland.

**Primary currency:** CHF

**Currency strategy:** The Swiss Franc will be used for all transactions. No additional international risk management is needed.