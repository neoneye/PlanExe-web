### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides strategic oversight and direction for the entire ILRS project, given its scale, complexity, international nature, and high financial investment. Ensures alignment with strategic goals of participating nations and manages strategic risks.

**Responsibilities:**

- Approve overall project strategy and objectives.
- Approve major project milestones and stage-gate reviews.
- Approve annual budgets exceeding $50 million USD.
- Oversee strategic risk management and mitigation.
- Resolve high-level conflicts and disputes.
- Approve major changes to project scope or direction.
- Monitor overall project performance against strategic objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint Chair and Vice-Chair.
- Establish communication protocols.
- Define escalation paths.
- Approve initial project budget and resource allocation.

**Membership:**

- Senior representatives from Beijing governance (e.g., China National Space Administration)
- Senior representatives from Roscosmos
- Representatives from key participating nations (BRICS+)
- Independent expert in international space law (external)
- Independent expert in large-scale project management (external)

**Decision Rights:** Strategic decisions related to project scope, budget (above $50 million USD), timeline, and strategic risks. Final authority on project direction.

**Decision Mechanism:** Decisions made by consensus whenever possible. In cases where consensus cannot be reached, a majority vote (at least 75%) is required. The Chair has the tie-breaking vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance and budget status.
- Discussion of strategic risks and mitigation plans.
- Approval of major change requests.
- Updates from the Project Management Office (PMO).
- Reports from Specialized Advisory Groups (e.g., Technical Advisory Group, Ethics & Compliance Committee).

**Escalation Path:** Escalate to the highest levels of the Chinese and Russian space agencies (e.g., Heads of CNSA and Roscosmos) for unresolved strategic issues or conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Essential for managing the day-to-day execution of the ILRS project, ensuring adherence to timelines, budgets, and quality standards. Provides centralized coordination and support for all project activities.

**Responsibilities:**

- Develop and maintain the project management plan.
- Manage project budgets and track expenditures (below $50 million USD).
- Monitor project progress and identify potential delays or issues.
- Coordinate communication between project teams and stakeholders.
- Manage project risks and implement mitigation plans.
- Ensure adherence to project standards and procedures.
- Prepare regular project status reports for the Project Steering Committee.
- Manage the project's document control system.

**Initial Setup Actions:**

- Establish project management methodologies and tools.
- Develop project communication plan.
- Recruit and train project management staff.
- Set up project reporting systems.
- Define roles and responsibilities within the PMO.

**Membership:**

- Project Director
- Project Managers (for each major workstream: e.g., Construction, ISRU, Reactor)
- Project Controller
- Risk Manager
- Communications Manager
- Document Control Specialist

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Director, in consultation with the relevant Project Managers. Conflicts are resolved through discussion and negotiation. If unresolved, escalate to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Approval of change requests (below strategic thresholds).
- Review of budget status and expenditures.
- Coordination of activities between project teams.
- Action item tracking.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic decisions.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Provides expert technical advice and assurance on the complex technologies involved in the ILRS project, including autonomous construction, ISRU, and the modular surface fission reactor. Mitigates technical risks and ensures the feasibility and safety of the project.

**Responsibilities:**

- Review and assess the technical feasibility of proposed technologies.
- Provide expert advice on technical challenges and potential solutions.
- Evaluate the safety and reliability of technical systems.
- Monitor technology development and integration progress.
- Identify potential technical risks and recommend mitigation strategies.
- Ensure compliance with relevant technical standards and regulations.
- Advise on technology selection and procurement decisions.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Recruit and appoint technical experts.
- Establish communication protocols with the PMO.
- Develop technical review processes.
- Define criteria for technology assessment.

**Membership:**

- Experts in autonomous construction technology
- Experts in in-situ resource utilization (ISRU)
- Experts in modular surface fission reactors
- Experts in lunar environment and space systems
- Independent expert in space systems engineering (external)
- Independent expert in nuclear safety (external)

**Decision Rights:** Provides recommendations and assessments on technical matters. Does not have direct decision-making authority but its advice is highly influential.

**Decision Mechanism:** Decisions made by consensus among the technical experts. In cases where consensus cannot be reached, the Chair of the TAG will make the final recommendation, based on the weight of evidence and expert opinion.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of technology development progress.
- Discussion of technical challenges and potential solutions.
- Assessment of technology readiness levels (TRLs).
- Evaluation of safety and reliability data.
- Review of technical risk assessments.
- Updates from the PMO on technology integration activities.

**Escalation Path:** Escalate technical issues to the Project Steering Committee if they have strategic implications or cannot be resolved within the TAG.
### 4. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations and standards, including international space law, environmental regulations, and ethical guidelines for research and collaboration. Addresses risks related to corruption, misuse of funds, and non-compliance.

**Responsibilities:**

- Develop and maintain a code of ethics for the ILRS project.
- Ensure compliance with all relevant international and national regulations.
- Investigate allegations of ethical violations or non-compliance.
- Provide guidance on ethical issues related to research and collaboration.
- Oversee the project's whistleblower mechanism.
- Monitor compliance with data protection regulations (e.g., GDPR).
- Ensure adherence to the non-weaponization clause.
- Review and approve all contracts and agreements to ensure ethical and legal compliance.

**Initial Setup Actions:**

- Develop a code of ethics for the ILRS project.
- Establish compliance procedures and protocols.
- Set up a whistleblower mechanism.
- Recruit and appoint committee members.
- Define reporting lines and escalation paths.

**Membership:**

- Legal counsel (specializing in international space law)
- Ethics officer
- Compliance officer
- Data protection officer
- Representative from a participating nation's ethics board
- Independent expert in ethics and compliance (external)

**Decision Rights:** Investigates ethical violations and non-compliance issues. Recommends corrective actions and sanctions. Has the authority to halt project activities if there is a serious ethical or compliance breach.

**Decision Mechanism:** Decisions made by a majority vote of the committee members. The Chair has the tie-breaking vote. All decisions are documented and reported to the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance reports.
- Investigation of alleged ethical violations.
- Discussion of ethical issues related to research and collaboration.
- Review of contracts and agreements.
- Updates on relevant regulations and standards.
- Review of whistleblower reports.

**Escalation Path:** Escalate serious ethical or compliance breaches to the Project Steering Committee and, if necessary, to the relevant national authorities or international organizations.