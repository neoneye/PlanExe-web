### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 5. Circulate Draft PSC ToR for review by senior representatives from Beijing governance and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PSC ToR

**Dependencies:**

- Draft PSC ToR v0.1

### 6. Circulate Draft PMO ToR for review by senior representatives from Beijing governance and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 7. Circulate Draft TAG ToR for review by senior representatives from Beijing governance and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1

### 8. Circulate Draft ECC ToR for review by senior representatives from Beijing governance and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1

### 9. Project Manager finalizes PSC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary on PSC ToR

### 10. Project Manager finalizes PMO ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 11. Project Manager finalizes TAG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 12. Project Manager finalizes ECC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 13. Senior representatives from Beijing governance and Roscosmos jointly appoint the Chair and Vice-Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Public Announcement

**Dependencies:**

- Final PSC ToR v1.0

### 14. Project Steering Committee (PSC) Chair, in consultation with senior representatives from Beijing governance and Roscosmos, approves the membership of the Project Steering Committee (PSC).

**Responsible Body/Role:** PSC Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PSC Membership List
- Appointment Confirmation Letters

**Dependencies:**

- Appointment Confirmation Email (PSC Chair)
- Final PSC ToR v1.0

### 15. Project Steering Committee (PSC) holds its initial kick-off meeting.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Communication Protocols Defined
- Escalation Paths Defined
- Initial Project Budget and Resource Allocation Approved

**Dependencies:**

- PSC Membership List
- Final PSC ToR v1.0

### 16. Project Director is appointed by the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email (Project Director)
- Public Announcement

**Dependencies:**

- Meeting Minutes with Action Items (PSC Kick-off)

### 17. Project Director, in consultation with the Project Steering Committee (PSC), recruits and appoints the Project Managers, Project Controller, Risk Manager, Communications Manager, and Document Control Specialist for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- PMO Staffing List
- Appointment Confirmation Letters

**Dependencies:**

- Appointment Confirmation Email (Project Director)
- Final PMO ToR v1.0

### 18. Project Management Office (PMO) holds its initial kick-off meeting.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Project Management Methodologies and Tools Established
- Project Communication Plan Developed
- Project Reporting Systems Set Up
- Roles and Responsibilities Defined within the PMO

**Dependencies:**

- PMO Staffing List
- Final PMO ToR v1.0

### 19. Project Steering Committee (PSC) approves the membership of the Technical Advisory Group (TAG), based on recommendations from the Project Director and considering expertise in autonomous construction, ISRU, modular reactors, lunar environment, and space systems.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- TAG Membership List
- Appointment Confirmation Letters

**Dependencies:**

- Meeting Minutes with Action Items (PSC Kick-off)
- Final TAG ToR v1.0

### 20. Technical Advisory Group (TAG) holds its initial kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Scope of Technical Expertise Defined
- Communication Protocols with the PMO Established
- Technical Review Processes Developed
- Criteria for Technology Assessment Defined

**Dependencies:**

- TAG Membership List
- Final TAG ToR v1.0

### 21. Project Steering Committee (PSC) approves the membership of the Ethics & Compliance Committee (ECC), based on recommendations from the Project Director and considering expertise in international space law, ethics, compliance, and data protection.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- ECC Membership List
- Appointment Confirmation Letters

**Dependencies:**

- Meeting Minutes with Action Items (PSC Kick-off)
- Final ECC ToR v1.0

### 22. Ethics & Compliance Committee (ECC) holds its initial kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Code of Ethics for the ILRS Project Developed
- Compliance Procedures and Protocols Established
- Whistleblower Mechanism Set Up
- Reporting Lines and Escalation Paths Defined

**Dependencies:**

- ECC Membership List
- Final ECC ToR v1.0