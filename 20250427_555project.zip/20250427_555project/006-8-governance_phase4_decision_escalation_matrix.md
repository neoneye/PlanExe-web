**Budget Request Exceeding PMO Authority ($50 million USD)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote (at least 75% majority)
Rationale: Exceeds the PMO's financial authority as defined in its responsibilities. Requires strategic oversight and approval due to significant financial impact.
Negative Consequences: Potential budget overruns, delays in project milestones, and misalignment with strategic objectives.

**Critical Technical Risk Materialization (e.g., Reactor Safety)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review by PSC with input from Technical Advisory Group, followed by Steering Committee Vote.
Rationale: Technical risks with strategic implications require higher-level review and decision-making to ensure project feasibility and safety.
Negative Consequences: Project delays, safety hazards, environmental damage, and reputational damage.

**PMO Deadlock on Vendor Selection (Strategic Technology)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Presentation of options by PMO, review by PSC, and final decision by Steering Committee Vote.
Rationale: Disagreements within the PMO on critical vendor selection require resolution at a higher level to ensure alignment with project goals and strategic partnerships.
Negative Consequences: Delays in technology acquisition, suboptimal vendor selection, and potential conflicts of interest.

**Proposed Major Scope Change (e.g., Adding a New Research Module)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Detailed proposal review by PMO and TAG, presentation to PSC, and approval by Steering Committee Vote.
Rationale: Significant changes to the project scope require strategic review and approval to assess impact on budget, timeline, and resources.
Negative Consequences: Budget overruns, project delays, resource constraints, and misalignment with strategic objectives.

**Reported Ethical Concern (e.g., Conflict of Interest, Data Breach)**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Investigation by ECC, recommendation of corrective actions, and reporting to the Project Steering Committee.
Rationale: Ethical violations require independent review and action to ensure compliance with regulations and maintain project integrity.
Negative Consequences: Legal penalties, reputational damage, loss of stakeholder trust, and project disruption.

**Unresolved Technical Issue within Technical Advisory Group (TAG)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Presentation of the issue and differing opinions by the TAG Chair to the PSC, followed by discussion and decision by Steering Committee Vote.
Rationale: Technical disagreements with strategic implications require resolution at a higher level to ensure project feasibility and safety.
Negative Consequences: Project delays, safety hazards, technical failures, and increased costs.