
## Audit - Corruption Risks

- Bribery of officials in participating nations to secure favorable regulatory approvals or circumvent environmental impact assessments.
- Nepotism or favoritism in the selection of institutions or scientists, compromising merit-based selection processes.
- Conflicts of interest involving project personnel who may have financial ties to suppliers or contractors.
- Kickbacks from contractors in exchange for inflated contracts or preferential treatment in the bidding process.
- Misuse of confidential project information for personal gain, such as insider trading related to resource discoveries or technology breakthroughs.

## Audit - Misallocation Risks

- Misuse of Chinese central allocations or Belt-and-Road aerospace credits for purposes unrelated to the ILRS project.
- Double spending on research or development activities already funded by other international space agencies.
- Inefficient allocation of resources due to poor project management or lack of coordination between participating institutions.
- Unauthorized use of project assets, such as lunar landers or construction robots, for private ventures or non-project-related activities.
- Misreporting of project progress or results to secure continued funding or attract new participants, leading to unrealistic expectations and potential financial losses.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, including expense reports, procurement contracts, and fund transfers, with a focus on identifying irregularities or unauthorized expenditures. Responsibility: Internal Audit Team.
- Perform annual external audits of the project's financial statements and compliance with international regulations, conducted by an independent auditing firm. Responsibility: External Audit Firm.
- Implement a contract review process with multiple levels of approval for all contracts exceeding a specified threshold (e.g., $1 million USD), ensuring transparency and preventing potential conflicts of interest. Responsibility: Legal and Procurement Departments.
- Establish a detailed expense workflow with clear guidelines for allowable expenses, required documentation, and approval processes, to prevent misuse of project funds. Responsibility: Finance Department.
- Conduct regular compliance checks to ensure adherence to international safety and environmental regulations, nuclear safety standards, and space exploration treaties. Responsibility: Compliance Officer.

## Audit - Transparency Measures

- Develop a public project progress dashboard displaying key milestones, budget expenditures, and risk assessments, updated monthly. Responsibility: Project Management Office.
- Publish minutes of joint steering committee meetings (Beijing, Roscosmos) and advisory board meetings on a publicly accessible website. Responsibility: Project Secretariat.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with protection for whistleblowers. Responsibility: Ethics Committee.
- Provide public access to relevant project policies, reports, and environmental impact assessments on a dedicated project website. Responsibility: Communications Department.
- Document and publish the selection criteria for major decisions, such as vendor selection and technology choices, to ensure fairness and transparency in the decision-making process. Responsibility: Project Management Office.