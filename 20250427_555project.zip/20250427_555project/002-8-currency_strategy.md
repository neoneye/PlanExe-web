This plan involves money.

## Currencies

- **CNY:** Chinese central allocations will be a major funding source.
- **RUB:** Roscosmos launch barter and other Russian contributions will involve RUB.
- **USD:** International transactions, cost-sharing from participant nations, and potential Western entity involvement may require USD.
- **EUR:** Neutral European partners may contribute funds or resources denominated in EUR.
- **BRL:** Brazil is part of BRICS and may contribute funds or resources denominated in BRL.
- **INR:** India is part of BRICS and may contribute funds or resources denominated in INR.
- **ZAR:** South Africa is part of BRICS and may contribute funds or resources denominated in ZAR.

**Primary currency:** USD

**Currency strategy:** Given the international scope and involvement of multiple countries, USD is recommended as the primary currency for budgeting and reporting. This mitigates risks associated with exchange rate fluctuations. Local currencies (CNY, RUB, EUR, BRL, INR, ZAR) will be used for in-country transactions. Hedging strategies may be necessary to manage currency risks effectively.