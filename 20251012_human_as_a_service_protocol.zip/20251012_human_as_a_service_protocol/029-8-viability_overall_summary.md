- Status: YELLOW
- Confidence: Low
- Recommendation: GO\_IF\_FP0

## Concerns Affecting Viability
| Pillar | Status | Reasoning Codes |
|--------|--------|-----------------|
| Ecological Integrity | GRAY | Evidence needed: Environmental baseline note \(scope, metrics\) — done when: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign\-off\., Cloud carbon estimate v1 \(regions/services\) — done when: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard\. |
| Human Stability | YELLOW | GOVERNANCE\_WEAK, TRAINING\_GAPS |
| Economic Resilience | YELLOW | CONTINGENCY\_LOW, UNIT\_ECON\_UNKNOWN |

## What Flips to GO
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Data privacy policy v2 published
- GDPR compliance verified
- CCPA compliance verified