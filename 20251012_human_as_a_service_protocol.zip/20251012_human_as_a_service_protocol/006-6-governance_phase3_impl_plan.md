### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Circulate Draft SteerCo ToR for review by nominated members (CTO, CFO, VP of Product, Head of Strategy, Independent External Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 5. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Legal Counsel, Compliance Officer, HR Manager, Independent Ethics Advisor, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft Technical Advisory Group ToR for review by nominated members (Lead Developer, Senior Architect, Cybersecurity Expert, Independent Technical Advisor, Operations Lead).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 8. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 9. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. Senior Management formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Senior Management formally appoints the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 12. Senior Management formally appoints the Technical Advisory Group Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 13. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 14. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 15. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 16. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 17. Hold initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 18. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 19. Establish project management methodologies and standards for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Methodology Document

**Dependencies:**

- Project Plan Approved

### 20. Develop a project communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Communication Plan

**Dependencies:**

- Project Management Methodology Document

### 21. Set up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Project Communication Plan

### 22. Define roles and responsibilities for project team members within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Tracking System

### 23. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Roles and Responsibilities Matrix