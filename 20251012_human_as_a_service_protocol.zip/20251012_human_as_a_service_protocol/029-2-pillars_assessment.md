<div class="pillars-grid">
  <!-- Green Pillar Card -->
  <div class="pillar-card pillar-card--green pillar-card--count-zero" role="status" aria-labelledby="pillars-green-title">
    <div class="pillar-card__header">
      <div class="pillar-card__left">
        <span class="pillar-card__icon" aria-hidden="true">✔</span>
        <span id="pillars-green-title" class="pillar-card__status-name">GREEN</span>
      </div>
      <span class="pillar-card__count">0 pillars</span>
    </div>
    <div class="pillar-card__body">
      <p>Good to go. You have solid evidence and no open critical unknowns. Proceed. Any remaining tasks are minor polish.</p>
    </div>
  </div>

  <!-- Yellow Pillar Card -->
  <div class="pillar-card pillar-card--yellow " role="status" aria-labelledby="pillars-yellow-title">
    <div class="pillar-card__header">
      <div class="pillar-card__left">
        <span class="pillar-card__icon" aria-hidden="true">!</span>
        <span id="pillars-yellow-title" class="pillar-card__status-name">YELLOW</span>
      </div>
      <span class="pillar-card__count">3 pillars</span>
    </div>
    <div class="pillar-card__body">
      <p>Viable, but risks/unknowns exist. There’s promise, but you’re missing proof on key points or see non-fatal risks. Proceed with caution and a focused checklist.</p>
    </div>
  </div>

  <!-- Red Pillar Card -->
  <div class="pillar-card pillar-card--red pillar-card--count-zero" role="status" aria-labelledby="pillars-red-title">
    <div class="pillar-card__header">
      <div class="pillar-card__left">
        <span class="pillar-card__icon" aria-hidden="true">✖</span>
        <span id="pillars-red-title" class="pillar-card__status-name">RED</span>
      </div>
      <span class="pillar-card__count">0 pillars</span>
    </div>
    <div class="pillar-card__body">
      <p>Not viable right now. There’s a concrete blocker or negative evidence (legal, technical, economic) that stops execution until fixed. Pause or pivot.</p>
    </div>
  </div>

  <!-- Gray Pillar Card -->
  <div class="pillar-card pillar-card--gray " role="status" aria-labelledby="pillars-gray-title">
    <div class="pillar-card__header">
      <div class="pillar-card__left">
        <span class="pillar-card__icon" aria-hidden="true">?</span>
        <span id="pillars-gray-title" class="pillar-card__status-name">GRAY</span>
      </div>
      <span class="pillar-card__count">1 pillar</span>
    </div>
    <div class="pillar-card__body">
      <p>Unknown / unassessed. You don’t have enough information to judge. Don’t guess—add a “first measurement” task to get out of uncertainty.</p>
    </div>
  </div>
</div>



## Pillar Details
### Legend: How to Read the Scores

The viability of each pillar is rated on a 1–5 scale across three key metrics. Higher scores are better.

| Metric | Strong Negative (1) | Weak Negative (2) | Neutral (3) | Weak Positive (4) | Strong Positive (5) |
|--------|--------------------|-------------------|-------------|-------------------|---------------------|
| **Evidence** | No/contradictory evidence; claims only | Anecdotes/unstable drafts | Inconclusive; limited data | Internal tests/pilot support | Independent, reproducible validation; monitored |
| **Risk** | Severe exposure; blockers/unknowns | Major exposure; mitigations not in place | Moderate; mitigations planned/in progress | Low residual risk; mitigations in place | Minimal residual risk; contingencies tested |
| **Fit** | Conflicts with constraints/strategy | Low alignment; major trade-offs | Mixed/unclear alignment | Good alignment; minor trade-offs | Strong alignment; directly reinforces strategy |

### Pillar 1: Human Stability

**Status**: YELLOW — driven by fit (training gaps).

**Metrics**: evidence=3, risk=3, fit=2

**Issues:**

- GOVERNANCE_WEAK
- TRAINING_GAPS

**Evidence Needed:**

- Advisory board charter v1 (purpose, membership, schedule) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.
- Skills gap analysis v2 (updated with cybersecurity, data privacy, open-source) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.


### Pillar 2: Economic Resilience

**Status**: YELLOW — driven by evidence (unit econ).

**Metrics**: evidence=2, risk=3, fit=3

**Issues:**

- CONTINGENCY_LOW
- UNIT_ECON_UNKNOWN

**Evidence Needed:**

- Financial model v3 (premium features + alternative revenue streams) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.
- Contingency plan v1 (cost-cutting scenarios, phased rollout) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.


### Pillar 3: Ecological Integrity

**Status**: GRAY.

**Metrics**: evidence=—, risk=—, fit=—

**Evidence Needed:**

- Environmental baseline note (scope, metrics) — done when: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign-off.
- Cloud carbon estimate v1 (regions/services) — done when: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard.


### Pillar 4: Rights & Legality

**Status**: YELLOW — driven by evidence (dpia gaps).

**Metrics**: evidence=2, risk=3, fit=3

**Issues:**

- DPIA_GAPS

**Evidence Needed:**

- Data privacy policy v2 (GDPR, CCPA compliance) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.
- Worker classification checklist v2 (AB5 compliance) — done when: artifact is published to the workspace with an owner, acceptance evidence, and review date recorded.

