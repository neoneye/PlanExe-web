### B1: Skills gap analysis incomplete

**Pillar:** HumanStability


**Reason Codes:** TRAINING_GAPS


**Acceptance Tests:**

  - Skills gap analysis v2 published
  - Cybersecurity skills included
  - Data privacy skills included

**Artifacts Required:**

  - Skills\_Gap\_v2\.pdf

**Owner:** HR


**ROM:** LOW cost, 7 days


### B2: Contingency too low

**Pillar:** EconomicResilience


**Reason Codes:** CONTINGENCY_LOW


**Acceptance Tests:**

  - \>=10% contingency approved
  - Monte Carlo risk workbook attached

**Artifacts Required:**

  - Budget\_v2\.pdf
  - Risk\_MC\.xlsx

**Owner:** PMO


**ROM:** LOW cost, 14 days


### B3: Unit economics unproven

**Pillar:** EconomicResilience


**Reason Codes:** UNIT_ECON_UNKNOWN


**Acceptance Tests:**

  - Unit economics model v1 published
  - CAC \< LTV
  - Payback period \< 12 months

**Artifacts Required:**

  - Unit\_Econ\_v1\.xlsx

**Owner:** Finance


**ROM:** MEDIUM cost, 21 days


### B4: Data privacy impact assessment gaps

**Pillar:** Rights_Legality


**Reason Codes:** DPIA_GAPS


**Acceptance Tests:**

  - Data privacy policy v2 published
  - GDPR compliance verified
  - CCPA compliance verified

**Artifacts Required:**

  - Privacy\_Policy\_v2\.pdf

**Owner:** Legal


**ROM:** MEDIUM cost, 28 days

