This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and the primary location is the United States.

**Primary currency:** USD

**Currency strategy:** USD will be used for all budgeting and reporting. No additional international risk management is needed as the project is primarily based in the United States.