## Suggestion 1 - TaskRabbit

TaskRabbit is an online marketplace that connects freelance labor with local demand, allowing customers to find immediate help with everyday tasks, including cleaning, moving, handyman work, and more. Founded in 2008, it operates across major metropolitan areas in the United States, Canada, and the United Kingdom. TaskRabbit's business model relies on a platform fee charged on completed tasks. The company was acquired by IKEA in 2017.

### Success Metrics

Number of registered Taskers (service providers)
Number of active users (customers)
Task completion rate
Customer satisfaction scores
Revenue growth
Geographic expansion

### Risks and Challenges Faced

**Challenge:** Ensuring the quality and reliability of Taskers.
**Mitigation:** Implemented background checks, user reviews, and a rating system to build trust and accountability.
**Challenge:** Managing disputes between Taskers and clients.
**Mitigation:** Established a dispute resolution process with mediation and arbitration options.
**Challenge:** Scaling the platform to handle increasing demand.
**Mitigation:** Invested in technology infrastructure and customer support to maintain service quality during periods of rapid growth.
**Challenge:** Regulatory compliance, particularly regarding worker classification (employee vs. independent contractor).
**Mitigation:** Engaged legal counsel to ensure compliance with labor laws and implemented clear contractual agreements with Taskers.

### Where to Find More Information

TaskRabbit Official Website: [https://www.taskrabbit.com/](https://www.taskrabbit.com/)
IKEA Acquires TaskRabbit: [https://news.clearcompany.com/ikea-acquires-taskrabbit/](https://news.clearcompany.com/ikea-acquires-taskrabbit/)

### Actionable Steps

**Role:** Contact TaskRabbit's customer support or business development team.
**Contact Method:** Through the TaskRabbit website's contact form or LinkedIn.
**Information to Request:** Inquire about their experiences with scaling a service provider network, managing quality control, and navigating regulatory challenges.

### Rationale for Suggestion

TaskRabbit is a relevant example because it operates in the same domain of connecting individuals with physical labor opportunities. It has faced and overcome challenges related to quality control, dispute resolution, and regulatory compliance, which are directly applicable to the user's HaaS pilot project. TaskRabbit's experience in scaling a platform for on-demand services can provide valuable insights into the operational aspects of the project. While TaskRabbit is a closed platform, understanding its operational model and challenges can inform the development of an open protocol.
## Suggestion 2 - Upwork

Upwork is a global freelancing platform where businesses and independent professionals connect and collaborate remotely. Founded in 2015 (following the merger of Elance and oDesk), Upwork provides a marketplace for a wide range of services, including writing, web development, design, and administrative support. Upwork's business model relies on charging a percentage of freelancers' earnings and offering premium services to businesses.

### Success Metrics

Number of registered freelancers
Number of active clients
Total value of contracts awarded through the platform
Client satisfaction scores
Freelancer earnings
Geographic reach

### Risks and Challenges Faced

**Challenge:** Maintaining the quality of freelancers on the platform.
**Mitigation:** Implemented skill tests, client reviews, and a rating system to assess freelancer competence and performance.
**Challenge:** Ensuring fair pricing and preventing undercutting.
**Mitigation:** Provided data on market rates for different skills and services, and implemented mechanisms to prevent excessively low bids.
**Challenge:** Managing disputes between clients and freelancers.
**Mitigation:** Established a dispute resolution process with mediation and arbitration options.
**Challenge:** Competing with other freelancing platforms.
**Mitigation:** Focused on building a strong brand, offering a wide range of services, and providing a user-friendly platform.

### Where to Find More Information

Upwork Official Website: [https://www.upwork.com/](https://www.upwork.com/)
Upwork Investor Relations: [https://investors.upwork.com/](https://investors.upwork.com/)

### Actionable Steps

**Role:** Contact Upwork's business development or partnership team.
**Contact Method:** Through the Upwork website's contact form or LinkedIn.
**Information to Request:** Inquire about their experiences with building a global freelancing platform, managing quality control, and fostering trust between clients and freelancers.

### Rationale for Suggestion

Upwork is a relevant example because it operates a large-scale marketplace for freelance labor. While Upwork primarily focuses on digital services, its experience in managing a diverse pool of freelancers, ensuring quality, and resolving disputes can provide valuable insights for the user's HaaS pilot project. Upwork's platform also offers lessons in building a reputation system and incentivizing high-quality work. Although Upwork is not focused on physical labor or an open protocol, its operational challenges and solutions are broadly applicable to the user's project.
## Suggestion 3 - HomeAdvisor (Now Angi)

HomeAdvisor, now known as Angi, is a digital marketplace connecting homeowners with pre-screened home service professionals. Founded in 1998, it provides tools and resources for homeowners to find, compare, and book local service providers for a wide range of home improvement, maintenance, and repair projects. Angi's business model relies on lead generation fees charged to service providers and subscription fees for enhanced profiles and services.

### Success Metrics

Number of registered service professionals
Number of active homeowners
Number of service requests submitted through the platform
Customer satisfaction scores
Revenue growth
Market share

### Risks and Challenges Faced

**Challenge:** Ensuring the quality and reliability of service professionals.
**Mitigation:** Implemented background checks, license verification, and a rating system to build trust and accountability.
**Challenge:** Managing disputes between homeowners and service professionals.
**Mitigation:** Established a dispute resolution process with mediation and arbitration options.
**Challenge:** Competing with other home service marketplaces.
**Mitigation:** Focused on building a strong brand, offering a wide range of services, and providing a user-friendly platform.
**Challenge:** Adapting to changing consumer preferences and technological advancements.
**Mitigation:** Invested in mobile apps, online booking tools, and other technologies to enhance the user experience.

### Where to Find More Information

Angi Official Website: [https://www.angi.com/](https://www.angi.com/)
Angi Investor Relations: [https://ir.angi.com/](https://ir.angi.com/)

### Actionable Steps

**Role:** Contact Angi's business development or partnership team.
**Contact Method:** Through the Angi website's contact form or LinkedIn.
**Information to Request:** Inquire about their experiences with screening and verifying service professionals, managing customer expectations, and resolving disputes in the home services market.

### Rationale for Suggestion

Angi is a relevant example because it focuses specifically on connecting users with professionals for physical labor and home services. Its experience in screening and verifying service providers, managing customer expectations, and resolving disputes is directly applicable to the user's HaaS pilot project. Angi's platform also offers lessons in building trust and accountability in a marketplace for physical services. While Angi is not an open protocol, its operational model and challenges can inform the development of the user's project, particularly in the areas of quality control and dispute resolution.

## Summary

Based on the provided documents, the user is planning a pilot project for a Human-as-a-Service (HaaS) platform in Silicon Valley. The project aims to create an open protocol for physical labor service providers, ensuring interoperability and preventing vendor lock-in. The project has a budget of $40 million and a 24-month timeframe. The strategic decisions emphasize a balanced approach, focusing on hybrid verification, reputation-based rewards, selective partnerships, and a phased rollout of services. The project prioritizes low risk and real-world functionality. Here are some reference projects that could provide valuable insights.