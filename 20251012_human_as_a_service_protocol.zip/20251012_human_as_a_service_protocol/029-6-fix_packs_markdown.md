### FP0: Pre-Commit Gate
- Priority: Immediate
- Blockers:
  - B2
  - B4

### FP1: Address Skills Gap for Human Stability
- Priority: High
- Blockers:
  - B1

### FP2: Validate Unit Economics for Economic Resilience
- Priority: High
- Blockers:
  - B3