This plan involves money.

## Currencies

- **USD:** Originating location of the statue and potential for US-based contracts.
- **EUR:** Destination location and primary currency for expenses in France.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. USD may be used for initial contracts in the US. Exchange rate fluctuations should be monitored and hedging strategies considered.