### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 6. Circulate Draft SteerCo ToR v0.1 for review by nominated members (US National Park Service, French Ministry of Culture, key funding organizations, independent experts, Project Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR v0.1 for review by the Project Manager and potential PMO members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 8. Circulate Draft TAG ToR v0.1 for review by potential TAG members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1
- Identification of potential TAG members

### 9. Circulate Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel and Compliance Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Ethics & Compliance Committee ToR

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 10. Circulate Draft Stakeholder Engagement Group ToR v0.1 for review by Communications Manager and Public Relations Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Stakeholder Engagement Group ToR

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 11. Project Manager finalizes the Project Steering Committee Terms of Reference (ToR v1.0) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 12. Project Manager finalizes the Project Management Office (PMO) Terms of Reference (ToR v1.0) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 13. Project Manager finalizes the Technical Advisory Group Terms of Reference (ToR v1.0) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 14. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference (ToR v1.0) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary on Ethics & Compliance Committee ToR

### 15. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference (ToR v1.0) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary on Stakeholder Engagement Group ToR

### 16. Senior representatives from US National Park Service and French Ministry of Culture formally appoint the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 17. Project Steering Committee Chair, in consultation with Senior representatives from US National Park Service and French Ministry of Culture, confirms the membership of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 18. Project Steering Committee Chair schedules and facilitates the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Agenda
- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed SteerCo Membership List

### 19. Project Manager appoints the Project Controller, Risk Manager, Communications Manager, and representatives from key project teams to form the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed PMO Membership List

**Dependencies:**

- Final PMO ToR v1.0

### 20. Project Manager schedules and facilitates the initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Agenda
- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed PMO Membership List

### 21. Project Manager, in consultation with the Project Steering Committee Chair, appoints the members of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed TAG Membership List

**Dependencies:**

- Final TAG ToR v1.0
- SteerCo Kick-off Meeting Minutes with Action Items

### 22. Project Manager schedules and facilitates the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Agenda
- TAG Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed TAG Membership List

### 23. Project Manager, in consultation with Legal Counsel and Compliance Officer, appoints the members of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 24. Legal Counsel schedules and facilitates the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Agenda
- Ethics & Compliance Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 25. Project Manager, in consultation with Communications Manager and Public Relations Manager, appoints the members of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Stakeholder Engagement Group Membership List

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 26. Communications Manager schedules and facilitates the initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Agenda
- Stakeholder Engagement Group Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Stakeholder Engagement Group Membership List

### 27. The Project Steering Committee reviews and approves the project scope, budget, and timeline.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Approved Project Scope
- Approved Project Budget
- Approved Project Timeline

**Dependencies:**

- SteerCo Kick-off Meeting Minutes with Action Items

### 28. The Project Management Office (PMO) develops and maintains project management plans.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Project Management Plans

**Dependencies:**

- PMO Kick-off Meeting Minutes with Action Items
- Approved Project Scope
- Approved Project Budget
- Approved Project Timeline

### 29. The Technical Advisory Group reviews and approves technical designs and specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Approved Technical Designs and Specifications

**Dependencies:**

- TAG Kick-off Meeting Minutes with Action Items
- Project Management Plans

### 30. The Ethics & Compliance Committee develops and implements an ethics and compliance program.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Ethics and Compliance Program

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Minutes with Action Items

### 31. The Stakeholder Engagement Group develops and implements a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Minutes with Action Items