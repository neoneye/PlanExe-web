**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit defined in PMO's decision rights. Requires strategic review and alignment with overall project budget.
Negative Consequences: Potential budget overrun and impact on project financial viability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a risk with high severity (e.g., statue damage, international relations strain) requires strategic decision-making and resource allocation beyond the PMO's authority.
Negative Consequences: Project delays, increased costs, potential project abandonment, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Mediation and Vote
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates higher-level intervention to ensure project progress.
Negative Consequences: Project delays, potential selection of a suboptimal vendor, and internal team conflict.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope (e.g., altering the modular relocation architecture) require strategic alignment and assessment of impact on budget, timeline, and stakeholder expectations.
Negative Consequences: Project delays, budget overruns, stakeholder dissatisfaction, and potential project failure.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee
Rationale: Allegations of ethical violations (e.g., fraud, corruption) require independent review and potential corrective action to maintain project integrity and reputation.
Negative Consequences: Legal penalties, reputational damage, project delays, and loss of stakeholder trust.

**Technical Design Dispute within Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Dissenting Opinions and Final Decision
Rationale: Lack of consensus within the Technical Advisory Group on a critical technical aspect requires strategic oversight and resolution to ensure project feasibility and safety.
Negative Consequences: Compromised structural integrity, increased technical risks, and potential project delays.