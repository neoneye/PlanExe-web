
## Audit - Corruption Risks

- Bribery of regulatory officials in the US or France to expedite permit approvals or overlook non-compliance issues.
- Kickbacks from contractors or suppliers in exchange for being selected for the project, potentially compromising quality or inflating costs.
- Conflicts of interest involving project team members who have undisclosed financial ties to vendors or subcontractors.
- Misuse of confidential project information for personal gain, such as insider trading based on knowledge of land acquisition or contract awards.
- Nepotism in the hiring of personnel or awarding of contracts, leading to unqualified individuals being placed in critical roles.

## Audit - Misallocation Risks

- Misuse of project funds for personal expenses or unauthorized activities by project managers or team members.
- Double billing or fraudulent invoicing by contractors or suppliers, resulting in inflated project costs.
- Inefficient allocation of resources, such as overspending on certain project phases while underfunding others, leading to delays or quality issues.
- Unauthorized use of project assets, such as equipment or materials, for personal purposes or outside of the project scope.
- Misreporting of project progress or results to conceal delays or cost overruns, leading to inaccurate decision-making and further misallocation of resources.

## Audit - Procedures

- Conduct periodic internal audits of project finances, including expense reports, invoices, and contracts, to detect irregularities or unauthorized spending (quarterly, Internal Audit Department).
- Perform regular compliance checks to ensure adherence to regulatory requirements, safety protocols, and environmental standards (monthly, Compliance Officer).
- Implement a contract review process with pre-defined thresholds for independent legal and financial review of all major contracts (>$100,000, Legal Counsel and CFO).
- Conduct post-project external audit to assess overall project performance, identify lessons learned, and verify compliance with all applicable regulations (post-project, Independent Audit Firm).
- Establish a whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with clear procedures for investigation and resolution (ongoing, Ethics Committee).

## Audit - Transparency Measures

- Establish a public project website with regular updates on project progress, budget expenditures, and key decisions.
- Publish minutes of the US-French steering committee meetings, redacting confidential information as necessary.
- Implement a progress/budget dashboard accessible to stakeholders, providing real-time information on project milestones, costs, and resource utilization.
- Document and publish the selection criteria and rationale for all major vendors and contractors.
- Establish a clear and accessible whistleblower policy, protecting individuals who report suspected wrongdoing.