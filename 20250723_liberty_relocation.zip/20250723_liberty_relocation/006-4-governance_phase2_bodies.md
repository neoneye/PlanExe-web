### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this high-risk, high-complexity, and high-ambition infrastructure project with significant cultural and international implications. Ensures alignment with strategic goals and stakeholder expectations.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$5M EUR or impacting critical path by >1 month).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve key stakeholder engagement strategies.
- Ensure compliance with international relations protocols.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Secretary.
- Establish meeting schedule and communication protocols.
- Review and approve project charter and initial risk assessment.

**Membership:**

- Senior representatives from US National Park Service
- Senior representatives from French Ministry of Culture
- Senior representatives from key funding organizations (government and private)
- Independent expert in international relations
- Independent expert in cultural heritage preservation
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, risk management, and stakeholder engagement. Approval of changes exceeding defined thresholds (>$5M EUR or impacting critical path by >1 month).

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the deciding vote. Issues related to international relations require unanimous agreement between US and French representatives. If unanimous agreement cannot be reached, the issue is escalated to the respective government heads.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of project budget and expenditures.
- Discussion of key risks and mitigation strategies.
- Review of stakeholder engagement activities.
- Approval of change requests exceeding defined thresholds.
- Discussion of strategic issues and challenges.
- Compliance report review.

**Escalation Path:** Issues unresolved at the Steering Committee level are escalated to the respective heads of the US National Park Service and French Ministry of Culture, or to the relevant government ministers for international relations issues.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized project management support, ensures consistent application of project management methodologies, and monitors project performance. Manages day-to-day execution and operational risks.

**Responsibilities:**

- Develop and maintain project management plans.
- Monitor project progress against plan.
- Manage project budget and expenditures (within approved limits).
- Identify and manage project risks and issues (below strategic thresholds).
- Coordinate project activities across different teams.
- Provide project reporting and communication.
- Ensure compliance with project management standards and procedures.
- Manage change requests below strategic thresholds (<$5M EUR and not impacting critical path by >1 month).

**Initial Setup Actions:**

- Establish project management standards and procedures.
- Develop project management templates and tools.
- Recruit and train project management staff.
- Set up project reporting and communication systems.

**Membership:**

- Project Manager
- Project Controller
- Risk Manager
- Communications Manager
- Representatives from key project teams (Engineering, Construction, Logistics, Regulatory)

**Decision Rights:** Operational decisions related to project execution, risk management (below strategic thresholds), and resource allocation (within approved budget). Approval of change requests below defined thresholds (<$5M EUR and not impacting critical path by >1 month).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the PMO team. Issues requiring escalation are referred to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of project budget and expenditures.
- Coordination of project activities.
- Review of change requests.
- Project reporting and communication.

**Escalation Path:** Issues exceeding the PMO's authority are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on engineering, construction, and logistical aspects of the project. Ensures the project adheres to the highest technical standards and mitigates technical risks.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance on engineering, construction, and logistical challenges.
- Assess the structural integrity of the Statue of Liberty.
- Evaluate the feasibility of different relocation methods.
- Identify and mitigate technical risks.
- Ensure compliance with relevant technical standards and regulations.
- Advise on the use of innovative technologies.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Recruit and appoint technical experts.
- Establish communication protocols.
- Review project technical documentation.

**Membership:**

- Structural engineers
- Construction experts
- Logistics specialists
- Material scientists
- Robotics experts
- Independent expert in historical monument preservation

**Decision Rights:** Provides recommendations on technical matters. Final decisions rest with the Project Steering Committee and Project Manager, but TAG recommendations carry significant weight.

**Decision Mechanism:** Decisions made by consensus among the technical experts. Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical challenges and solutions.
- Assessment of structural integrity.
- Evaluation of relocation methods.
- Identification and mitigation of technical risks.
- Review of technical standards and regulations.

**Escalation Path:** Technical issues unresolved by the Technical Advisory Group are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, anti-corruption laws, and environmental regulations. Provides assurance on ethical conduct and regulatory compliance.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with relevant regulations and ethical standards.
- Investigate allegations of fraud, corruption, or ethical violations.
- Provide training on ethics and compliance.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee environmental compliance.
- Review and approve contracts to ensure compliance with ethical and legal requirements.
- Manage the whistleblower mechanism.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a whistleblower mechanism.
- Recruit and appoint committee members.
- Develop a training program on ethics and compliance.

**Membership:**

- Legal Counsel
- Compliance Officer
- Ethics Officer
- Independent expert in ethics and compliance
- Representative from the US National Park Service
- Representative from the French Ministry of Culture

**Decision Rights:** Investigates ethical breaches and compliance violations. Recommends corrective actions to the Project Steering Committee. Has the authority to halt project activities in cases of serious ethical or compliance violations.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Investigation of allegations of fraud, corruption, or ethical violations.
- Review of ethics and compliance training programs.
- Review of contracts and agreements.
- Review of whistleblower reports.

**Escalation Path:** Serious ethical or compliance violations are escalated to the Project Steering Committee and, if necessary, to relevant law enforcement authorities.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the public, government agencies, and NGOs. Ensures stakeholder concerns are addressed and promotes a positive image of the project.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Manage communication with key stakeholders.
- Organize public forums and meetings.
- Address stakeholder concerns and feedback.
- Monitor public opinion and media coverage.
- Promote a positive image of the project.
- Coordinate with the Public Relations Team.
- Manage the project website and social media channels.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Set up a project website and social media channels.

**Membership:**

- Communications Manager
- Public Relations Manager
- Community Liaison Officer
- Representatives from the US National Park Service
- Representatives from the French Ministry of Culture
- Representatives from key NGOs

**Decision Rights:** Manages stakeholder communication and engagement activities. Recommends strategies to address stakeholder concerns to the Project Steering Committee.

**Decision Mechanism:** Decisions made by consensus among the group members. Issues requiring escalation are referred to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Monitoring of public opinion and media coverage.
- Planning of public forums and meetings.
- Review of communication materials.
- Review of project website and social media channels.

**Escalation Path:** Stakeholder issues unresolved by the Stakeholder Engagement Group are escalated to the Project Steering Committee.