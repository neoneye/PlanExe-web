### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, ensuring alignment with project goals and objectives, especially critical given the funding constraints and the need for sustainable solutions.

**Responsibilities:**

- Approve the project plan and budget.
- Provide strategic direction and guidance.
- Monitor project progress against key performance indicators.
- Approve major changes to the project scope or budget (>$50,000 USD).
- Oversee risk management and mitigation strategies.
- Ensure alignment with organizational strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review project plan and risk assessment.

**Membership:**

- Senior Management Representative (Chair)
- Project Director
- Representative from Ghana Ministry of Health
- Representative from a major funding partner (if secured)
- Independent Public Health Expert

**Decision Rights:** Strategic decisions related to project scope, budget (>$50,000 USD), and key performance indicators.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Any decision impacting the project's core goal of reducing malaria cases by 30% requires unanimous agreement.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion of key risks and mitigation strategies.
- Approval of budget revisions or scope changes.
- Strategic updates from the Project Director.
- Review of stakeholder engagement activities.

**Escalation Path:** To the Senior Management Team of the organization.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation and adherence to project timelines, crucial for a project with limited funding and ambitious goals.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and resources.
- Track project progress and report on key performance indicators.
- Coordinate project activities and tasks.
- Manage project risks and issues.
- Ensure project deliverables are completed on time and within budget.
- Manage decisions below the strategic threshold (i.e., <$50,000 USD).

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop project plan and budget.
- Set up project tracking and reporting systems.
- Define roles and responsibilities for project team members.

**Membership:**

- Project Manager (Head of PMO)
- Medical Officer
- Community Outreach Coordinator
- Logistics Coordinator
- Monitoring and Evaluation Specialist

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and task management (decisions <$50,000 USD).

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Conflicts are resolved through discussion and consensus. If consensus cannot be reached, the Project Director makes the final decision.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of upcoming tasks and deadlines.
- Identification and resolution of project issues.
- Review of project budget and expenses.
- Update on project risks and mitigation strategies.

**Escalation Path:** To the Project Director.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with relevant regulations, including GDPR (if applicable due to data collection), Ghanaian laws, and ethical standards, vital for maintaining trust and accountability.

**Responsibilities:**

- Develop and implement a code of ethics for the project.
- Ensure compliance with relevant regulations, including GDPR, Ghanaian laws, and ethical standards.
- Investigate and resolve ethical complaints.
- Provide training on ethical conduct and compliance.
- Oversee the whistleblower mechanism.
- Review and approve project policies and procedures to ensure ethical and compliant practices.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish whistleblower mechanism.

**Membership:**

- Independent Legal Counsel (Chair)
- Senior Management Representative
- Representative from the Ghana Ministry of Health (Compliance Officer)
- Community Representative
- Ethics Officer

**Decision Rights:** Decisions related to ethical conduct, compliance with regulations, and resolution of ethical complaints.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Decisions involving potential legal violations require unanimous agreement.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of ethical complaints and investigations.
- Update on compliance with relevant regulations.
- Discussion of ethical issues and dilemmas.
- Review of project policies and procedures.
- Training on ethical conduct and compliance.

**Escalation Path:** To the Senior Management Team of the organization and, if necessary, to external regulatory bodies.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and collaboration with key stakeholders, including local communities, government agencies, and funding partners, essential for project success and sustainability.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with key stakeholders.
- Address stakeholder concerns and feedback.
- Promote community participation in project activities.
- Build and maintain relationships with government agencies and funding partners.
- Ensure that project activities are culturally sensitive and appropriate.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop stakeholder engagement plan.
- Establish communication channels.
- Schedule initial consultations.

**Membership:**

- Community Outreach Coordinator (Chair)
- Project Director
- Representative from the Ghana Ministry of Health
- Community Representatives (various regions)
- Representative from a major funding partner (if secured)

**Decision Rights:** Decisions related to stakeholder engagement strategies, communication plans, and community participation initiatives.

**Decision Mechanism:** Decisions made by consensus, with the Community Outreach Coordinator facilitating discussions and ensuring that all stakeholders have an opportunity to express their views. If consensus cannot be reached, the Project Director makes the final decision.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Planning for upcoming community consultations.
- Updates on project progress and impact.
- Review of communication materials.

**Escalation Path:** To the Project Director and, if necessary, to the Project Steering Committee.