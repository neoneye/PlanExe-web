**Budget Request Exceeding PMO Authority ($50,000 USD)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit delegated to PMO; requires strategic oversight.
Negative Consequences: Potential budget overruns and misalignment with strategic goals.

**Critical Risk Materialization (e.g., Major Supply Chain Disruption)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Strategic impact on project goals and requires higher-level resource allocation and decision-making.
Negative Consequences: Project delays, increased costs, and failure to achieve objectives.

**PMO Deadlock on Vendor Selection (e.g., Bed Net Supplier)**
Escalation Level: Project Director
Approval Process: Project Director Review of Proposals and Final Decision
Rationale: Requires higher authority to resolve operational disagreements and ensure timely procurement.
Negative Consequences: Delays in procurement, potential for suboptimal vendor selection, and impact on intervention effectiveness.

**Proposed Major Scope Change (e.g., Adding a New Target Region)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant impact on project resources, timelines, and strategic objectives.
Negative Consequences: Project delays, budget overruns, and potential failure to achieve original goals.

**Reported Ethical Concern (e.g., Misuse of Funds, Violation of Community Trust)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation, followed by Senior Management Team Decision
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of community trust.

**Stakeholder Engagement Group cannot reach consensus on community intervention strategy**
Escalation Level: Project Director
Approval Process: Project Director reviews stakeholder input and makes final decision, documenting rationale.
Rationale: Ensures timely decision-making and prevents delays in community engagement activities.
Negative Consequences: Reduced community participation, ineffective interventions, and strained relationships with stakeholders.