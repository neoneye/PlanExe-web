### 1. Designate an Interim Chair for the Project Steering Committee to lead initial setup.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Designation

**Dependencies:**

- Project Start

### 2. Interim Chair drafts initial Terms of Reference (ToR) for the Project Steering Committee, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Interim Chair (Project Steering Committee)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Interim Chair Designation

### 3. Circulate Draft SteerCo ToR v0.1 for review by nominated members (Senior Management Representative, Project Director, Representative from Ghana Ministry of Health, Representative from a major funding partner (if secured), Independent Public Health Expert).

**Responsible Body/Role:** Interim Chair (Project Steering Committee)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Finalize the Project Steering Committee Terms of Reference (ToR) based on feedback.

**Responsible Body/Role:** Interim Chair (Project Steering Committee)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 5. Senior Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Formally confirm Project Steering Committee membership and communicate appointments.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 7. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 9. Establish project management processes and procedures for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Documented PMO Processes and Procedures

**Dependencies:**

- Project Start

### 10. Develop project plan and budget for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Plan
- Project Budget

**Dependencies:**

- Documented PMO Processes and Procedures

### 11. Set up project tracking and reporting systems for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Project Plan

### 12. Define roles and responsibilities for project team members within the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Plan

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Roles and Responsibilities Matrix

### 14. Designate an Interim Chair for the Ethics & Compliance Committee to lead initial setup.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Interim Chair Designation

**Dependencies:**

- Project Steering Committee established

### 15. Interim Chair drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Interim Chair (Ethics & Compliance Committee)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Interim Chair Designation

### 16. Circulate Draft Ethics & Compliance Committee ToR v0.1 for review by nominated members (Independent Legal Counsel, Senior Management Representative, Representative from the Ghana Ministry of Health (Compliance Officer), Community Representative, Ethics Officer).

**Responsible Body/Role:** Interim Chair (Ethics & Compliance Committee)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 17. Finalize the Ethics & Compliance Committee Terms of Reference (ToR) based on feedback.

**Responsible Body/Role:** Interim Chair (Ethics & Compliance Committee)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Senior Sponsor formally appoints the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 19. Formally confirm Ethics & Compliance Committee membership and communicate appointments.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 20. Schedule the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 21. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Code of Ethics

**Dependencies:**

- Meeting Invitation

### 22. Establish whistleblower mechanism for the Ethics & Compliance Committee.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Whistleblower Policy and Procedures

**Dependencies:**

- Meeting Minutes with Action Items

### 23. Designate an Interim Chair for the Stakeholder Engagement Group to lead initial setup.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Interim Chair Designation

**Dependencies:**

- Project Steering Committee established

### 24. Interim Chair drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Interim Chair (Stakeholder Engagement Group)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Interim Chair Designation

### 25. Circulate Draft Stakeholder Engagement Group ToR v0.1 for review by nominated members (Community Outreach Coordinator, Project Director, Representative from the Ghana Ministry of Health, Community Representatives (various regions), Representative from a major funding partner (if secured)).

**Responsible Body/Role:** Interim Chair (Stakeholder Engagement Group)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 26. Finalize the Stakeholder Engagement Group Terms of Reference (ToR) based on feedback.

**Responsible Body/Role:** Interim Chair (Stakeholder Engagement Group)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 27. Project Director formally appoints the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 28. Formally confirm Stakeholder Engagement Group membership and communicate appointments.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 29. Schedule the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation Emails

### 30. Hold the initial Stakeholder Engagement Group kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Stakeholder Engagement Plan

**Dependencies:**

- Meeting Invitation

### 31. Identify key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Draft Stakeholder Engagement Plan

### 32. Establish communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**

- List of Key Stakeholders

### 33. Schedule initial consultations for the Stakeholder Engagement Group.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Consultation Schedule

**Dependencies:**

- Communication Channels Established