This plan involves money.

## Currencies

- **GHS:** Ghanaian Cedi, the local currency for transactions within Ghana.
- **USD:** US Dollar, a stable currency for budgeting and potentially for larger transactions, given potential economic instability and the halt of USAID funding.

**Primary currency:** USD

**Currency strategy:** Due to the halt of USAID funding and potential economic instability, USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. GHS will be used for local transactions. For significant projects, the primary currency must be USD.