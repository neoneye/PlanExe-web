**Purpose:** business

**Purpose Detailed:** Public health initiative to combat malaria resurgence due to funding cuts.

**Topic:** Malaria prevention project in Ghana after USAID halt