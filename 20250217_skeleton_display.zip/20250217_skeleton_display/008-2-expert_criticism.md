# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Bioethicist

**Knowledge**: Bioethics, Medical Ethics, End-of-Life Care

**Why**: To address the ethical considerations surrounding the project, particularly regarding the display of human remains and potential impact on family members.

**What**: Advise on the ethical will, stakeholder engagement, and addressing potential ethical concerns related to the display of human remains.

**Skills**: Ethical reasoning, conflict resolution, communication, legal knowledge

**Search**: bioethicist end of life care

## 1.1 Primary Actions

- Immediately consult with a family therapist or mediator experienced in end-of-life care and conflict resolution to prepare for the family meeting.
- Consult with a certified industrial hygienist or a biohazard safety expert to conduct a comprehensive risk assessment and develop a detailed biohazard control plan.
- Consult with an attorney specializing in estate planning *and* body disposition law to ensure your legal will and advance directives explicitly authorize your wishes and are legally defensible.

## 1.2 Secondary Actions

- Research alternative legal pathways for body disposition in case family consent is not obtained.
- Document all training and safety procedures related to biohazard handling.
- Consider establishing a trust specifically for the execution of your post-mortem wishes.

## 1.3 Follow Up Consultation

In the next consultation, we will review the legal documents drafted by your attorney, the biohazard control plan developed by the industrial hygienist, and the strategies for managing family conflict proposed by the therapist/mediator. Bring copies of all documents and a detailed account of your conversations with these professionals.

## 1.4.A Issue - Lack of Skepticism Regarding Family Acceptance

You are assuming that a family meeting will automatically lead to acceptance and written consent. This is a dangerous assumption. Family dynamics are complex, and your desire, while personal, may be deeply disturbing or offensive to your relatives. Their concerns may be rooted in religious beliefs, emotional distress, or simply a sense of what is 'normal' and respectful. You need to prepare for strong resistance and consider alternative approaches if they do not consent.

### 1.4.B Tags

- unrealistic_expectation
- lack_of_contingency
- family_dynamics

### 1.4.C Mitigation

Consult with a family therapist or mediator experienced in end-of-life care and conflict resolution *before* the family meeting. They can help you anticipate potential objections, develop empathetic responses, and explore alternative solutions that might be more palatable to your family. Also, prepare for the possibility that your family will *never* consent, and research alternative legal pathways (e.g., body donation to science with specific stipulations, though these are unlikely to be honored).

### 1.4.D Consequence

If you proceed with the assumption of family consent and they strongly object, you risk legal challenges, irreparable family rifts, and the potential invalidation of your ethical will, leaving your wishes unfulfilled.

### 1.4.E Root Cause

Overly optimistic view of family dynamics and a failure to fully appreciate the potential emotional and ethical objections to your plan.

## 1.5.A Issue - Insufficient Detail Regarding Biohazard Protocols

While you mention biohazard containment, your plan lacks specific details. Decomposition involves a complex ecosystem of microorganisms, some of which may pose significant health risks, even with standard PPE. You need to go beyond general statements and outline precisely how you will handle specific biohazards, including airborne pathogens, bloodborne viruses, and fungal spores. The plan must address waste disposal, decontamination procedures, and emergency protocols in case of accidental exposure.

### 1.5.B Tags

- insufficient_detail
- biohazard_risk
- safety_protocol

### 1.5.C Mitigation

Consult with a certified industrial hygienist or a biohazard safety expert *before* commencing any work. They can conduct a comprehensive risk assessment, recommend appropriate PPE (including specific respirator types and glove materials), and develop a detailed biohazard control plan that complies with all applicable regulations. This plan should include specific protocols for handling bodily fluids, tissues, and contaminated materials, as well as emergency procedures for accidental exposure. Document all training and safety procedures.

### 1.5.D Consequence

Inadequate biohazard protocols could lead to serious health risks for yourself, the osteologist, and anyone else involved in the project. It could also result in legal liabilities and regulatory penalties.

### 1.5.E Root Cause

Underestimation of the complexity and potential dangers associated with handling decomposing human remains.

## 1.6.A Issue - Ethical Will vs. Standard Will: Misunderstanding of Legal Weight

You repeatedly refer to an 'ethical will' as a legally binding document that will guarantee your wishes are carried out. While an ethical will can express your values and intentions, it typically does *not* have the same legal force as a standard will or advance directive. Your plan hinges on the assumption that the ethical will will override any objections or legal challenges. This is likely incorrect. The legal enforceability of your wishes depends on the specific wording of your *legal* will and any advance directives, as well as applicable state laws regarding body disposition.

### 1.6.B Tags

- legal_misunderstanding
- unenforceable_document
- estate_planning

### 1.6.C Mitigation

Consult with an attorney specializing in estate planning *and* body disposition law in your specific jurisdiction. Ensure your *legal* will and any advance directives explicitly authorize the skeletal articulation and display, and that these documents are drafted in a way that is legally defensible against potential challenges. The 'ethical will' should be considered a supplementary document that expresses your values and provides context, but it should not be relied upon as the primary legal instrument. Discuss the possibility of establishing a trust specifically for the execution of your wishes.

### 1.6.D Consequence

Relying solely on an ethical will could result in your wishes being ignored or overturned by the courts, especially if family members object. Your plan could be thwarted, and your body could be disposed of in a manner contrary to your desires.

### 1.6.E Root Cause

Misunderstanding of the legal distinctions between an ethical will and a standard will, and a failure to seek expert legal advice on body disposition law.

---

# 2 Expert: Mortuary Law Attorney

**Knowledge**: Mortuary Law, Estate Planning, Bioethics Law

**Why**: To ensure full legal compliance with all applicable laws and regulations regarding cadaver disposition, anatomical donation, and handling of human remains.

**What**: Advise on legal compliance, permits, ethical will, and chain of custody protocols.

**Skills**: Legal research, contract drafting, regulatory compliance, risk assessment

**Search**: mortuary law attorney

## 2.1 Primary Actions

- Immediately consult with an attorney specializing in mortuary law and bioethics to assess the legal viability of the project and draft a legally sound ethical will.
- Engage a qualified grief counselor or therapist to facilitate family discussions and address potential emotional distress.
- Revise the project timeline and budget based on realistic estimates from professionals and develop contingency plans for potential delays or cost overruns.
- Obtain explicit written consent from all immediate family members, acknowledging their understanding of your plans and their agreement to not contest them.

## 2.2 Secondary Actions

- Research relevant case law regarding the display of human remains.
- Explore alternative mortuary facilities and display case options.
- Consider crowdfunding or seeking grants to supplement the budget.
- Document all communication with family members, legal counsel, and other stakeholders.

## 2.3 Follow Up Consultation

In the next consultation, we will review the revised ethical will, the family consent documentation, the updated project timeline and budget, and the legal opinion on the project's viability. We will also discuss strategies for addressing potential ethical concerns and mitigating legal risks.

## 2.4.A Issue - Over-reliance on Generic Zombie Tropes Without Legal Foresight

While your enthusiasm for zombies is evident, fixating on 'zombie-themed display protocols' without first solidifying the legal and ethical groundwork is a misdirection of effort. The legal system doesn't care about zombie archetypes; it cares about the rights of the deceased, the rights of the family, and public health. You're prioritizing aesthetics before ensuring the entire project isn't shut down immediately due to legal challenges or ethical violations. The focus on zombie characteristics should be secondary to ensuring the legality and ethical defensibility of the project.

### 2.4.B Tags

- misplaced_priority
- legal_oversight
- ethical_neglect

### 2.4.C Mitigation

Immediately shift focus to legal and ethical consultations. Prioritize drafting a legally sound ethical will that addresses potential family objections and emphasizes the artistic/educational value *before* further developing zombie-themed display protocols. Consult with an attorney specializing in mortuary law and bioethics. Research relevant case law regarding the display of human remains. Provide the attorney with a detailed outline of your plans, including the zombie theme, and ask for specific advice on how to mitigate potential legal challenges. Obtain a written legal opinion on the project's viability.

### 2.4.D Consequence

Legal challenges from family, court injunctions halting the project, potential criminal charges related to improper handling of human remains, and reputational damage.

### 2.4.E Root Cause

Prioritizing personal interests (zombie aesthetics) over legal and ethical obligations; lack of understanding of the legal complexities surrounding cadaver disposition.

## 2.5.A Issue - Unrealistic Timelines and Resource Allocation

Your timelines for securing facilities, drafting legal documents, and implementing biohazard protocols are overly optimistic and lack contingency planning. Securing a mortuary facility with specific equipment within 24 hours is highly improbable. Drafting a legally sound ethical will requires more than a few days, especially given the unusual nature of your request. The $5,000 budget seems insufficient to cover legal fees, facility costs, osteologist fees, and display case expenses. This unrealistic planning increases the risk of project failure and potential legal repercussions if deadlines are missed or corners are cut.

### 2.5.B Tags

- unrealistic_timeline
- insufficient_budget
- lack_of_contingency

### 2.5.C Mitigation

Revise the project timeline based on realistic estimates from professionals (attorney, mortuary facility manager, osteologist). Obtain detailed cost estimates for all aspects of the project and adjust the budget accordingly. Develop contingency plans for potential delays or cost overruns. For example, identify alternative mortuary facilities or explore less expensive display case options. Consider crowdfunding or seeking grants to supplement the budget. Extend the project completion timeline to at least 12 months to allow for unforeseen delays.

### 2.5.D Consequence

Missed deadlines, increased costs, legal complications due to rushed or incomplete legal documents, and potential project abandonment.

### 2.5.E Root Cause

Lack of experience in project management, underestimation of the complexities and costs involved in cadaver disposition and skeletal articulation, and a desire to expedite the project without proper planning.

## 2.6.A Issue - Insufficient Focus on Family Consent and Grief Counseling

While you mention informing your family, simply 'addressing their concerns' is insufficient. This project is emotionally charged and potentially distressing for your family. You need to proactively address their grief, potential objections, and emotional well-being. Failing to do so could lead to irreparable family rifts and legal challenges based on emotional distress or undue influence. The SWOT analysis mentions 'potential for emotional distress or objections from family members' but doesn't adequately address the depth of this issue.

### 2.6.B Tags

- family_neglect
- emotional_distress
- legal_vulnerability

### 2.6.C Mitigation

Engage a qualified grief counselor or therapist to facilitate family discussions about your post-mortem plans. Provide your family with resources and support to process their grief and address their concerns. Obtain *explicit written consent* from all immediate family members, acknowledging their understanding of your plans and their agreement to not contest them. Include a clause in your ethical will that acknowledges the potential emotional impact on your family and expresses your desire to minimize their distress. Consider offering to pay for grief counseling for family members after your death.

### 2.6.D Consequence

Family disputes, legal challenges based on emotional distress or undue influence, irreparable damage to family relationships, and potential invalidation of your ethical will.

### 2.6.E Root Cause

Underestimation of the emotional impact of the project on family members, lack of experience in dealing with grief and family dynamics, and a focus on personal desires over family well-being.

---

# The following experts did not provide feedback:

# 3 Expert: Osteologist/Anatomical Preparator

**Knowledge**: Osteology, Skeletal Articulation, Anatomical Preparation

**Why**: To provide expertise on the articulation process, ensuring anatomical accuracy and long-term preservation of the skeleton.

**What**: Advise on skeletal articulation procedure, reinforcement materials, and biohazard containment protocols.

**Skills**: Anatomical knowledge, skeletal articulation techniques, biohazard handling, preservation methods

**Search**: osteologist anatomical preparation

# 4 Expert: Display Case Designer

**Knowledge**: Museum Display, Security, Environmental Control

**Why**: To design a secure and aesthetically appropriate display case that protects the skeleton and enhances its presentation.

**What**: Advise on skeleton display safety measures, enclosure design, and environmental control.

**Skills**: Design, engineering, security, environmental control

**Search**: museum display case designer

# 5 Expert: Grief Counselor

**Knowledge**: Grief Counseling, Family Therapy, End-of-Life Support

**Why**: To provide support and guidance to family members who may be experiencing emotional distress or grief related to the project.

**What**: Advise on stakeholder engagement, addressing family concerns, and mitigating potential emotional distress.

**Skills**: Communication, empathy, conflict resolution, psychological assessment

**Search**: grief counselor end of life

# 6 Expert: Biohazard Safety Consultant

**Knowledge**: Biohazard Containment, Infection Control, Occupational Safety

**Why**: To ensure the implementation of effective biohazard containment protocols and protect the health and safety of all personnel involved in the project.

**What**: Advise on biohazard containment protocols, PPE, waste disposal, and training.

**Skills**: Risk assessment, safety protocols, training, regulatory compliance

**Search**: biohazard safety consultant

# 7 Expert: Art Conservator

**Knowledge**: Art Preservation, Material Science, Conservation Techniques

**Why**: To provide expertise on the long-term preservation and maintenance of the articulated skeleton, preventing deterioration or damage.

**What**: Advise on skeleton display safety measures, preservation techniques, and maintenance protocols.

**Skills**: Material analysis, conservation methods, environmental control, risk assessment

**Search**: art conservator skeletal remains

# 8 Expert: Public Relations Specialist

**Knowledge**: Public Communication, Media Relations, Crisis Management

**Why**: To manage public perception and address any potential negative publicity or ethical concerns related to the project.

**What**: Advise on stakeholder engagement, addressing ethical concerns, and managing public perception.

**Skills**: Communication, media relations, crisis management, ethical communication

**Search**: public relations specialist bioethics