This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting, publisher investments, and potential government grants in the USA.
- **CAD:** Relevant for operations and potential government grants in Montreal, Canada.
- **GBP:** Relevant for operations and potential government grants in Edinburgh, UK.

**Primary currency:** USD

**Currency strategy:** Given the international scope of the project across the USA, Canada, and the UK, USD will be used for consolidated budgeting and reporting. Local currencies (CAD and GBP) will be used for local transactions. Hedging strategies should be considered to mitigate risks from exchange rate fluctuations.