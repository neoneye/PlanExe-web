This plan involves money.

## Currencies

- **USD:** For international transactions, lab equipment purchases, and potential research grants.
- **IDR:** For local expenses in Indonesia (part of Southeast Asia).
- **PHP:** For local expenses in the Philippines (part of Southeast Asia).
- **VND:** For local expenses in Vietnam (part of Southeast Asia).
- **THB:** For local expenses in Thailand (part of Southeast Asia).
- **EUR:** For expenses related to research in the Mediterranean Sea and European research institutions.

**Primary currency:** USD

**Currency strategy:** Due to the international scope of the project, USD is recommended for budgeting and reporting. Local currencies (IDR, PHP, VND, THB, EUR) will be used for in-country expenses. Consider hedging against exchange rate fluctuations, especially for larger transactions.