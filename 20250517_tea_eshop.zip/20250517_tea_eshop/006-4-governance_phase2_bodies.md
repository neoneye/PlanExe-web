### 1. Project Steering Committee

**Rationale for Inclusion:** Given the complexity of launching an e-commerce business in a regulated environment, a Project Steering Committee is essential for providing strategic oversight and ensuring alignment with business goals.

**Responsibilities:**

- Approve project milestones and budgets exceeding CZK 100,000.
- Provide strategic direction and resolve high-level issues.
- Monitor overall project performance and risk management.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Elect Chair and define roles.
- Set meeting schedule.

**Membership:**

- Project Sponsor
- Business Manager
- Independent Legal Advisor
- Marketing Specialist

**Decision Rights:** Empowered to make decisions on project scope changes and budget reallocations above CZK 100,000.

**Decision Mechanism:** Decisions made by majority vote; in case of a tie, the Chair has the casting vote.

**Meeting Cadence:** Monthly meetings with additional meetings as required.

**Typical Agenda Items:**

- Review project progress and milestones.
- Discuss strategic risks and mitigation strategies.
- Evaluate budget status and financial forecasts.

**Escalation Path:** Issues unresolved at the Steering Committee level escalate to the Project Board.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** The PMO is necessary to manage day-to-day operations, ensuring that project execution aligns with strategic goals and operational efficiency.

**Responsibilities:**

- Oversee project execution and resource allocation.
- Manage operational risks and ensure compliance with project timelines.
- Facilitate communication among project teams.

**Initial Setup Actions:**

- Define project management methodologies and tools.
- Establish reporting templates and communication protocols.
- Train team members on project management processes.

**Membership:**

- Project Manager
- Logistics Coordinator
- Finance Officer

**Decision Rights:** Authorized to make operational decisions within the budget of CZK 100,000.

**Decision Mechanism:** Decisions made by consensus; if consensus cannot be reached, the Project Manager makes the final decision.

**Meeting Cadence:** Weekly meetings to review project status and address immediate concerns.

**Typical Agenda Items:**

- Review project timelines and deliverables.
- Discuss operational challenges and resource needs.
- Update on risk management activities.

**Escalation Path:** Operational issues that cannot be resolved escalate to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** To ensure compliance with technical and regulatory standards, a Technical Advisory Group is essential for providing specialized input on legal, safety, and operational aspects.

**Responsibilities:**

- Review compliance with local health and safety regulations.
- Advise on technical aspects of e-commerce platform development.
- Provide insights on supplier selection and sustainability practices.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the scope of advisory services.
- Establish meeting schedules.

**Membership:**

- Independent Compliance Expert
- Legal Advisor
- Supply Chain Specialist

**Decision Rights:** No decision-making authority; provides recommendations to the PMO and Steering Committee.

**Decision Mechanism:** Consensus-based recommendations presented to the PMO.

**Meeting Cadence:** Bi-monthly meetings or as needed.

**Typical Agenda Items:**

- Review compliance documentation and requirements.
- Discuss technical challenges and solutions.
- Evaluate supplier compliance and sustainability practices.

**Escalation Path:** Issues requiring further attention escalate to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** To address potential ethical concerns and ensure compliance with regulations, this committee is crucial for maintaining integrity and transparency throughout the project.

**Responsibilities:**

- Monitor compliance with ethical standards and regulations.
- Review and address any reported unethical behavior.
- Ensure transparency in supplier selection and hiring processes.

**Initial Setup Actions:**

- Establish a code of ethics and compliance guidelines.
- Recruit committee members with relevant expertise.
- Set up reporting mechanisms for ethical concerns.

**Membership:**

- Independent Ethics Officer
- HR Representative
- Project Sponsor

**Decision Rights:** Empowered to recommend actions regarding compliance issues; no financial decision-making authority.

**Decision Mechanism:** Decisions made by majority vote; in case of a tie, the Ethics Officer has the casting vote.

**Meeting Cadence:** Quarterly meetings or as needed.

**Typical Agenda Items:**

- Review reported ethical concerns and compliance issues.
- Discuss updates to compliance policies and practices.
- Evaluate the effectiveness of transparency measures.

**Escalation Path:** Serious compliance issues escalate to the Project Steering Committee.