This plan involves money.

## Currencies

- **CZK:** The official currency of the Czech Republic, necessary for local transactions and budgeting.

**Primary currency:** CZK

**Currency strategy:** The local currency (CZK) will be used for all transactions, as the project is focused on the Czech market and does not involve international currency risks.