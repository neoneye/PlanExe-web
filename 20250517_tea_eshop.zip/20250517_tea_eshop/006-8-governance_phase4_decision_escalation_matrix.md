**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit set for PMO decisions.
Negative Consequences: Potential project delays due to funding issues.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Requires strategic oversight and resources beyond PMO capabilities.
Negative Consequences: Increased likelihood of project failure or significant delays.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Consensus cannot be reached on critical vendor decisions.
Negative Consequences: Delays in project execution and potential loss of competitive advantage.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant impact on project objectives and resources.
Negative Consequences: Misalignment with project goals and potential budget overruns.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review to ensure compliance and integrity.
Negative Consequences: Reputational damage and potential legal implications if not addressed.