### 1. Project Sponsor drafts initial Terms of Reference (ToR) for Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ToR for Project Steering Committee v0.1

**Dependencies:**


### 2. Circulate Draft ToR for review by nominated members of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Draft ToR

**Dependencies:**

- Draft ToR for Project Steering Committee v0.1

### 3. Project Sponsor finalizes the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Finalized ToR for Project Steering Committee

**Dependencies:**

- Feedback Summary on Draft ToR

### 4. Project Sponsor formally appoints Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for Chair

**Dependencies:**

- Finalized ToR for Project Steering Committee

### 5. Project Sponsor confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed Membership List for Project Steering Committee

**Dependencies:**

- Finalized ToR for Project Steering Committee

### 6. Hold initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Chair of Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items from Kick-off Meeting

**Dependencies:**

- Appointment Confirmation Email for Chair
- Confirmed Membership List for Project Steering Committee

### 7. Project Manager drafts initial Terms of Reference (ToR) for Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ToR for PMO v0.1

**Dependencies:**


### 8. Circulate Draft ToR for review by nominated members of the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary on Draft ToR for PMO

**Dependencies:**

- Draft ToR for PMO v0.1

### 9. Project Manager finalizes the Terms of Reference for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized ToR for PMO

**Dependencies:**

- Feedback Summary on Draft ToR for PMO

### 10. Hold initial kick-off meeting for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items from PMO Kick-off Meeting

**Dependencies:**

- Finalized ToR for PMO

### 11. Technical Advisory Group identifies and recruits technical experts.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of Recruited Technical Experts

**Dependencies:**


### 12. Establish meeting schedules for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Schedule for Technical Advisory Group

**Dependencies:**

- List of Recruited Technical Experts

### 13. Ethics & Compliance Committee establishes a code of ethics and compliance guidelines.

**Responsible Body/Role:** Interim Chair of Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Code of Ethics and Compliance Guidelines

**Dependencies:**


### 14. Recruit committee members for the Ethics & Compliance Committee.

**Responsible Body/Role:** Interim Chair of Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Membership List for Ethics & Compliance Committee

**Dependencies:**

- Draft Code of Ethics and Compliance Guidelines

### 15. Hold initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Interim Chair of Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items from Ethics & Compliance Committee Kick-off Meeting

**Dependencies:**

- Confirmed Membership List for Ethics & Compliance Committee