**Purpose:** business

**Purpose Detailed:** Societal impact through governmental policy changes affecting public health infrastructure and resource management.

**Topic:** Government-mandated CDC restructuring