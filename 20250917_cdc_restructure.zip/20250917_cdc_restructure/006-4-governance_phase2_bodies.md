### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the CDC restructuring project, ensuring alignment with government mandates and addressing high-level risks and strategic decisions.

**Responsibilities:**

- Approve the overall project plan and any significant deviations.
- Provide strategic guidance and direction to the Project Management Office.
- Approve major budget allocations and reallocations exceeding $1 million USD.
- Monitor project progress against key performance indicators (KPIs).
- Oversee risk management and approve mitigation strategies for high-impact risks.
- Resolve strategic conflicts and escalate issues to the appropriate government authorities.
- Approve key stakeholder communication strategies.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish meeting schedule and communication protocols.
- Review and approve the initial project plan and budget.
- Define escalation paths and decision-making processes.

**Membership:**

- Senior Government Official (Chair)
- CDC Director (or designated representative)
- Representative from the Department of Health and Human Services (HHS)
- Independent Legal Expert
- Independent Public Health Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above $1 million USD), timeline, and risk management. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions are made by majority vote, with the Senior Government Official holding the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Monthly, or more frequently as needed during critical phases of the project.

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion and approval of proposed changes to the project plan.
- Review of risk management activities and mitigation strategies.
- Approval of major budget allocations and reallocations.
- Stakeholder communication updates and strategies.
- Review of compliance and legal matters.

**Escalation Path:** Secretary of the Department of Health and Human Services (HHS) or higher government authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the CDC restructuring project, ensuring adherence to the project plan and budget, and coordinating activities across different teams.

**Responsibilities:**

- Develop and maintain the project plan, including timelines, budgets, and resource allocation.
- Monitor project progress and identify potential delays or issues.
- Coordinate activities across different teams and departments within the CDC.
- Manage project risks and implement mitigation strategies.
- Prepare regular progress reports for the Project Steering Committee.
- Manage the project budget and track expenditures.
- Ensure compliance with relevant regulations and policies.
- Facilitate communication and collaboration among stakeholders.

**Initial Setup Actions:**

- Establish the PMO team and define roles and responsibilities.
- Develop project management templates and tools.
- Establish communication protocols and reporting mechanisms.
- Develop a risk management plan.

**Membership:**

- Project Manager (Lead)
- IT Specialist
- HR Representative
- Finance Officer
- Communication Specialist
- Legal Counsel

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $1 million USD), and risk management within the approved project plan and budget.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the PMO team. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, or more frequently as needed during critical phases of the project.

**Typical Agenda Items:**

- Review of project progress against the project plan.
- Discussion of potential risks and issues.
- Review of budget and expenditures.
- Coordination of activities across different teams.
- Preparation of progress reports for the Project Steering Committee.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical considerations and compliance with relevant laws, regulations, and policies during the CDC restructuring, particularly regarding data security, employment laws, and scientific integrity.

**Responsibilities:**

- Review and approve ethical guidelines for the restructuring project.
- Monitor compliance with relevant laws, regulations, and policies, including employment laws, data security regulations, and environmental regulations.
- Investigate allegations of ethical misconduct or non-compliance.
- Provide guidance on ethical dilemmas and conflicts of interest.
- Ensure the protection of employee rights and data privacy.
- Oversee the whistleblower mechanism and ensure that complaints are investigated and addressed.
- Review and approve the selection process for science advisors to ensure scientific integrity.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish meeting schedule and communication protocols.
- Develop a compliance checklist and monitoring plan.
- Establish procedures for investigating allegations of misconduct.

**Membership:**

- Independent Legal Expert (Chair)
- Ethics Officer
- Compliance Officer
- HR Representative
- Data Security Officer
- Representative from a Public Health Ethics Organization

**Decision Rights:** Decisions related to ethical guidelines, compliance policies, and investigations of misconduct. Authority to recommend corrective actions to the Project Steering Committee.

**Decision Mechanism:** Decisions are made by majority vote, with the Independent Legal Expert holding the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Bi-weekly, or more frequently as needed during critical phases of the project or in response to specific ethical or compliance concerns.

**Typical Agenda Items:**

- Review of ethical guidelines and compliance policies.
- Discussion of potential ethical dilemmas and conflicts of interest.
- Review of compliance monitoring activities and audit results.
- Investigation of allegations of misconduct or non-compliance.
- Review of data security incidents and breaches.
- Review of the selection process for science advisors.

**Escalation Path:** Project Steering Committee, with direct reporting line to the HHS Office of Inspector General for serious ethical breaches or compliance violations.