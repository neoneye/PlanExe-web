This plan involves money.

## Currencies

- **USD:** The primary currency for budgeting and reporting, given that the project is based in the USA.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.