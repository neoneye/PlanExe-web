### 1. Identify and appoint an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Appointment Confirmation

**Dependencies:**

- Project Start

### 2. Interim Chair drafts initial Terms of Reference (ToR) for the Project Steering Committee, outlining responsibilities, membership, and decision-making processes.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Interim Chair Appointment Confirmation

### 3. Circulate Draft SteerCo ToR v0.1 for review and feedback from proposed Steering Committee members (CDC Director, HHS Representative, Independent Legal Expert, Independent Public Health Expert).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Incorporate feedback and finalize the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 5. Senior Government Official formally appoints members to the Project Steering Committee (CDC Director, HHS Representative, Independent Legal Expert, Independent Public Health Expert).

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize governance processes, and elect a permanent Chair (if different from the Interim Chair).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Election of Permanent Chair (if applicable)

**Dependencies:**

- Meeting Invitation

### 8. Establish the Project Management Office (PMO) team and define roles and responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Team Roster
- Roles and Responsibilities Matrix

**Dependencies:**

- Project Start

### 9. Develop project management templates and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Risk Register Template
- Issue Log Template

**Dependencies:**

- PMO Team Roster

### 10. Establish communication protocols and reporting mechanisms for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Schedule

**Dependencies:**

- PMO Team Roster

### 11. Develop a risk management plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Management Plan

**Dependencies:**

- Project Management Templates

### 12. Hold the initial PMO kick-off meeting to review the project plan, establish communication protocols, and assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Roster
- Communication Plan

### 13. Identify and appoint an Interim Chair for the Ethics and Compliance Committee.

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Appointment Confirmation

**Dependencies:**

- Project Start

### 14. Interim Chair drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee, outlining responsibilities, membership, and decision-making processes.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Interim Chair Appointment Confirmation

### 15. Circulate Draft Ethics and Compliance Committee ToR v0.1 for review and feedback from proposed committee members (Ethics Officer, Compliance Officer, HR Representative, Data Security Officer, Representative from a Public Health Ethics Organization).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1
- Nominated Members List Available

### 16. Incorporate feedback and finalize the Ethics and Compliance Committee Terms of Reference (ToR).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Senior Government Official formally appoints members to the Ethics and Compliance Committee (Ethics Officer, Compliance Officer, HR Representative, Data Security Officer, Representative from a Public Health Ethics Organization).

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Nominated Members List Available

### 18. Schedule the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 19. Hold the initial Ethics and Compliance Committee kick-off meeting to review the project plan, finalize governance processes, and elect a permanent Chair (if different from the Interim Chair).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Election of Permanent Chair (if applicable)

**Dependencies:**

- Meeting Invitation

### 20. Develop a compliance checklist and monitoring plan for the Ethics and Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Compliance Checklist
- Monitoring Plan

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 21. Establish procedures for investigating allegations of misconduct for the Ethics and Compliance Committee.

**Responsible Body/Role:** Ethics Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Investigation Procedures

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0