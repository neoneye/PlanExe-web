**Purpose:** business

**Purpose Detailed:** Societal initiative involving a government-sanctioned competition for debt resolution and public entertainment, framed as a public welfare project.

**Topic:** Government-sponsored 'Squid Game' for debt resolution and national entertainment.