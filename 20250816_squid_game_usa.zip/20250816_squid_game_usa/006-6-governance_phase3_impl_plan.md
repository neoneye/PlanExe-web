### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by Senior Government Representative, Project Director, Legal Counsel, Ethics and Compliance Officer, Independent Risk Management Expert, and Representative from the Department of Public Entertainment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Government Representative formally appointed as Steering Committee Chair.

**Responsible Body/Role:** Secretary of Public Entertainment

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints remaining members of the Project Steering Committee: Project Director, Legal Counsel, Ethics and Compliance Officer, Independent Risk Management Expert, and Representative from the Department of Public Entertainment.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Senior Government Representative Appointed as Chair

### 6. Schedule initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- SteerCo Members Appointed

### 7. Hold initial Project Steering Committee kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Appointed
- Meeting Invitation Sent

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Circulate Draft Ethics and Compliance Committee ToR for review by Legal Counsel and Project Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 10. Project Manager incorporates feedback and finalizes the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Steering Committee formally appoints Independent Ethics Expert as Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Project Steering Committee Established

### 12. Ethics and Compliance Committee Chair, in consultation with the Project Steering Committee, formally appoints remaining members of the Ethics and Compliance Committee: Legal Counsel, Data Protection Officer, Representative from the Department of Justice, Representative from a Civil Liberties Organization, and Community Representative.

**Responsible Body/Role:** Ethics and Compliance Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0
- Ethics and Compliance Committee Chair Appointed
- Project Steering Committee Established

### 13. Schedule initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Ethics and Compliance Committee Members Appointed

### 14. Hold initial Ethics and Compliance Committee kick-off meeting to review ToR, ethical guidelines, and initial priorities.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics and Compliance Committee Members Appointed
- Meeting Invitation Sent

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 16. Circulate Draft Technical Advisory Group ToR for review by Project Director and AI/Robotics Experts.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 17. Project Manager incorporates feedback and finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Project Steering Committee formally appoints AI/Robotics Expert as Technical Advisory Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Project Steering Committee Established

### 19. Technical Advisory Group Chair, in consultation with the Project Steering Committee, formally appoints remaining members of the Technical Advisory Group: Software Engineer, Hardware Engineer, Safety Engineer, Cybersecurity Expert, and Independent Technical Consultant.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Technical Advisory Group Chair Appointed
- Project Steering Committee Established

### 20. Schedule initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Technical Advisory Group Members Appointed

### 21. Hold initial Technical Advisory Group kick-off meeting to review ToR, technical standards, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Members Appointed
- Meeting Invitation Sent

### 22. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 23. Circulate Draft Stakeholder Engagement Group ToR for review by Project Director and Communications Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 24. Project Manager incorporates feedback and finalizes the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 25. Project Steering Committee formally appoints Communications Officer as Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Project Steering Committee Established

### 26. Stakeholder Engagement Group Chair, in consultation with the Project Steering Committee, formally appoints remaining members of the Stakeholder Engagement Group: Public Relations Specialist, Community Liaison, Participant Representative, Spectator Representative, and Media Relations Specialist.

**Responsible Body/Role:** Stakeholder Engagement Group Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Stakeholder Engagement Group Chair Appointed
- Project Steering Committee Established

### 27. Schedule initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Stakeholder Engagement Group Members Appointed

### 28. Hold initial Stakeholder Engagement Group kick-off meeting to review ToR, stakeholder engagement plan, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Members Appointed
- Meeting Invitation Sent

### 29. Establish PMO structure and processes.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Process Flowcharts

**Dependencies:**

- Project Plan Approved

### 30. Develop project management templates and tools.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Plan Template
- Risk Register Template
- Issue Log Template

**Dependencies:**

- PMO Structure Document

### 31. Recruit and train PMO staff: PMO Director, Project Managers, Project Coordinators, Risk Management Specialist, Financial Analyst, Communications Officer.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Job Descriptions
- Training Materials
- Staff Onboarding Checklist

**Dependencies:**

- Project Budget Approved

### 32. Define communication protocols for the PMO.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Plan
- Contact List

**Dependencies:**

- PMO Staff Onboarded

### 33. Set up project tracking and reporting systems.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Project Management Software Configuration
- Reporting Dashboard

**Dependencies:**

- Communication Plan Defined

### 34. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Management Software Configured
- Reporting Dashboard Created