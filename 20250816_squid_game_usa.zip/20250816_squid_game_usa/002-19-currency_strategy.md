This plan involves money.

## Currencies

- **USD:** The project is based in the USA and involves significant expenses.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.