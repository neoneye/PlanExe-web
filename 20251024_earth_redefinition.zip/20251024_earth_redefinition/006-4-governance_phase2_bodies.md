### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's political sensitivity, high budget, and potential for significant societal impact.  Ensures alignment with the supreme political leader's vision and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$10 million DKK).
- Oversee risk management and mitigation strategies.
- Resolve strategic issues and conflicts.
- Approve key strategic decisions (e.g., curriculum adaptation strategy, teacher re-education protocol).
- Ensure alignment with the supreme political leader's vision.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation procedures.
- Review and approve initial project plan.

**Membership:**

- Supreme Political Leader (or designated representative)
- Minister of Education
- Permanent Secretary of the Ministry of Education
- Independent Expert in Educational Governance (external)
- Representative from the Ministry of Finance

**Decision Rights:** Strategic decisions related to project scope, budget (>$10 million DKK), timeline, and key strategic choices (e.g., curriculum adaptation, teacher re-education).

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Supreme Political Leader (or designated representative) has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion and approval of strategic decisions.
- Review of risk management activities.
- Budget review and approval of major expenditures (>$10 million DKK).
- Discussion of stakeholder engagement activities.
- Escalated issues from the Project Management Office.

**Escalation Path:** Directly to the Supreme Political Leader for unresolved issues or disagreements within the Steering Committee.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource utilization and adherence to the project plan.  Provides operational risk management and supports the Project Steering Committee.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and resources.
- Track project progress and report to the Steering Committee.
- Identify and manage operational risks.
- Coordinate project activities across different workstreams.
- Manage procurement and contracting processes.
- Facilitate communication among project stakeholders.
- Implement and monitor quality control procedures.
- Manage decisions below strategic thresholds (e.g., <$10 million DKK).

**Initial Setup Actions:**

- Establish PMO structure and processes.
- Develop project management templates and tools.
- Recruit project team members.
- Define communication protocols.
- Establish risk management framework.

**Membership:**

- Project Manager
- Curriculum Development Lead
- Teacher Re-education Lead
- Communications Lead
- Finance Officer
- Procurement Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $10 million DKK), and risk management within the approved project plan.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with relevant team members.  Disagreements escalated to the Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of operational issues and risks.
- Budget tracking and expenditure review.
- Resource allocation and management.
- Action item review and follow-up.
- Preparation of reports for the Steering Committee.

**Escalation Path:** To the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic guidance.
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical and compliance aspects of the project, given the controversial nature of the project and the potential for legal and ethical violations. Ensures adherence to GDPR, ethical standards, and relevant regulations.

**Responsibilities:**

- Review and approve project plans from an ethical and compliance perspective.
- Monitor project activities for compliance with relevant laws, regulations, and ethical standards (including GDPR).
- Investigate and resolve ethical complaints and compliance violations.
- Provide guidance and training to project team members on ethical and compliance issues.
- Develop and maintain a code of ethics for the project.
- Ensure data privacy and security.
- Oversee the whistleblower mechanism.
- Review and approve all public communications to ensure accuracy and ethical messaging.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish reporting procedures for ethical concerns.

**Membership:**

- Independent Legal Counsel (external)
- Ethics Officer from the Ministry of Education
- Data Protection Officer
- Representative from a Civil Society Organization focused on education (external)
- Representative from the Teacher's Union

**Decision Rights:** Authority to halt project activities that violate ethical standards or compliance requirements. Authority to recommend disciplinary action for ethical violations.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Independent Legal Counsel has the deciding vote.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of ethical and compliance risks.
- Discussion of ethical complaints and compliance violations.
- Review of project plans and activities for ethical and compliance concerns.
- Training and awareness programs on ethical and compliance issues.
- Review of data privacy and security measures.
- Review of public communications for ethical messaging.

**Escalation Path:** To the Supreme Political Leader and the Minister of Justice for serious ethical violations or compliance breaches that cannot be resolved within the Committee.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical input and assurance on the curriculum development process, given the challenges of creating a coherent flat earth curriculum and the need to address potential scientific criticisms.  Ensures the curriculum is internally consistent, even if scientifically inaccurate.

**Responsibilities:**

- Review and provide feedback on the curriculum development process.
- Assess the technical feasibility and coherence of the flat earth curriculum.
- Identify and address potential scientific criticisms of the curriculum.
- Provide guidance on how to present the flat earth model in a consistent and understandable manner.
- Ensure the curriculum aligns with the overall project goals.
- Advise on the selection of appropriate teaching materials.
- Monitor the quality of the curriculum and recommend improvements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define criteria for evaluating the curriculum.
- Identify key areas of technical challenge.

**Membership:**

- Professor of Rhetoric (external)
- Historian of Science (external)
- Senior Curriculum Developer
- Representative from the Ministry of Education
- Expert in Pseudoscience (external)

**Decision Rights:** Authority to recommend changes to the curriculum to improve its technical coherence and address potential criticisms.  Authority to flag inconsistencies or inaccuracies in the curriculum.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Chair facilitates discussion and seeks to find a compromise. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of curriculum development progress.
- Discussion of technical challenges and potential solutions.
- Assessment of the curriculum's coherence and consistency.
- Identification of potential scientific criticisms and responses.
- Review of teaching materials.
- Recommendations for curriculum improvements.

**Escalation Path:** To the Project Steering Committee for unresolved technical issues or disagreements within the Advisory Group.