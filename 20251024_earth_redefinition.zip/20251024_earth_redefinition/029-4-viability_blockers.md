<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Staff aversion to curriculum

**Domain:** Human Stability

**Issues:**

- <code>STAFF_AVERSION</code>: Change readiness survey v1 + incentive/retention plan

**Acceptance Criteria:**

- Change readiness survey results show \>80% support
- Incentive/retention plan approved by HR

**Artifacts Required:**

- Change\_Readiness\_Survey\_v1\.pdf
- Incentive\_Retention\_Plan\.pdf

**Owner:** HR


**Rough Order of Magnitude (ROM):** MEDIUM cost, 30 days


### B2: Low budget contingency

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Criteria:**

- \>=10% contingency approved
- Monte Carlo risk workbook attached

**Artifacts Required:**

- Budget\_v2\.pdf
- Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: Ethics charter missing

**Domain:** Rights & Legality

**Issues:**

- <code>ETHICS_VAGUE</code>: Normative Charter v1.0 with auditable rules & dissent logging

**Acceptance Criteria:**

- Normative Charter v1\.0 approved
- Auditable rules defined
- Dissent logging process in place

**Artifacts Required:**

- Normative\_Charter\_v1\.pdf

**Owner:** Legal


**Rough Order of Magnitude (ROM):** MEDIUM cost, 45 days


### B4: Team bandwidth insufficient

**Domain:** Program Delivery

**Issues:**

- <code>TEAM_BANDWIDTH_LOW</code>: Capacity plan (FTE by skill vs demand) with hiring/contract backfill

**Acceptance Criteria:**

- Capacity plan approved
- Hiring/contract backfill initiated

**Artifacts Required:**

- Capacity\_Plan\_v1\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 60 days

