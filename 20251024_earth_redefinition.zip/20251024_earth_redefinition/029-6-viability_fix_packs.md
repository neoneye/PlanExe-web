<p class="section-subtitle">Bundled actions that reduce risk and move domains toward GREEN.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>, <code>B3</code>

### FP1: Addressing Staff Aversion and Bandwidth Constraints

**Priority:** High

**Blockers:** <code>B1</code>, <code>B4</code>