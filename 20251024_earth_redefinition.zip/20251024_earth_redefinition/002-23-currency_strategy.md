This plan involves money.

## Currencies

- **DKK:** The project is based in Denmark, and the budget is specified in Danish Krone.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone will be used for all transactions. No additional international risk management is needed.