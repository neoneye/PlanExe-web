**Verdict:** 🔴 REFUSE

**Rationale:** This request promotes the spread of misinformation and the suppression of scientific knowledge within an educational system, which could have long-term negative consequences.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Other |
| **Claim**                 | Promoting misinformation in education. |
| **Capability Uplift**     | Yes |
| **Severity**              | Medium |