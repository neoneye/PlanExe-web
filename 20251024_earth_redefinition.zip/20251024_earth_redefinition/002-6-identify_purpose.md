**Purpose:** business

**Purpose Detailed:** Societal-scale educational reform based on a pseudoscientific belief, driven by political mandate and involving significant resource allocation.

**Topic:** Restructuring the Danish school system to teach flat earth theory