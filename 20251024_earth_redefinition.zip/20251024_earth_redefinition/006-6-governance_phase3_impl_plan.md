### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR for review by the Minister of Education and Permanent Secretary of the Ministry of Education.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Review Request Email

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Reviewer Feedback Received

### 4. Project Sponsor (Supreme Political Leader) formally appoints the Chair of the Project Steering Committee (or designates a representative).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- SteerCo Chair Acceptance

**Dependencies:**

- SteerCo ToR v1.0 Approved

### 5. Project Manager coordinates with the Supreme Political Leader (or designated representative), Minister of Education, Permanent Secretary of the Ministry of Education, Independent Expert in Educational Governance, and Representative from the Ministry of Finance to confirm their membership on the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- SteerCo Chair Appointed

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, establish communication protocols, and define decision-making processes.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan

**Dependencies:**

- Meeting Invitation Sent

### 8. Project Manager establishes the Project Management Office (PMO) structure and processes.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Process Flowcharts

**Dependencies:**

- Project Plan Approved

### 9. Project Manager develops project management templates and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Risk Register Template

**Dependencies:**

- PMO Structure Document

### 10. Project Manager recruits project team members for the PMO (Curriculum Development Lead, Teacher Re-education Lead, Communications Lead, Finance Officer, Procurement Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Team Members Onboarded

**Dependencies:**

- Project Management Templates

### 11. Project Manager defines communication protocols for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Communication Plan
- Stakeholder Communication Matrix

**Dependencies:**

- PMO Team Members Onboarded

### 12. Project Manager establishes a risk management framework for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Risk Management Plan
- Risk Register

**Dependencies:**

- Communication Plan

### 13. Hold initial PMO kick-off meeting to assign initial tasks and review project plan.

**Responsible Body/Role:** Project Management Office

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Task Assignments

**Dependencies:**

- Risk Management Plan

### 14. Project Manager drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 15. Project Manager circulates Draft Ethics and Compliance Committee ToR for review by the Minister of Education and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1
- Review Request Email

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 16. Project Manager incorporates feedback and finalizes the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics and Compliance Committee ToR v1.0
- Feedback Summary

**Dependencies:**

- Reviewer Feedback Received

### 17. Minister of Education formally appoints the Chair of the Ethics and Compliance Committee (Independent Legal Counsel).

**Responsible Body/Role:** Minister of Education

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Ethics and Compliance Committee Chair Acceptance

**Dependencies:**

- Ethics and Compliance Committee ToR v1.0 Approved

### 18. Project Manager coordinates with the Independent Legal Counsel, Ethics Officer from the Ministry of Education, Data Protection Officer, Representative from a Civil Society Organization focused on education, and Representative from the Teacher's Union to confirm their membership on the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Ethics and Compliance Committee Chair Appointed

### 19. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Membership List

### 20. Hold the initial Ethics and Compliance Committee kick-off meeting to review the project plan, establish communication protocols, and define decision-making processes.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Code of Ethics

**Dependencies:**

- Meeting Invitation Sent

### 21. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 22. Project Manager circulates Draft Technical Advisory Group ToR for review by the Senior Curriculum Developer and Representative from the Ministry of Education.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1
- Review Request Email

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 23. Project Manager incorporates feedback and finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group ToR v1.0
- Feedback Summary

**Dependencies:**

- Reviewer Feedback Received

### 24. Minister of Education formally appoints the Chair of the Technical Advisory Group (Professor of Rhetoric).

**Responsible Body/Role:** Minister of Education

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Technical Advisory Group Chair Acceptance

**Dependencies:**

- Technical Advisory Group ToR v1.0 Approved

### 25. Project Manager coordinates with the Professor of Rhetoric, Historian of Science, Senior Curriculum Developer, Representative from the Ministry of Education, and Expert in Pseudoscience to confirm their membership on the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Membership List

**Dependencies:**

- Technical Advisory Group Chair Appointed

### 26. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Membership List

### 27. Hold the initial Technical Advisory Group kick-off meeting to review the curriculum development process, establish communication protocols, and define decision-making processes.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Criteria for Evaluating the Curriculum

**Dependencies:**

- Meeting Invitation Sent