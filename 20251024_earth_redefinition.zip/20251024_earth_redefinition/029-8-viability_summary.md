- **Status:** RED
- **Recommendation:** <code>HOLD</code>, Do not proceed \- resolve blockers first

### Summary of Critical Issues by Domain
| Domain | Status | Issue Codes |
|--------|--------|-------------|
| Human Stability | RED | STAFF\_AVERSION, TRAINING\_GAPS, CHANGE\_MGMT\_GAPS |
| Rights & Legality | RED | ETHICS\_VAGUE, DPIA\_GAPS, INFOSEC\_GAPS |
| Ecological Integrity | GRAY | Evidence needed: Environmental baseline note \(scope, metrics\) — acceptance criteria: scope, metrics, measurement methods, and data sources detailed with sustainability lead sign\-off\., Cloud carbon estimate v1 \(regions/services\) — acceptance criteria: regional/service mix applied, monthly kgCO2e calculated with methodology notes, and results published to shared dashboard\. |

### Go/No-Go Criteria
<p class="section-subtitle">Must be met to proceed.</p>
- \>=10% contingency approved
- Monte Carlo risk workbook attached
- Normative Charter v1\.0 approved
- Auditable rules defined
- Dissent logging process in place