**Purpose:** business

**Purpose Detailed:** Societal initiative to reform a cultural event, balancing tradition with animal welfare standards, involving significant funding and stakeholder engagement.

**Topic:** Running of the Bulls Reform Initiative