
## Risk 1 - Regulatory & Permitting
Obtaining necessary permits and approvals from local authorities in Pamplona for proposed reforms to the Running of the Bulls may be delayed or denied due to political or cultural sensitivities. Changes to a deeply ingrained cultural event can face strong resistance.

**Impact:** Project delays of 3-6 months, increased costs due to legal challenges (estimated €50,000 - €100,000), or complete rejection of reform proposals, potentially rendering the project unsuccessful.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with local authorities and cultural organizations early in the project to build consensus and address concerns. Conduct thorough legal research to understand permitting requirements and potential challenges. Develop alternative reform proposals that are less controversial.

## Risk 2 - Social
Public opposition to proposed reforms from traditionalists and bullfighting enthusiasts could lead to protests, boycotts, or even sabotage of the initiative. Negative media coverage could damage the project's reputation and hinder its progress.

**Impact:** Project delays of 2-4 weeks due to disruptions, increased security costs (estimated €20,000 - €40,000), and difficulty engaging with stakeholders. Damage to the project's reputation could reduce its long-term impact.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive communication strategy to engage with the public and address concerns. Highlight the project's commitment to preserving cultural heritage while improving animal welfare. Work with local influencers to build support for the initiative.

## Risk 3 - Financial
Unforeseen expenses, such as legal fees, security costs, or cost overruns on research and consulting services, could exceed the €15 million budget. Inflation or currency fluctuations (although EUR is the primary currency) could also impact the budget.

**Impact:** Project delays of 1-3 months due to budget constraints, reduced scope of the initiative, or the need to secure additional funding. Potential cost overruns of 5-10% (€750,000 - €1,500,000).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget with contingency funds to cover unforeseen expenses. Implement strict cost control measures and regularly monitor project spending. Explore opportunities to secure additional funding from external sources.

## Risk 4 - Operational
Coordinating the activities of multidisciplinary stakeholders (researchers, consultants, local authorities, animal welfare organizations) could be challenging, leading to delays and inefficiencies. Logistical challenges related to travel, accommodation, and meeting spaces in Pamplona could also arise.

**Impact:** Project delays of 2-4 weeks due to communication breakdowns and logistical challenges. Reduced efficiency and productivity of the project team. Increased administrative costs.

**Likelihood:** Medium

**Severity:** Low

**Action:** Establish clear roles and responsibilities for all stakeholders. Develop a detailed project schedule with milestones and deadlines. Implement effective communication and collaboration tools. Secure appropriate travel, accommodation, and meeting arrangements in Pamplona well in advance.

## Risk 5 - Security
Given the controversial nature of the project, there is a risk of security threats to project personnel, equipment, and facilities. Vandalism, protests, or even acts of violence could disrupt the project and endanger participants.

**Impact:** Project delays of 1-2 weeks due to security incidents. Increased security costs (estimated €30,000 - €60,000). Potential harm to project personnel and damage to equipment and facilities.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct a thorough security risk assessment and develop a security plan. Coordinate with local law enforcement to ensure adequate security measures are in place. Provide security training to project personnel. Implement access control measures to protect project facilities.

## Risk 6 - Environmental
While not immediately obvious, proposed changes to the event route or infrastructure could have unintended environmental consequences, such as disrupting local ecosystems or increasing pollution. Improper waste disposal during the event could also pose an environmental risk.

**Impact:** Project delays of 1-3 months due to environmental impact assessments and mitigation measures. Increased costs for environmental remediation. Damage to the project's reputation.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct an environmental impact assessment of proposed reforms. Implement measures to minimize environmental impacts, such as using sustainable materials and reducing waste. Engage with environmental organizations to address concerns.

## Risk 7 - Technical
If the reforms involve technical modifications to the bullring or event route, there could be unexpected technical challenges or delays in implementation. Integration with existing infrastructure may prove difficult.

**Impact:** Project delays of 2-4 weeks. Increased costs for technical modifications (estimated €25,000 - €50,000). Potential need to revise reform proposals.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct thorough technical feasibility studies before implementing any reforms. Engage with experienced engineers and contractors to ensure that technical modifications are feasible and safe. Develop contingency plans to address potential technical challenges.

## Risk summary
The Running of the Bulls Reform Initiative faces significant risks related to regulatory approvals, social acceptance, and financial management. The most critical risks are the potential for denial of permits due to cultural sensitivities and strong public opposition to reforms, both of which could significantly jeopardize the project's success. A proactive engagement strategy with local authorities and the public, coupled with a robust financial contingency plan, is crucial for mitigating these risks. Security risks, while less likely, also warrant careful attention due to their potential severity.