
## Documents to Create

### 1. Project Charter

**ID:** 29e34e2b-e557-4d1b-a9f0-fcf50b8a81c5

**Description:** Formal document authorizing the Running of the Bulls Reform Initiative, outlining its objectives, scope, stakeholders, and governance structure. It serves as a high-level agreement and reference point for the project.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project goals and objectives.
- Identify key stakeholders.
- Outline project scope and deliverables.
- Establish project governance structure.
- Define roles and responsibilities.
- Secure approval from relevant authorities.

**Approval Authorities:** Steering Committee

### 2. Risk Register

**ID:** 36d0b01f-1d9f-423f-803c-7d5e399ae4b4

**Description:** A comprehensive log of identified risks associated with the Running of the Bulls Reform Initiative, including their likelihood, impact, and mitigation strategies. It will be regularly updated throughout the project lifecycle.

**Responsible Role Type:** Risk and Security Coordinator

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.
- Regularly review and update the risk register.

**Approval Authorities:** Project Manager

### 3. Communication Plan

**ID:** a879c87d-e11d-4499-90a5-074ddddef281

**Description:** A detailed plan outlining how information will be communicated to stakeholders throughout the Running of the Bulls Reform Initiative. It specifies communication channels, frequency, and responsible parties.

**Responsible Role Type:** Communications and Public Relations Manager

**Primary Template:** Project Communication Plan Template

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication channels and frequency.
- Develop key messages.
- Assign responsibility for communication activities.
- Establish a process for monitoring and evaluating the effectiveness of communication.

**Approval Authorities:** Project Manager

### 4. Stakeholder Engagement Plan

**ID:** 50fbf607-3928-43e8-af97-f37a82a34be5

**Description:** A plan outlining strategies for engaging stakeholders throughout the Running of the Bulls Reform Initiative. It identifies stakeholders, their interests, and engagement methods.

**Responsible Role Type:** Stakeholder Liaison Manager

**Primary Template:** Stakeholder Engagement Plan Template

**Steps:**

- Identify key stakeholders and their interests.
- Assess stakeholder influence and impact.
- Develop engagement strategies for each stakeholder group.
- Establish a process for monitoring and evaluating the effectiveness of engagement.
- Define conflict resolution mechanisms.

**Approval Authorities:** Project Manager

### 5. Change Management Plan

**ID:** 72473ce0-922e-4738-8f2a-51c910271559

**Description:** A plan outlining the process for managing changes to the Running of the Bulls event protocols. It defines how changes will be identified, assessed, approved, and implemented.

**Responsible Role Type:** Project Manager

**Primary Template:** Change Management Plan Template

**Steps:**

- Define the change management process.
- Establish a change control board.
- Develop a process for assessing the impact of proposed changes.
- Define approval authorities for changes.
- Establish a process for communicating changes to stakeholders.

**Approval Authorities:** Steering Committee

### 6. High-Level Budget/Funding Framework

**ID:** 22a7795f-dc47-4541-9b45-9898a25fc2de

**Description:** A high-level overview of the project budget, including funding sources, allocation of funds to different project activities, and contingency planning. It provides a financial roadmap for the initiative.

**Responsible Role Type:** Financial Risk Analyst

**Primary Template:** Project Budget Template

**Steps:**

- Identify all project costs.
- Allocate costs to different project activities.
- Identify potential funding sources.
- Develop a contingency plan for unforeseen expenses.
- Establish a process for tracking and reporting on project expenses.

**Approval Authorities:** Steering Committee

### 7. Funding Agreement Structure/Template

**ID:** b36ebd1a-3722-4230-a0ea-f392853d3c93

**Description:** A template for structuring agreements with funding organizations, outlining the terms and conditions of funding, reporting requirements, and intellectual property rights. This ensures clear and legally sound funding arrangements.

**Responsible Role Type:** Legal and Regulatory Advisor

**Primary Template:** Standard Funding Agreement Template

**Steps:**

- Define the terms and conditions of funding.
- Establish reporting requirements.
- Define intellectual property rights.
- Include clauses for dispute resolution.
- Ensure compliance with all applicable laws and regulations.

**Approval Authorities:** Legal Counsel, Steering Committee

### 8. Initial High-Level Schedule/Timeline

**ID:** c1a0099c-606f-4fe2-98a9-bd716a50037e

**Description:** A high-level timeline outlining the key milestones and deadlines for the Running of the Bulls Reform Initiative. It provides a roadmap for project execution and helps track progress.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key project milestones.
- Define the duration of each milestone.
- Establish dependencies between milestones.
- Assign responsibility for completing each milestone.
- Regularly review and update the timeline.

**Approval Authorities:** Project Manager

### 9. M&E Framework

**ID:** 9d2e1099-6331-4736-8c5c-5eb18489811c

**Description:** A framework outlining how the impact of the Running of the Bulls Reform Initiative will be monitored and evaluated. It defines key performance indicators (KPIs), data collection methods, and reporting requirements.

**Responsible Role Type:** Monitoring and Evaluation Specialist

**Primary Template:** Logical Framework Template

**Steps:**

- Define project goals and objectives.
- Identify key performance indicators (KPIs).
- Develop data collection methods.
- Establish reporting requirements.
- Define a process for analyzing and interpreting data.

**Approval Authorities:** Project Manager

### 10. Animal Welfare Improvement Framework

**ID:** e7a2d710-e342-4063-b197-32997682fa96

**Description:** A framework outlining the strategy for improving animal welfare during the Running of the Bulls event. It defines specific goals, objectives, and actions to minimize animal suffering.

**Responsible Role Type:** Animal Welfare Specialist

**Primary Template:** Animal Welfare Strategy Template

**Steps:**

- Assess current animal welfare practices.
- Define specific, measurable animal welfare standards.
- Develop actions to improve animal welfare.
- Establish a monitoring and evaluation plan.
- Consult with animal welfare experts.

**Approval Authorities:** Animal Welfare Ethologist, Steering Committee

### 11. Cultural Heritage Preservation Strategy

**ID:** 7972a99a-e16f-4caf-b863-dfb2042a2b62

**Description:** A strategy outlining how the cultural significance of the Running of the Bulls event will be preserved while implementing reforms. It defines actions to respect and protect local traditions.

**Responsible Role Type:** Cultural Heritage Consultant

**Primary Template:** Cultural Heritage Management Plan Template

**Steps:**

- Assess the cultural significance of the event.
- Identify key cultural elements to preserve.
- Develop actions to protect cultural heritage.
- Consult with local community members.
- Ensure reforms are culturally sensitive.

**Approval Authorities:** Cultural Heritage Consultant, Steering Committee

### 12. Current State Assessment of Animal Welfare Practices

**ID:** 81ea8215-77bd-4d4b-b29a-844a88a8b0f0

**Description:** A report detailing the current animal welfare practices during the Running of the Bulls, including injury rates, stress levels, and handling procedures. This assessment will serve as a baseline for measuring the impact of reforms.

**Responsible Role Type:** Animal Welfare Specialist

**Primary Template:** Assessment Report Template

**Steps:**

- Collect data on animal injury rates.
- Assess animal handling procedures.
- Measure animal stress levels.
- Interview event organizers and participants.
- Document current practices.

**Approval Authorities:** Animal Welfare Ethologist, Project Manager

### 13. Ethical Framework Document

**ID:** 7458eff4-1180-4d68-80c2-ab7a0c2d20c2

**Description:** A document outlining the ethical principles that will guide the project's decision-making process, including considerations for animal welfare, cultural heritage, and stakeholder interests. It provides a moral compass for the initiative.

**Responsible Role Type:** Animal Welfare Specialist

**Primary Template:** Ethical Framework Template

**Steps:**

- Define ethical principles.
- Identify conflicting values.
- Develop a decision-making process.
- Consult with ethicists.
- Document ethical considerations.

**Approval Authorities:** Animal Welfare Ethologist, Steering Committee

## Documents to Find

### 1. Pamplona Running of the Bulls Historical Event Data

**ID:** 91ec1e92-61e7-4dbd-9bef-8519128f87dd

**Description:** Historical data on the Running of the Bulls event in Pamplona, including participant demographics, event attendance, and economic impact. This data will provide context for the project and inform decision-making.

**Recency Requirement:** At least 10 years of historical data

**Responsible Role Type:** Project Manager

**Access Difficulty:** Medium: Requires contacting local authorities and searching archives.

**Steps:**

- Contact the Pamplona City Council.
- Search local archives and libraries.
- Review academic publications on the event.

### 2. Existing Pamplona Local Ordinances Related to the Running of the Bulls

**ID:** e7bf60d7-5535-4a03-bfd2-0d5e55c6e037

**Description:** Existing local ordinances in Pamplona related to the Running of the Bulls, including regulations on event safety, animal handling, and public order. These ordinances will inform the project's legal and regulatory framework.

**Recency Requirement:** Current and all amendments

**Responsible Role Type:** Legal and Regulatory Advisor

**Access Difficulty:** Medium: Requires searching local government websites and potentially contacting legal experts.

**Steps:**

- Search the Pamplona City Council website.
- Contact the Pamplona City Council legal department.
- Consult with local legal experts.

### 3. Existing Spanish Animal Welfare Laws and Regulations

**ID:** 96a4d237-b6e6-4bf7-93a3-4f1c2c177d41

**Description:** Existing Spanish animal welfare laws and regulations, including those related to the treatment of bulls and other animals in sporting events. These laws will inform the project's animal welfare standards.

**Recency Requirement:** Current and all amendments

**Responsible Role Type:** Legal and Regulatory Advisor

**Access Difficulty:** Medium: Requires searching government databases and potentially contacting legal experts.

**Steps:**

- Search the Spanish government's legislative database.
- Contact the Spanish Ministry of Agriculture, Fisheries and Food.
- Consult with Spanish legal experts.

### 4. Participating Nations Animal Injury Statistical Data

**ID:** f8e525c3-6c72-4afe-84e1-19362d8baaca

**Description:** Statistical data on animal injuries during the Running of the Bulls event, including the type and severity of injuries. This data will provide a baseline for measuring the impact of reforms.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Animal Welfare Specialist

**Access Difficulty:** Medium: Requires contacting local organizations and reviewing event records.

**Steps:**

- Contact local veterinary clinics.
- Review event records.
- Consult with animal welfare organizations.

### 5. Official National Tourism Revenue Data for Pamplona

**ID:** 694c3033-fdaa-4172-8520-68e81d7679af

**Description:** Data on tourism revenue generated by the Running of the Bulls event in Pamplona, including visitor spending, hotel occupancy rates, and economic impact on local businesses. This data will inform the project's economic impact assessment.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Financial Risk Analyst

**Access Difficulty:** Medium: Requires contacting government agencies and reviewing economic reports.

**Steps:**

- Contact the Spanish Ministry of Tourism.
- Contact the Pamplona City Council tourism department.
- Review economic reports on the event.

### 6. Official National Public Opinion Survey Data on Animal Welfare

**ID:** 8213059a-b30e-4f5d-b008-ed876b4eeaec

**Description:** Survey data on public opinion regarding animal welfare in Spain, including attitudes towards the use of animals in sporting events. This data will inform the project's communication strategy.

**Recency Requirement:** Last 3 years

**Responsible Role Type:** Communications and Public Relations Manager

**Access Difficulty:** Medium: Requires searching government databases and contacting polling organizations.

**Steps:**

- Search the Spanish government's survey database.
- Contact polling organizations.
- Review academic publications on public opinion.

### 7. Existing EU Animal Welfare Standards

**ID:** bbad2222-2e77-4dc7-a15e-424091ac1ec9

**Description:** Existing EU animal welfare standards and directives relevant to the treatment of animals, even if not directly applicable to bullfighting. These standards can inform best practices and ethical considerations.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Regulatory Advisor

**Access Difficulty:** Easy: Publicly available on the European Commission's website.

**Steps:**

- Search the European Commission's website.
- Consult with EU legal experts.
- Review relevant EU directives and regulations.

### 8. Official National Data on Alternative Economic Opportunities in Pamplona

**ID:** ea92d104-96af-46ab-b04d-6acc2f6b5dc5

**Description:** Data on alternative economic opportunities in Pamplona, such as ecotourism, sustainable agriculture, and other industries that could provide livelihoods for communities dependent on the Running of the Bulls. This data will inform the project's economic diversification strategy.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Financial Risk Analyst

**Access Difficulty:** Medium: Requires contacting government agencies and reviewing economic reports.

**Steps:**

- Contact the Spanish Ministry of Economy.
- Contact the Pamplona City Council economic development department.
- Review economic reports on the region.

### 9. Official National Security Incident Data for Pamplona Events

**ID:** 89d0ebb7-6f80-4c42-8103-8f918d8102b8

**Description:** Data on security incidents during past Running of the Bulls events, including types of incidents, frequency, and response protocols. This data will inform the project's security plan.

**Recency Requirement:** Last 5 years

**Responsible Role Type:** Risk and Security Coordinator

**Access Difficulty:** Hard: Requires contacting law enforcement and accessing potentially sensitive data.

**Steps:**

- Contact local law enforcement agencies.
- Review event security records.
- Consult with security experts.

### 10. Official National Environmental Impact Assessment Regulations

**ID:** 01f4b7ac-6841-4a98-8a54-5d7f476db07e

**Description:** Regulations and guidelines for conducting environmental impact assessments in Spain, including requirements for assessing the environmental impact of events like the Running of the Bulls. This will inform the project's environmental impact assessment.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Regulatory Advisor

**Access Difficulty:** Medium: Requires searching government databases and potentially contacting legal experts.

**Steps:**

- Search the Spanish government's environmental regulations database.
- Contact the Spanish Ministry for Ecological Transition.
- Consult with environmental law experts.