# Documents to Create

## Create Document 1: Project Charter

**ID**: 29e34e2b-e557-4d1b-a9f0-fcf50b8a81c5

**Description**: Formal document authorizing the Running of the Bulls Reform Initiative, outlining its objectives, scope, stakeholders, and governance structure. It serves as a high-level agreement and reference point for the project.

**Responsible Role Type**: Project Manager

**Primary Template**: PMI Project Charter Template

**Secondary Template**: None

**Steps to Create**:

- Define project goals and objectives.
- Identify key stakeholders.
- Outline project scope and deliverables.
- Establish project governance structure.
- Define roles and responsibilities.
- Secure approval from relevant authorities.

**Approval Authorities**: Steering Committee

**Essential Information**:

- What are the specific, measurable, achievable, relevant, and time-bound (SMART) goals and objectives of the Running of the Bulls Reform Initiative?
- Who are the key stakeholders (primary and secondary) and what are their roles, responsibilities, and levels of influence?
- What is the detailed project scope, including in-scope and out-of-scope items, and what are the key deliverables?
- What is the project governance structure, including the decision-making process, escalation paths, and reporting requirements?
- What are the high-level project risks, assumptions, and constraints?
- What is the allocated budget and how is it distributed across different project phases and activities?
- What is the project timeline, including key milestones and deadlines?
- What are the criteria for project success and how will they be measured?
- A section detailing the project's alignment with organizational strategy and objectives.
- A section outlining the project's benefits and how they will be realized.

**Risks of Poor Quality**:

- Unclear project objectives lead to scope creep and misalignment among stakeholders.
- Inadequate stakeholder identification results in resistance and delays.
- Poorly defined scope leads to rework and budget overruns.
- Lack of a clear governance structure results in decision-making bottlenecks and conflicts.
- Unrealistic assumptions lead to project failure.
- Insufficient budget allocation leads to resource constraints and compromised quality.
- Unrealistic timeline leads to missed deadlines and increased pressure on the project team.
- Ambiguous success criteria make it difficult to assess project performance and impact.

**Worst Case Scenario**: The project fails to secure necessary approvals due to stakeholder opposition and lack of a clear governance structure, resulting in the abandonment of the Running of the Bulls Reform Initiative and significant financial losses.

**Best Case Scenario**: The Project Charter clearly defines the project's objectives, scope, and governance structure, enabling efficient decision-making, effective stakeholder engagement, and successful implementation of the Running of the Bulls Reform Initiative, leading to improved animal welfare standards and enhanced cultural heritage preservation.

**Fallback Alternative Approaches**:

- Utilize a simplified project initiation document focusing on core objectives and stakeholders.
- Conduct a series of workshops with key stakeholders to collaboratively define the project scope and governance structure.
- Engage a project management consultant to facilitate the development of the Project Charter.
- Adopt an agile approach, creating a 'minimum viable charter' and iterating based on feedback and learnings.

## Create Document 2: Risk Register

**ID**: 36d0b01f-1d9f-423f-803c-7d5e399ae4b4

**Description**: A comprehensive log of identified risks associated with the Running of the Bulls Reform Initiative, including their likelihood, impact, and mitigation strategies. It will be regularly updated throughout the project lifecycle.

**Responsible Role Type**: Risk and Security Coordinator

**Primary Template**: PMI Risk Register Template

**Secondary Template**: None

**Steps to Create**:

- Identify potential risks.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for each risk.
- Assign responsibility for monitoring and managing each risk.
- Regularly review and update the risk register.

**Approval Authorities**: Project Manager

**Essential Information**:

- Identify all potential risks associated with the Running of the Bulls Reform Initiative across all project phases (assessment, planning, implementation, evaluation).
- For each identified risk, quantify the likelihood of occurrence (e.g., High, Medium, Low or a numerical probability).
- For each identified risk, assess the potential impact on the project in terms of cost (EUR), schedule (days/weeks), scope, and quality (using defined metrics).
- Develop specific and actionable mitigation strategies for each identified risk, including preventative and reactive measures.
- Assign a responsible individual or role for monitoring each risk and implementing the mitigation strategy.
- Define triggers or warning signs that indicate a risk is becoming more likely or is materializing.
- Document the current status of each risk (e.g., Open, In Progress, Closed).
- Include a risk score calculation (Likelihood x Impact) to prioritize risks.
- Detail the assumptions used in assessing the likelihood and impact of each risk.
- Specify the source of information used to identify and assess each risk (e.g., stakeholder interviews, historical data, expert opinions).
- Categorize risks by type (e.g., Regulatory, Social, Financial, Operational, Security, Environmental, Technical).
- Requires access to the project plan, stakeholder analysis, budget, timeline, and regulatory requirements documents.
- Requires input from all key stakeholders, including event organizers, animal welfare organizations, local community representatives, and government agencies.

**Risks of Poor Quality**:

- Failure to identify critical risks leads to unexpected project delays and cost overruns.
- Inaccurate risk assessments result in ineffective mitigation strategies and increased project vulnerability.
- Lack of assigned responsibility for risk monitoring leads to delayed responses and escalation of issues.
- An outdated risk register fails to reflect the current project environment and emerging threats.
- Poorly defined mitigation strategies result in inadequate risk response and increased negative impacts.
- Incomplete risk register leads to overlooking potential threats, resulting in project failure.

**Worst Case Scenario**: A major, unmitigated risk (e.g., denial of permits, significant public opposition, security breach) forces the complete cancellation of the Running of the Bulls Reform Initiative, resulting in a loss of €15 million in funding, reputational damage, and failure to improve animal welfare standards.

**Best Case Scenario**: The Risk Register enables proactive identification and mitigation of potential issues, leading to successful implementation of the Running of the Bulls Reform Initiative within budget and timeline, improved animal welfare standards, increased public support, and a sustainable future for the event. Enables informed decision-making regarding resource allocation and contingency planning.

**Fallback Alternative Approaches**:

- Conduct a rapid risk assessment workshop with key stakeholders to identify the most critical risks and mitigation strategies.
- Utilize a simplified risk assessment matrix focusing on high-level risks and mitigation actions.
- Adapt a pre-existing risk register from a similar cultural or societal initiative.
- Engage a risk management consultant to facilitate the risk identification and assessment process.

## Create Document 3: Stakeholder Engagement Plan

**ID**: 50fbf607-3928-43e8-af97-f37a82a34be5

**Description**: A plan outlining strategies for engaging stakeholders throughout the Running of the Bulls Reform Initiative. It identifies stakeholders, their interests, and engagement methods.

**Responsible Role Type**: Stakeholder Liaison Manager

**Primary Template**: Stakeholder Engagement Plan Template

**Secondary Template**: None

**Steps to Create**:

- Identify key stakeholders and their interests.
- Assess stakeholder influence and impact.
- Develop engagement strategies for each stakeholder group.
- Establish a process for monitoring and evaluating the effectiveness of engagement.
- Define conflict resolution mechanisms.

**Approval Authorities**: Project Manager

**Essential Information**:

- Identify all primary and secondary stakeholders, including event organizers, animal welfare organizations, local community members, government agencies, tourists, regulatory bodies, bull breeders, tourism operators, and political factions.
- Assess the interests, influence, and potential impact (positive or negative) of each stakeholder group on the Running of the Bulls Reform Initiative.
- Define specific engagement strategies tailored to each stakeholder group, including the frequency, method (e.g., meetings, surveys, workshops), and content of communication.
- Detail the communication channels to be used for each stakeholder group (e.g., email, website, social media, public forums).
- Establish a clear process for monitoring and evaluating the effectiveness of stakeholder engagement activities, including metrics for measuring engagement levels and satisfaction.
- Define conflict resolution mechanisms to address and resolve disagreements or conflicts among stakeholders.
- Outline a plan for proactively addressing potential concerns or resistance from stakeholders, including strategies for mitigating negative impacts.
- Specify roles and responsibilities for stakeholder engagement activities within the project team.
- Include a timeline for stakeholder engagement activities throughout the project lifecycle.
- Detail how stakeholder feedback will be incorporated into project decisions and outcomes.
- Based on the stakeholder analysis, determine the level of engagement required for each stakeholder group (e.g., inform, consult, involve, collaborate, empower).
- Identify potential incentives for stakeholders to support the reform initiative, particularly for those who may be negatively impacted by the changes (e.g., bull breeders).
- Define the criteria for success in stakeholder engagement, such as increased support for the initiative, reduced conflict, or improved collaboration.

**Risks of Poor Quality**:

- Stakeholder resistance and opposition to the reform initiative, leading to delays or project failure.
- Negative media coverage and public backlash due to perceived lack of stakeholder consultation.
- Misunderstandings and conflicts among stakeholders, hindering collaboration and progress.
- Failure to address stakeholder concerns, resulting in decreased support for the initiative.
- Ineffective communication, leading to misinformation and mistrust.
- Delays in obtaining necessary permits and approvals due to lack of stakeholder buy-in.
- Increased project costs due to the need for additional stakeholder engagement efforts.
- Damage to the project's reputation and credibility.
- Legal challenges or lawsuits from dissatisfied stakeholders.

**Worst Case Scenario**: The project faces widespread public opposition, leading to protests, boycotts, and legal challenges that ultimately force the cancellation of the Running of the Bulls Reform Initiative, resulting in a significant financial loss and reputational damage.

**Best Case Scenario**: The Stakeholder Engagement Plan fosters strong collaboration and support among all stakeholders, leading to the successful implementation of animal welfare reforms while preserving cultural heritage, resulting in increased public support, positive media coverage, and a sustainable future for the Running of the Bulls event. Enables informed decisions on resource allocation and project direction based on stakeholder feedback.

**Fallback Alternative Approaches**:

- Conduct a rapid stakeholder assessment using existing data and publicly available information to identify key stakeholders and their interests.
- Utilize a simplified stakeholder engagement framework with a focus on informing and consulting key stakeholders through targeted communication channels.
- Prioritize engagement with the most influential stakeholders and those who are most likely to be negatively impacted by the reforms.
- Develop a 'minimum viable engagement plan' focusing on essential communication and feedback mechanisms.
- Engage a consultant specializing in stakeholder engagement to provide guidance and support.
- Utilize a pre-approved company template for stakeholder engagement plans and adapt it to the specific context of the Running of the Bulls Reform Initiative.

## Create Document 4: High-Level Budget/Funding Framework

**ID**: 22a7795f-dc47-4541-9b45-9898a25fc2de

**Description**: A high-level overview of the project budget, including funding sources, allocation of funds to different project activities, and contingency planning. It provides a financial roadmap for the initiative.

**Responsible Role Type**: Financial Risk Analyst

**Primary Template**: Project Budget Template

**Secondary Template**: None

**Steps to Create**:

- Identify all project costs.
- Allocate costs to different project activities.
- Identify potential funding sources.
- Develop a contingency plan for unforeseen expenses.
- Establish a process for tracking and reporting on project expenses.

**Approval Authorities**: Steering Committee

**Essential Information**:

- What are the specific funding sources for the €15 million budget (e.g., government grants, private donations, sponsorships)?
- Detail the allocation of funds across the major project phases (Assessment & Planning, Implementation, Evaluation) and key activities (Animal Welfare Improvements, Stakeholder Engagement, Monitoring & Evaluation).
- Quantify the contingency budget (€50,000 currently) and define the criteria for its use.
- What are the key assumptions underlying the budget projections (e.g., inflation rate, exchange rates, resource costs)?
- Identify the process for budget monitoring, reporting, and approval of budget changes.
- What are the specific cost categories included within 'Animal Welfare Improvements' (e.g., veterinary services, facility upgrades, equipment)?
- What are the specific cost categories included within 'Stakeholder Engagement' (e.g., public forums, workshops, translation services)?
- What are the specific cost categories included within 'Monitoring & Evaluation' (e.g., data collection, analysis, reporting)?
- Detail the payment schedule and milestones linked to funding disbursement.
- Identify the individuals or roles responsible for budget management and financial reporting.

**Risks of Poor Quality**:

- Inaccurate budget projections lead to funding shortfalls and project delays.
- Lack of clarity on funding sources results in difficulty securing necessary resources.
- Poorly defined cost categories make it difficult to track expenses and manage the budget effectively.
- Insufficient contingency planning leaves the project vulnerable to unforeseen expenses.
- Inadequate budget monitoring and reporting leads to cost overruns and financial mismanagement.

**Worst Case Scenario**: The project runs out of funding due to poor budget planning and unforeseen expenses, leading to project termination and reputational damage.

**Best Case Scenario**: The project secures all necessary funding, manages the budget effectively, and achieves its goals within budget, demonstrating financial responsibility and attracting future investment.

**Fallback Alternative Approaches**:

- Develop a phased funding approach, securing funding for Phase 1 (Assessment & Planning) initially.
- Utilize a simplified budget template initially and refine it as more information becomes available.
- Conduct a benchmarking exercise to compare the budget with similar projects.
- Engage a financial consultant to review the budget and identify potential cost savings.
- Prioritize essential project activities and defer non-essential activities if funding is limited.

## Create Document 5: Animal Welfare Improvement Framework

**ID**: e7a2d710-e342-4063-b197-32997682fa96

**Description**: A framework outlining the strategy for improving animal welfare during the Running of the Bulls event. It defines specific goals, objectives, and actions to minimize animal suffering.

**Responsible Role Type**: Animal Welfare Specialist

**Primary Template**: Animal Welfare Strategy Template

**Secondary Template**: None

**Steps to Create**:

- Assess current animal welfare practices.
- Define specific, measurable animal welfare standards.
- Develop actions to improve animal welfare.
- Establish a monitoring and evaluation plan.
- Consult with animal welfare experts.

**Approval Authorities**: Animal Welfare Ethologist, Steering Committee

**Essential Information**:

- What are the specific, measurable, achievable, relevant, and time-bound (SMART) goals for animal welfare improvement during the Running of the Bulls?
- What are the key performance indicators (KPIs) that will be used to track progress towards these goals?
- Detail the specific actions that will be taken to improve animal welfare, including modifications to event practices, infrastructure, and animal handling procedures.
- What are the EU Animal Welfare Standards that are applicable to the Running of the Bulls?
- What are the specific Spanish Animal Welfare Laws that are applicable to the Running of the Bulls?
- Describe the monitoring and evaluation plan, including data collection methods, frequency of monitoring, and reporting mechanisms.
- Identify the roles and responsibilities of individuals and organizations involved in implementing the animal welfare improvement framework.
- What are the resource requirements (budget, personnel, equipment) for implementing the framework?
- Detail the risk mitigation strategies for potential challenges to improving animal welfare, such as stakeholder resistance or unexpected costs.
- What are the ethical considerations related to animal welfare in the context of the Running of the Bulls?
- Requires consultation with animal welfare experts and ethologists to ensure the framework is based on scientific evidence and best practices.
- Requires a section detailing how the framework aligns with the project's overall goal of balancing cultural heritage with animal welfare standards.
- Requires a section detailing the process for addressing concerns raised by stakeholders regarding animal welfare.
- Requires a section detailing the process for independent monitoring of animal welfare during the event.

**Risks of Poor Quality**:

- Failure to define clear and measurable animal welfare standards leads to disagreements among stakeholders and difficulty in assessing the success of the initiative.
- Lack of a comprehensive monitoring and evaluation plan results in an inability to track progress and identify areas for improvement.
- Insufficient stakeholder engagement leads to resistance and delays in implementing animal welfare improvements.
- Inadequate resource allocation hinders the effective implementation of the framework.
- Failure to address ethical considerations damages the project's reputation and undermines public support.

**Worst Case Scenario**: The initiative fails to improve animal welfare, leading to continued animal suffering, negative media coverage, public backlash, and potential legal challenges, ultimately jeopardizing the future of the Running of the Bulls event.

**Best Case Scenario**: The framework leads to significant and measurable improvements in animal welfare, enhancing the event's reputation, increasing public support, and ensuring its long-term sustainability while respecting cultural heritage. Enables informed decisions on resource allocation and future event protocols.

**Fallback Alternative Approaches**:

- Utilize a pre-approved animal welfare strategy template from a reputable organization and adapt it to the specific context of the Running of the Bulls.
- Schedule a focused workshop with animal welfare experts, event organizers, and other key stakeholders to collaboratively define animal welfare standards and actions.
- Engage an animal welfare consultant to develop a 'minimum viable framework' covering only the most critical elements initially, with the option to expand it later.
- Conduct a rapid literature review of best practices in animal welfare for similar events and adapt those practices to the Running of the Bulls.

## Create Document 6: Current State Assessment of Animal Welfare Practices

**ID**: 81ea8215-77bd-4d4b-b29a-844a88a8b0f0

**Description**: A report detailing the current animal welfare practices during the Running of the Bulls, including injury rates, stress levels, and handling procedures. This assessment will serve as a baseline for measuring the impact of reforms.

**Responsible Role Type**: Animal Welfare Specialist

**Primary Template**: Assessment Report Template

**Secondary Template**: None

**Steps to Create**:

- Collect data on animal injury rates.
- Assess animal handling procedures.
- Measure animal stress levels.
- Interview event organizers and participants.
- Document current practices.

**Approval Authorities**: Animal Welfare Ethologist, Project Manager

**Essential Information**:

- Quantify the current injury rates for bulls during the Running of the Bulls event, differentiating between types of injuries (e.g., broken bones, lacerations, stress-related injuries).
- Detail the existing animal handling procedures from the moment the bulls arrive in Pamplona to their departure, including transportation, penning, and release into the arena.
- Measure and document the physiological stress levels of the bulls before, during, and after the event, using indicators such as cortisol levels, heart rate variability, and behavioral observations.
- Conduct structured interviews with event organizers, bull breeders, veterinarians, and participants to gather qualitative data on current animal welfare practices and perceptions.
- Provide a comprehensive description of the physical environment where the bulls are kept, including pen size, access to food and water, and environmental enrichment.
- Identify and document all existing protocols and regulations related to animal welfare during the event, including local, regional, and national laws.
- Analyze the existing veterinary care provided to the bulls, including preventative measures, emergency treatment, and post-event care.
- Based on the data collected, identify the key areas of concern regarding animal welfare during the Running of the Bulls.
- Requires access to historical data on animal injuries, veterinary records, and event protocols.
- Requires on-site observation of animal handling procedures and environmental conditions.
- Requires ethical approval for any procedures involving animal handling or physiological measurements.

**Risks of Poor Quality**:

- Inaccurate assessment of current practices leads to ineffective reforms that fail to address the root causes of animal suffering.
- Incomplete data collection results in a biased understanding of the situation, potentially overlooking critical areas for improvement.
- Lack of stakeholder input leads to reforms that are not culturally sensitive or practically feasible.
- Failure to establish a clear baseline makes it impossible to accurately measure the impact of future reforms.
- An inadequate assessment prevents securing buy-in from animal welfare organizations, leading to continued public opposition.

**Worst Case Scenario**: The reforms implemented based on a flawed assessment fail to improve animal welfare, leading to increased public outrage, potential legal challenges, and the cancellation of the Running of the Bulls event, resulting in significant economic and cultural losses.

**Best Case Scenario**: The assessment provides a comprehensive and accurate understanding of current animal welfare practices, enabling the development and implementation of targeted reforms that significantly reduce animal suffering while preserving the cultural heritage of the event. This leads to increased public support, improved relations with animal welfare organizations, and a sustainable future for the Running of the Bulls.

**Fallback Alternative Approaches**:

- Conduct a rapid literature review of existing research on animal welfare during similar events to identify potential areas of concern and best practices.
- Organize a workshop with animal welfare experts to develop a preliminary assessment framework based on available knowledge.
- Utilize publicly available data and reports from animal welfare organizations to create a high-level overview of current practices.
- Focus the initial assessment on a limited number of key indicators, such as injury rates and stress levels, to provide a focused and actionable overview.


# Documents to Find

## Find Document 1: Existing Pamplona Local Ordinances Related to the Running of the Bulls

**ID**: e7bf60d7-5535-4a03-bfd2-0d5e55c6e037

**Description**: Existing local ordinances in Pamplona related to the Running of the Bulls, including regulations on event safety, animal handling, and public order. These ordinances will inform the project's legal and regulatory framework.

**Recency Requirement**: Current and all amendments

**Responsible Role Type**: Legal and Regulatory Advisor

**Steps to Find**:

- Search the Pamplona City Council website.
- Contact the Pamplona City Council legal department.
- Consult with local legal experts.

**Access Difficulty**: Medium: Requires searching local government websites and potentially contacting legal experts.

**Essential Information**:

- List all current Pamplona local ordinances directly pertaining to the Running of the Bulls.
- Detail specific regulations regarding event safety measures (e.g., barrier placement, emergency services access).
- Describe all animal handling regulations currently in place (e.g., pre-event veterinary checks, post-event treatment).
- Outline regulations concerning public order and safety during the event (e.g., alcohol consumption, crowd control).
- Identify any recent amendments or pending changes to these ordinances.
- Clarify the enforcement mechanisms and penalties for violations of these ordinances.
- Determine the process for obtaining waivers or exemptions from specific ordinances, if any.
- Provide official Spanish and certified English translations of all relevant ordinances.

**Risks of Poor Quality**:

- Project may propose reforms that conflict with existing legal requirements, leading to rejection by local authorities.
- Failure to understand current regulations could result in non-compliance and legal challenges.
- Inaccurate or outdated information could lead to flawed risk assessments and mitigation strategies.
- Misinterpretation of ordinances could result in inadequate safety measures and increased risk of injury.

**Worst Case Scenario**: The project proposes reforms that are illegal under existing Pamplona ordinances, leading to immediate rejection by the city council, significant financial losses due to wasted resources, and reputational damage for the initiative.

**Best Case Scenario**: The project has a comprehensive understanding of all relevant local ordinances, enabling the development of legally sound and politically feasible reforms that are readily accepted by the Pamplona City Council, leading to successful implementation and improved event safety and animal welfare.

**Fallback Alternative Approaches**:

- Engage a Pamplona-based legal firm specializing in local ordinances to conduct a comprehensive review and provide expert interpretation.
- Request a formal briefing from the Pamplona City Council legal department on the relevant ordinances and their application to the Running of the Bulls.
- Purchase a comprehensive legal database that includes up-to-date Pamplona local ordinances and legal precedents.
- Conduct targeted interviews with local event organizers and law enforcement officials to gather practical insights into the enforcement of these ordinances.

## Find Document 2: Existing Spanish Animal Welfare Laws and Regulations

**ID**: 96a4d237-b6e6-4bf7-93a3-4f1c2c177d41

**Description**: Existing Spanish animal welfare laws and regulations, including those related to the treatment of bulls and other animals in sporting events. These laws will inform the project's animal welfare standards.

**Recency Requirement**: Current and all amendments

**Responsible Role Type**: Legal and Regulatory Advisor

**Steps to Find**:

- Search the Spanish government's legislative database.
- Contact the Spanish Ministry of Agriculture, Fisheries and Food.
- Consult with Spanish legal experts.

**Access Difficulty**: Medium: Requires searching government databases and potentially contacting legal experts.

**Essential Information**:

- List all relevant Spanish national and regional laws pertaining to animal welfare, specifically those applicable to bulls and their treatment in sporting events.
- Detail the specific requirements and prohibitions outlined in these laws regarding animal handling, transportation, and treatment during events like the Running of the Bulls.
- Identify the government agencies responsible for enforcing these laws and the penalties for non-compliance.
- Summarize any recent amendments or legal challenges to these laws that may impact the project.
- Provide official Spanish and certified English translations of the relevant legal texts.
- Clarify the legal definition of 'cruelty' and 'acceptable treatment' of bulls within the context of Spanish law.
- Outline any specific exemptions or exceptions to animal welfare laws that may apply to traditional cultural events.

**Risks of Poor Quality**:

- Incorrect interpretation of legal requirements leading to non-compliance and potential legal action.
- Failure to meet minimum animal welfare standards resulting in negative media coverage and public backlash.
- Project delays due to the need to revise protocols to comply with overlooked legal requirements.
- Financial penalties or legal challenges due to violations of animal welfare laws.
- Damage to the project's reputation and loss of stakeholder trust.

**Worst Case Scenario**: The project implements reforms that are later deemed non-compliant with Spanish animal welfare laws, resulting in legal action, significant financial penalties, project shutdown, and severe reputational damage.

**Best Case Scenario**: The project's animal welfare standards are fully aligned with and exceed Spanish legal requirements, leading to positive media coverage, increased public support, and recognition as a model for ethical cultural event management.

**Fallback Alternative Approaches**:

- Engage a Spanish legal expert specializing in animal welfare law to provide a formal legal opinion.
- Purchase a comprehensive legal database subscription that includes up-to-date Spanish legislation.
- Contact the EU Animal Welfare Platform for guidance on relevant EU standards and their relationship to Spanish law.
- Commission a detailed legal review from a reputable Spanish law firm.
- Consult with animal welfare organizations operating in Spain for their interpretation of the relevant laws.

## Find Document 3: Participating Nations Animal Injury Statistical Data

**ID**: f8e525c3-6c72-4afe-84e1-19362d8baaca

**Description**: Statistical data on animal injuries during the Running of the Bulls event, including the type and severity of injuries. This data will provide a baseline for measuring the impact of reforms.

**Recency Requirement**: Last 5 years

**Responsible Role Type**: Animal Welfare Specialist

**Steps to Find**:

- Contact local veterinary clinics.
- Review event records.
- Consult with animal welfare organizations.

**Access Difficulty**: Medium: Requires contacting local organizations and reviewing event records.

**Essential Information**:

- Quantify the number of bulls injured during each Running of the Bulls event for the last 5 years.
- Categorize the types of injuries sustained by bulls (e.g., broken bones, lacerations, stress-related injuries).
- Detail the severity of each injury type (e.g., minor, moderate, severe) using a standardized scoring system.
- Identify the specific sections of the bull run route where injuries are most frequent.
- Compare injury rates across different years to identify trends or patterns.
- Provide data on any fatalities among bulls during the event.
- Include information on the methodology used to collect and verify the injury data (e.g., veterinary reports, observer accounts).

**Risks of Poor Quality**:

- Inaccurate injury data leads to flawed baseline measurements and ineffective reform strategies.
- Incomplete data prevents accurate assessment of the impact of implemented changes.
- Biased or manipulated data undermines the credibility of the initiative and stakeholder trust.
- Lack of standardized injury classification hinders meaningful comparisons across years.
- Failure to identify injury hotspots prevents targeted interventions.

**Worst Case Scenario**: The initiative implements reforms based on faulty data, leading to no actual improvement in animal welfare, continued public outcry, and potential legal challenges, ultimately resulting in the project's failure and reputational damage.

**Best Case Scenario**: Accurate and comprehensive injury data enables the development and implementation of highly effective reforms, significantly reducing animal suffering, increasing public support for the event, and establishing Pamplona as a leader in ethical cultural event management.

**Fallback Alternative Approaches**:

- Engage an independent veterinary research team to conduct a new, comprehensive injury assessment during the next Running of the Bulls event.
- Conduct targeted interviews with veterinarians, event staff, and animal welfare observers to gather qualitative data on animal injuries.
- Purchase access to relevant databases or reports from international animal welfare organizations that may contain comparable data from similar events.
- Develop a predictive model of injury risk based on route characteristics, bull characteristics, and participant behavior, using available historical data and expert opinions.

## Find Document 4: Official National Tourism Revenue Data for Pamplona

**ID**: 694c3033-fdaa-4172-8520-68e81d7679af

**Description**: Data on tourism revenue generated by the Running of the Bulls event in Pamplona, including visitor spending, hotel occupancy rates, and economic impact on local businesses. This data will inform the project's economic impact assessment.

**Recency Requirement**: Last 5 years

**Responsible Role Type**: Financial Risk Analyst

**Steps to Find**:

- Contact the Spanish Ministry of Tourism.
- Contact the Pamplona City Council tourism department.
- Review economic reports on the event.

**Access Difficulty**: Medium: Requires contacting government agencies and reviewing economic reports.

**Essential Information**:

- Quantify the total tourism revenue generated in Pamplona during the Running of the Bulls event for each of the last 5 years (2019-2023, excluding 2020 if the event was cancelled).
- Detail the breakdown of tourism revenue, specifying contributions from visitor spending (accommodation, food, transportation, souvenirs), event-related activities, and other tourism-related sectors.
- Identify the average hotel occupancy rates in Pamplona during the event for each of the last 5 years.
- Quantify the economic impact of the event on local businesses, including revenue increases, job creation, and other economic benefits.
- Compare the tourism revenue generated during the Running of the Bulls with other major events in Spain to provide context.

**Risks of Poor Quality**:

- Inaccurate or incomplete data leads to flawed economic impact assessments, misrepresenting the event's financial significance.
- Outdated data results in unrealistic projections and ineffective resource allocation.
- Failure to account for all revenue streams underestimates the event's economic value, potentially leading to underinvestment in related infrastructure or services.
- Lack of comparative data makes it difficult to contextualize the event's economic impact relative to other events, hindering informed decision-making.

**Worst Case Scenario**: The project team significantly underestimates the economic impact of the Running of the Bulls due to poor data, leading to flawed recommendations that negatively affect local businesses and tourism, ultimately undermining the project's goal of balancing tradition with economic sustainability and potentially causing significant financial losses for the region.

**Best Case Scenario**: Accurate and comprehensive tourism revenue data enables the project team to develop a robust economic impact assessment, demonstrating the event's financial significance and informing recommendations that enhance both cultural preservation and economic benefits for Pamplona, leading to increased public support and sustainable event management.

**Fallback Alternative Approaches**:

- Engage a market research firm specializing in tourism economics to conduct an independent assessment of the event's economic impact.
- Conduct surveys of tourists and local businesses to gather primary data on spending patterns and economic benefits.
- Analyze publicly available data from tourism agencies and economic reports to estimate tourism revenue and economic impact, acknowledging limitations.
- Consult with economists and tourism experts to develop a model for estimating tourism revenue based on available data and industry benchmarks.

## Find Document 5: Official National Environmental Impact Assessment Regulations

**ID**: 01f4b7ac-6841-4a98-8a54-5d7f476db07e

**Description**: Regulations and guidelines for conducting environmental impact assessments in Spain, including requirements for assessing the environmental impact of events like the Running of the Bulls. This will inform the project's environmental impact assessment.

**Recency Requirement**: Current

**Responsible Role Type**: Legal and Regulatory Advisor

**Steps to Find**:

- Search the Spanish government's environmental regulations database.
- Contact the Spanish Ministry for Ecological Transition.
- Consult with environmental law experts.

**Access Difficulty**: Medium: Requires searching government databases and potentially contacting legal experts.

**Essential Information**:

- Identify the specific Spanish national regulations governing Environmental Impact Assessments (EIAs).
- Detail the required content and format for an EIA submission related to public events.
- List the criteria used by Spanish authorities to evaluate the environmental impact of events like the Running of the Bulls.
- Specify the permissible levels of environmental disturbance (noise, waste, etc.) allowed during such events according to Spanish law.
- Outline the legal consequences of non-compliance with EIA regulations in Spain.
- Identify any recent amendments or updates to the Spanish EIA regulations that are relevant to the project.
- Provide a checklist of all required documentation and permits related to environmental impact for the Running of the Bulls event.

**Risks of Poor Quality**:

- Failure to comply with Spanish environmental regulations, leading to project delays and potential legal penalties.
- Inaccurate or incomplete EIA, resulting in rejection of the project proposal by regulatory bodies.
- Underestimation of the environmental impact, leading to negative public perception and reputational damage.
- Increased project costs due to the need for rework or additional mitigation measures.
- Legal challenges from environmental organizations or concerned citizens.

**Worst Case Scenario**: The project is halted due to non-compliance with Spanish environmental regulations, resulting in significant financial losses, reputational damage, and potential legal action.

**Best Case Scenario**: The project's environmental impact assessment is fully compliant with Spanish regulations, leading to smooth approval processes, positive public perception, and a sustainable event that minimizes environmental harm.

**Fallback Alternative Approaches**:

- Engage a Spanish environmental law firm to provide expert guidance on EIA requirements.
- Purchase a subscription to a legal database that provides access to up-to-date Spanish environmental regulations.
- Contact the Spanish Ministry for Ecological Transition directly to request clarification on specific EIA requirements.
- Review EIAs from similar events in Spain to identify best practices and potential pitfalls.