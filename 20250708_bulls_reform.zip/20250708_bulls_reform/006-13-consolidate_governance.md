# Governance Audit


## Audit - Corruption Risks

- Bribery of local officials to expedite permits or overlook non-compliance with regulations.
- Kickbacks from contractors providing animal welfare improvements or security services.
- Conflicts of interest involving steering committee members with personal financial stakes in the event or related tourism businesses.
- Misuse of confidential information regarding reform proposals to benefit specific stakeholders (e.g., leaking information to bull breeders before public announcement).
- Nepotism in awarding contracts for services such as stakeholder engagement or communication, favoring relatives or close associates.

## Audit - Misallocation Risks

- Inflated invoices from contractors providing services related to animal welfare improvements, with the excess funds being diverted.
- Double-billing for stakeholder engagement activities, such as claiming expenses for meetings that did not occur or were already covered by other funding.
- Inefficient allocation of resources to less impactful areas of the project, such as excessive spending on administrative overhead while underfunding critical animal welfare initiatives.
- Unauthorized use of project funds for personal travel or entertainment expenses by project team members.
- Misreporting of project progress to justify continued funding, even if the project is behind schedule or not achieving its goals.

## Audit - Procedures

- Conduct quarterly internal audits of project expenses, focusing on high-value contracts and travel expenses, with a review of supporting documentation.
- Implement a mandatory ethics training program for all project team members and steering committee members, with annual refresher courses.
- Establish a whistleblower mechanism with a confidential reporting channel and protection against retaliation, overseen by an independent third party.
- Perform regular compliance checks against local ordinances, Spanish animal welfare laws, and EU animal welfare standards, documented and reviewed by legal counsel.
- Conduct a post-project external audit to assess the overall effectiveness of the project and identify any instances of fraud or mismanagement.

## Audit - Transparency Measures

- Create a public-facing project dashboard displaying key performance indicators (KPIs) related to animal welfare, stakeholder engagement, and budget utilization.
- Publish minutes of steering committee meetings on the project website, redacting any confidential or sensitive information.
- Develop and publish a clear and accessible policy on conflicts of interest for all project team members and steering committee members.
- Establish a publicly accessible register of all contracts awarded for the project, including the contractor's name, contract value, and a brief description of the services provided.
- Implement a transparent process for selecting contractors, including documented selection criteria and a scoring system, with the results published on the project website.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the €15 million initiative, ensuring alignment with project goals and stakeholder interests. Given the high budget and potential for stakeholder conflict, a steering committee is crucial for strategic decision-making.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against key performance indicators (KPIs).
- Approve major project changes and deviations from the plan.
- Resolve strategic issues and conflicts.
- Oversee risk management at a strategic level.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Review and approve project charter.

**Membership:**

- Representative from the Pamplona City Council (Senior Official)
- Representative from a leading Animal Welfare Organization (Independent)
- Representative from the Spanish Ministry of Culture (Senior Official)
- Representative from the Tourism Board of Navarra (Senior Official)
- Project Director
- Independent Ethics Advisor

**Decision Rights:** Strategic decisions related to project scope, budget (above €500,000), timeline, and major risks. Approval of key deliverables and milestones.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion and resolution of strategic issues.
- Approval of budget revisions and change requests.
- Review of risk register and mitigation strategies.
- Stakeholder engagement updates.

**Escalation Path:** Escalate unresolved issues to the Director General of the Ministry of Culture.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** To manage the day-to-day execution of the project, ensuring adherence to timelines, budget, and quality standards. Given the multidisciplinary nature and the need for coordination, a PMO is essential for operational efficiency.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Track project progress and report on performance.
- Manage project risks and issues at an operational level.
- Coordinate project team activities.
- Ensure adherence to project management standards and methodologies.
- Manage project documentation and communication.

**Initial Setup Actions:**

- Establish project management processes and templates.
- Set up project tracking and reporting systems.
- Recruit and train PMO staff.
- Define roles and responsibilities within the PMO.

**Membership:**

- Project Manager
- Project Coordinator
- Financial Analyst
- Risk Manager
- Communication Specialist

**Decision Rights:** Operational decisions related to project execution, resource allocation (below €500,000), and risk mitigation within defined thresholds.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Escalation to the Project Steering Committee for issues exceeding their authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress and upcoming tasks.
- Discussion of project risks and issues.
- Review of budget and expenses.
- Coordination of team activities.
- Update on stakeholder communication.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** To ensure the project adheres to the highest ethical standards and complies with all relevant regulations, including animal welfare laws, GDPR, and anti-corruption measures. Given the sensitive nature of the project and the potential for ethical conflicts, this committee is crucial for maintaining integrity and public trust.

**Responsibilities:**

- Develop and enforce a code of ethics for the project.
- Review and approve all project activities for ethical compliance.
- Monitor compliance with relevant regulations, including animal welfare laws and GDPR.
- Investigate and resolve ethical complaints and concerns.
- Provide training on ethical conduct and compliance.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of ethics for the project.
- Establish compliance monitoring procedures.
- Set up a confidential reporting channel for ethical concerns.
- Recruit committee members with expertise in ethics, law, and animal welfare.

**Membership:**

- Independent Ethics Advisor (Chair)
- Legal Counsel
- Animal Welfare Expert (Independent)
- Data Protection Officer
- Representative from the Pamplona City Council (Legal Department)

**Decision Rights:** Decisions related to ethical compliance, data privacy, and adherence to regulations. Authority to halt project activities that violate ethical standards or regulations.

**Decision Mechanism:** Decisions made by majority vote. The Chair has the casting vote. Dissenting opinions are recorded.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of ethical complaints and concerns.
- Monitoring of compliance with regulations.
- Discussion of ethical issues related to project activities.
- Review of data privacy practices.
- Training on ethical conduct and compliance.

**Escalation Path:** Escalate unresolved issues to the Director General of the Ministry of Culture and the relevant regulatory bodies.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** To ensure effective communication and collaboration with all stakeholders, addressing their concerns and incorporating their feedback into the project. Given the diverse range of stakeholders and the potential for conflict, this group is crucial for building consensus and achieving project goals.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and consultations with stakeholders.
- Gather and analyze stakeholder feedback.
- Address stakeholder concerns and resolve conflicts.
- Communicate project progress and key milestones to stakeholders.
- Manage stakeholder expectations.

**Initial Setup Actions:**

- Identify and map all key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels and protocols.
- Recruit group members with expertise in communication and stakeholder management.

**Membership:**

- Communication Specialist (Chair)
- Representative from the Pamplona City Council (Public Relations)
- Representative from a leading Animal Welfare Organization
- Representative from the Tourism Board of Navarra
- Community Liaison Officer

**Decision Rights:** Decisions related to stakeholder communication, engagement strategies, and conflict resolution. Authority to recommend changes to the project based on stakeholder feedback.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns and issues.
- Planning of stakeholder engagement activities.
- Review of communication materials.
- Update on stakeholder communication.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Pamplona City Council Rep, Animal Welfare Org Rep, Spanish Ministry of Culture Rep, Tourism Board of Navarra Rep, Project Director, Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Official from Pamplona City Council formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Pamplona City Council Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 5. Project Steering Committee Chair formally appoints the Project Steering Committee Vice-Chair.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Steering Committee Chair Appointed
- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Steering Committee Chair Appointed
- Steering Committee Vice-Chair Appointed
- Final SteerCo ToR v1.0

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Final SteerCo ToR v1.0

### 8. Project Manager drafts initial PMO processes and templates.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Processes and Templates

**Dependencies:**

- Project Plan Approved

### 9. Project Manager sets up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Draft PMO Processes and Templates

### 10. Project Manager recruits and trains PMO staff (Project Coordinator, Financial Analyst, Risk Manager, Communication Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Staff Onboarded
- Training Records

**Dependencies:**

- Project Tracking System
- Reporting Templates

### 11. Project Manager defines roles and responsibilities within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Roles and Responsibilities Document

**Dependencies:**

- PMO Staff Onboarded

### 12. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- PMO Roles and Responsibilities Document

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- PMO Roles and Responsibilities Document

### 14. Legal Counsel drafts initial Code of Ethics for the project.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Code of Ethics v0.1

**Dependencies:**

- Project Plan Approved

### 15. Legal Counsel establishes compliance monitoring procedures.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Compliance Monitoring Procedures Document

**Dependencies:**

- Draft Code of Ethics v0.1

### 16. Legal Counsel sets up a confidential reporting channel for ethical concerns.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confidential Reporting Channel Established

**Dependencies:**

- Compliance Monitoring Procedures Document

### 17. Project Manager identifies and nominates Ethics and Compliance Committee members (Independent Ethics Advisor, Legal Counsel, Animal Welfare Expert, Data Protection Officer, Pamplona City Council Legal Rep).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Confidential Reporting Channel Established

### 18. Senior Official from Pamplona City Council formally appoints the Independent Ethics Advisor as Chair of the Ethics and Compliance Committee.

**Responsible Body/Role:** Pamplona City Council Representative

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Nominated Members List
- Draft Code of Ethics v0.1

### 19. Ethics and Compliance Committee Chair confirms membership of remaining committee members.

**Responsible Body/Role:** Independent Ethics Advisor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email
- Nominated Members List

### 20. Ethics and Compliance Committee reviews and approves the Code of Ethics.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Code of Ethics v1.0

**Dependencies:**

- Membership Confirmation Emails
- Draft Code of Ethics v0.1

### 21. Ethics and Compliance Committee Chair schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Independent Ethics Advisor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Approved Code of Ethics v1.0
- Membership Confirmation Emails

### 22. Hold initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Approved Code of Ethics v1.0

### 23. Communication Specialist drafts initial Stakeholder Engagement Plan.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**

- Project Plan Approved

### 24. Communication Specialist identifies and maps all key stakeholders.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Map

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1

### 25. Communication Specialist establishes communication channels and protocols.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Channels and Protocols Document

**Dependencies:**

- Stakeholder Map

### 26. Project Manager identifies and nominates Stakeholder Engagement Group members (Communication Specialist, Pamplona City Council Public Relations Rep, Animal Welfare Org Rep, Tourism Board of Navarra Rep, Community Liaison Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Communication Channels and Protocols Document

### 27. Project Manager appoints the Communication Specialist as Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Nominated Members List
- Draft Stakeholder Engagement Plan v0.1

### 28. Stakeholder Engagement Group Chair confirms membership of remaining group members.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email
- Nominated Members List

### 29. Stakeholder Engagement Group reviews and approves the Stakeholder Engagement Plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Plan v1.0

**Dependencies:**

- Membership Confirmation Emails
- Draft Stakeholder Engagement Plan v0.1

### 30. Stakeholder Engagement Group Chair schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Approved Stakeholder Engagement Plan v1.0
- Membership Confirmation Emails

### 31. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Approved Stakeholder Engagement Plan v1.0

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun, impacting project scope and timeline.

**Critical Risk Materialization (e.g., Denial of Key Permit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Action Plan Approval
Rationale: Materialization of a critical risk (e.g., denial of a key permit) has strategic implications and requires high-level intervention and resource allocation.
Negative Consequences: Significant project delays, increased costs, or project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Lack of consensus within the PMO on a key operational decision necessitates resolution by the Steering Committee to ensure project progress.
Negative Consequences: Project delays, inefficient resource allocation, and potential vendor disputes.

**Proposed Major Scope Change (e.g., Significant Alteration to Animal Welfare Reforms)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A major change to the project scope requires strategic review and approval to ensure alignment with project goals and stakeholder expectations.
Negative Consequences: Project delays, budget overruns, and potential stakeholder dissatisfaction.

**Reported Ethical Concern (e.g., Allegation of Misuse of Funds)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Director General of the Ministry of Culture and relevant regulatory bodies.
Rationale: Ethical violations require independent review and investigation to ensure compliance with ethical standards and regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Stakeholder Engagement Group cannot resolve conflict**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Resolution
Rationale: Unresolved conflict between stakeholders requires intervention by the Steering Committee to ensure project progress.
Negative Consequences: Project delays, stakeholder dissatisfaction, and potential project failure.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Monthly Progress Reports

**Frequency:** Monthly

**Responsible Role:** PMO

**Adaptation Process:** PMO proposes adjustments via Change Request to Steering Committee

**Adaptation Trigger:** KPI deviates >10% from target or critical milestone delayed by >2 weeks

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Project Management Software

**Frequency:** Bi-weekly

**Responsible Role:** Risk Manager (within PMO)

**Adaptation Process:** Risk mitigation plan updated by Risk Manager, approved by PMO and Steering Committee if significant budget/scope impact

**Adaptation Trigger:** New critical risk identified, existing risk likelihood/impact increases significantly, or mitigation plan proves ineffective

### 3. Stakeholder Engagement Monitoring
**Monitoring Tools/Platforms:**

  - Stakeholder Feedback Database
  - Meeting Minutes
  - Survey Platform
  - Communication Logs

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement Group

**Adaptation Process:** Stakeholder Engagement Group recommends adjustments to communication strategy or project plan to Steering Committee

**Adaptation Trigger:** Negative feedback trend identified, significant stakeholder concerns raised, or participation rates decline

### 4. Budget vs. Actual Expenditure Tracking
**Monitoring Tools/Platforms:**

  - Financial Management System
  - Budget Tracking Spreadsheet

**Frequency:** Monthly

**Responsible Role:** Financial Analyst (within PMO)

**Adaptation Process:** PMO proposes budget reallocations or cost-cutting measures to Steering Committee

**Adaptation Trigger:** Projected cost overrun exceeds contingency budget, or significant budget variance identified

### 5. Compliance Audit Monitoring
**Monitoring Tools/Platforms:**

  - Compliance Checklist
  - Audit Reports
  - Regulatory Updates Database

**Frequency:** Quarterly

**Responsible Role:** Ethics and Compliance Committee

**Adaptation Process:** Ethics and Compliance Committee recommends corrective actions to PMO and Steering Committee

**Adaptation Trigger:** Audit finding requires action, new regulatory requirement identified, or compliance breach reported

### 6. Animal Welfare Standards Monitoring
**Monitoring Tools/Platforms:**

  - Animal Injury Reports
  - Veterinary Assessments
  - Independent Monitoring Reports

**Frequency:** Post-Event (July 2026) and interim review 6 months prior

**Responsible Role:** Animal Welfare Expert (Independent, member of Ethics and Compliance Committee)

**Adaptation Process:** Animal Welfare Expert provides recommendations to Ethics and Compliance Committee and Steering Committee for adjustments to event protocols

**Adaptation Trigger:** Animal injury rates exceed pre-defined thresholds, negative veterinary assessment, or concerns raised by independent monitors

### 7. Regulatory & Permitting Status Monitoring
**Monitoring Tools/Platforms:**

  - Permit Tracking Spreadsheet
  - Communication Logs with Authorities

**Frequency:** Weekly

**Responsible Role:** Project Manager

**Adaptation Process:** Project Manager escalates potential delays to Steering Committee; legal counsel develops alternative proposals

**Adaptation Trigger:** Permit application delayed beyond expected timeframe, or indication of potential denial

### 8. Public Sentiment Analysis
**Monitoring Tools/Platforms:**

  - Social Media Monitoring Tools
  - Media Monitoring Reports
  - Survey Data

**Frequency:** Monthly

**Responsible Role:** Communication Specialist (within PMO)

**Adaptation Process:** Communication Specialist adjusts communication strategy based on sentiment analysis; escalates significant negative sentiment to Steering Committee

**Adaptation Trigger:** Significant increase in negative media coverage or social media sentiment, or decline in public support survey results

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses defined governance bodies. The Escalation Matrix aligns with the governance hierarchy. Monitoring roles are consistent with defined roles. The components appear logically aligned.
3. Point 3: Potential Gaps / Areas for Enhancement: The role and authority of the Project Sponsor (presumably the Director General of the Ministry of Culture, given the escalation paths) is not explicitly defined within the governance structure or membership of any committee. This should be clarified.
4. Point 4: Potential Gaps / Areas for Enhancement: The Ethics and Compliance Committee's responsibilities mention overseeing the whistleblower mechanism, but the details of the investigation process following a whistleblower report are not elaborated. A clear process, including timelines and reporting lines, is needed.
5. Point 5: Potential Gaps / Areas for Enhancement: The Stakeholder Engagement Group's decision-making process relies on 'consensus.' The definition of consensus and the process for resolving disagreements within the group *before* escalation to the Steering Committee should be defined to avoid bottlenecks.
6. Point 6: Potential Gaps / Areas for Enhancement: While the Monitoring Progress plan includes 'Public Sentiment Analysis,' the adaptation process only mentions adjusting the communication strategy. There should be a defined process for escalating significant negative sentiment to trigger potential *project* adjustments, not just communication adjustments.
7. Point 7: Potential Gaps / Areas for Enhancement: The Animal Welfare Standards Monitoring relies on post-event and interim review. More frequent monitoring (e.g., during event preparation and setup) should be considered, with clear thresholds for immediate corrective action if pre-event conditions are deemed unacceptable.

## Tough Questions

1. What specific, measurable targets have been set for reducing animal injuries during the Running of the Bulls, and how will these targets be validated by independent experts?
2. Show evidence of a documented process for managing potential conflicts of interest among Steering Committee members, particularly those with ties to tourism or bull breeding.
3. What contingency plans are in place if the initial stakeholder engagement efforts are unsuccessful in gaining the support of key resistant groups (e.g., bull breeders)?
4. What is the current probability-weighted forecast for securing all necessary permits by [Date], and what alternative strategies are being developed in case of delays?
5. How will the project ensure compliance with GDPR and other data privacy regulations when collecting and processing stakeholder data, especially given the sensitivity of opinions on animal welfare?
6. What specific security measures are in place to protect project personnel and equipment from potential vandalism or violence, and how are these measures being coordinated with local law enforcement?
7. What is the detailed budget breakdown for the 'Animal Welfare Improvements' allocation, and how will the effectiveness of these improvements be rigorously evaluated?
8. What are the specific criteria that will be used to evaluate the success of the 'Stakeholder Engagement' efforts, and how will these criteria be measured and reported?
9. What are the specific, pre-defined thresholds for animal injury rates that will trigger immediate corrective action during event preparation and setup, prior to the main event in July 2026?

## Summary

The governance framework establishes a multi-layered approach to oversee the Running of the Bulls Reform Initiative, emphasizing strategic direction, operational efficiency, ethical compliance, and stakeholder engagement. The framework's strength lies in its defined governance bodies and monitoring mechanisms, but requires further detail in areas such as conflict of interest management, whistleblower processes, and adaptation strategies based on public sentiment and animal welfare monitoring to ensure proactive and effective management of the project's risks and objectives.