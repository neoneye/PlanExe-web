# Purpose

**Purpose:** business

**Purpose Detailed:** Societal initiative to reform a cultural event, balancing tradition with animal welfare standards, involving significant funding and stakeholder engagement.

**Topic:** Running of the Bulls Reform Initiative

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* a physical presence in Pamplona, Spain, for assessing the event, engaging with stakeholders, and proposing reforms. The initiative involves on-site observation, meetings, and potential physical modifications to the event setup. The scale of the initiative (€15 million) and the involvement of multidisciplinary stakeholders further solidify the physical requirements.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Accessibility for stakeholders
- Proximity to the bullring and event route
- Meeting spaces for discussions and negotiations
- Accommodation for researchers and participants

## Location 1
Spain

Pamplona

Plaza de Toros de Pamplona (Pamplona Bullring)

**Rationale**: The bullring is the central location for the Running of the Bulls event, making it a crucial site for assessment and planning.

## Location 2
Spain

Pamplona

City Center Hotels and Conference Centers

**Rationale**: Provides accessible meeting spaces and accommodations for stakeholders involved in the reform initiative.

## Location 3
Spain

Pamplona

Offices near the event route

**Rationale**: Establishing offices near the Running of the Bulls route allows for direct observation, data collection, and engagement with local businesses and residents.

## Location Summary
The initiative requires a physical presence in Pamplona, Spain, specifically at the Plaza de Toros, city center locations for stakeholder meetings, and offices near the event route for observation and engagement.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The project is based in Pamplona, Spain, and the budget is specified in Euros.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Obtaining necessary permits and approvals from local authorities in Pamplona for proposed reforms to the Running of the Bulls may be delayed or denied due to political or cultural sensitivities. Changes to a deeply ingrained cultural event can face strong resistance.

**Impact:** Project delays of 3-6 months, increased costs due to legal challenges (estimated €50,000 - €100,000), or complete rejection of reform proposals, potentially rendering the project unsuccessful.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with local authorities and cultural organizations early in the project to build consensus and address concerns. Conduct thorough legal research to understand permitting requirements and potential challenges. Develop alternative reform proposals that are less controversial.

## Risk 2 - Social
Public opposition to proposed reforms from traditionalists and bullfighting enthusiasts could lead to protests, boycotts, or even sabotage of the initiative. Negative media coverage could damage the project's reputation and hinder its progress.

**Impact:** Project delays of 2-4 weeks due to disruptions, increased security costs (estimated €20,000 - €40,000), and difficulty engaging with stakeholders. Damage to the project's reputation could reduce its long-term impact.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive communication strategy to engage with the public and address concerns. Highlight the project's commitment to preserving cultural heritage while improving animal welfare. Work with local influencers to build support for the initiative.

## Risk 3 - Financial
Unforeseen expenses, such as legal fees, security costs, or cost overruns on research and consulting services, could exceed the €15 million budget. Inflation or currency fluctuations (although EUR is the primary currency) could also impact the budget.

**Impact:** Project delays of 1-3 months due to budget constraints, reduced scope of the initiative, or the need to secure additional funding. Potential cost overruns of 5-10% (€750,000 - €1,500,000).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget with contingency funds to cover unforeseen expenses. Implement strict cost control measures and regularly monitor project spending. Explore opportunities to secure additional funding from external sources.

## Risk 4 - Operational
Coordinating the activities of multidisciplinary stakeholders (researchers, consultants, local authorities, animal welfare organizations) could be challenging, leading to delays and inefficiencies. Logistical challenges related to travel, accommodation, and meeting spaces in Pamplona could also arise.

**Impact:** Project delays of 2-4 weeks due to communication breakdowns and logistical challenges. Reduced efficiency and productivity of the project team. Increased administrative costs.

**Likelihood:** Medium

**Severity:** Low

**Action:** Establish clear roles and responsibilities for all stakeholders. Develop a detailed project schedule with milestones and deadlines. Implement effective communication and collaboration tools. Secure appropriate travel, accommodation, and meeting arrangements in Pamplona well in advance.

## Risk 5 - Security
Given the controversial nature of the project, there is a risk of security threats to project personnel, equipment, and facilities. Vandalism, protests, or even acts of violence could disrupt the project and endanger participants.

**Impact:** Project delays of 1-2 weeks due to security incidents. Increased security costs (estimated €30,000 - €60,000). Potential harm to project personnel and damage to equipment and facilities.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct a thorough security risk assessment and develop a security plan. Coordinate with local law enforcement to ensure adequate security measures are in place. Provide security training to project personnel. Implement access control measures to protect project facilities.

## Risk 6 - Environmental
While not immediately obvious, proposed changes to the event route or infrastructure could have unintended environmental consequences, such as disrupting local ecosystems or increasing pollution. Improper waste disposal during the event could also pose an environmental risk.

**Impact:** Project delays of 1-3 months due to environmental impact assessments and mitigation measures. Increased costs for environmental remediation. Damage to the project's reputation.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct an environmental impact assessment of proposed reforms. Implement measures to minimize environmental impacts, such as using sustainable materials and reducing waste. Engage with environmental organizations to address concerns.

## Risk 7 - Technical
If the reforms involve technical modifications to the bullring or event route, there could be unexpected technical challenges or delays in implementation. Integration with existing infrastructure may prove difficult.

**Impact:** Project delays of 2-4 weeks. Increased costs for technical modifications (estimated €25,000 - €50,000). Potential need to revise reform proposals.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct thorough technical feasibility studies before implementing any reforms. Engage with experienced engineers and contractors to ensure that technical modifications are feasible and safe. Develop contingency plans to address potential technical challenges.

## Risk summary
The Running of the Bulls Reform Initiative faces significant risks related to regulatory approvals, social acceptance, and financial management. The most critical risks are the potential for denial of permits due to cultural sensitivities and strong public opposition to reforms, both of which could significantly jeopardize the project's success. A proactive engagement strategy with local authorities and the public, coupled with a robust financial contingency plan, is crucial for mitigating these risks. Security risks, while less likely, also warrant careful attention due to their potential severity.

# Make Assumptions


## Question 1 - What is the detailed breakdown of the €15 million budget, including allocations for research, stakeholder engagement, legal fees, and contingency?

**Assumptions:** Assumption: 60% of the budget (€9 million) is allocated to research and consulting services, 20% (€3 million) to stakeholder engagement and communication, 10% (€1.5 million) to legal and regulatory compliance, and 10% (€1.5 million) to contingency.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation and its adequacy for each project phase.
Details: A detailed budget breakdown is crucial for tracking expenses and ensuring financial viability. The assumed allocation allows for significant investment in research and stakeholder engagement, which are critical for project success. However, the contingency fund should be reviewed and potentially increased based on the identified risks, particularly regulatory and social opposition. Regular budget reviews and adjustments are necessary to mitigate potential cost overruns. Quantifiable metrics include tracking actual vs. budgeted expenses and monitoring the contingency fund utilization rate.

## Question 2 - What are the specific milestones and deadlines within the 1-year timeline, particularly for research completion, stakeholder consultations, proposal development, and securing necessary approvals?

**Assumptions:** Assumption: Research and initial stakeholder consultations will be completed within the first 4 months, proposal development within the next 3 months, securing approvals within the following 3 months, and final preparations in the last 2 months.

**Assessments:** Title: Timeline Adherence Assessment
Description: Evaluation of the project timeline and its feasibility given the complexity of the tasks.
Details: The assumed timeline allocates sufficient time for each phase, but the critical path analysis should identify potential bottlenecks. Securing approvals is a high-risk area and may require more than 3 months. Regular monitoring of milestone completion and proactive management of potential delays are essential. Quantifiable metrics include tracking milestone completion rates and identifying any deviations from the planned schedule. A buffer should be added to the timeline to account for unforeseen delays.

## Question 3 - What specific expertise and roles are required for the multidisciplinary team, and how will these resources be allocated across the project phases?

**Assumptions:** Assumption: The team will include researchers specializing in animal welfare, cultural heritage, and event management; legal experts; communication specialists; and project managers. Resources will be allocated based on the needs of each project phase, with research requiring the most resources initially.

**Assessments:** Title: Resource Allocation Assessment
Description: Evaluation of the adequacy and allocation of human resources for the project.
Details: Having the right expertise is crucial for the project's success. The assumed team composition covers the key areas, but a skills gap analysis should be conducted to identify any missing expertise. Resource allocation should be flexible and adjusted based on project needs. Quantifiable metrics include tracking resource utilization rates and assessing team performance against project milestones. Clear roles and responsibilities are essential for effective collaboration.

## Question 4 - What specific governance structure will be implemented to oversee the initiative, and what regulatory bodies or laws in Pamplona and Spain will govern the proposed reforms?

**Assumptions:** Assumption: A steering committee composed of representatives from key stakeholder groups (local authorities, animal welfare organizations, cultural organizations) will oversee the initiative. The reforms will be governed by local ordinances in Pamplona and relevant Spanish animal welfare laws.

**Assessments:** Title: Governance and Regulatory Compliance Assessment
Description: Evaluation of the governance structure and its effectiveness in ensuring compliance with relevant regulations.
Details: A strong governance structure is essential for ensuring accountability and transparency. The steering committee should have clear decision-making authority and a well-defined process for resolving conflicts. Thorough legal research is crucial to identify all applicable regulations and ensure compliance. Quantifiable metrics include tracking the number of regulatory approvals obtained and assessing the effectiveness of the governance structure in resolving conflicts. Early engagement with regulatory bodies is crucial for mitigating risks.

## Question 5 - What specific safety protocols and risk mitigation strategies will be implemented to protect project personnel and the public during the assessment and potential implementation of reforms?

**Assumptions:** Assumption: A comprehensive safety plan will be developed in consultation with local law enforcement and security experts. This plan will include measures to protect project personnel from potential threats, manage crowd control during assessments, and address potential safety hazards related to the Running of the Bulls event.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the safety protocols and risk mitigation strategies.
Details: Given the potential for social unrest and security threats, a robust safety plan is essential. The plan should be regularly reviewed and updated based on the evolving risk landscape. Coordination with local law enforcement is crucial for ensuring adequate security measures are in place. Quantifiable metrics include tracking the number of security incidents and assessing the effectiveness of the safety protocols in preventing harm. Security training for project personnel is also essential.

## Question 6 - What specific measures will be taken to assess and minimize the environmental impact of any proposed reforms to the Running of the Bulls event, considering potential alterations to the event route or infrastructure?

**Assumptions:** Assumption: An environmental impact assessment will be conducted to identify potential environmental consequences of proposed reforms. Measures will be implemented to minimize any negative impacts, such as using sustainable materials, reducing waste, and protecting local ecosystems.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the potential environmental consequences of the project.
Details: While the environmental impact may not be immediately obvious, it is important to consider potential consequences of any proposed reforms. The environmental impact assessment should be conducted by qualified experts and should consider all potential impacts. Mitigation measures should be implemented to minimize any negative impacts. Quantifiable metrics include tracking the amount of waste generated and assessing the impact on local ecosystems. Engaging with environmental organizations can help to identify potential concerns and develop effective mitigation strategies.

## Question 7 - What specific strategies will be used to engage with diverse stakeholders, including traditionalists, animal welfare advocates, local businesses, and government officials, to ensure their perspectives are considered in the reform process?

**Assumptions:** Assumption: A multi-faceted stakeholder engagement strategy will be implemented, including public forums, workshops, online surveys, and one-on-one meetings. The strategy will be tailored to the specific needs and interests of each stakeholder group.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluation of the effectiveness of the stakeholder engagement strategy.
Details: Effective stakeholder engagement is crucial for building consensus and ensuring the project's success. The engagement strategy should be inclusive and transparent, and it should provide opportunities for all stakeholders to voice their concerns and perspectives. Quantifiable metrics include tracking the number of stakeholders engaged and assessing the level of satisfaction with the engagement process. Addressing concerns proactively can help to mitigate potential opposition.

## Question 8 - What specific operational systems and technologies will be used to manage project data, communication, and collaboration among the multidisciplinary team and stakeholders?

**Assumptions:** Assumption: A cloud-based project management system will be used to manage project data, track progress, and facilitate communication among team members. Online collaboration tools will be used to facilitate remote collaboration and stakeholder engagement.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the effectiveness of the operational systems and technologies used to manage the project.
Details: Efficient operational systems are essential for managing the complexity of the project. The project management system should be user-friendly and provide real-time access to project data. Online collaboration tools can facilitate communication and collaboration among team members and stakeholders. Quantifiable metrics include tracking the number of project tasks completed and assessing the efficiency of the communication channels. Training for project personnel on the use of these systems is essential.

# Distill Assumptions

- €9M is for research/consulting, €3M for engagement, and €1.5M each for legal/contingency.
- Research/consultations in 4 months, proposal in 3, approvals in 3, prep in 2.
- Team includes animal welfare, cultural, legal, comms, and project management experts.
- Steering committee oversees; local ordinances and Spanish animal welfare laws govern reforms.
- Safety plan protects personnel, manages crowds, and addresses Running of the Bulls hazards.
- Environmental impact assessment minimizes negative impacts via sustainable practices.
- Multi-faceted engagement includes forums, workshops, surveys, and meetings for stakeholders.
- Cloud-based system manages data, tracks progress, and facilitates team/stakeholder communication.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment for Cultural and Societal Initiatives

## Domain-specific considerations

- Cultural Sensitivity
- Stakeholder Alignment
- Regulatory Compliance
- Animal Welfare Standards
- Public Safety
- Financial Transparency

## Issue 1 - Incomplete Stakeholder Analysis and Engagement Strategy
The current plan acknowledges the need for stakeholder engagement but lacks a detailed analysis of all relevant stakeholder groups and a comprehensive strategy for managing their diverse interests and potential conflicts. Critical stakeholders such as bull breeders, tourism operators, and local political factions are not explicitly mentioned. Without a thorough understanding of each stakeholder's motivations and influence, the project risks facing significant resistance and delays.

**Recommendation:** Conduct a comprehensive stakeholder analysis to identify all relevant groups, assess their interests and influence, and develop tailored engagement strategies for each. This should include: 1) Mapping all stakeholders and their relationships. 2) Assessing their level of support or opposition to the proposed reforms. 3) Developing communication plans that address their specific concerns and interests. 4) Establishing clear channels for feedback and dialogue. 5) Creating a conflict resolution mechanism to address disagreements among stakeholders. Prioritize engagement with potentially resistant groups early in the project to build trust and address concerns proactively. For example, offer incentives or alternative economic opportunities to bull breeders if the reforms impact their livelihoods.

**Sensitivity:** Failure to adequately engage stakeholders could lead to project delays of 6-12 months due to protests, legal challenges, or political interference. This could increase project costs by €200,000-€500,000 and reduce the project's ROI by 10-20% (baseline ROI estimated at project completion within 1 year).

## Issue 2 - Insufficient Detail Regarding Animal Welfare Standards and Metrics
The plan mentions improving animal welfare standards but lacks specific, measurable, achievable, relevant, and time-bound (SMART) goals. Without clearly defined standards and metrics, it will be difficult to assess the success of the reform initiative and demonstrate its impact on animal welfare. This ambiguity could also lead to disagreements among stakeholders regarding the effectiveness of the proposed reforms.

**Recommendation:** Define specific, measurable animal welfare standards and metrics that will be used to evaluate the success of the reform initiative. These should be based on scientific evidence and best practices in animal welfare. Examples include: 1) Reducing the number of injuries to bulls during the Running of the Bulls by X%. 2) Improving the living conditions of bulls before and after the event, as measured by Y. 3) Implementing independent monitoring and reporting of animal welfare practices. 4) Establishing a clear process for addressing animal welfare concerns. Consult with animal welfare experts and organizations to develop these standards and metrics. Regularly monitor and report on progress towards achieving these goals.

**Sensitivity:** Lack of clear animal welfare standards could lead to negative media coverage and public backlash, damaging the project's reputation and hindering its progress. This could reduce the project's long-term impact and potentially lead to a 5-10% reduction in ROI due to decreased public support and potential boycotts.

## Issue 3 - Unclear Definition of 'Success' and Lack of Measurable Outcomes
The plan lacks a clear and measurable definition of 'success' for the reform initiative. Without specific, quantifiable outcomes, it will be difficult to assess whether the project has achieved its goals and delivered the intended benefits. This ambiguity could also lead to disagreements among stakeholders regarding the overall value of the project.

**Recommendation:** Define specific, measurable outcomes that will be used to evaluate the success of the reform initiative. These should be aligned with the project's overall purpose and objectives. Examples include: 1) Increased public support for the Running of the Bulls, as measured by surveys. 2) Improved animal welfare standards, as measured by the metrics defined above. 3) Reduced risk of injuries to participants, as measured by incident reports. 4) Enhanced economic benefits for the local community, as measured by tourism revenue. Establish a baseline for each outcome before the project begins and track progress regularly. Communicate these outcomes to stakeholders and the public to demonstrate the value of the reform initiative.

**Sensitivity:** Failure to define clear success metrics could lead to a perception that the project is ineffective or a waste of resources. This could reduce the project's long-term impact and potentially lead to a 10-15% reduction in ROI due to decreased public support and stakeholder engagement.

## Review conclusion
The Running of the Bulls Reform Initiative has the potential to balance tradition with animal welfare standards, but its success hinges on addressing key gaps in stakeholder engagement, animal welfare metrics, and outcome measurement. By implementing the recommendations outlined above, the project can increase its chances of achieving its goals and delivering lasting benefits to the community and animal welfare.