
## Audit - Corruption Risks

- Bribery of local officials to expedite permits or overlook non-compliance with regulations.
- Kickbacks from contractors providing animal welfare improvements or security services.
- Conflicts of interest involving steering committee members with personal financial stakes in the event or related tourism businesses.
- Misuse of confidential information regarding reform proposals to benefit specific stakeholders (e.g., leaking information to bull breeders before public announcement).
- Nepotism in awarding contracts for services such as stakeholder engagement or communication, favoring relatives or close associates.

## Audit - Misallocation Risks

- Inflated invoices from contractors providing services related to animal welfare improvements, with the excess funds being diverted.
- Double-billing for stakeholder engagement activities, such as claiming expenses for meetings that did not occur or were already covered by other funding.
- Inefficient allocation of resources to less impactful areas of the project, such as excessive spending on administrative overhead while underfunding critical animal welfare initiatives.
- Unauthorized use of project funds for personal travel or entertainment expenses by project team members.
- Misreporting of project progress to justify continued funding, even if the project is behind schedule or not achieving its goals.

## Audit - Procedures

- Conduct quarterly internal audits of project expenses, focusing on high-value contracts and travel expenses, with a review of supporting documentation.
- Implement a mandatory ethics training program for all project team members and steering committee members, with annual refresher courses.
- Establish a whistleblower mechanism with a confidential reporting channel and protection against retaliation, overseen by an independent third party.
- Perform regular compliance checks against local ordinances, Spanish animal welfare laws, and EU animal welfare standards, documented and reviewed by legal counsel.
- Conduct a post-project external audit to assess the overall effectiveness of the project and identify any instances of fraud or mismanagement.

## Audit - Transparency Measures

- Create a public-facing project dashboard displaying key performance indicators (KPIs) related to animal welfare, stakeholder engagement, and budget utilization.
- Publish minutes of steering committee meetings on the project website, redacting any confidential or sensitive information.
- Develop and publish a clear and accessible policy on conflicts of interest for all project team members and steering committee members.
- Establish a publicly accessible register of all contracts awarded for the project, including the contractor's name, contract value, and a brief description of the services provided.
- Implement a transparent process for selecting contractors, including documented selection criteria and a scoring system, with the results published on the project website.