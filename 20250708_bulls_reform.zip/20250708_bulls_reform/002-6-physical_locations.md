This plan implies one or more physical locations.

## Requirements for physical locations

- Accessibility for stakeholders
- Proximity to the bullring and event route
- Meeting spaces for discussions and negotiations
- Accommodation for researchers and participants

## Location 1
Spain

Pamplona

Plaza de Toros de Pamplona (Pamplona Bullring)

**Rationale**: The bullring is the central location for the Running of the Bulls event, making it a crucial site for assessment and planning.

## Location 2
Spain

Pamplona

City Center Hotels and Conference Centers

**Rationale**: Provides accessible meeting spaces and accommodations for stakeholders involved in the reform initiative.

## Location 3
Spain

Pamplona

Offices near the event route

**Rationale**: Establishing offices near the Running of the Bulls route allows for direct observation, data collection, and engagement with local businesses and residents.

## Location Summary
The initiative requires a physical presence in Pamplona, Spain, specifically at the Plaza de Toros, city center locations for stakeholder meetings, and offices near the event route for observation and engagement.