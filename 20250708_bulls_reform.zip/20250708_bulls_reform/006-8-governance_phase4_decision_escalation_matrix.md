**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun, impacting project scope and timeline.

**Critical Risk Materialization (e.g., Denial of Key Permit)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Action Plan Approval
Rationale: Materialization of a critical risk (e.g., denial of a key permit) has strategic implications and requires high-level intervention and resource allocation.
Negative Consequences: Significant project delays, increased costs, or project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Lack of consensus within the PMO on a key operational decision necessitates resolution by the Steering Committee to ensure project progress.
Negative Consequences: Project delays, inefficient resource allocation, and potential vendor disputes.

**Proposed Major Scope Change (e.g., Significant Alteration to Animal Welfare Reforms)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A major change to the project scope requires strategic review and approval to ensure alignment with project goals and stakeholder expectations.
Negative Consequences: Project delays, budget overruns, and potential stakeholder dissatisfaction.

**Reported Ethical Concern (e.g., Allegation of Misuse of Funds)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Director General of the Ministry of Culture and relevant regulatory bodies.
Rationale: Ethical violations require independent review and investigation to ensure compliance with ethical standards and regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Stakeholder Engagement Group cannot resolve conflict**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Discussion and Resolution
Rationale: Unresolved conflict between stakeholders requires intervention by the Steering Committee to ensure project progress.
Negative Consequences: Project delays, stakeholder dissatisfaction, and potential project failure.