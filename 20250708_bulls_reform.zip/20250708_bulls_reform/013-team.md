# Roles

## 1. Stakeholder Liaison Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent engagement and relationship management with stakeholders throughout the year-long initiative.

**Explanation**:
Crucial for building and maintaining relationships with diverse stakeholders, including event organizers, animal welfare groups, local community members, and government agencies.

**Consequences**:
Increased resistance to change, project delays, and potential failure to achieve consensus among stakeholders.

**People Count**:
min 2, max 4, depending on the number of stakeholder groups and their level of engagement.

**Typical Activities**:
Facilitating meetings between stakeholders, mediating disputes, developing communication strategies, building relationships with community leaders, and ensuring that all stakeholders are informed and engaged in the project.

**Background Story**:
Isabella Rodriguez, born and raised in Seville, Spain, has dedicated her career to fostering understanding and collaboration between diverse groups. With a degree in Sociology and a Master's in Conflict Resolution from the University of Granada, Isabella has worked for various NGOs, mediating disputes between local communities and international organizations. Her deep understanding of Spanish culture, coupled with her exceptional communication and negotiation skills, makes her perfectly suited to navigate the complex stakeholder landscape of the Running of the Bulls initiative. She is relevant because of her ability to build consensus and ensure that all voices are heard.

**Equipment Needs**:
Laptop, mobile phone, access to stakeholder database, travel budget for meetings and site visits.

**Facility Needs**:
Office space, meeting rooms, access to event venues and stakeholder locations.

## 2. Animal Welfare Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Animal welfare expertise is central to the project's goals and requires dedicated, consistent involvement.

**Explanation**:
Provides expertise on animal welfare standards, assesses current practices, and proposes improvements to minimize animal suffering during the event.

**Consequences**:
Inadequate animal welfare improvements, negative media coverage, and potential legal challenges.

**People Count**:
min 2, max 3, to cover different areas of expertise (e.g., veterinary science, animal behavior).

**Typical Activities**:
Assessing current animal welfare practices, developing and implementing animal welfare standards, conducting research on animal behavior and physiology, providing veterinary care, and training event staff on animal handling techniques.

**Background Story**:
Dr. Alistair McGregor, a veterinarian from Edinburgh, Scotland, has spent the last 15 years researching animal welfare in various cultural contexts. He holds a PhD in Veterinary Science from the University of Cambridge and has published extensively on the ethical treatment of animals in sporting events. Alistair's expertise in animal behavior and physiology, combined with his experience in developing and implementing animal welfare standards, makes him an invaluable asset to the Running of the Bulls initiative. He is relevant because of his ability to provide evidence-based recommendations for improving animal welfare during the event.

**Equipment Needs**:
Veterinary equipment (for on-site assessments), laptop, specialized software for data analysis, camera for documentation.

**Facility Needs**:
Laboratory access (for sample analysis), office space, access to bullring and surrounding areas.

## 3. Cultural Heritage Consultant

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Cultural heritage expertise is needed for a specific assessment and advisory role, making a contractor suitable.

**Explanation**:
Ensures that proposed reforms respect and preserve the cultural significance of the Running of the Bulls event.

**Consequences**:
Alienation of the local community, loss of cultural heritage, and potential backlash against the project.

**People Count**:
1

**Typical Activities**:
Advising the project team on the cultural significance of the Running of the Bulls, conducting historical research, consulting with local community members, and ensuring that proposed reforms are culturally sensitive and respectful of local traditions.

**Background Story**:
Ricardo Alvarez, a native of Pamplona, Spain, is a renowned historian and cultural anthropologist specializing in the traditions and customs of the Navarre region. With a PhD from the University of Navarre, Ricardo has dedicated his life to studying the cultural significance of the Running of the Bulls. His deep understanding of the event's history, rituals, and social context makes him uniquely qualified to advise the project team on how to preserve its cultural heritage while implementing reforms. He is relevant because of his ability to ensure that proposed changes are culturally sensitive and respectful of local traditions.

**Equipment Needs**:
Laptop, access to historical archives and databases, recording equipment for interviews.

**Facility Needs**:
Office space, access to local libraries and archives, meeting rooms.

## 4. Risk and Security Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Risk and security coordination requires constant monitoring and proactive management throughout the project's duration.

**Explanation**:
Identifies and mitigates potential risks related to public safety, security threats, and operational challenges during the event.

**Consequences**:
Increased risk of accidents, security breaches, and disruptions to the event.

**People Count**:
min 1, max 2, depending on the complexity of the security assessment and coordination needs.

**Typical Activities**:
Conducting risk assessments, developing and implementing security protocols, coordinating with law enforcement agencies, training event staff on security procedures, and monitoring security threats.

**Background Story**:
Sergei Volkov, a former security consultant from Moscow, Russia, brings a wealth of experience in risk assessment and security management to the Running of the Bulls initiative. With a background in law enforcement and counter-terrorism, Sergei has worked on security projects for major sporting events and public gatherings around the world. His expertise in identifying and mitigating potential risks, combined with his experience in developing and implementing security protocols, makes him an essential member of the project team. He is relevant because of his ability to ensure the safety and security of participants, spectators, and event staff.

**Equipment Needs**:
Security assessment tools, communication devices (radios, mobile phones), surveillance equipment, laptop with security software.

**Facility Needs**:
Office space, access to event site for security assessments, coordination room with law enforcement.

## 5. Communications and Public Relations Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Communications and PR require ongoing management and responsiveness to public perception throughout the project.

**Explanation**:
Develops and implements a communication strategy to inform the public about the project, address concerns, and promote positive media coverage.

**Consequences**:
Negative public perception, misinformation, and difficulty engaging stakeholders.

**People Count**:
min 1, max 2, to handle media relations, social media, and public outreach.

**Typical Activities**:
Developing and implementing a communication strategy, managing media relations, creating social media content, organizing public events, and responding to media inquiries.

**Background Story**:
Aisha Khan, a communications specialist from London, England, has a proven track record of developing and implementing successful communication strategies for high-profile projects. With a degree in Journalism and a Master's in Public Relations, Aisha has worked for various organizations, managing media relations, social media campaigns, and public outreach efforts. Her expertise in crafting compelling messages, combined with her experience in engaging diverse audiences, makes her perfectly suited to manage the communications and public relations for the Running of the Bulls initiative. She is relevant because of her ability to shape public perception and build support for the project.

**Equipment Needs**:
Laptop, access to media databases, social media management tools, camera and video equipment.

**Facility Needs**:
Office space, access to media outlets, press conference facilities.

## 6. Legal and Regulatory Advisor

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Legal and regulatory advice is needed for specific tasks and compliance, making a contractor suitable.

**Explanation**:
Provides guidance on legal and regulatory requirements, ensures compliance with local ordinances and Spanish animal welfare laws, and obtains necessary permits and approvals.

**Consequences**:
Legal challenges, project delays, and potential fines or penalties.

**People Count**:
1

**Typical Activities**:
Providing legal advice, conducting legal research, drafting legal documents, negotiating with regulatory agencies, and ensuring compliance with all applicable laws and regulations.

**Background Story**:
Elena Ramirez, a lawyer from Madrid, Spain, specializes in regulatory compliance and animal welfare law. With a law degree from the Complutense University of Madrid and a Master's in Environmental Law, Elena has worked for various law firms and NGOs, advising clients on legal and regulatory matters related to animal rights and environmental protection. Her expertise in Spanish law, combined with her knowledge of animal welfare regulations, makes her an invaluable asset to the Running of the Bulls initiative. She is relevant because of her ability to ensure that the project complies with all applicable laws and regulations.

**Equipment Needs**:
Laptop, access to legal databases, legal research software.

**Facility Needs**:
Office space, access to legal libraries, meeting rooms.

## 7. Project Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Project management requires full-time oversight and coordination to ensure the project stays on track and within budget.

**Explanation**:
Oversees all aspects of the project, including planning, execution, monitoring, and reporting, to ensure that it is completed on time and within budget.

**Consequences**:
Lack of coordination, project delays, budget overruns, and failure to achieve project goals.

**People Count**:
1

**Typical Activities**:
Developing project plans, managing project budgets, coordinating project teams, monitoring project progress, and reporting on project status.

**Background Story**:
Jean-Pierre Dubois, a seasoned project manager from Paris, France, has over 20 years of experience in managing complex projects for international organizations. With a degree in Engineering and an MBA from INSEAD, Jean-Pierre has a proven track record of delivering projects on time and within budget. His expertise in project planning, execution, and monitoring, combined with his strong leadership skills, makes him the ideal candidate to oversee the Running of the Bulls initiative. He is relevant because of his ability to ensure that the project stays on track and achieves its goals.

**Equipment Needs**:
Laptop, project management software, communication tools (email, video conferencing).

**Facility Needs**:
Office space, meeting rooms, access to project documentation and data.

## 8. Monitoring and Evaluation Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Monitoring and evaluation require consistent data collection and analysis throughout the project's lifecycle.

**Explanation**:
Develops and implements a monitoring and evaluation plan to assess the impact of the reforms, track progress towards goals, and identify areas for improvement. This role is crucial for the 'Monitoring & Adjustment' and 'Maintenance & Sustainability' phases.

**Consequences**:
Inability to measure the effectiveness of the reforms, lack of data-driven decision-making, and difficulty sustaining the project's impact over time.

**People Count**:
min 1, max 2, depending on the complexity of the data collection and analysis requirements.

**Typical Activities**:
Developing and implementing a monitoring and evaluation plan, collecting and analyzing data, tracking progress towards goals, and identifying areas for improvement.

**Background Story**:
Mei Lin, a data analyst from Beijing, China, specializes in monitoring and evaluating the impact of social and environmental programs. With a degree in Statistics and a Master's in Public Policy from Harvard University, Mei has worked for various organizations, developing and implementing monitoring and evaluation plans. Her expertise in data collection, analysis, and reporting, combined with her experience in assessing the effectiveness of social programs, makes her perfectly suited to monitor and evaluate the impact of the Running of the Bulls initiative. She is relevant because of her ability to measure the success of the project and identify areas for improvement.

**Equipment Needs**:
Laptop, statistical software, data collection tools, survey platforms.

**Facility Needs**:
Office space, access to data storage and analysis resources, meeting rooms.

---

# Omissions

## 1. Dedicated Volunteer Coordinator

The plan lacks a role dedicated to recruiting, training, and managing volunteers. Volunteers can significantly contribute to various aspects of the project, such as data collection, stakeholder engagement, and logistical support, especially given the scale of the initiative and the need for on-the-ground presence.

**Recommendation**:
Assign a team member or hire a part-time coordinator to manage volunteer recruitment, training, scheduling, and supervision. This will ensure effective utilization of volunteer resources and enhance project reach.

## 2. Local Liaison

While the Stakeholder Liaison Manager is present, a dedicated 'Local Liaison' who is deeply embedded in the Pamplona community is missing. This person would have pre-existing relationships and a nuanced understanding of local customs and sensitivities, which is crucial for effective stakeholder engagement and navigating potential cultural barriers.

**Recommendation**:
Identify and engage a local resident of Pamplona who is well-connected and respected within the community to serve as a Local Liaison. This person can provide valuable insights, facilitate introductions, and help build trust with local stakeholders.

## 3. Ethics Advisor

Given the ethical complexities of balancing cultural heritage with animal welfare, an Ethics Advisor is missing. This role would provide guidance on ethical considerations, ensuring that all decisions align with the project's ethical goals and values.

**Recommendation**:
Engage an Ethics Advisor, potentially on a consulting basis, to provide guidance on ethical dilemmas and ensure that the project's actions are aligned with its ethical principles. This advisor should have expertise in animal ethics, cultural ethics, or both.

---

# Potential Improvements

## 1. Clarify Responsibilities of Stakeholder Liaison Manager

The description of the Stakeholder Liaison Manager's role is broad. Clarifying specific responsibilities and key performance indicators (KPIs) will improve accountability and effectiveness.

**Recommendation**:
Define specific responsibilities for the Stakeholder Liaison Manager, such as the number of stakeholder meetings held, the level of stakeholder satisfaction, and the resolution of conflicts. Establish KPIs to track their performance and ensure they are meeting project objectives.

## 2. Enhance Communication between Animal Welfare Specialist and Cultural Heritage Consultant

Effective communication and collaboration between the Animal Welfare Specialist and the Cultural Heritage Consultant are crucial for finding solutions that balance animal welfare with cultural preservation. The current plan doesn't explicitly address how this collaboration will be facilitated.

**Recommendation**:
Establish regular joint meetings between the Animal Welfare Specialist and the Cultural Heritage Consultant to discuss potential conflicts and develop integrated solutions. Encourage open communication and mutual understanding of each other's perspectives.

## 3. Improve Risk and Security Coordinator's Integration with Local Law Enforcement

While the Risk and Security Coordinator is responsible for coordinating with law enforcement, the plan lacks detail on how this coordination will be achieved and maintained. Strong relationships with local law enforcement are essential for effective security management.

**Recommendation**:
Develop a formal protocol for communication and collaboration between the Risk and Security Coordinator and local law enforcement agencies. This protocol should include regular meetings, information sharing, and joint training exercises.