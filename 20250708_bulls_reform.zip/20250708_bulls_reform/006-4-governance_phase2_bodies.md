### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the €15 million initiative, ensuring alignment with project goals and stakeholder interests. Given the high budget and potential for stakeholder conflict, a steering committee is crucial for strategic decision-making.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against key performance indicators (KPIs).
- Approve major project changes and deviations from the plan.
- Resolve strategic issues and conflicts.
- Oversee risk management at a strategic level.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Review and approve project charter.

**Membership:**

- Representative from the Pamplona City Council (Senior Official)
- Representative from a leading Animal Welfare Organization (Independent)
- Representative from the Spanish Ministry of Culture (Senior Official)
- Representative from the Tourism Board of Navarra (Senior Official)
- Project Director
- Independent Ethics Advisor

**Decision Rights:** Strategic decisions related to project scope, budget (above €500,000), timeline, and major risks. Approval of key deliverables and milestones.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion and resolution of strategic issues.
- Approval of budget revisions and change requests.
- Review of risk register and mitigation strategies.
- Stakeholder engagement updates.

**Escalation Path:** Escalate unresolved issues to the Director General of the Ministry of Culture.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** To manage the day-to-day execution of the project, ensuring adherence to timelines, budget, and quality standards. Given the multidisciplinary nature and the need for coordination, a PMO is essential for operational efficiency.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Track project progress and report on performance.
- Manage project risks and issues at an operational level.
- Coordinate project team activities.
- Ensure adherence to project management standards and methodologies.
- Manage project documentation and communication.

**Initial Setup Actions:**

- Establish project management processes and templates.
- Set up project tracking and reporting systems.
- Recruit and train PMO staff.
- Define roles and responsibilities within the PMO.

**Membership:**

- Project Manager
- Project Coordinator
- Financial Analyst
- Risk Manager
- Communication Specialist

**Decision Rights:** Operational decisions related to project execution, resource allocation (below €500,000), and risk mitigation within defined thresholds.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Escalation to the Project Steering Committee for issues exceeding their authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress and upcoming tasks.
- Discussion of project risks and issues.
- Review of budget and expenses.
- Coordination of team activities.
- Update on stakeholder communication.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** To ensure the project adheres to the highest ethical standards and complies with all relevant regulations, including animal welfare laws, GDPR, and anti-corruption measures. Given the sensitive nature of the project and the potential for ethical conflicts, this committee is crucial for maintaining integrity and public trust.

**Responsibilities:**

- Develop and enforce a code of ethics for the project.
- Review and approve all project activities for ethical compliance.
- Monitor compliance with relevant regulations, including animal welfare laws and GDPR.
- Investigate and resolve ethical complaints and concerns.
- Provide training on ethical conduct and compliance.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of ethics for the project.
- Establish compliance monitoring procedures.
- Set up a confidential reporting channel for ethical concerns.
- Recruit committee members with expertise in ethics, law, and animal welfare.

**Membership:**

- Independent Ethics Advisor (Chair)
- Legal Counsel
- Animal Welfare Expert (Independent)
- Data Protection Officer
- Representative from the Pamplona City Council (Legal Department)

**Decision Rights:** Decisions related to ethical compliance, data privacy, and adherence to regulations. Authority to halt project activities that violate ethical standards or regulations.

**Decision Mechanism:** Decisions made by majority vote. The Chair has the casting vote. Dissenting opinions are recorded.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of ethical complaints and concerns.
- Monitoring of compliance with regulations.
- Discussion of ethical issues related to project activities.
- Review of data privacy practices.
- Training on ethical conduct and compliance.

**Escalation Path:** Escalate unresolved issues to the Director General of the Ministry of Culture and the relevant regulatory bodies.
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** To ensure effective communication and collaboration with all stakeholders, addressing their concerns and incorporating their feedback into the project. Given the diverse range of stakeholders and the potential for conflict, this group is crucial for building consensus and achieving project goals.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and consultations with stakeholders.
- Gather and analyze stakeholder feedback.
- Address stakeholder concerns and resolve conflicts.
- Communicate project progress and key milestones to stakeholders.
- Manage stakeholder expectations.

**Initial Setup Actions:**

- Identify and map all key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels and protocols.
- Recruit group members with expertise in communication and stakeholder management.

**Membership:**

- Communication Specialist (Chair)
- Representative from the Pamplona City Council (Public Relations)
- Representative from a leading Animal Welfare Organization
- Representative from the Tourism Board of Navarra
- Community Liaison Officer

**Decision Rights:** Decisions related to stakeholder communication, engagement strategies, and conflict resolution. Authority to recommend changes to the project based on stakeholder feedback.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns and issues.
- Planning of stakeholder engagement activities.
- Review of communication materials.
- Update on stakeholder communication.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.