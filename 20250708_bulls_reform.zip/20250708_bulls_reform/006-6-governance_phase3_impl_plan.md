### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Pamplona City Council Rep, Animal Welfare Org Rep, Spanish Ministry of Culture Rep, Tourism Board of Navarra Rep, Project Director, Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Official from Pamplona City Council formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Pamplona City Council Representative

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 5. Project Steering Committee Chair formally appoints the Project Steering Committee Vice-Chair.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Steering Committee Chair Appointed
- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Steering Committee Chair Appointed
- Steering Committee Vice-Chair Appointed
- Final SteerCo ToR v1.0

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize governance processes, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Final SteerCo ToR v1.0

### 8. Project Manager drafts initial PMO processes and templates.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Processes and Templates

**Dependencies:**

- Project Plan Approved

### 9. Project Manager sets up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Draft PMO Processes and Templates

### 10. Project Manager recruits and trains PMO staff (Project Coordinator, Financial Analyst, Risk Manager, Communication Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Staff Onboarded
- Training Records

**Dependencies:**

- Project Tracking System
- Reporting Templates

### 11. Project Manager defines roles and responsibilities within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Roles and Responsibilities Document

**Dependencies:**

- PMO Staff Onboarded

### 12. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- PMO Roles and Responsibilities Document

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- PMO Roles and Responsibilities Document

### 14. Legal Counsel drafts initial Code of Ethics for the project.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Code of Ethics v0.1

**Dependencies:**

- Project Plan Approved

### 15. Legal Counsel establishes compliance monitoring procedures.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Compliance Monitoring Procedures Document

**Dependencies:**

- Draft Code of Ethics v0.1

### 16. Legal Counsel sets up a confidential reporting channel for ethical concerns.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confidential Reporting Channel Established

**Dependencies:**

- Compliance Monitoring Procedures Document

### 17. Project Manager identifies and nominates Ethics and Compliance Committee members (Independent Ethics Advisor, Legal Counsel, Animal Welfare Expert, Data Protection Officer, Pamplona City Council Legal Rep).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Confidential Reporting Channel Established

### 18. Senior Official from Pamplona City Council formally appoints the Independent Ethics Advisor as Chair of the Ethics and Compliance Committee.

**Responsible Body/Role:** Pamplona City Council Representative

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Nominated Members List
- Draft Code of Ethics v0.1

### 19. Ethics and Compliance Committee Chair confirms membership of remaining committee members.

**Responsible Body/Role:** Independent Ethics Advisor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email
- Nominated Members List

### 20. Ethics and Compliance Committee reviews and approves the Code of Ethics.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Code of Ethics v1.0

**Dependencies:**

- Membership Confirmation Emails
- Draft Code of Ethics v0.1

### 21. Ethics and Compliance Committee Chair schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Independent Ethics Advisor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Approved Code of Ethics v1.0
- Membership Confirmation Emails

### 22. Hold initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Approved Code of Ethics v1.0

### 23. Communication Specialist drafts initial Stakeholder Engagement Plan.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**

- Project Plan Approved

### 24. Communication Specialist identifies and maps all key stakeholders.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Map

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1

### 25. Communication Specialist establishes communication channels and protocols.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Channels and Protocols Document

**Dependencies:**

- Stakeholder Map

### 26. Project Manager identifies and nominates Stakeholder Engagement Group members (Communication Specialist, Pamplona City Council Public Relations Rep, Animal Welfare Org Rep, Tourism Board of Navarra Rep, Community Liaison Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Communication Channels and Protocols Document

### 27. Project Manager appoints the Communication Specialist as Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Nominated Members List
- Draft Stakeholder Engagement Plan v0.1

### 28. Stakeholder Engagement Group Chair confirms membership of remaining group members.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email
- Nominated Members List

### 29. Stakeholder Engagement Group reviews and approves the Stakeholder Engagement Plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Plan v1.0

**Dependencies:**

- Membership Confirmation Emails
- Draft Stakeholder Engagement Plan v0.1

### 30. Stakeholder Engagement Group Chair schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Communication Specialist

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Approved Stakeholder Engagement Plan v1.0
- Membership Confirmation Emails

### 31. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent
- Approved Stakeholder Engagement Plan v1.0