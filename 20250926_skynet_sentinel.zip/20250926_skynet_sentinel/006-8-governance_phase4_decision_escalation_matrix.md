**Budget Request Exceeding PMO Authority (€500,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential for uncontrolled cost overruns and impact on overall project budget.

**Critical Risk Materialization (Cybersecurity Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Remediation Plan
Rationale: Represents a significant threat to the project's security and requires immediate strategic attention.
Negative Consequences: Data compromise, system disruption, reputational damage, and potential regulatory fines.

**PMO Deadlock on Sensor Vendor Selection (Lots A/B/C)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Vendor Proposals and Selection Vote
Rationale: Inability to reach consensus within the PMO necessitates higher-level arbitration to ensure timely procurement.
Negative Consequences: Delays in sensor procurement, impacting project timeline and potentially affecting KPI achievement.

**Proposed Major Scope Change (Addition of New Airport)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Scope Change Request
Rationale: Represents a significant deviation from the original project scope, requiring strategic alignment and budget reallocation.
Negative Consequences: Potential for budget overruns, schedule delays, and impact on existing project objectives.

**Reported Ethical Concern (Privacy Violation)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation
Rationale: Requires independent review and investigation to ensure compliance with ethical guidelines and privacy regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of public trust.

**Unresolved Technical Issue Impacting KPIs**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation
Rationale: Requires specialized technical expertise to resolve issues affecting critical performance metrics.
Negative Consequences: Failure to meet KPIs, system rejection, and rework costs.