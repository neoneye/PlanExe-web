# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Aviation Cybersecurity Specialist

**Knowledge**: aviation cybersecurity, threat modeling, incident response, SIEM, vulnerability assessment

**Why**: Crucial for assessing and hardening the system's cybersecurity posture, especially given the Zero-Trust requirements.

**What**: Review the cybersecurity hardening approach and patching SLOs, ensuring alignment with aviation-specific threats.

**Skills**: penetration testing, risk management, compliance auditing, secure coding, network security

**Search**: aviation cybersecurity expert, SIEM, threat intelligence

## 1.1 Primary Actions

- Immediately conduct a formal threat modeling exercise, involving cybersecurity experts with aviation experience.
- Develop a detailed incident response plan that addresses specific attack scenarios and outlines clear procedures for containment, eradication, and recovery.
- Develop a comprehensive supply chain security plan that includes vendor vetting, hardware and software integrity verification, and contingency planning.

## 1.2 Secondary Actions

- Consult with aviation cybersecurity specialists to understand industry-specific threats and vulnerabilities.
- Consult with incident response experts and review industry best practices, such as the NIST Computer Security Incident Handling Guide.
- Consult with supply chain security experts and review industry best practices, such as the NIST Supply Chain Risk Management Practices for Federal Information Systems and Organizations.

## 1.3 Follow Up Consultation

Review the threat model, incident response plan, and supply chain security plan to ensure they adequately address the identified risks and meet industry best practices. Discuss specific attack scenarios and potential mitigation strategies. Evaluate the effectiveness of the proposed security controls and identify any gaps or weaknesses.

## 1.4.A Issue - Insufficient Cybersecurity Threat Modeling

While the plan mentions Zero-Trust, SBOM, SLSA-3+, mTLS, and other security measures, it lacks a comprehensive threat model. A threat model is crucial to identify potential attack vectors, prioritize security efforts, and ensure that the chosen security controls are effective against the most likely and impactful threats. The current approach seems to be a checklist of security best practices without a clear understanding of how they mitigate specific risks in the aviation context. For example, what specific threats does mTLS with pinning address in the context of sUAS localization? What are the potential attack vectors against the edge nodes, and how do secure boot and TPM protect against them? Without a threat model, the security measures may be misaligned with the actual risks, leading to wasted resources and potential vulnerabilities.

### 1.4.B Tags

- cybersecurity
- threat_modeling
- risk_assessment

### 1.4.C Mitigation

Immediately conduct a formal threat modeling exercise, involving cybersecurity experts with aviation experience. Use frameworks like STRIDE or PASTA to systematically identify threats, vulnerabilities, and potential attack scenarios. Document the threat model and use it to prioritize security controls and testing efforts. Consult with aviation cybersecurity specialists to understand industry-specific threats and vulnerabilities. Review the NIST Cybersecurity Framework and ENISA guidelines for aviation cybersecurity. Provide the threat model as input for the next consultation.

### 1.4.D Consequence

Without a threat model, the project may implement ineffective security measures, leaving the system vulnerable to cyberattacks that could disrupt airport operations, compromise data, or even cause physical harm.

### 1.4.E Root Cause

Lack of expertise in aviation cybersecurity threat modeling and a reliance on generic security best practices without considering the specific context of the project.

## 1.5.A Issue - Inadequate Incident Response Planning

The plan mentions SOC monitoring and an incident response plan, but it lacks specific details on how incidents will be handled in the context of a distributed sUAS localization system. What are the specific incident response procedures for different types of cyberattacks, such as a compromised edge node, a data breach, or a denial-of-service attack? How will the system be isolated and contained in the event of an incident? What are the communication protocols for notifying stakeholders, including airport authorities, EASA, and law enforcement? The current plan is too vague and does not provide a clear roadmap for responding to security incidents in a timely and effective manner. The 7-day patching SLO is a good start, but it's only one piece of the puzzle.

### 1.5.B Tags

- cybersecurity
- incident_response
- SOC

### 1.5.C Mitigation

Develop a detailed incident response plan that addresses specific attack scenarios and outlines clear procedures for containment, eradication, and recovery. Establish communication protocols for notifying stakeholders and coordinating with external agencies. Conduct regular incident response exercises to test the plan and identify areas for improvement. Consult with incident response experts and review industry best practices, such as the NIST Computer Security Incident Handling Guide. Provide the incident response plan for review during the next consultation.

### 1.5.D Consequence

Without a detailed incident response plan, the project may be unable to effectively respond to security incidents, leading to prolonged disruptions, data loss, and reputational damage.

### 1.5.E Root Cause

Lack of experience in developing and implementing incident response plans for complex, distributed systems and a failure to consider the specific challenges of the aviation environment.

## 1.6.A Issue - Insufficient Focus on Supply Chain Security

While the plan mentions SBOM and SLSA-3+, it doesn't adequately address the risks associated with the supply chain for hardware and software components. The project relies on numerous vendors for PTZ cameras, sensors, edge nodes, and software, each of which could be a potential source of vulnerabilities. What are the procedures for vetting vendors and ensuring the security of their products? How will the project verify the integrity of hardware and software components before deployment? What are the contingency plans in case a vendor is compromised or a critical component is found to be vulnerable? The current plan is too focused on software supply chain security and neglects the hardware aspects, which are equally important.

### 1.6.B Tags

- cybersecurity
- supply_chain
- SBOM
- SLSA

### 1.6.C Mitigation

Develop a comprehensive supply chain security plan that includes vendor vetting, hardware and software integrity verification, and contingency planning. Implement a process for regularly monitoring vendors for security vulnerabilities and incidents. Consider using a Software Bill of Materials (SBOM) to track the components used in the system and identify potential vulnerabilities. Consult with supply chain security experts and review industry best practices, such as the NIST Supply Chain Risk Management Practices for Federal Information Systems and Organizations. Provide the supply chain security plan for review during the next consultation.

### 1.6.D Consequence

Without a robust supply chain security plan, the project may be vulnerable to attacks that exploit vulnerabilities in hardware or software components, leading to system compromise and data breaches.

### 1.6.E Root Cause

Lack of awareness of the risks associated with supply chain security and a failure to implement adequate controls to mitigate those risks.

---

# 2 Expert: PTZ Camera Calibration Engineer

**Knowledge**: PTZ camera systems, optical calibration, lens distortion correction, DLT, bundle adjustment

**Why**: Needed to refine the calibration methodology, ensuring the required 3D accuracy KPIs are met consistently.

**What**: Evaluate the proposed calibration methodology, focusing on accuracy, drift, and automation potential.

**Skills**: computer vision, photogrammetry, robotics, Kalman filtering, error propagation

**Search**: PTZ camera calibration, DLT, bundle adjustment, computer vision

## 2.1 Primary Actions

- Develop a detailed error budget for the calibration process, quantifying expected errors and modeling error propagation through DLT triangulation.
- Implement a continuous zoom calibration procedure and evaluate different lens distortion models to accurately handle dynamic zoom and lens distortion.
- Implement a robust PTP monitoring system and develop a synchronization error compensation algorithm to mitigate the impact of temporal synchronization errors.

## 2.2 Secondary Actions

- Conduct a sensitivity analysis to determine how sensitive the 3D accuracy is to errors in each calibration parameter.
- Incorporate zoom level into the EDXP data structure.
- Conduct regular synchronization audits using an independent time source.

## 2.3 Follow Up Consultation

In the next consultation, we should discuss the specific methods for implementing the error budget, continuous zoom calibration, and synchronization error compensation. Please bring detailed information on the PTZ camera models being used, the network architecture, and the available calibration equipment.

## 2.4.A Issue - Insufficient Focus on Calibration Error Propagation and Uncertainty

The plan mentions multi-view RANSAC triangulation and uncertainty propagation, but lacks crucial details on how calibration errors are propagated through the DLT triangulation process and ultimately affect the 3D accuracy KPI. DLT is notoriously sensitive to calibration errors, especially with irregular camera geometries. The weekly drift checks via landmark resection and RTK-GNSS reference flights are a good start, but the plan needs a more rigorous error budget and sensitivity analysis. The current approach risks underestimating the impact of calibration errors on the overall system accuracy, potentially leading to failure to meet the P50 < 1.0 m, P90 ≤ 2.0 m accuracy KPI.

### 2.4.B Tags

- calibration
- error propagation
- uncertainty
- DLT
- accuracy KPI

### 2.4.C Mitigation

1.  **Develop a detailed error budget:** Quantify the expected errors in each stage of the calibration process (GCP surveying, intrinsic calibration, extrinsic calibration). Consult with a photogrammetry expert to model the error propagation through the DLT triangulation. Provide the error budget to the calibration team.
2.  **Conduct a sensitivity analysis:** Determine how sensitive the 3D accuracy is to errors in each calibration parameter (e.g., focal length, principal point, rotation angles, translation vectors). This will help prioritize calibration efforts and identify critical parameters. Consult with a computer vision specialist.
3.  **Implement a robust uncertainty propagation framework:** Use a method like the Kalman filter or Monte Carlo simulation to propagate the calibration uncertainties through the DLT triangulation process. This will provide a more realistic estimate of the 3D position uncertainty. Read papers on Kalman filtering and Monte Carlo simulation.
4.  **Refine the weekly drift checks:** Augment the landmark resection with a full bundle adjustment incorporating all cameras and GCPs. This will provide a more comprehensive assessment of the system's calibration drift. Provide the bundle adjustment results to the calibration team.

### 2.4.D Consequence

Failure to adequately address calibration error propagation could result in the system failing to meet the 3D accuracy KPI, leading to operational ineffectiveness and potential contract penalties.

### 2.4.E Root Cause

Lack of deep expertise in photogrammetry and error propagation within the project team. Underestimation of the complexity of calibrating irregular PTZ camera clusters.

## 2.5.A Issue - Insufficient Detail on Handling Dynamic Zoom and Lens Distortion

The plan mentions 'zoom-grid intrinsics per PTZ with lens distortion,' which is a good starting point, but it lacks specifics on how this will be implemented and maintained. PTZ cameras with dynamic zoom present a significant calibration challenge because the intrinsic parameters (focal length, distortion coefficients) change with zoom. Simply calibrating at a few zoom levels and interpolating is unlikely to be sufficient for achieving the required accuracy. Furthermore, lens distortion correction is crucial for accurate triangulation, and the plan needs to specify the distortion model being used (e.g., Brown-Conrady, Kannala-Brandt) and how the distortion parameters will be estimated and updated. The current approach risks significant errors in 2D keypoint localization, which will propagate through the DLT triangulation and degrade the 3D accuracy.

### 2.5.B Tags

- dynamic zoom
- lens distortion
- calibration
- 2D keypoints
- accuracy

### 2.5.C Mitigation

1.  **Implement a continuous zoom calibration procedure:** Develop a method for calibrating the camera at multiple zoom levels and fitting a continuous function to the intrinsic parameters as a function of zoom. Consult with a lens calibration expert.
2.  **Evaluate different lens distortion models:** Compare the performance of different distortion models (e.g., Brown-Conrady, Kannala-Brandt) on the specific PTZ cameras being used. Select the model that provides the best accuracy and stability. Read papers on lens distortion models.
3.  **Develop a robust lens distortion correction algorithm:** Implement a sub-pixel accurate lens distortion correction algorithm that can be applied to the 2D keypoints before triangulation. Provide the algorithm to the keypoint extraction team.
4.  **Incorporate zoom level into the EDXP data:** Include the current zoom level of each camera in the EDXP data structure. This will allow downstream systems to account for the zoom-dependent calibration parameters.

### 2.5.D Consequence

Inadequate handling of dynamic zoom and lens distortion could result in significant errors in 2D keypoint localization, leading to degraded 3D accuracy and failure to meet the accuracy KPI.

### 2.5.E Root Cause

Underestimation of the complexity of calibrating PTZ cameras with dynamic zoom and significant lens distortion. Lack of expertise in advanced lens calibration techniques.

## 2.6.A Issue - Insufficient Consideration of Temporal Synchronization Errors

The plan mentions PTP (IEEE-1588) with GPSDO and an end-to-end sync error ≤1 ms, which is a good target. However, achieving and maintaining this level of synchronization in a real-world deployment with multiple cameras and network hops is challenging. The plan lacks details on how the synchronization will be verified and maintained over time. Even small temporal synchronization errors can significantly degrade the accuracy of the DLT triangulation, especially for fast-moving targets. The plan needs to address potential sources of synchronization errors (e.g., network jitter, clock drift) and implement mitigation strategies. Furthermore, the impact of residual synchronization errors on the 3D accuracy KPI needs to be quantified.

### 2.6.B Tags

- temporal synchronization
- PTP
- IEEE-1588
- clock drift
- network jitter
- accuracy

### 2.6.C Mitigation

1.  **Implement a robust PTP monitoring system:** Continuously monitor the PTP synchronization status of each camera and edge node. Log any synchronization errors and alert operators if the error exceeds a predefined threshold. Consult with a network engineer.
2.  **Develop a synchronization error compensation algorithm:** Implement an algorithm to compensate for residual synchronization errors in the DLT triangulation process. This could involve estimating the time offset between cameras and correcting the 2D keypoint timestamps. Read papers on synchronization error compensation.
3.  **Conduct regular synchronization audits:** Periodically verify the end-to-end synchronization accuracy using an independent time source. This will help identify any potential synchronization issues and ensure that the PTP system is functioning correctly. Consult with a metrology expert.
4.  **Quantify the impact of synchronization errors on 3D accuracy:** Conduct simulations or experiments to determine how sensitive the 3D accuracy is to temporal synchronization errors. This will help define the acceptable synchronization error threshold.

### 2.6.D Consequence

Failure to adequately address temporal synchronization errors could result in degraded 3D accuracy, especially for fast-moving targets, leading to failure to meet the accuracy KPI.

### 2.6.E Root Cause

Underestimation of the challenges in achieving and maintaining accurate temporal synchronization in a real-world deployment. Lack of expertise in network timing and synchronization protocols.

---

# The following experts did not provide feedback:

# 3 Expert: EUROCONTROL/ASTERIX Data Standards Expert

**Knowledge**: EUROCONTROL, ASTERIX, surveillance data processing, air traffic management, data fusion

**Why**: Essential for ensuring the EDXP data format is fully compliant with EUROCONTROL/ASTERIX and NATO/STANAG standards.

**What**: Verify EDXP data structure compliance with EUROCONTROL/ASTERIX and NATO/STANAG, ensuring interoperability.

**Skills**: data modeling, data integration, air traffic control, aviation regulations, systems engineering

**Search**: EUROCONTROL ASTERIX expert, data standards, air traffic management

# 4 Expert: Airport Operations Specialist

**Knowledge**: airport operations, security protocols, UAS detection systems, disruption management, risk assessment

**Why**: Needed to assess the operational impact of the system and ensure seamless integration with existing airport workflows.

**What**: Review the CONOPS and integration plans, focusing on minimizing disruption and maximizing operational effectiveness.

**Skills**: airport security, emergency response, contingency planning, stakeholder management, process optimization

**Search**: airport operations specialist, UAS detection, security, risk management

# 5 Expert: Regulatory Compliance Consultant

**Knowledge**: aviation regulations, EASA compliance, GDPR, data protection, risk management

**Why**: Vital for navigating the regulatory landscape and ensuring compliance with EASA and GDPR requirements throughout the project.

**What**: Assess the regulatory compliance framework and identify potential gaps in the project plan.

**Skills**: regulatory analysis, compliance auditing, legal research, policy development, stakeholder engagement

**Search**: EASA compliance consultant, GDPR expert, aviation regulations

# 6 Expert: Data Privacy Officer

**Knowledge**: data privacy laws, GDPR compliance, data governance, risk assessment, privacy impact assessments

**Why**: Essential for ensuring that the project adheres to data privacy regulations and implements effective data governance strategies.

**What**: Review the data governance framework and privacy measures to ensure compliance with GDPR and other regulations.

**Skills**: privacy law, data protection strategies, risk management, compliance auditing, stakeholder communication

**Search**: data privacy officer, GDPR compliance, data governance expert

# 7 Expert: Sensor Fusion Algorithm Developer

**Knowledge**: sensor fusion, machine learning, Kalman filters, data analytics, real-time processing

**Why**: Crucial for optimizing the sensor fusion strategy to enhance detection accuracy and reduce false alerts in various conditions.

**What**: Evaluate and refine the proposed sensor fusion algorithms to ensure they meet performance KPIs.

**Skills**: algorithm development, statistical analysis, programming, data modeling, system integration

**Search**: sensor fusion expert, machine learning algorithms, Kalman filter developer

# 8 Expert: Project Management Officer (PMO)

**Knowledge**: project management, risk management, stakeholder engagement, resource allocation, timeline management

**Why**: Key for overseeing the project execution, ensuring adherence to timelines, budgets, and stakeholder expectations.

**What**: Review the project plan and timeline, ensuring alignment with strategic objectives and resource availability.

**Skills**: project planning, agile methodologies, communication, leadership, performance monitoring

**Search**: project management officer, PMO expert, project planning specialist