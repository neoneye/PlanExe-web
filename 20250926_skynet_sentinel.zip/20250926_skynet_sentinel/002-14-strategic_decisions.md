## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of **Security vs. Cost**, **Accuracy vs. Complexity**, **Privacy vs. Utility**, and **Risk vs. Speed**. These levers collectively govern the project's core risk/reward profile, balancing performance, security, and compliance within the given budget and timeline. No key strategic dimensions appear to be missing.

### Decision 1: Deployment Density Strategy
**Lever ID:** `9ae15147-ad9a-490f-a07e-d642abe2b550`

**The Core Decision:** The Deployment Density Strategy lever controls the number of sensor clusters deployed within the operational area. Objectives include balancing cost, coverage, and accuracy. A sparse deployment minimizes initial costs but risks coverage gaps. A moderate deployment balances cost and performance. A dense deployment maximizes coverage and accuracy, dynamically allocating resources. Key success metrics include detection probability (Pd), 3D accuracy, and reduction in disruption minutes, all measured against the chosen density.

**Why It Matters:** Cluster density affects coverage, accuracy, and cost. Immediate: Impacts initial deployment expenses. → Systemic: Influences the overall system's detection probability and localization accuracy, affecting operational effectiveness. → Strategic: Determines the scalability and adaptability of the system to different airport layouts and threat profiles, impacting long-term ROI.

**Strategic Choices:**

1. Sparse Deployment: Minimize initial costs by deploying fewer clusters, accepting potential coverage gaps and reduced accuracy in some areas.
2. Moderate Deployment: Balance cost and performance by deploying clusters at a density that provides adequate coverage and accuracy in critical areas.
3. Dense Deployment with Adaptive Resource Allocation: Maximize coverage and accuracy by deploying a high density of clusters, dynamically allocating resources based on real-time threat assessments and environmental conditions.

**Trade-Off / Risk:** Controls Cost vs. Coverage. Weakness: The options don't consider the impact of cluster density on the frequency of calibration and maintenance required.

**Strategic Connections:**

**Synergy:** A denser deployment strategy significantly enhances the effectiveness of the `Sensor Fusion Strategy` by providing more overlapping views and redundant data, leading to improved accuracy and robustness. It also works well with `Calibration Methodology` as more data points can be used for calibration.

**Conflict:** A denser deployment strategy directly conflicts with budget constraints. It also increases the complexity and cost of the `Cybersecurity Hardening Approach`, as more nodes require protection. A sparse deployment reduces these costs but compromises performance.

**Justification:** *High*, High importance due to its direct impact on cost, coverage, and accuracy, influencing both initial expenses and long-term ROI. Its synergy and conflict texts show strong connections to sensor fusion and cybersecurity.

### Decision 2: Cybersecurity Hardening Approach
**Lever ID:** `f32fdaa8-a36a-484c-acea-122231821bb4`

**The Core Decision:** The Cybersecurity Hardening Approach lever determines the level of security measures implemented to protect the system. Objectives include preventing unauthorized access, data breaches, and system disruptions. Options range from baseline security measures to a proactive, AI-driven approach with blockchain integration. Key success metrics include the number of detected cyber incidents, patch SLO compliance, and the results of red-team exercises, all measured against the chosen security level.

**Why It Matters:** Cybersecurity measures impact system security and operational overhead. Immediate: Affects initial development costs and ongoing security monitoring expenses. → Systemic: Determines the system's vulnerability to cyberattacks and data breaches, influencing public trust and regulatory compliance. → Strategic: Impacts the long-term security and resilience of the system, affecting its ability to operate in a contested environment.

**Strategic Choices:**

1. Baseline Security: Implement standard cybersecurity measures, focusing on compliance with basic regulations and industry best practices.
2. Enhanced Security: Implement a comprehensive Zero-Trust architecture with advanced threat detection and response capabilities, exceeding regulatory requirements.
3. Proactive Security with AI-Driven Threat Hunting: Utilize AI to proactively identify and mitigate emerging cyber threats, continuously adapting security measures to stay ahead of attackers and incorporating blockchain for immutable audit trails.

**Trade-Off / Risk:** Controls Security vs. Operational Overhead. Weakness: The options don't explicitly address the impact of security measures on system performance and latency.

**Strategic Connections:**

**Synergy:** A proactive cybersecurity approach strongly complements the `Data Governance Framework`, ensuring that privacy measures like anonymization and differential privacy are effectively enforced and that data is protected throughout its lifecycle. It also enhances the `Calibration Methodology` by protecting the integrity of calibration data.

**Conflict:** A more robust cybersecurity approach increases costs and complexity, potentially conflicting with budget constraints and schedule. It may also constrain the `Deployment Density Strategy` if security requirements necessitate more expensive hardware or network configurations. Baseline security reduces costs but increases risk.

**Justification:** *Critical*, Critical because it governs the system's vulnerability to cyberattacks, impacting public trust and regulatory compliance. Its conflict text reveals a core trade-off between security, cost, and schedule, making it a central decision point.

### Decision 3: Calibration Methodology
**Lever ID:** `c04e5f31-bb7b-49e0-991a-f5b28babf6c7`

**The Core Decision:** The Calibration Methodology lever determines how the system's sensors are calibrated to ensure accuracy. Objectives include achieving the required 3D accuracy KPIs and maintaining system performance over time. Options range from manual calibration to semi-automated and fully autonomous calibration. Key success metrics include 3D accuracy (P50, P90), drift rate, and the frequency of required recalibration, all measured against the chosen methodology.

**Why It Matters:** Calibration rigor directly affects localization accuracy and maintenance costs. Immediate: Impacts initial system accuracy. → Systemic: 20% reduction in maintenance costs due to less frequent recalibration needs. → Strategic: Ensures long-term system performance and reduces operational expenses.

**Strategic Choices:**

1. Manual Calibration: Rely on manual measurements and adjustments for camera calibration.
2. Semi-Automated Calibration: Use automated tools to assist with calibration, supplemented by manual verification.
3. Autonomous Calibration: Implement a fully automated calibration system using AI and continuous self-calibration techniques.

**Trade-Off / Risk:** Controls Accuracy vs. Cost. Weakness: The options lack detail on how calibration frequency is balanced against initial calibration effort.

**Strategic Connections:**

**Synergy:** An autonomous calibration system greatly enhances the effectiveness of the `Deployment Density Strategy`, as it can automatically compensate for variations in sensor placement and environmental conditions across a dense network. It also supports the `Sensor Fusion Strategy` by ensuring that the input data is accurately aligned.

**Conflict:** A fully autonomous calibration system requires significant initial investment and may increase the complexity of the system, potentially conflicting with budget constraints and schedule. It may also constrain the `Cybersecurity Hardening Approach` if the calibration system introduces new vulnerabilities. Manual calibration is cheaper but less accurate and more labor-intensive.

**Justification:** *Critical*, Critical because it directly affects localization accuracy and maintenance costs, ensuring long-term system performance. Its synergy and conflict texts show it's a central hub connecting deployment density, sensor fusion, and cybersecurity.

### Decision 4: Deployment Phasing Strategy
**Lever ID:** `c05cf7cd-3836-46fb-b62f-93bb42e69604`

**The Core Decision:** The Deployment Phasing Strategy dictates the speed and scope of airport deployments. It controls the number of airports brought online in each phase (2026 and 2027). Objectives include minimizing risk, optimizing resource allocation, and achieving full operational capability (FOC) on schedule. Key success metrics are the number of airports deployed per phase, adherence to the overall timeline, and the successful completion of acceptance tests at each location. This lever directly impacts budget allocation and resource planning.

**Why It Matters:** The pace of airport rollout affects resource allocation and risk exposure. Immediate: Slower initial deployment → Systemic: Reduced strain on integration teams and supply chains → Strategic: Delayed achievement of full operational capability and potential loss of market share.

**Strategic Choices:**

1. Conservative Rollout: Focus on a single pilot airport (CPH) in 2026 before expanding to additional locations in 2027.
2. Planned Rollout: Execute the planned Phase 1 (CPH, AAL) in 2026 and Phase 2 (30 airports) in 2027.
3. Accelerated Rollout: Parallelize deployment across multiple airports in 2026, leveraging modular designs and automated installation tools, accepting higher initial risk and resource demands.

**Trade-Off / Risk:** Controls Risk vs. Speed. Weakness: The options don't account for potential delays due to unforeseen regulatory hurdles at different airports.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with `Deployment Density Strategy`. A conservative rollout allows for higher deployment density in the initial airports, maximizing early KPI validation. A planned or accelerated rollout requires careful coordination with `Deployment Density Strategy` to avoid over-extending resources.

**Conflict:** An accelerated rollout conflicts with the `Calibration Methodology`. More airports online sooner demands a faster, potentially less rigorous calibration process, risking accuracy KPIs. Conversely, a conservative rollout allows for more thorough calibration but delays overall program completion.

**Justification:** *Critical*, Critical because it controls the speed and scope of airport deployments, directly impacting resource allocation, risk exposure, and the achievement of FOC. It governs the fundamental trade-off between risk and speed.

### Decision 5: Countermeasure Integration
**Lever ID:** `9cdde6a1-0a3d-435b-8503-1c283e1fce9b`

**The Core Decision:** The Countermeasure Integration lever defines the level of integration with non-kinetic countermeasures. It controls whether the system passively monitors, provides advisory alerts, or autonomously responds to threats. Objectives include minimizing disruption, maximizing security, and adhering to legal/ethical guidelines. Key success metrics are the reduction in disruption minutes, the effectiveness of countermeasures, and the avoidance of unintended consequences. This lever is heavily influenced by national regulations.

**Why It Matters:** The level of integration with non-kinetic countermeasures impacts operational effectiveness and legal compliance. Immediate: Increased system complexity → Systemic: 10% higher integration costs and potential legal liabilities → Strategic: Enhanced ability to mitigate UAS threats and protect airport operations.

**Strategic Choices:**

1. Passive Monitoring: Focus solely on detection and tracking, providing data to authorities for independent action.
2. Advisory Integration: Provide automated alerts and recommendations to operators, enabling informed decision-making.
3. Autonomous Response: Integrate with automated non-kinetic countermeasures (e.g., jamming, spoofing) under strict human oversight and pre-approved rules of engagement, leveraging AI-powered threat assessment and response protocols.

**Trade-Off / Risk:** Controls Security vs. Legality. Weakness: The options fail to consider the ethical implications of autonomous countermeasures.

**Strategic Connections:**

**Synergy:** This lever has strong synergy with the `Data Governance Framework`. More aggressive countermeasure integration (Advisory or Autonomous) requires a robust data governance framework to ensure responsible and ethical use of data, including privacy protection and audit trails. It also synergizes with `Sensor Fusion Strategy` to improve threat assessment.

**Conflict:** Autonomous response conflicts with `Cybersecurity Hardening Approach`. Increased automation introduces new attack vectors and requires significantly more robust cybersecurity measures to prevent malicious actors from manipulating the system. Passive monitoring minimizes this conflict but limits the system's overall effectiveness.

**Justification:** *Critical*, Critical because it defines the level of integration with non-kinetic countermeasures, impacting operational effectiveness, legal compliance, and ethical considerations. It controls the core tension between security and legality.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Sensor Fusion Strategy
**Lever ID:** `a7767ff4-2d4a-42dd-8fc7-e0ad09e6eb23`

**The Core Decision:** The Sensor Fusion Strategy lever defines how data from different sensors (optical, thermal, RF, acoustic) is combined to improve detection accuracy and reliability. Objectives include maximizing detection probability (Pd), minimizing false alerts, and ensuring track continuity. Options range from rule-based fusion to Kalman filter fusion and deep learning fusion. Key success metrics include Pd, false alert rate, and track continuity, measured under various environmental conditions.

**Why It Matters:** Selecting a sensor fusion approach impacts system performance and cost. Immediate: Changes detection rates. → Systemic: 15% improvement in detection probability in adverse weather conditions leads to fewer operational disruptions. → Strategic: Enhances overall system reliability and reduces the need for costly physical countermeasures.

**Strategic Choices:**

1. Rule-Based Fusion: Prioritize sensor data based on predefined rules and environmental conditions.
2. Kalman Filter Fusion: Employ a Kalman filter to optimally combine sensor data based on estimated noise characteristics.
3. Deep Learning Fusion: Utilize a deep neural network to learn complex sensor relationships and improve fusion accuracy in dynamic environments.

**Trade-Off / Risk:** Controls Accuracy vs. Complexity. Weakness: The options don't explicitly address the computational cost associated with each fusion method, particularly Deep Learning Fusion.

**Strategic Connections:**

**Synergy:** A deep learning fusion strategy benefits significantly from a `Dense Deployment Strategy`, as it provides more data for training the neural network and improving its accuracy. It also synergizes with a robust `Calibration Methodology`, as accurate sensor calibration is crucial for effective data fusion.

**Conflict:** A more sophisticated sensor fusion strategy, like deep learning, requires more computational resources and may increase latency, potentially conflicting with the latency KPI. It may also increase the complexity of the `Cybersecurity Hardening Approach`, as the fusion algorithms themselves become a potential attack vector. Rule-based fusion is simpler but less accurate.

**Justification:** *High*, High importance as it directly impacts detection accuracy, reliability, and latency, influencing the system's ability to meet its KPIs. Its synergy and conflict texts highlight its connections to deployment density and calibration.

### Decision 7: Data Governance Framework
**Lever ID:** `45bf7b70-507c-459e-9dfe-37f9d8a8f93f`

**The Core Decision:** The Data Governance Framework lever defines how data is managed to protect privacy while maximizing its utility for analysis. Objectives include complying with privacy regulations, minimizing the risk of data breaches, and enabling effective threat detection. Options range from strict anonymization to differential privacy and federated learning. Key success metrics include compliance with privacy regulations, the level of data utility retained, and the number of privacy incidents.

**Why It Matters:** Data governance dictates privacy compliance and data utility. Immediate: Affects data accessibility. → Systemic: 30% faster incident response times due to streamlined data access and analysis. → Strategic: Builds trust with stakeholders and ensures legal compliance, reducing reputational and financial risks.

**Strategic Choices:**

1. Strict Anonymization: Implement strict anonymization techniques to protect privacy, limiting data utility.
2. Differential Privacy: Apply differential privacy techniques to balance privacy and data utility for analysis.
3. Federated Learning: Utilize federated learning to train models without directly accessing sensitive data, maximizing both privacy and utility.

**Trade-Off / Risk:** Controls Privacy vs. Utility. Weakness: The options don't consider the impact of data governance on the ability to train and improve the AI models used for detection and tracking.

**Strategic Connections:**

**Synergy:** Federated learning, as a data governance framework, strongly supports the `Sensor Fusion Strategy` by allowing models to be trained on decentralized data without compromising privacy. This is especially useful when combining data from multiple airports. It also works well with `Cybersecurity Hardening Approach`.

**Conflict:** Strict anonymization, while maximizing privacy, can significantly reduce the utility of the data for analysis, potentially conflicting with the objective of effective threat detection. It may also constrain the `Deployment Density Strategy` if the data is not rich enough to optimize sensor placement. Differential privacy offers a better balance but is more complex.

**Justification:** *High*, High importance as it dictates privacy compliance and data utility, impacting incident response times and stakeholder trust. Its synergy and conflict texts show strong connections to sensor fusion and cybersecurity.
