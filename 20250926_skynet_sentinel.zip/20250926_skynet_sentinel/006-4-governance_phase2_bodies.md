### 1. Project Steering Committee

**Rationale for Inclusion:** Mandated by EASA and crucial for providing strategic direction, approving major milestones, and ensuring alignment with EASA, EUROCONTROL, and NATO requirements. Given the €200M budget and multi-airport deployment, high-level oversight is essential.

**Responsibilities:**

- Provide strategic direction and oversight for the SkyNet Sentinel program.
- Approve major project milestones (PDR, CDR, Pilot Acceptance, Down-select/PRR, IOC, FOC).
- Approve budget allocations and changes exceeding €5M.
- Review and approve risk mitigation strategies for high-impact risks.
- Ensure compliance with EASA, EUROCONTROL, and NATO regulations.
- Resolve strategic conflicts and escalate unresolved issues.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson (EASA representative).
- Establish a communication protocol with the PMO and other governance bodies.
- Define the escalation path for unresolved issues.

**Membership:**

- EASA Representative (Chair)
- Senior Representative from EUROCONTROL
- Representative from a NATO Member State (rotating)
- Senior Representative from the PMO
- Independent Technical Expert
- Independent Legal Counsel

**Decision Rights:** Approval authority for strategic decisions, budget allocations exceeding €5M, major project milestones, and changes to project scope or objectives.

**Decision Mechanism:** Decisions are made by majority vote, with the EASA representative holding the tie-breaking vote. Any decision impacting regulatory compliance requires unanimous approval.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions or escalations.

**Typical Agenda Items:**

- Review of project progress against milestones and KPIs.
- Discussion and approval of budget allocations and changes.
- Review of risk assessments and mitigation strategies.
- Updates on regulatory compliance and stakeholder engagement.
- Resolution of strategic conflicts and escalations.

**Escalation Path:** EASA Director General for unresolved strategic issues or conflicts impacting EASA regulations.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Essential for managing the day-to-day execution of the project, coordinating Teams A/B/C, tracking progress against KPIs, and managing operational risks. The PMO ensures consistent application of project management methodologies and facilitates communication across all project stakeholders.

**Responsibilities:**

- Manage the day-to-day execution of the SkyNet Sentinel program.
- Develop and maintain the project plan, schedule, and budget.
- Coordinate the activities of Teams A/B/C and ensure alignment with project objectives.
- Track project progress against milestones and KPIs.
- Manage operational risks and implement mitigation strategies.
- Report project status to the Steering Committee and other stakeholders.
- Manage procurement processes and vendor relationships.
- Ensure compliance with project policies and procedures.

**Initial Setup Actions:**

- Establish a project management framework and methodology.
- Develop a detailed project plan, schedule, and budget.
- Define roles and responsibilities for PMO staff.
- Establish communication protocols with project teams and stakeholders.
- Implement a risk management process.

**Membership:**

- Project Manager (PMO Lead)
- Technical Lead
- Financial Controller
- Risk Manager
- Procurement Manager
- Communications Manager
- Representatives from Teams A, B, and C

**Decision Rights:** Authority to make operational decisions within the approved project plan and budget, manage project resources, and implement risk mitigation strategies. Decisions with a financial impact exceeding €500,000 require Steering Committee approval.

**Decision Mechanism:** Decisions are made by the PMO Lead in consultation with relevant PMO staff and project team members. Conflicts are resolved through discussion and negotiation, with escalation to the Steering Committee if necessary.

**Meeting Cadence:** Weekly, with ad-hoc meetings as needed for critical issues or escalations.

**Typical Agenda Items:**

- Review of project progress against milestones and KPIs.
- Discussion of operational risks and mitigation strategies.
- Coordination of activities across project teams.
- Review of budget status and financial performance.
- Updates on procurement activities and vendor relationships.
- Identification and resolution of project issues and challenges.

**Escalation Path:** Project Steering Committee for issues exceeding PMO authority or impacting strategic objectives.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on critical aspects of the project, such as sensor selection, algorithm development, and system integration. Given the technical complexity of the project and the need to achieve stringent accuracy and latency KPIs, independent technical review is essential.

**Responsibilities:**

- Provide technical guidance and expertise to the PMO and project teams.
- Review and assess the technical feasibility of project plans and designs.
- Evaluate sensor selection and algorithm development processes.
- Assess system integration and testing plans.
- Provide recommendations for improving system performance and reliability.
- Review and approve technical documentation and specifications.
- Conduct independent technical audits and assessments.

**Initial Setup Actions:**

- Define the scope and objectives of the Technical Advisory Group.
- Identify and recruit qualified technical experts.
- Establish a communication protocol with the PMO and project teams.
- Develop a process for reviewing and approving technical documentation.

**Membership:**

- Independent Expert in Optical Sensors
- Independent Expert in Thermal Sensors
- Independent Expert in RF and Acoustic Sensors
- Independent Expert in Algorithm Development
- Independent Expert in System Integration
- Representative from the PMO (non-voting)

**Decision Rights:** Authority to provide technical recommendations and approve technical specifications. The PMO is responsible for implementing the recommendations, but must justify any deviations to the Steering Committee.

**Decision Mechanism:** Decisions are made by consensus among the technical experts. If consensus cannot be reached, the issue is escalated to the Steering Committee for resolution.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical progress and challenges.
- Assessment of sensor selection and algorithm performance.
- Evaluation of system integration and testing results.
- Discussion of technical risks and mitigation strategies.
- Review of technical documentation and specifications.
- Identification of opportunities for technical innovation.

**Escalation Path:** Project Steering Committee for unresolved technical issues or conflicts impacting project objectives.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with GDPR, ethical standards, and relevant regulations, particularly regarding privacy and data security. Given the sensitive nature of the data collected and the potential for misuse, independent oversight of ethical and compliance issues is crucial.

**Responsibilities:**

- Ensure compliance with GDPR and other privacy regulations.
- Develop and implement ethical guidelines for data collection and use.
- Review and approve data protection impact assessments (DPIAs).
- Monitor data handling practices and identify potential privacy risks.
- Investigate and resolve privacy complaints.
- Provide training to project staff on ethical and compliance issues.
- Conduct regular compliance audits.
- Oversee the implementation of privacy zones and auto-redaction features.

**Initial Setup Actions:**

- Develop a comprehensive data protection plan.
- Establish ethical guidelines for data collection and use.
- Define roles and responsibilities for compliance staff.
- Establish a process for investigating and resolving privacy complaints.
- Implement a compliance monitoring program.

**Membership:**

- Independent Legal Counsel (Chair)
- Data Protection Officer (DPO)
- Ethics Officer
- Representative from the PMO (non-voting)
- Independent Expert in Data Privacy
- Representative from a relevant advocacy group (e.g., civil liberties organization)

**Decision Rights:** Authority to approve data protection policies, ethical guidelines, and data protection impact assessments. The PMO is responsible for implementing the decisions, but must justify any deviations to the Steering Committee.

**Decision Mechanism:** Decisions are made by majority vote, with the Independent Legal Counsel holding the tie-breaking vote. Any decision impacting GDPR compliance requires unanimous approval.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical compliance issues.

**Typical Agenda Items:**

- Review of data protection policies and procedures.
- Discussion of ethical issues and concerns.
- Review of data protection impact assessments (DPIAs).
- Updates on privacy complaints and investigations.
- Review of compliance audit results.
- Discussion of regulatory changes and their impact on the project.

**Escalation Path:** Data Protection Authority for unresolved compliance issues or breaches of GDPR.
### 5. Independent Verification and Validation (IV&V) Team

**Rationale for Inclusion:** Provides independent assessment of project progress, technical quality, and compliance with requirements. Given the complexity and criticality of the project, independent IV&V is essential to ensure objectivity and identify potential issues early on. Public quarterly summaries enhance transparency.

**Responsibilities:**

- Conduct independent reviews of project plans, designs, and deliverables.
- Assess the technical quality of the system and its components.
- Verify compliance with requirements and standards.
- Identify potential risks and issues.
- Provide recommendations for improving project performance and quality.
- Prepare and publish quarterly summaries of IV&V findings.
- Conduct independent testing and validation of the system.

**Initial Setup Actions:**

- Define the scope and objectives of the IV&V team.
- Establish a communication protocol with the PMO and project teams.
- Develop a process for reviewing project documentation and deliverables.
- Establish a process for reporting IV&V findings and recommendations.

**Membership:**

- Independent Technical Expert (IV&V Lead)
- Independent Quality Assurance Expert
- Independent Security Expert
- Independent Regulatory Compliance Expert

**Decision Rights:** Authority to conduct independent assessments and report findings to the Steering Committee. The PMO is responsible for addressing the IV&V findings, but must justify any deviations to the Steering Committee.

**Decision Mechanism:** Decisions are made by consensus among the IV&V team members. If consensus cannot be reached, the issue is escalated to the Steering Committee for resolution.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical issues or milestones.

**Typical Agenda Items:**

- Review of project progress and milestones.
- Assessment of technical quality and compliance with requirements.
- Discussion of potential risks and issues.
- Review of IV&V findings and recommendations.
- Preparation of quarterly summaries for publication.

**Escalation Path:** Project Steering Committee for unresolved issues or concerns regarding project performance or compliance.