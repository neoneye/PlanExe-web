### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Independent Verification and Validation (IV&V) Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft IV&V Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 6. Circulate Draft Project Steering Committee ToR v0.1 for review by EASA and EUROCONTROL representatives.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1

### 7. Circulate Draft Technical Advisory Group ToR v0.1 for review by potential members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Technical Advisory Group ToR

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 8. Circulate Draft Ethics & Compliance Committee ToR v0.1 for review by potential members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Ethics & Compliance Committee ToR

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 9. Circulate Draft Independent Verification and Validation (IV&V) Team ToR v0.1 for review by potential members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on IV&V Team ToR

**Dependencies:**

- Draft IV&V Team ToR v0.1

### 10. Circulate Draft Project Management Office (PMO) ToR v0.1 for review by potential members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1

### 11. Project Manager finalizes Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 12. Project Manager finalizes Technical Advisory Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary on Technical Advisory Group ToR

### 13. Project Manager finalizes Ethics & Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary on Ethics & Compliance Committee ToR

### 14. Project Manager finalizes Independent Verification and Validation (IV&V) Team ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final IV&V Team ToR v1.0

**Dependencies:**

- Feedback Summary on IV&V Team ToR

### 15. Project Manager finalizes Project Management Office (PMO) ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 16. EASA formally appoints the Chairperson of the Project Steering Committee.

**Responsible Body/Role:** EASA

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Manager, in consultation with EASA, identifies and invites members to the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment of SteerCo Chair

### 18. Project Manager identifies and invites members to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 19. Project Manager identifies and invites members to the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 20. Project Manager identifies and invites members to the Independent Verification and Validation (IV&V) Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Nominated Members List Available
- Invitation Letters Sent

**Dependencies:**

- Final IV&V Team ToR v1.0

### 21. Project Manager identifies and appoints PMO Lead and PMO staff.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Staff List
- Appointment Confirmation Emails

**Dependencies:**

- Final PMO ToR v1.0

### 22. Formally confirm membership of the Project Steering Committee.

**Responsible Body/Role:** EASA

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Nominated Members List Available
- Appointment of SteerCo Chair

### 23. Formally confirm membership of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Nominated Members List Available

### 24. Formally confirm membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Nominated Members List Available

### 25. Formally confirm membership of the Independent Verification and Validation (IV&V) Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Confirmed IV&V Team Membership List

**Dependencies:**

- Nominated Members List Available

### 26. Schedule and hold the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed SteerCo Membership List
- Final SteerCo ToR v1.0

### 27. Schedule and hold the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Technical Advisory Group Membership List
- Final Technical Advisory Group ToR v1.0

### 28. Schedule and hold the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List
- Final Ethics & Compliance Committee ToR v1.0

### 29. Schedule and hold the initial kick-off meeting for the Independent Verification and Validation (IV&V) Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Confirmed IV&V Team Membership List
- Final IV&V Team ToR v1.0

### 30. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staff List
- Final PMO ToR v1.0

### 31. The Project Steering Committee reviews and approves the project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Project Plan

**Dependencies:**

- Meeting Minutes with Action Items from SteerCo Kick-off
- Final Project Plan

### 32. The Technical Advisory Group reviews and approves the technical specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Technical Specifications

**Dependencies:**

- Meeting Minutes with Action Items from Technical Advisory Group Kick-off
- Draft Technical Specifications

### 33. The Ethics & Compliance Committee reviews and approves the data protection plan.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Data Protection Plan

**Dependencies:**

- Meeting Minutes with Action Items from Ethics & Compliance Committee Kick-off
- Draft Data Protection Plan

### 34. The Independent Verification and Validation (IV&V) Team conducts an initial review of the project plan and provides feedback.

**Responsible Body/Role:** Independent Verification and Validation (IV&V) Team

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- IV&V Initial Review Report

**Dependencies:**

- Meeting Minutes with Action Items from IV&V Team Kick-off
- Project Plan Approved