**Purpose:** business

**Purpose Detailed:** Development and deployment of a real-time unauthorized sUAS localization system for airports, including technology specifications, KPIs, privacy/cybersecurity measures, governance, and schedule.

**Topic:** EASA program "SkyNet Sentinel" for unauthorized sUAS localization