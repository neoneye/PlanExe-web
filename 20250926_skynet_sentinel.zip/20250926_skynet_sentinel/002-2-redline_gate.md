**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** The prompt describes a surveillance system, but focuses on high-level design, governance, and privacy considerations, so a response should avoid operational details.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |