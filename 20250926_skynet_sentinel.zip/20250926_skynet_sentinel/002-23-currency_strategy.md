This plan involves money.

## Currencies

- **EUR:** Primary currency for the EASA program and budgeting.
- **DKK:** Local currency for Denmark, where Copenhagen (CPH) and Aalborg (AAL) airports are located.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. DKK may be used for local transactions in Denmark. No additional international risk management is needed within the Eurozone.