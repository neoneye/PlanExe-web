# Purpose

**Purpose:** business

**Purpose Detailed:** Development and deployment of a real-time unauthorized sUAS localization system for airports, including technology specifications, KPIs, privacy/cybersecurity measures, governance, and schedule.

**Topic:** EASA program "SkyNet Sentinel" for unauthorized sUAS localization

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* physical deployment of camera clusters at airports, physical testing, and ongoing maintenance. The plan includes physical hardware (cameras, sensors, edge nodes), physical locations (airports), and physical activities (installation, calibration, testing, and maintenance). The development and deployment of the system *inherently involves* physical components and real-world environments.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Airports with suitable infrastructure for sensor cluster deployment (10-40m height, 300-800m baselines)
- Access to surveyed control points (≥6) for DLT resection and bundle adjustment
- Availability of GPSDO for PTP synchronization (≤1ms sync error)
- Compliance with EASA, EUROCONTROL, and NATO regulations
- Facilities for calibration, testing, and maintenance activities
- Privacy zones

## Location 1
Denmark

Copenhagen Airport (CPH)

Kastrup Airport, Copenhagen, Denmark

**Rationale**: Copenhagen Airport (CPH) is explicitly named as a Phase 1 pilot location, making it a primary site for deployment and testing. It is an existing international airport, likely possessing the necessary infrastructure and regulatory framework.

## Location 2
Denmark

Aalborg Airport (AAL)

Aalborg Airport, Aalborg, Denmark

**Rationale**: Aalborg Airport (AAL) is explicitly named as a Phase 1 pilot location, making it a primary site for deployment and testing. It is an existing international airport, likely possessing the necessary infrastructure and regulatory framework.

## Location 3
European Union

Major EU Airports

Airports in major EU cities

**Rationale**: The plan involves rolling out to 30 airports in the EU. Major airports in key EU cities (e.g., Frankfurt, Paris, Amsterdam) are logical candidates due to their high traffic volume and strategic importance.

## Location 4
NATO Member States

Airports in NATO Member States

Airports in NATO Member States

**Rationale**: The plan mentions NATO/STANAG integration, suggesting potential deployment in NATO member states. Airports in these countries would be relevant for interoperability and security cooperation.

## Location Summary
The plan requires deployment at Copenhagen Airport (CPH) and Aalborg Airport (AAL) as Phase 1 pilot locations. Subsequent rollout to 30 airports in the EU and potentially airports in NATO member states is also planned. These locations are relevant due to their existing infrastructure, strategic importance, and alignment with regulatory and security requirements.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** Primary currency for the EASA program and budgeting.
- **DKK:** Local currency for Denmark, where Copenhagen (CPH) and Aalborg (AAL) airports are located.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. DKK may be used for local transactions in Denmark. No additional international risk management is needed within the Eurozone.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Delays in obtaining necessary permits and approvals from EASA, EUROCONTROL, and national aviation authorities for deploying sensor clusters at airports. This includes potential conflicts with existing airport regulations and airspace management procedures.

**Impact:** A delay of 3-6 months in the deployment schedule, particularly affecting Phase 2 rollout. Could also lead to redesign of sensor cluster placement, incurring an extra cost of €100,000-€300,000 per airport.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with regulatory bodies (EASA, EUROCONTROL, national authorities) early in the project to understand requirements and establish a clear permitting process. Conduct preliminary site surveys to identify potential regulatory hurdles.

## Risk 2 - Technical
Failure to achieve the required 3D accuracy (P50 < 1.0 m, P90 ≤ 2.0 m at 1.5 km) due to challenges in calibrating irregular PTZ camera clusters and maintaining synchronization across the network. This includes issues with lens distortion correction, extrinsic calibration, and PTP synchronization.

**Impact:** Inability to meet the accuracy KPIs, leading to rejection of the system during acceptance testing. Could require significant rework of the calibration methodology and sensor fusion algorithms, resulting in a cost overrun of €500,000-€1,000,000 and a delay of 2-4 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Invest in advanced calibration tools and techniques, including AI-powered self-calibration. Conduct rigorous testing and validation of the calibration methodology in diverse environmental conditions. Implement redundant synchronization mechanisms to mitigate PTP failures.

## Risk 3 - Technical
Inability to meet the latency requirements (≤200 ms edge-to-bus; ≤750 ms to operator UI) due to computational bottlenecks in the edge nodes or network congestion. This includes challenges in processing high-resolution video streams, performing DLT triangulation, and fusing data from multiple sensors.

**Impact:** Failure to meet the latency KPIs, rendering the system unusable for real-time threat detection. Could require upgrading the edge node hardware or optimizing the network architecture, resulting in a cost overrun of €200,000-€400,000 and a delay of 1-2 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Optimize the edge node software and hardware for efficient processing of sensor data. Implement quality-of-service (QoS) mechanisms to prioritize EDXP traffic on the network. Conduct thorough performance testing and profiling to identify and address latency bottlenecks.

## Risk 4 - Cybersecurity
Vulnerabilities in the system's cybersecurity architecture, leading to unauthorized access, data breaches, or system disruptions. This includes potential attacks on the edge nodes, the network infrastructure, or the central threat database.

**Impact:** Compromise of sensitive data, disruption of airport operations, and reputational damage. Could result in significant financial losses and legal liabilities. Estimated cost of a major breach: €1,000,000 - €5,000,000.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement a robust Zero-Trust architecture with multi-factor authentication, encryption, and intrusion detection systems. Conduct regular penetration testing and vulnerability assessments. Establish a comprehensive incident response plan. Enforce strict patch SLOs (crit ≤7d).

## Risk 5 - Supply Chain
Disruptions in the supply chain for critical components, such as PTZ cameras, sensors, and edge node hardware, due to geopolitical events, natural disasters, or supplier bankruptcies.

**Impact:** Delays in the deployment schedule and increased costs due to the need to find alternative suppliers or redesign the system. A delay of 2-4 weeks per affected component.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish relationships with multiple suppliers for critical components. Maintain a buffer stock of key components. Implement a supply chain risk management plan to identify and mitigate potential disruptions.

## Risk 6 - Operational
Difficulties in integrating the system with existing airport security infrastructure and workflows. This includes challenges in training operators, managing false alerts, and coordinating with other security personnel.

**Impact:** Reduced effectiveness of the system and increased operational costs. Could lead to delays in the deployment schedule and negative feedback from airport operators. A 10-20% increase in operational costs.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Involve airport operators in the design and development of the system. Provide comprehensive training to operators on the use of the system. Establish clear protocols for managing false alerts and coordinating with other security personnel. Conduct regular operational exercises to validate the system's effectiveness.

## Risk 7 - Social
Public concerns about privacy and data security, leading to negative publicity and regulatory scrutiny. This includes concerns about the collection and storage of personal data, the use of facial recognition technology (even though explicitly prohibited), and the potential for misuse of the system.

**Impact:** Damage to the project's reputation and loss of public trust. Could lead to regulatory restrictions and delays in the deployment schedule. A 10-20% increase in project costs due to additional privacy measures.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement robust privacy measures, including data anonymization, privacy zones, and auto-redaction. Communicate transparently with the public about the system's purpose and privacy safeguards. Engage with privacy advocacy groups to address their concerns. Ensure compliance with GDPR and other relevant privacy regulations.

## Risk 8 - Financial
Cost overruns due to unforeseen technical challenges, regulatory changes, or supply chain disruptions. This includes potential increases in the cost of hardware, software, and labor.

**Impact:** Reduction in the scope of the project or cancellation of the project. Could lead to financial losses for the stakeholders. A 10-20% increase in overall project costs.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a robust cost management plan with contingency reserves. Monitor project costs closely and identify potential overruns early. Implement change management procedures to control scope creep. Negotiate favorable contracts with suppliers and subcontractors.

## Risk 9 - Integration with Existing Infrastructure
Challenges in integrating the new SkyNet Sentinel system with existing airport security systems (e.g., radar, CCTV, access control). This includes potential compatibility issues, data format inconsistencies, and network integration problems.

**Impact:** Reduced effectiveness of the overall security system and increased operational complexity. Could lead to delays in the deployment schedule and increased integration costs. An extra cost of €50,000-€150,000 per airport.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct thorough integration testing with existing airport security systems. Develop clear integration specifications and data exchange protocols. Provide training to airport personnel on the integrated system. Establish a dedicated integration team with expertise in airport security systems.

## Risk 10 - Environmental
Environmental impact of deploying sensor clusters at airports, including potential noise pollution, visual intrusion, and disruption of wildlife habitats.

**Impact:** Delays in obtaining environmental permits and negative publicity. Could require modifications to the sensor cluster design or relocation of the clusters. A delay of 1-3 months in deployment.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct environmental impact assessments to identify potential environmental concerns. Implement mitigation measures to minimize the environmental impact of the sensor clusters. Engage with environmental advocacy groups to address their concerns. Ensure compliance with all relevant environmental regulations.

## Risk summary
The SkyNet Sentinel project faces significant risks across multiple domains. The most critical risks are regulatory delays, technical challenges in achieving the required accuracy and latency, and cybersecurity vulnerabilities. Failure to manage these risks could jeopardize the project's success by causing delays, cost overruns, and reputational damage. Mitigation strategies should focus on early engagement with regulatory bodies, investment in advanced calibration techniques, and implementation of a robust Zero-Trust cybersecurity architecture. The trade-off between security and cost, accuracy and complexity, and privacy and utility must be carefully managed to ensure the project's success.

# Make Assumptions


## Question 1 - What is the detailed breakdown of the €200M budget across the two phases, including allocations for sensor procurement, integration, personnel, and contingency?

**Assumptions:** Assumption: 60% of the budget (€120M) is allocated to sensor procurement and integration, 20% (€40M) to personnel (including training and PMO), 10% (€20M) to infrastructure and network setup, and 10% (€20M) as a contingency fund. This aligns with typical large-scale technology deployment budgets.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation and potential financial risks.
Details: A detailed budget breakdown is crucial for tracking expenses and managing potential cost overruns. The contingency fund is essential to mitigate unforeseen expenses. Risk: Cost overruns in sensor procurement or integration could deplete the contingency fund, jeopardizing the project's financial stability. Impact: Project delays or scope reduction. Mitigation: Implement rigorous cost control measures, negotiate favorable contracts with suppliers, and closely monitor project expenses. Opportunity: Efficient budget management could free up resources for additional features or deployments.

## Question 2 - Can you provide a detailed Gantt chart outlining all project milestones, including dependencies, resource allocation, and critical path analysis, especially for the integration of the system with existing airport infrastructure?

**Assumptions:** Assumption: The integration with existing airport infrastructure is on the critical path and requires at least 6 months per airport, including testing and validation. This is based on the complexity of integrating new systems with legacy infrastructure in operational environments.

**Assessments:** Title: Timeline and Milestone Assessment
Description: Evaluation of the project timeline and potential schedule risks.
Details: A detailed Gantt chart is essential for tracking progress and identifying potential delays. Risk: Delays in integrating with existing airport infrastructure could push back the entire project timeline. Impact: Failure to meet the IOC and FOC deadlines. Mitigation: Prioritize integration activities, allocate sufficient resources, and establish clear communication channels with airport authorities. Opportunity: Streamlining the integration process could accelerate the timeline and reduce costs.

## Question 3 - What specific expertise and number of personnel are allocated to each team (A, B, C) for sensor development, algorithm implementation, and system integration, and how will these teams collaborate?

**Assumptions:** Assumption: Each team (A, B, C) consists of 10-15 highly skilled engineers and researchers with expertise in optics, thermal imaging, RF/acoustic sensing, and algorithm development. This is based on the technical complexity of the project and the need for specialized skills.

**Assessments:** Title: Resource and Personnel Assessment
Description: Evaluation of the adequacy of resources and personnel allocation.
Details: Adequate staffing and expertise are crucial for successful project execution. Risk: Insufficient personnel or lack of expertise could lead to delays and quality issues. Impact: Failure to meet the technical KPIs. Mitigation: Conduct a skills gap analysis, hire qualified personnel, and provide adequate training. Opportunity: Leveraging existing expertise and fostering collaboration could improve efficiency and innovation.

## Question 4 - What specific EASA regulations and EUROCONTROL standards will govern the deployment and operation of the SkyNet Sentinel system, and how will compliance be ensured and documented?

**Assumptions:** Assumption: The system must comply with EASA regulations for UAS operations near airports (e.g., Part 107 equivalent) and EUROCONTROL standards for air traffic management integration. Compliance will be documented through regular audits and certifications. This is based on the need to ensure safe and efficient airspace operations.

**Assessments:** Title: Governance and Regulations Assessment
Description: Evaluation of the regulatory compliance framework and potential risks.
Details: Compliance with regulations is essential for legal operation and public acceptance. Risk: Failure to comply with regulations could lead to fines, operational restrictions, and reputational damage. Impact: Project delays or cancellation. Mitigation: Engage with regulatory bodies early in the project, establish a clear compliance framework, and conduct regular audits. Opportunity: Proactive compliance could build trust with stakeholders and streamline the approval process.

## Question 5 - What are the detailed safety protocols and risk mitigation strategies for the installation, operation, and maintenance of the sensor clusters, considering potential hazards such as high-altitude work, electrical safety, and weather conditions?

**Assumptions:** Assumption: Strict safety protocols will be implemented for all installation, operation, and maintenance activities, including fall protection, electrical safety procedures, and weather monitoring. Regular safety audits and training will be conducted. This is based on the need to protect workers and prevent accidents.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the safety protocols and risk mitigation strategies.
Details: Safety is paramount for protecting workers and preventing accidents. Risk: Accidents during installation, operation, or maintenance could lead to injuries, delays, and legal liabilities. Impact: Project delays and increased costs. Mitigation: Implement comprehensive safety protocols, provide adequate training, and conduct regular safety audits. Opportunity: A strong safety culture could improve morale and productivity.

## Question 6 - What specific measures will be taken to minimize the environmental impact of the sensor clusters, including noise pollution, visual intrusion, and disruption of wildlife habitats, and how will these measures be assessed and monitored?

**Assumptions:** Assumption: Environmental impact assessments will be conducted to identify potential environmental concerns. Mitigation measures will be implemented to minimize noise pollution, visual intrusion, and disruption of wildlife habitats. Regular monitoring will be conducted to assess the effectiveness of these measures. This is based on the need to protect the environment and comply with environmental regulations.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the environmental impact and mitigation measures.
Details: Minimizing environmental impact is crucial for sustainability and public acceptance. Risk: Negative environmental impacts could lead to regulatory restrictions and negative publicity. Impact: Project delays and increased costs. Mitigation: Conduct environmental impact assessments, implement mitigation measures, and engage with environmental advocacy groups. Opportunity: Environmentally friendly practices could enhance the project's reputation and attract stakeholders.

## Question 7 - How will airport authorities, local communities, and privacy advocacy groups be involved in the planning and deployment of the SkyNet Sentinel system, and what mechanisms will be used to address their concerns and feedback?

**Assumptions:** Assumption: Airport authorities, local communities, and privacy advocacy groups will be consulted throughout the project lifecycle. Their concerns and feedback will be addressed through regular meetings, public forums, and online communication channels. This is based on the need to build trust and ensure public acceptance.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the stakeholder engagement strategy.
Details: Stakeholder involvement is crucial for building trust and ensuring public acceptance. Risk: Lack of stakeholder engagement could lead to opposition and delays. Impact: Project delays and reputational damage. Mitigation: Establish a clear communication plan, conduct regular stakeholder meetings, and address concerns promptly. Opportunity: Positive stakeholder relationships could enhance the project's reputation and facilitate smooth deployment.

## Question 8 - What specific operational systems and processes will be implemented to manage the data flow, alert management, and system maintenance, including procedures for handling false alerts, system failures, and cybersecurity incidents?

**Assumptions:** Assumption: A comprehensive operational system will be implemented to manage data flow, alert management, and system maintenance. This system will include procedures for handling false alerts, system failures, and cybersecurity incidents. Regular training and drills will be conducted to ensure operational readiness. This is based on the need to ensure reliable and efficient system operation.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the operational systems and processes.
Details: Efficient operational systems are crucial for reliable and effective system operation. Risk: Inadequate operational systems could lead to system failures, data breaches, and ineffective threat detection. Impact: Reduced system performance and increased operational costs. Mitigation: Implement comprehensive operational systems, provide adequate training, and conduct regular drills. Opportunity: Streamlined operational processes could improve efficiency and reduce costs.

# Distill Assumptions

- €120M is for sensors/integration, €40M for personnel, €20M for infrastructure, €20M contingency.
- Airport infrastructure integration is critical, requiring 6 months per airport for testing.
- Each team (A, B, C) has 10-15 engineers with optics, RF, and algorithm expertise.
- System complies with EASA UAS rules and EUROCONTROL air traffic standards via audits.
- Strict safety protocols are implemented for installation/maintenance, including training and audits.
- Environmental impact assessments will minimize noise, visual intrusion, and habitat disruption; monitored regularly.
- Authorities/communities/advocates consulted via meetings/forums to address concerns and ensure public acceptance.
- Comprehensive system manages data, alerts, maintenance; includes procedures for failures and cyber incidents.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment for Complex Technology Deployments

## Domain-specific considerations

- Regulatory compliance (EASA, EUROCONTROL, national aviation authorities)
- Cybersecurity risks in critical infrastructure
- Integration with existing airport systems
- Public perception and privacy concerns
- Supply chain vulnerabilities
- Technical feasibility of achieving accuracy and latency KPIs

## Issue 1 - Unrealistic Timeline for Airport Infrastructure Integration
The assumption that airport infrastructure integration requires only 6 months per airport seems overly optimistic. Integrating complex systems with existing airport security, air traffic control, and IT infrastructure often involves unforeseen challenges, bureaucratic delays, and extensive testing. This timeframe doesn't account for potential customization needed for each airport's unique setup, nor does it consider the time required for user training and acceptance.

**Recommendation:** Conduct a detailed assessment of the integration requirements at a representative sample of airports (at least 3-5). This assessment should involve consultations with airport IT and security personnel to identify potential integration challenges and estimate realistic timelines. Based on this assessment, revise the project schedule and budget accordingly. Consider a phased integration approach, starting with simpler integrations and gradually moving to more complex ones. Allocate additional resources (personnel, budget, and time) to the integration phase. Engage a specialized systems integrator with experience in airport infrastructure projects.

**Sensitivity:** Underestimating the integration timeline (baseline: 6 months) could delay the project completion date by 6-12 months, potentially pushing the FOC beyond the planned timeframe. This delay could increase project costs by 10-15% due to penalties, extended contracts, and inflation. A more realistic integration timeline of 9-12 months per airport would increase the overall project cost by €20-40 million.

## Issue 2 - Insufficient Detail on Cybersecurity Measures and Budget Allocation
While the plan mentions a 'Zero-Trust architecture,' it lacks specific details on the cybersecurity measures to be implemented and the budget allocated to cybersecurity. Given the critical nature of the system and the potential for catastrophic consequences in case of a cyberattack, a more detailed cybersecurity plan is essential. The plan should address specific threats, vulnerabilities, and mitigation strategies, as well as the resources required to implement and maintain these measures. The current budget allocation of €20M for infrastructure and network setup may be insufficient to cover the costs of robust cybersecurity.

**Recommendation:** Develop a comprehensive cybersecurity plan that addresses all aspects of the system, from the edge nodes to the central threat database. This plan should include specific security controls, such as encryption, intrusion detection, access control, and vulnerability management. Conduct a thorough risk assessment to identify potential cybersecurity threats and vulnerabilities. Allocate a dedicated budget for cybersecurity, including personnel, software, hardware, and training. Consider engaging a specialized cybersecurity firm to conduct penetration testing and vulnerability assessments. Implement a robust incident response plan to address potential cyberattacks.

**Sensitivity:** A major cybersecurity breach could cost the project €1,000,000 - €5,000,000 in direct costs (remediation, legal fees, fines) and significantly damage the project's reputation. A failure to uphold GDPR principles may result in fines ranging from 5-10% of annual turnover. Increasing the cybersecurity budget by 5-10% (€10-20 million) could significantly reduce the risk of a successful cyberattack and protect the project's investment.

## Issue 3 - Lack of Granularity in Budget Allocation for Sensor Procurement and Integration
The assumption that 60% of the budget (€120M) is allocated to sensor procurement and integration is too high-level. This allocation needs to be broken down further to identify the specific costs associated with each sensor type (optical, thermal, RF, acoustic), integration activities, and software development. Without a more granular budget, it will be difficult to track expenses, manage potential cost overruns, and make informed decisions about resource allocation. The plan also doesn't account for potential cost increases due to supply chain disruptions or technological obsolescence.

**Recommendation:** Develop a detailed bill of materials (BOM) for all sensor components, including specifications, quantities, and unit costs. Obtain firm quotes from multiple suppliers for each component. Develop a detailed work breakdown structure (WBS) for the integration activities, including tasks, durations, and resource requirements. Allocate specific budget amounts to each sensor type, integration activity, and software development task. Establish a change management process to control scope creep and manage potential cost overruns. Regularly monitor project expenses and compare them to the budget. Consider purchasing insurance to mitigate the risk of supply chain disruptions or technological obsolescence.

**Sensitivity:** A 15% increase in the cost of sensors (baseline: €120 million) could reduce the project's ROI by 5-7%. Underestimating software development costs could delay the project by 3-6 months, or the ROI could be reduced by 10-15%. A more detailed budget breakdown and proactive cost management could save the project €5-10 million.

## Review conclusion
The SkyNet Sentinel project is ambitious and complex, requiring careful planning and execution. The identified issues highlight the need for more detailed assessments of the integration timeline, cybersecurity measures, and budget allocation. Addressing these issues proactively will significantly improve the project's chances of success and ensure that it delivers the desired benefits.