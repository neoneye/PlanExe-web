This plan implies one or more physical locations.

## Requirements for physical locations

- Airports with suitable infrastructure for sensor cluster deployment (10-40m height, 300-800m baselines)
- Access to surveyed control points (≥6) for DLT resection and bundle adjustment
- Availability of GPSDO for PTP synchronization (≤1ms sync error)
- Compliance with EASA, EUROCONTROL, and NATO regulations
- Facilities for calibration, testing, and maintenance activities
- Privacy zones

## Location 1
Denmark

Copenhagen Airport (CPH)

Kastrup Airport, Copenhagen, Denmark

**Rationale**: Copenhagen Airport (CPH) is explicitly named as a Phase 1 pilot location, making it a primary site for deployment and testing. It is an existing international airport, likely possessing the necessary infrastructure and regulatory framework.

## Location 2
Denmark

Aalborg Airport (AAL)

Aalborg Airport, Aalborg, Denmark

**Rationale**: Aalborg Airport (AAL) is explicitly named as a Phase 1 pilot location, making it a primary site for deployment and testing. It is an existing international airport, likely possessing the necessary infrastructure and regulatory framework.

## Location 3
European Union

Major EU Airports

Airports in major EU cities

**Rationale**: The plan involves rolling out to 30 airports in the EU. Major airports in key EU cities (e.g., Frankfurt, Paris, Amsterdam) are logical candidates due to their high traffic volume and strategic importance.

## Location 4
NATO Member States

Airports in NATO Member States

Airports in NATO Member States

**Rationale**: The plan mentions NATO/STANAG integration, suggesting potential deployment in NATO member states. Airports in these countries would be relevant for interoperability and security cooperation.

## Location Summary
The plan requires deployment at Copenhagen Airport (CPH) and Aalborg Airport (AAL) as Phase 1 pilot locations. Subsequent rollout to 30 airports in the EU and potentially airports in NATO member states is also planned. These locations are relevant due to their existing infrastructure, strategic importance, and alignment with regulatory and security requirements.