**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority limit of €25,000, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun, delayed project milestones, and impact on overall project profitability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., supply chain disruption) requires strategic intervention and resource allocation beyond the PMO's capacity.
Negative Consequences: Significant project delays, increased costs, and potential project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability of the PMO to reach a consensus on a key operational decision (e.g., vendor selection) necessitates resolution by the Steering Committee to avoid project delays.
Negative Consequences: Project delays, potential selection of a suboptimal vendor, and impact on project quality.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A significant change to the project scope (e.g., adding new features) requires strategic evaluation and approval by the Steering Committee due to its potential impact on budget, timeline, and resources.
Negative Consequences: Scope creep, budget overruns, project delays, and potential misalignment with strategic objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Reports of ethical violations (e.g., misuse of confidential information) require independent investigation and resolution by the Ethics & Compliance Committee to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, loss of customer trust, and potential project termination.

**Technical Design Impasse**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendations and Final Decision
Rationale: The Technical Advisory Group (TAG) cannot reach a consensus on a critical design or manufacturing issue, requiring strategic guidance from the Steering Committee.
Negative Consequences: Technical flaws, increased manufacturing costs, and potential product failure.