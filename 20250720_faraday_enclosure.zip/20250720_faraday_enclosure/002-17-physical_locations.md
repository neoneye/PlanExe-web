This plan implies one or more physical locations.

## Requirements for physical locations

- Low-cost precision-metal ecosystem
- ISO-certified manufacturing
- Proximity to European prepping networks and critical-infrastructure buyers
- Geographically diverse secondary manufacturing location

## Location 1
Estonia

Tallinn

Various manufacturing facilities in Tallinn

**Rationale**: The plan explicitly anchors manufacturing in Tallinn, Estonia, to leverage its low-cost, ISO-certified precision-metal ecosystem.

## Location 2
Poland

Various locations in Poland

Industrial parks in major Polish cities

**Rationale**: Poland offers a geographically diverse location from Estonia, mitigating supply chain risks and increasing production capacity, as suggested in the Manufacturing Scalability Strategy.

## Location 3
Portugal

Various locations in Portugal

Industrial areas near Lisbon or Porto

**Rationale**: Portugal provides a geographically diverse location from Estonia, mitigating supply chain risks and increasing production capacity, as suggested in the Manufacturing Scalability Strategy.

## Location 4
Germany

Various locations in Germany

Industrial areas in major German cities

**Rationale**: Germany is close to European prepping networks and critical-infrastructure buyers.

## Location Summary
The primary manufacturing location is Tallinn, Estonia, due to its low-cost, ISO-certified precision-metal ecosystem. Secondary manufacturing locations in Poland and Portugal are suggested to mitigate supply chain risks and increase production capacity. Germany is close to European prepping networks and critical-infrastructure buyers.