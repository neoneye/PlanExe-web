This plan involves money.

## Currencies

- **EUR:** The project is based in Europe and the funding is in EUR.
- **EEK:** Historical currency of Estonia, may be relevant for older contracts or records.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions in Estonia will also use EUR, as it is the official currency. No additional international risk management is needed.