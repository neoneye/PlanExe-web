### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Circulate Draft SteerCo ToR for review by proposed members (CEO/Investor, Head of Product Development, Head of Marketing, Independent Advisors).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Collate feedback on SteerCo ToR and revise accordingly.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback from proposed members

### 4. CEO/Investor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** CEO/Investor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Revised SteerCo ToR v0.2

### 5. CEO/Investor formally appoints the Project Steering Committee Chair (CEO/Investor).

**Responsible Body/Role:** CEO/Investor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager formally invites nominated members to the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment Confirmation Email

### 7. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 8. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 9. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start

### 10. Circulate Draft TAG ToR for review by proposed members (Senior Design Engineer, Senior Manufacturing Specialist, External Technical Experts).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1 circulated for review

**Dependencies:**

- Draft TAG ToR v0.1

### 11. Collate feedback on TAG ToR and revise accordingly.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised TAG ToR v0.2

**Dependencies:**

- Draft TAG ToR v0.1 circulated for review
- Feedback from proposed members

### 12. Project Steering Committee formally approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0

**Dependencies:**

- Revised TAG ToR v0.2
- Project Steering Committee established

### 13. Project Manager formally invites nominated members to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Approved TAG ToR v1.0

### 14. Schedule the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 15. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 16. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 17. Circulate Draft Ethics & Compliance Committee ToR for review by proposed members (Legal Counsel, Compliance Officer, Data Protection Officer, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 18. Collate feedback on Ethics & Compliance Committee ToR and revise accordingly.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1 circulated for review
- Feedback from proposed members

### 19. Project Steering Committee formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Revised Ethics & Compliance Committee ToR v0.2
- Project Steering Committee established

### 20. Project Steering Committee formally appoints the Ethics & Compliance Committee Chair (Legal Counsel).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0
- Project Steering Committee established

### 21. Project Manager formally invites nominated members to the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0
- Appointment Confirmation Email

### 22. Schedule the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 23. Hold the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 24. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Start