
## Audit - Corruption Risks

- Bribery of Singaporean officials to ignore or expedite permits/inspections related to the underground facility.
- Kickbacks from suppliers of genetic modification equipment or neural implants in exchange for inflated contracts.
- Nepotism or favoritism in hiring, leading to unqualified personnel in critical roles (e.g., security, research).
- Misuse of project funds for personal enrichment by project directors or other high-ranking personnel.
- Trading favors with external entities (e.g., other research labs, government agencies) in exchange for access to restricted resources or information.

## Audit - Misallocation Risks

- Inflated invoices from shell companies controlled by project personnel to siphon off funds.
- Unnecessary or redundant purchases of equipment and supplies to exhaust the budget and obscure actual spending.
- Misreporting of project progress to justify continued funding despite delays or failures.
- Diversion of resources (e.g., chimpanzees, equipment) for unauthorized personal research or gain.
- Inefficient allocation of personnel, with overstaffing in some areas and understaffing in others, leading to wasted effort and delays.

## Audit - Procedures

- Implement a system of mandatory dual authorization for all financial transactions above a specified threshold ($10,000).
- Conduct periodic (quarterly) internal audits of project expenses, focusing on high-risk areas such as procurement and personnel costs.
- Engage an external auditor to conduct a comprehensive review of project finances and compliance at the midpoint (Year 5) and end (Year 10) of the project.
- Establish a confidential whistleblower mechanism for reporting suspected fraud or misconduct, with guaranteed protection against retaliation.
- Implement a robust system for tracking and managing project assets, including chimpanzees, equipment, and supplies, with regular inventory checks.

## Audit - Transparency Measures

- Establish a secure, internal project dashboard displaying key performance indicators (KPIs) related to budget, schedule, and research progress (access restricted to authorized personnel).
- Document and archive all major project decisions, including the rationale behind them, in a secure, auditable repository.
- Implement a policy of open communication and collaboration among project team members, while maintaining strict adherence to security protocols.
- Establish clear and transparent criteria for vendor selection and contract awards, with documented justification for all decisions.
- Develop and maintain a comprehensive project website (access restricted to authorized personnel) containing relevant policies, procedures, and reports.