### 1. Project Sponsor (Senior Executive) to designate an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Senior Executive

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Appointment Notification

**Dependencies:**

- Project Start Date Confirmed

### 2. Interim Chair of the Project Steering Committee drafts the initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Interim Chair Appointment Notification

### 3. Project Manager circulates Draft SteerCo ToR v0.1 to nominated members (Senior Representative from Funding Source, Project Director, Security Chief, Independent Legal Counsel, Independent Risk Management Expert) for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Nominated Members List

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Interim Chair consolidates feedback on the SteerCo ToR and finalizes version 1.0.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Circulation Email
- Feedback from Nominated Members

### 5. Senior Executive formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Executive

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- SteerCo ToR v1.0

### 6. Project Manager schedules the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- SteerCo ToR v1.0

### 7. Hold the Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Director defines team roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start Date Confirmed

### 9. Project Director establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 10. Project Director sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Setup

**Dependencies:**

- Core Project Team Communication Protocols Document

### 11. Project Director develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Project Management Tools and Systems Setup

### 12. Project Director schedules the initial kick-off meeting for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Detailed Project Schedule

### 13. Hold the Core Project Team Kick-off Meeting.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 14. Project Steering Committee appoints an Interim Chair for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Interim Chair Appointment Notification

**Dependencies:**

- Meeting Minutes with Action Items

### 15. Interim Chair of the Ethics & Compliance Committee drafts the initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Interim Chair, Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Interim Chair Appointment Notification

### 16. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 to nominated members (Independent Ethicist, Independent Legal Counsel, Senior Representative from Funding Source, Project Director, Security Chief) for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Circulation Email
- Nominated Members List

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 17. Interim Chair consolidates feedback on the Ethics & Compliance Committee ToR and finalizes version 1.0.

**Responsible Body/Role:** Interim Chair, Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR v1.0
- Feedback Summary

**Dependencies:**

- Circulation Email
- Feedback from Nominated Members

### 18. Project Steering Committee formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Ethics & Compliance Committee ToR v1.0

### 19. Project Manager schedules the initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Ethics & Compliance Committee ToR v1.0

### 20. Hold the Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 21. Project Steering Committee appoints an Interim Chair for the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Interim Chair Appointment Notification

**Dependencies:**

- Meeting Minutes with Action Items

### 22. Interim Chair of the Technical Advisory Group drafts the initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Interim Chair, Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Interim Chair Appointment Notification

### 23. Project Manager circulates Draft Technical Advisory Group ToR v0.1 to nominated members (Lead Geneticist, Lead Neuroscientist, Chief Engineer, External Expert in Genetic Modification, External Expert in Neural Implantation, External Expert in BSL-4 Operations) for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Circulation Email
- Nominated Members List

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 24. Interim Chair consolidates feedback on the Technical Advisory Group ToR and finalizes version 1.0.

**Responsible Body/Role:** Interim Chair, Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Technical Advisory Group ToR v1.0
- Feedback Summary

**Dependencies:**

- Circulation Email
- Feedback from Nominated Members

### 25. Project Steering Committee formally appoints the Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Technical Advisory Group ToR v1.0

### 26. Project Manager schedules the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Technical Advisory Group ToR v1.0

### 27. Hold the Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda