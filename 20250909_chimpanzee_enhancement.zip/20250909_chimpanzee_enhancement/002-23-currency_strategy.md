This plan involves money.

## Currencies

- **SGD:** Local currency for Singapore, where the primary facility is located.
- **USD:** Stable international currency for budgeting and large transactions, given the project's scale and potential for unforeseen expenses.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks. SGD will be used for local transactions in Singapore. Given the scale of the project, hedging against exchange fluctuations is advisable.