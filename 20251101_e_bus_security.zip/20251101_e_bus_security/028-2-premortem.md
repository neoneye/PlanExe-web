A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Vendors will readily share detailed technical specifications of their e-bus systems. | Request detailed technical documentation (schematics, software code, network diagrams) from the top 3 e-bus vendors. | Any vendor refuses to provide the requested documentation within 2 weeks, citing proprietary concerns or legal restrictions. |
| A2 | The proposed 'no-remote-kill' design can be implemented without significantly impacting e-bus performance or reliability. | Develop a prototype 'no-remote-kill' system and test it on a representative e-bus model in a controlled environment. | The prototype implementation results in a >5% reduction in e-bus performance (e.g., acceleration, braking distance) or introduces new system errors. |
| A3 | The public will accept potential service disruptions or inconveniences resulting from enhanced security measures. | Conduct a public opinion survey in Copenhagen to gauge acceptance of potential security-related disruptions (e.g., longer maintenance times, stricter security checks). | The survey reveals that >40% of respondents are unwilling to accept any service disruptions, even for enhanced security. |
| A4 | The existing e-bus charging infrastructure is compatible with any modifications required for security enhancements. | Assess the charging infrastructure's compatibility with modified e-buses by testing a prototype e-bus with security enhancements at a representative charging station. | The prototype e-bus fails to charge correctly or efficiently (charging time increases by >20%, energy transfer efficiency decreases by >10%) at the existing charging station. |
| A5 | The project team possesses sufficient expertise in both cybersecurity and transportation engineering to effectively integrate security measures without compromising operational safety. | Conduct a joint workshop with cybersecurity experts and transportation engineers to assess their combined understanding of e-bus systems and potential security risks. | The workshop reveals significant gaps in knowledge or communication between the two groups, leading to disagreements on critical design decisions or risk assessments. |
| A6 | Local Danish cybersecurity regulations are comprehensive enough to cover all potential vulnerabilities in the e-bus systems. | Conduct a gap analysis comparing existing Danish cybersecurity regulations with international best practices for securing transportation systems. | The gap analysis identifies significant areas where Danish regulations are less stringent or do not address specific vulnerabilities relevant to e-bus systems (e.g., CAN bus security, GPS spoofing). |
| A7 | The e-bus operators will consistently adhere to the new security protocols and procedures after initial training. | Conduct unannounced spot checks on e-bus operators to assess their adherence to security protocols (e.g., password management, system access controls). | Spot checks reveal that >30% of operators are not consistently adhering to security protocols, indicating a need for ongoing reinforcement and training. |
| A8 | The supply chain for replacement parts and maintenance services will remain stable and unaffected by the implementation of security measures. | Contact key suppliers and maintenance providers to assess their capacity to support the modified e-bus systems and identify potential disruptions. | Suppliers or maintenance providers express concerns about their ability to meet demand or indicate potential price increases due to the complexity of the security modifications. |
| A9 | The public will perceive the security enhancements as a valuable improvement to the e-bus system, rather than an admission of prior vulnerability. | Conduct focus groups with e-bus users to gauge their perception of the security enhancements and assess whether they view it as a positive improvement or a sign of past security flaws. | Focus groups reveal that >50% of users perceive the security enhancements as an admission of prior vulnerability, leading to decreased trust in the e-bus system. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Paper Wall Panic | Process/Financial | A1 | Procurement Lead | CRITICAL (20/25) |
| FM2 | The Performance Paralysis | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Backlash Breakdown | Market/Human | A3 | Communications Lead | HIGH (12/25) |
| FM4 | The Charging Chaos Catastrophe | Process/Financial | A4 | Infrastructure Lead | CRITICAL (20/25) |
| FM5 | The Expertise Enigma | Technical/Logistical | A5 | Project Manager | CRITICAL (15/25) |
| FM6 | The Regulatory Reef | Market/Human | A6 | Legal Counsel | HIGH (12/25) |
| FM7 | The Human Error Escalation | Process/Financial | A7 | Training Manager | CRITICAL (20/25) |
| FM8 | The Supply Chain Strangulation | Technical/Logistical | A8 | Logistics Coordinator | CRITICAL (15/25) |
| FM9 | The Trust Tumble | Market/Human | A9 | Communications Director | HIGH (12/25) |


### Failure Modes

#### FM1 - The Paper Wall Panic

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Procurement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial viability crumbles due to unforeseen costs and delays stemming from a lack of vendor cooperation. Initially, the project team assumes vendors will readily provide detailed technical specifications. However, vendors, protective of their intellectual property and wary of potential liabilities, stonewall the project, refusing to share critical system information. This lack of information cascades into a series of problems.  The technical assessment phase grinds to a halt, forcing the team to rely on incomplete data and educated guesses.  The 'no-remote-kill' design specifications become vague and ineffective, failing to address key vulnerabilities.  Procurement reform is stymied, as the team lacks the information needed to evaluate vendor security claims.  The project is forced to hire expensive consultants to reverse-engineer the e-bus systems, blowing the budget.  The Copenhagen pilot is delayed, triggering penalty clauses in contracts with the city.  The national rollout is indefinitely postponed, and the project is ultimately deemed a failure.

##### Early Warning Signs
- Vendor response time to information requests exceeds 10 days.
- Consultant fees for reverse engineering exceed DKK 1 million within the first month.
- Project budget is revised upwards by >15% within the first quarter.

##### Tripwires
- Reverse engineering costs exceed DKK 2M
- Vendor provides <50% of requested documentation after 30 days
- Projected budget overrun exceeds 20%

##### Response Playbook
- Contain: Immediately halt all reverse engineering efforts.
- Assess: Conduct a thorough review of the project budget and identify potential cost-saving measures.
- Respond: Renegotiate contracts with vendors, offering incentives for information sharing or exploring alternative vendors.


**STOP RULE:** Reverse engineering costs exceed DKK 5M and vendors still refuse to provide necessary documentation.

---

#### FM2 - The Performance Paralysis

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's technical foundation collapses when the 'no-remote-kill' design proves incompatible with the e-bus systems. The team optimistically assumes that the proposed security measures can be implemented without significantly impacting e-bus performance or reliability. However, during the Copenhagen pilot, the implemented isolation measures introduce unforeseen technical glitches.  Braking systems become sluggish, acceleration is impaired, and the e-buses experience frequent system errors.  The performance degradation leads to safety concerns and passenger complaints.  The e-bus operators refuse to use the modified buses, citing safety risks.  The project team scrambles to fix the technical issues, but the underlying incompatibility between the security measures and the e-bus systems proves insurmountable.  The Copenhagen pilot is abandoned, and the national rollout is cancelled. The project is deemed a technical failure, highlighting the importance of thorough testing and validation.

##### Early Warning Signs
- E-bus operators report >3 system errors per day during pilot testing.
- Passenger complaints regarding e-bus performance increase by >50% during pilot testing.
- E-bus maintenance costs increase by >25% during pilot testing.

##### Tripwires
- Braking distance increases by >10% during testing
- System error rate exceeds 5 per day per bus
- E-bus availability drops below 80%

##### Response Playbook
- Contain: Immediately suspend the Copenhagen pilot and remove the implemented security measures.
- Assess: Conduct a thorough technical review of the e-bus systems and the 'no-remote-kill' design.
- Respond: Revise the 'no-remote-kill' design to address the identified performance and reliability issues, potentially exploring alternative security measures.


**STOP RULE:** A revised 'no-remote-kill' design cannot be implemented without causing significant performance degradation or safety risks.

---

#### FM3 - The Backlash Breakdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Communications Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's public support evaporates due to perceived inconveniences and service disruptions. The project team naively assumes that the public will readily accept potential service disruptions resulting from enhanced security measures. However, during the Copenhagen pilot, the implemented security protocols lead to longer boarding times, increased security checks, and occasional service delays.  The public reacts negatively, complaining about the added inconveniences and questioning the effectiveness of the security measures.  Social media is flooded with criticism, and public trust in the e-bus system plummets.  Political support for the project wanes, and funding is cut.  The Copenhagen pilot is scaled back, and the national rollout is abandoned. The project is deemed a public relations disaster, highlighting the importance of stakeholder engagement and communication.

##### Early Warning Signs
- Social media sentiment towards the e-bus system turns negative (<-20%) during pilot testing.
- Public transportation ridership in Copenhagen decreases by >10% during pilot testing.
- Political support for the project weakens, as evidenced by critical statements from key politicians.

##### Tripwires
- Public satisfaction with e-bus service drops below 60%
- Ridership decreases by >15% during the pilot
- Negative media coverage increases by >50%

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to communicate the benefits of the security measures.
- Assess: Conduct a thorough review of the security protocols and identify potential areas for improvement.
- Respond: Revise the security protocols to minimize inconveniences and address public concerns, potentially offering incentives for riders to offset the disruptions.


**STOP RULE:** Public support for the project falls below 40% and political support is withdrawn.

---

#### FM4 - The Charging Chaos Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Infrastructure Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial stability is undermined by unexpected infrastructure upgrade costs. The initial assumption that existing charging infrastructure would seamlessly integrate with security-enhanced e-buses proves false. Modifications to the e-buses, particularly those related to power isolation and secure communication, introduce compatibility issues with the existing charging stations. The charging time increases significantly, and energy transfer efficiency plummets. This necessitates costly upgrades to the charging infrastructure across Copenhagen and, eventually, the entire country. The budget is quickly depleted, forcing the project to scale back its security measures and delay the national rollout. The resulting patchwork of security implementations creates new vulnerabilities and undermines public confidence.

##### Early Warning Signs
- Prototype e-bus charging time increases by >15% during initial testing.
- Energy transfer efficiency during prototype charging decreases by >8%.
- Projected infrastructure upgrade costs exceed DKK 10 million within the first quarter.

##### Tripwires
- Charging infrastructure upgrade costs exceed DKK 15M
- Charging time increases by >25%
- Energy transfer efficiency drops below 85%

##### Response Playbook
- Contain: Immediately halt all infrastructure upgrade activities.
- Assess: Conduct a thorough review of the charging infrastructure requirements and explore alternative charging solutions.
- Respond: Renegotiate contracts with charging station vendors, seeking cost-effective upgrade options or exploring alternative charging technologies.


**STOP RULE:** Charging infrastructure upgrade costs exceed DKK 25M and a viable alternative charging solution cannot be identified.

---

#### FM5 - The Expertise Enigma

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's technical execution falters due to a lack of integrated expertise. The assumption that the project team possesses sufficient expertise in both cybersecurity and transportation engineering proves overly optimistic. The cybersecurity experts lack a deep understanding of the operational constraints and safety requirements of e-bus systems, while the transportation engineers are unfamiliar with advanced cybersecurity threats and mitigation techniques. This disconnect leads to design flaws that compromise both security and safety. Isolation measures inadvertently interfere with critical safety systems, and security protocols introduce operational inefficiencies. The resulting e-buses are both vulnerable to cyberattacks and prone to mechanical failures. The project is plagued by delays and technical setbacks, ultimately failing to achieve its security goals.

##### Early Warning Signs
- Frequent disagreements between cybersecurity experts and transportation engineers during design reviews.
- Security measures are implemented without proper consideration of operational safety requirements.
- E-bus maintenance costs increase significantly due to poorly integrated security systems.

##### Tripwires
- Design reviews are delayed by >2 weeks due to unresolved disagreements
- Safety audits identify >3 critical safety flaws related to security implementations
- E-bus downtime increases by >20%

##### Response Playbook
- Contain: Immediately establish a joint task force comprising cybersecurity experts and transportation engineers.
- Assess: Conduct a thorough review of the project's design and implementation plans, identifying areas where expertise is lacking.
- Respond: Provide cross-training for team members, hire consultants with integrated expertise, or revise the project scope to align with available expertise.


**STOP RULE:** A viable solution for integrating cybersecurity and transportation engineering expertise cannot be identified, leading to unacceptable safety risks or operational inefficiencies.

---

#### FM6 - The Regulatory Reef

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Legal Counsel
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's legal and regulatory compliance unravels due to unforeseen gaps in Danish cybersecurity regulations. The initial assumption that local regulations are comprehensive enough to cover all potential vulnerabilities proves incorrect. A gap analysis reveals significant shortcomings in areas such as CAN bus security and GPS spoofing, leaving the e-bus systems vulnerable to specific types of cyberattacks. The project team scrambles to address these gaps, but the regulatory landscape is slow to adapt. The resulting uncertainty creates legal and financial risks. Insurance companies refuse to cover the e-buses, and government agencies delay approvals. The project is caught in a regulatory limbo, unable to proceed with the national rollout. Public confidence erodes, and the project is ultimately deemed a failure.

##### Early Warning Signs
- The gap analysis identifies >3 significant areas where Danish regulations are insufficient.
- Insurance companies refuse to provide coverage for the security-enhanced e-buses.
- Government agencies delay approvals for the national rollout due to regulatory concerns.

##### Tripwires
- The gap analysis identifies >5 regulatory gaps
- Insurance premiums increase by >50%
- Regulatory approvals are delayed by >6 months

##### Response Playbook
- Contain: Immediately engage with relevant government agencies to address the regulatory gaps.
- Assess: Conduct a thorough review of the project's legal and regulatory compliance requirements.
- Respond: Advocate for regulatory changes, implement additional security measures to mitigate the identified gaps, or revise the project scope to align with existing regulations.


**STOP RULE:** The regulatory gaps cannot be addressed within a reasonable timeframe, creating unacceptable legal and financial risks.

---

#### FM7 - The Human Error Escalation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Training Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial projections are shattered by recurring security breaches stemming from human error. Despite initial training, e-bus operators fail to consistently adhere to the new security protocols. Weak password management, unauthorized system access, and susceptibility to phishing attacks become rampant. These human errors create vulnerabilities that cybercriminals exploit, leading to a series of costly security incidents. The project is forced to invest heavily in incident response, system recovery, and damage control. Insurance premiums skyrocket, and the project's financial reserves are quickly depleted. The national rollout is indefinitely postponed, and the project is ultimately deemed a financial failure due to unsustainable operational costs.

##### Early Warning Signs
- Spot checks reveal that >20% of operators are not adhering to security protocols.
- Phishing simulation click-through rates exceed 10%.
- The number of security incidents attributed to human error increases by >50% within the first quarter.

##### Tripwires
- Spot check failure rate exceeds 30%
- Phishing click-through rate exceeds 15%
- Security incident response costs exceed DKK 500,000 per incident

##### Response Playbook
- Contain: Immediately implement mandatory refresher training for all e-bus operators.
- Assess: Conduct a thorough review of the training program and identify areas for improvement.
- Respond: Implement stricter enforcement of security protocols, introduce multi-factor authentication, and enhance phishing awareness training.


**STOP RULE:** Security incident response costs exceed DKK 2 million and human error continues to be the primary cause of breaches.

---

#### FM8 - The Supply Chain Strangulation

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Logistics Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's technical implementation grinds to a halt due to supply chain disruptions. The assumption that the supply chain for replacement parts and maintenance services would remain stable proves false. The security modifications introduce new complexities that suppliers and maintenance providers are ill-equipped to handle. The demand for specialized parts increases, but suppliers struggle to meet the demand, leading to shortages and delays. Maintenance providers lack the training and expertise to service the modified e-bus systems, resulting in prolonged downtime. The e-bus fleet becomes increasingly unreliable, and service disruptions become frequent. The project is unable to maintain the e-bus systems effectively, leading to a gradual decline in performance and safety. The national rollout is abandoned, and the project is deemed a technical failure due to logistical challenges.

##### Early Warning Signs
- Lead times for replacement parts increase by >50%.
- Maintenance costs increase by >30%.
- E-bus downtime increases by >25%.

##### Tripwires
- Lead times for critical parts exceed 90 days
- Maintenance costs exceed DKK 1 million per month
- E-bus availability drops below 70%

##### Response Playbook
- Contain: Immediately identify alternative suppliers and maintenance providers.
- Assess: Conduct a thorough review of the supply chain and maintenance requirements.
- Respond: Negotiate contracts with new suppliers and maintenance providers, provide training for existing providers, and stockpile critical parts.


**STOP RULE:** A stable and reliable supply chain for replacement parts and maintenance services cannot be established.

---

#### FM9 - The Trust Tumble

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Communications Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's public image is tarnished by a perception of prior vulnerability. The assumption that the public would perceive the security enhancements as a valuable improvement proves incorrect. Instead, the public interprets the security measures as an admission that the e-bus system was previously vulnerable to cyberattacks. This perception erodes public trust in the safety and reliability of the e-bus system. Ridership declines, and public support for the project wanes. The media portrays the project as a costly and unnecessary overreaction. Political opponents seize on the opportunity to criticize the government's handling of the e-bus system. The project becomes a public relations disaster, undermining its long-term sustainability and damaging the reputation of the government and the transportation authority.

##### Early Warning Signs
- Public opinion surveys reveal a decrease in trust in the e-bus system.
- Social media sentiment towards the e-bus system turns negative.
- Media coverage of the project becomes increasingly critical.

##### Tripwires
- Public trust in e-bus safety drops below 50%
- Negative media mentions increase by >40%
- Ridership declines by >10%

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to emphasize the proactive nature of the security enhancements.
- Assess: Conduct a thorough review of the project's communication strategy and identify areas for improvement.
- Respond: Engage with community leaders and stakeholders to address their concerns, highlight the benefits of the security measures, and emphasize the government's commitment to public safety.


**STOP RULE:** Public trust in the e-bus system falls below 40% and cannot be restored through communication efforts.
