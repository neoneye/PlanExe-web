
## Risk 1 - Supply Chain
Reliance on Chinese-made e-buses creates a dependency on foreign suppliers, potentially leading to delays in obtaining necessary parts or support for implementing security measures. Geopolitical tensions could further exacerbate this risk.

**Impact:** Delays of 2-6 months in project implementation, potential cost increases of 10-20% due to supply chain disruptions, and difficulties in obtaining necessary vendor cooperation.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop contingency plans for alternative suppliers or in-house solutions for critical components. Establish clear communication channels with existing vendors and proactively address potential supply chain vulnerabilities. Consider legal protections against vendor non-compliance.

## Risk 2 - Technical
Air-gapping critical systems may introduce unforeseen technical challenges and compatibility issues with existing e-bus infrastructure. The process of isolating drive/brake/steer systems could inadvertently affect their performance or reliability.

**Impact:** A delay of 3-6 months due to unforeseen technical challenges. Increased maintenance costs by 20-30% due to the complexity of air-gapped systems. Potential safety risks if isolation is not implemented correctly.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough testing and simulations of air-gapped systems before full-scale implementation. Engage with cybersecurity experts and engineers experienced in embedded systems to identify and mitigate potential technical risks. Establish a robust monitoring system to detect any performance or reliability issues post-implementation.

## Risk 3 - Vendor Relationship
Adopting a firm or aggressive vendor relationship strategy could lead to non-cooperation from Yutong and other Chinese e-bus manufacturers, hindering access to critical system information and delaying the implementation of security measures. Legal battles could be costly and time-consuming.

**Impact:** Delays of 4-8 months in obtaining necessary system information. Increased legal costs of DKK 5-10 million. Potential for vendors to withhold support or updates, compromising long-term security.

**Likelihood:** Medium

**Severity:** High

**Action:** Prioritize clear and open communication with vendors, emphasizing the importance of security and compliance. Offer incentives for cooperation, such as long-term service contracts or joint research opportunities. Explore legal options for enforcing existing contracts and ensuring vendor compliance. Consider a phased approach, starting with cordial relations and escalating only if necessary.

## Risk 4 - Operational
Implementing a secure operator-controlled gateway for remote diagnostics and updates may introduce new operational complexities and require extensive training for operators. Inadequate training could lead to errors in managing the gateway, potentially compromising security.

**Impact:** A delay of 1-2 months in operator training. Increased operational costs by 10-15% due to the complexity of managing the gateway. Potential for security breaches due to operator error.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop comprehensive training programs for operators, including hands-on exercises and simulations. Establish clear procedures for managing the gateway and responding to security incidents. Implement a robust monitoring system to detect any unauthorized access or suspicious activity.

## Risk 5 - Procurement
Implementing a 'security-by-design' procurement framework may limit the pool of eligible vendors and potentially increase procurement costs. Smaller vendors may lack the resources or expertise to meet stringent security requirements.

**Impact:** A delay of 2-4 months in vendor selection. Increased procurement costs by 15-25%. Potential for reduced competition and innovation in the e-bus market.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Provide support and guidance to smaller vendors to help them meet security requirements. Explore options for joint ventures or partnerships between smaller and larger vendors. Consider a phased approach to implementing the 'security-by-design' framework, starting with less stringent requirements and gradually increasing them over time.

## Risk 6 - Regulatory & Permitting
New regulations or standards related to cybersecurity in public transportation could emerge during the project timeline, requiring adjustments to the project plan and potentially causing delays.

**Impact:** A delay of 1-3 months in project implementation. Increased compliance costs of DKK 1-3 million. Potential for project scope changes to align with new regulations.

**Likelihood:** Low

**Severity:** Medium

**Action:** Monitor regulatory developments closely and engage with relevant authorities to stay informed. Build flexibility into the project plan to accommodate potential changes in regulations. Allocate a contingency budget for compliance costs.

## Risk 7 - Social
Public perception of the security measures could be negative if they are perceived as overly intrusive or disruptive to public transportation services. Negative publicity could undermine public trust and support for the project.

**Impact:** Reduced public support for the project. Potential for delays or cancellations due to public pressure. Damage to the reputation of the project stakeholders.

**Likelihood:** Low

**Severity:** Medium

**Action:** Communicate the benefits of the security measures to the public clearly and transparently. Address any concerns or misconceptions proactively. Engage with community stakeholders to gather feedback and incorporate it into the project plan.

## Risk 8 - Financial
The budget of DKK 120M may be insufficient to cover all project costs, especially if unforeseen technical challenges or vendor non-cooperation arise. Cost overruns could jeopardize the project's success.

**Impact:** Project delays or cancellations due to lack of funding. Reduced scope or quality of security measures. Damage to the reputation of the project stakeholders.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed budget breakdown and track expenses closely. Identify potential cost-saving measures without compromising security. Secure additional funding sources or contingency funds to cover potential cost overruns.

## Risk 9 - Environmental
Modifying the e-buses could impact their energy efficiency or emissions, potentially conflicting with environmental regulations or sustainability goals.

**Impact:** Increased energy consumption or emissions. Potential for non-compliance with environmental regulations. Damage to the reputation of the project stakeholders.

**Likelihood:** Low

**Severity:** Low

**Action:** Assess the environmental impact of any modifications to the e-buses. Implement measures to mitigate any negative impacts. Ensure compliance with all relevant environmental regulations.

## Risk 10 - Security
The secure operator-controlled gateway itself could become a target for cyberattacks, potentially providing attackers with access to critical e-bus systems. Inadequate security measures for the gateway could compromise the entire project.

**Impact:** Compromise of critical e-bus systems. Potential for remote control of e-buses by attackers. Damage to public safety and security.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement robust security measures for the gateway, including strong authentication, access controls, and intrusion detection systems. Conduct regular security audits and penetration testing to identify and address vulnerabilities. Establish a clear incident response plan for dealing with security breaches.

## Risk summary
The most critical risks are related to vendor relationships, technical challenges in air-gapping, and financial constraints. A confrontational vendor relationship could hinder access to critical system information, while technical difficulties in isolating systems could lead to performance issues or safety risks. Insufficient funding could jeopardize the project's overall success. Mitigation strategies should focus on fostering collaboration with vendors, conducting thorough testing of air-gapped systems, and securing additional funding sources or contingency funds. The trade-off between security and maintainability is central, requiring careful consideration of the isolation depth strategy. Overlapping mitigation strategies include clear communication with vendors, comprehensive training for operators, and robust security measures for the secure operator-controlled gateway.