## Suggestion 1 - Securing America’s Passenger Rail

This U.S. Transportation Security Administration (TSA) initiative focuses on enhancing cybersecurity across passenger rail systems. It involves developing security directives, conducting security assessments, and promoting best practices to protect critical infrastructure from cyber threats. The project spans multiple states and involves collaboration with various rail operators and technology vendors.

### Success Metrics

Development and implementation of security directives.
Completion of cybersecurity assessments across passenger rail systems.
Adoption of best practices by rail operators.
Reduction in identified cybersecurity vulnerabilities.

### Risks and Challenges Faced

Resistance from rail operators to implement new security measures.
Complexity of integrating cybersecurity measures into legacy systems.
Rapidly evolving threat landscape requiring continuous adaptation.
Securing funding and resources for cybersecurity enhancements.

### Where to Find More Information

U.S. Transportation Security Administration (TSA) website: www.tsa.gov
Reports and publications on transportation cybersecurity from the U.S. Department of Homeland Security.

### Actionable Steps

Contact the TSA’s Surface Transportation Security Division to inquire about their cybersecurity initiatives.
Email: STSD.Stakeholder@tsa.dhs.gov
Review TSA security directives and guidance documents for passenger rail systems.

### Rationale for Suggestion

This project is relevant due to its focus on securing transportation systems from cyber threats, similar to the Danish e-bus project. It provides insights into developing security directives, conducting assessments, and promoting best practices. While geographically distant, the challenges and strategies employed are applicable to the Danish context, particularly in vendor management and regulatory compliance. The Danish project can learn from the TSA's approach to engaging with transportation operators and technology vendors to implement security measures.
## Suggestion 2 - European Union Agency for Cybersecurity (ENISA) Transportation Cybersecurity Initiatives

ENISA has several initiatives aimed at improving cybersecurity in the transportation sector across Europe. These include developing guidelines, conducting risk assessments, and promoting information sharing among transportation stakeholders. The initiatives cover various modes of transport, including road, rail, and air, and address both operational and IT security aspects. The project spans multiple EU member states and involves collaboration with transportation agencies, operators, and technology providers.

### Success Metrics

Development and publication of cybersecurity guidelines for the transportation sector.
Completion of risk assessments across various transportation modes.
Increased information sharing among transportation stakeholders.
Adoption of cybersecurity best practices by transportation operators.

### Risks and Challenges Faced

Lack of standardization across different transportation modes and member states.
Complexity of addressing cybersecurity in interconnected transportation systems.
Resistance from transportation operators to share sensitive security information.
Rapidly evolving threat landscape requiring continuous adaptation.

### Where to Find More Information

ENISA website: www.enisa.europa.eu
ENISA reports and publications on transportation cybersecurity.

### Actionable Steps

Contact ENISA to inquire about their transportation cybersecurity initiatives.
Email: info@enisa.europa.eu
Review ENISA guidelines and reports on transportation cybersecurity.
Engage with ENISA's cybersecurity experts for guidance and support.

### Rationale for Suggestion

This project is highly relevant due to its focus on cybersecurity in the European transportation sector, aligning directly with the Danish e-bus project's objectives. ENISA's initiatives provide valuable insights into developing cybersecurity guidelines, conducting risk assessments, and promoting information sharing. The Danish project can leverage ENISA's expertise and resources to enhance its cybersecurity measures and ensure compliance with EU regulations. The project's multi-stakeholder approach and focus on standardization are particularly relevant to the Danish context.
## Suggestion 3 - Singapore Land Transport Authority (LTA) Cybersecurity Master Plan

The Singapore LTA has implemented a comprehensive cybersecurity master plan to protect its land transport systems from cyber threats. This includes enhancing cybersecurity infrastructure, conducting regular security audits, and training personnel on cybersecurity best practices. The plan covers various aspects of land transport, including rail, bus, and traffic management systems. The project involves collaboration with technology vendors, cybersecurity experts, and government agencies.

### Success Metrics

Enhancement of cybersecurity infrastructure across land transport systems.
Completion of regular security audits and penetration testing.
Training of personnel on cybersecurity best practices.
Reduction in identified cybersecurity vulnerabilities.

### Risks and Challenges Faced

Complexity of securing interconnected land transport systems.
Rapidly evolving threat landscape requiring continuous adaptation.
Securing funding and resources for cybersecurity enhancements.
Integrating cybersecurity measures into legacy systems.

### Where to Find More Information

Singapore Land Transport Authority (LTA) website: www.lta.gov.sg
Reports and publications on transportation cybersecurity from the Singapore government.

### Actionable Steps

Contact the Singapore LTA to inquire about their cybersecurity master plan.
Email: LTA_Feedback@lta.gov.sg
Review LTA's cybersecurity policies and guidelines for land transport systems.

### Rationale for Suggestion

While geographically distant, the Singapore LTA's Cybersecurity Master Plan offers valuable insights into securing land transport systems from cyber threats. The plan's focus on enhancing cybersecurity infrastructure, conducting regular audits, and training personnel aligns with the Danish e-bus project's objectives. The Danish project can learn from Singapore's approach to integrating cybersecurity measures into various aspects of land transport and collaborating with technology vendors and government agencies. The project's emphasis on continuous adaptation to the evolving threat landscape is particularly relevant.
## Suggestion 4 - Cybersecurity of Connected Vehicles (Secondary Suggestion)

SAE International and NIST have collaborated on frameworks and standards for cybersecurity in connected vehicles.  This includes best practices for secure design, testing, and incident response.  While focused on passenger vehicles, the principles are applicable to e-buses.

### Success Metrics

Development of SAE J3061 and related standards.
Adoption of NIST Cybersecurity Framework by automotive manufacturers.

### Risks and Challenges Faced

Balancing security with vehicle performance and user experience.
Addressing vulnerabilities in complex software and hardware systems.
Keeping pace with evolving cyber threats.

### Where to Find More Information

SAE International: www.sae.org
NIST Cybersecurity Framework: www.nist.gov/cyberframework

### Actionable Steps

Review SAE J3061 and related standards for automotive cybersecurity.
Implement the NIST Cybersecurity Framework in the e-bus project.
Contact SAE and NIST for guidance and support.

### Rationale for Suggestion

This project, while focused on connected vehicles generally, provides a strong foundation in cybersecurity principles applicable to e-buses. The standards and frameworks developed by SAE and NIST offer valuable guidance for secure design, testing, and incident response. This is a secondary suggestion because it is not specific to public transportation but provides a strong base of knowledge.

## Summary

Based on the provided project plan to enhance the cybersecurity of Danish e-buses, focusing on eliminating remote kill-switch vulnerabilities, the following real-world projects are recommended as references. These projects offer insights into similar challenges related to cybersecurity in transportation, vendor management, and procurement reform.