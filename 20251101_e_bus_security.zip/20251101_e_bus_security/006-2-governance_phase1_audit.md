
## Audit - Corruption Risks

- Bribery of procurement officials to favor specific vendors who may not offer the most secure solutions.
- Kickbacks from vendors to project team members in exchange for overlooking security flaws or expediting approvals.
- Conflicts of interest where project team members have undisclosed financial ties to e-bus vendors.
- Misuse of confidential vendor information during procurement processes to give unfair advantages to favored companies.
- Trading favors with vendors, such as accepting gifts or hospitality, in exchange for lenient security assessments.

## Audit - Misallocation Risks

- Misuse of the DKK 120M budget for personal gain or unauthorized expenses.
- Double spending on cybersecurity testing or equipment due to poor coordination or oversight.
- Inefficient allocation of resources, such as overspending on consultants while underfunding essential security measures.
- Unauthorized use of project assets, such as cybersecurity testing tools, for non-project-related activities.
- Misreporting of project progress or results to mask delays or cost overruns.

## Audit - Procedures

- Conduct periodic internal reviews of procurement processes to ensure compliance with security standards and ethical guidelines (quarterly, Internal Audit).
- Perform post-project external audits to assess the effectiveness of security measures and identify areas for improvement (post-project, External Audit Firm).
- Implement contract review thresholds for vendor agreements, requiring independent legal and security review for contracts exceeding a certain value (e.g., DKK 1M).
- Establish expense workflows with multiple levels of approval to prevent unauthorized spending and ensure proper documentation (ongoing, Finance Department).
- Conduct regular compliance checks to ensure adherence to EU NIS Directive, Danish cybersecurity regulations, and GDPR (bi-annually, Compliance Officer).

## Audit - Transparency Measures

- Publish a project progress dashboard showing key milestones, budget expenditures, and security metrics (monthly, Project Management Office).
- Publish minutes of key project governance meetings, including decisions related to vendor selection, isolation strategies, and rollback procedures (monthly, Project Management Office).
- Establish a whistleblower mechanism for reporting suspected corruption or misconduct, with clear procedures for investigation and protection of whistleblowers (ongoing, Legal Department).
- Provide public access to relevant project policies and reports, such as the procurement policy, security assessment reports, and incident response plan (upon request, Project Management Office).
- Document and publish the selection criteria for major decisions and vendors, ensuring that security considerations are clearly articulated and weighted (before each major decision, Project Management Office).