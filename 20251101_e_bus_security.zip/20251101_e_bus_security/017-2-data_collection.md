## 1. Budget Allocation and Contingency Planning

Ensures financial feasibility and prevents project delays or scope reduction due to budget constraints. Addresses Issue 1 from expert-review.md.

### Data to Collect

- Detailed cost estimates for Copenhagen pilot and national rollout.
- Contingency budget allocation (recommended 15% of total budget).
- Regular budget review and update schedule.
- Potential additional funding sources.

### Simulation Steps

- Use Monte Carlo simulation in Excel to model potential cost overruns based on identified risks (supply chain, technical, vendor).
- Utilize project management software (e.g., MS Project, Jira) to track actual costs against planned budget.

### Expert Validation Steps

- Consult with a financial risk manager specializing in large-scale infrastructure projects.
- Review cost estimates with a certified project management professional (PMP) experienced in cybersecurity projects.
- Seek validation from the Danish Transport Authority regarding budget allocation for similar projects.

### Responsible Parties

- Project Manager
- Financial Risk Manager

### Assumptions

- **High:** The initial budget of DKK 120M is sufficient, provided a 15% contingency is allocated.
- **Medium:** Cost estimates are accurate within a 10% margin of error.

### SMART Validation Objective

By 2026-Q1, validate the budget allocation by comparing detailed cost estimates against the initial budget, ensuring a 15% contingency fund is allocated and documented.

### Notes

- Uncertainty: Potential for unforeseen technical challenges or regulatory changes impacting costs.
- Risk: Underestimation of rollout costs could deplete contingency and delay the project.
- Missing Data: Detailed breakdown of labor costs, technical challenges, and vendor prices.


## 2. Data Privacy and GDPR Compliance

Ensures compliance with GDPR and mitigates data privacy risks related to passenger data handling. Addresses Issue 2 from expert-review.md.

### Data to Collect

- Data Privacy Impact Assessment (DPIA) report.
- Implemented data security measures (encryption, access controls, anonymization).
- GDPR-compliant data privacy policy.
- Training records for personnel on data privacy.
- Process for handling data subject requests.

### Simulation Steps

- Use a data flow diagramming tool (e.g., Lucidchart) to map the flow of personal data within the e-bus systems.
- Simulate data breach scenarios using a cybersecurity training platform (e.g., KnowBe4) to assess the effectiveness of data security measures.

### Expert Validation Steps

- Consult with a data privacy consultant specializing in GDPR compliance.
- Review the DPIA and data privacy policy with a legal expert experienced in EU data protection law.
- Seek validation from the Danish Data Protection Agency regarding compliance with GDPR.

### Responsible Parties

- Risk & Compliance Manager
- Legal Advisors

### Assumptions

- **Medium:** The project can achieve GDPR compliance without significantly impacting operational efficiency.
- **Medium:** Data minimization techniques can be effectively implemented to reduce the scope of personal data processing.

### SMART Validation Objective

By 2026-Q1, validate GDPR compliance by completing a DPIA, implementing data security measures, and establishing a GDPR-compliant data privacy policy, ensuring alignment with Danish Data Protection Agency guidelines.

### Notes

- Uncertainty: Evolving interpretation of GDPR and potential for new data privacy regulations.
- Risk: Failure to uphold GDPR may result in fines and reputational damage.
- Missing Data: Specific details on the types of personal data collected by e-bus systems and the purposes for which it is processed.


## 3. Active Threat Intelligence and Adaptable Security Measures

Ensures proactive identification and mitigation of cyber threats, enhancing resilience against evolving attacks. Addresses Issue 3 from expert-review.md.

### Data to Collect

- Threat intelligence program documentation.
- Vulnerability management process documentation.
- Incident response plan.
- Penetration testing and security audit reports.
- SIEM system implementation details.

### Simulation Steps

- Use a threat intelligence platform (e.g., Recorded Future, CrowdStrike Falcon X) to identify emerging threats and vulnerabilities relevant to e-bus systems.
- Conduct simulated cyberattacks using a penetration testing tool (e.g., Metasploit, Burp Suite) to assess the effectiveness of security measures.

### Expert Validation Steps

- Consult with a cybersecurity expert specializing in threat intelligence and incident response.
- Review the threat intelligence program and incident response plan with a certified information systems security professional (CISSP).
- Engage a third-party cybersecurity firm to conduct penetration testing and security audits.

### Responsible Parties

- Cybersecurity Architect
- Incident Response Coordinator

### Assumptions

- **High:** The project can effectively integrate threat intelligence data into its security operations.
- **High:** The incident response plan is comprehensive and can be effectively executed in a real-world scenario.

### SMART Validation Objective

By 2026-Q1, establish a threat intelligence program, implement a vulnerability management process, and develop an incident response plan, conducting penetration testing and security audits to ensure adaptability to evolving cyber threats.

### Notes

- Uncertainty: The rapidly evolving cybersecurity landscape and the emergence of new attack vectors.
- Risk: A cyberattack could compromise systems, leading to service disruptions and safety risks.
- Missing Data: Specific details on the types of cyber threats targeting public transportation systems and the effectiveness of existing security measures.


## 4. Geopolitical Risks and Vendor Dependency

Addresses the risks associated with reliance on Chinese vendors and potential geopolitical instability. Addresses Issue 1.4 from expert-review.md.

### Data to Collect

- Geopolitical risk assessment report.
- Supply chain diversification strategy documentation.
- Alternative vendor identification.
- Contract review for termination clauses.
- Government agency engagement records.

### Simulation Steps

- Conduct a scenario analysis using a geopolitical simulation tool (e.g., Stratfor, Geopolitical Futures) to assess the potential impact of geopolitical events on the e-bus supply chain.
- Simulate vendor disruptions using supply chain management software (e.g., SAP Ariba) to evaluate the effectiveness of the diversification strategy.

### Expert Validation Steps

- Consult with a geopolitical risk analyst specializing in Chinese foreign policy and its impact on international supply chains.
- Review the supply chain diversification strategy with a supply chain security expert.
- Seek validation from government agencies responsible for national security regarding potential threats and mitigation strategies.

### Responsible Parties

- Vendor Liaison & Contract Specialist
- Risk & Compliance Manager

### Assumptions

- **High:** Alternative vendors can be identified and onboarded within a reasonable timeframe and cost.
- **Medium:** Existing contracts with e-bus vendors allow for termination or modification in the event of geopolitical instability.

### SMART Validation Objective

By 2026-Q2, complete a geopolitical risk assessment, develop a supply chain diversification strategy, and review existing contracts for termination clauses, ensuring mitigation of risks associated with reliance on Chinese vendors.

### Notes

- Uncertainty: The unpredictable nature of geopolitical events and their potential impact on international trade.
- Risk: Failure to adequately address geopolitical risks could result in compromised e-bus systems and supply chain disruptions.
- Missing Data: Detailed information on the vendors' ownership structure and their relationship with the Chinese government.


## 5. Definition and Verification of 'No-Remote-Kill' Design

Ensures that the core goal of eliminating remote kill-switch vulnerabilities is achieved through a clear definition and rigorous verification process. Addresses Issue 1.5 from expert-review.md.

### Data to Collect

- Detailed technical specification for 'no-remote-kill' designs.
- Certification process documentation.
- Accredited third-party auditor reports.
- Penetration testing and code review results.
- Vulnerability assessment reports.

### Simulation Steps

- Conduct simulated cyberattacks on e-bus systems with 'no-remote-kill' designs using a penetration testing tool (e.g., Metasploit, Burp Suite) to verify the effectiveness of the security measures.
- Perform code review using static analysis tools (e.g., SonarQube, Coverity) to identify potential vulnerabilities in the e-bus systems' software.

### Expert Validation Steps

- Consult with cybersecurity engineers and hardware security experts to develop the technical specification for 'no-remote-kill' designs.
- Review the certification process with legal professionals to ensure compliance with relevant regulations.
- Engage accredited third-party auditors to verify compliance with the technical specification.

### Responsible Parties

- Cybersecurity Architect
- Cybersecurity Attestation & Verification Specialist

### Assumptions

- **High:** A clear and technically precise definition of 'no-remote-kill' design can be developed and implemented.
- **Medium:** Accredited third-party auditors are available and capable of verifying compliance with the technical specification.

### SMART Validation Objective

By 2026-Q2, develop a detailed technical specification for 'no-remote-kill' designs, establish a rigorous certification process, and engage accredited third-party auditors to verify compliance, ensuring the elimination of remote kill-switch vulnerabilities.

### Notes

- Uncertainty: The complexity of hardware and software security and the potential for vendors to claim compliance without fully meeting the requirements.
- Risk: Without a clear definition and rigorous verification process, the project may fail to eliminate remote kill-switch vulnerabilities.
- Missing Data: Detailed technical documentation of the e-bus systems, including schematics, software code, and network diagrams.


## 6. Transportation Industry Specific Cyber Threats

Ensures that the project addresses the specific vulnerabilities and attack vectors relevant to the transportation industry and e-bus systems. Addresses Issue 1.6 from expert-review.md.

### Data to Collect

- Transportation industry-specific threat model.
- Mitigation strategies for identified threats.
- Intrusion detection system implementation details.
- Control system hardening measures.
- Secure communication channel implementation details.

### Simulation Steps

- Simulate GPS spoofing attacks using a GPS simulator to assess the vulnerability of e-bus systems to this type of attack.
- Conduct CAN bus manipulation attacks in a controlled environment to evaluate the effectiveness of security measures designed to protect the CAN bus.

### Expert Validation Steps

- Consult with transportation security experts to develop a transportation industry-specific threat model.
- Review the mitigation strategies with penetration testers and threat intelligence providers.
- Engage cybersecurity experts with experience in the transportation sector to validate the effectiveness of the security measures.

### Responsible Parties

- Cybersecurity Architect
- E-Bus Systems Engineer

### Assumptions

- **Medium:** Transportation industry-specific threat intelligence is readily available and can be effectively integrated into the project's security operations.
- **High:** Effective mitigation strategies can be developed and implemented for all identified transportation-specific cyber threats.

### SMART Validation Objective

By 2026-Q2, conduct a transportation industry-specific threat modeling exercise, develop mitigation strategies for identified threats, and implement intrusion detection systems, control system hardening measures, and secure communication channels, ensuring protection against transportation-specific cyber threats.

### Notes

- Uncertainty: The emergence of new transportation-specific cyber threats and the effectiveness of existing security measures against these threats.
- Risk: Failure to address transportation-specific cyber threats could leave e-bus systems vulnerable to attacks that exploit unique vulnerabilities.
- Missing Data: Detailed information about the e-bus systems, including control system architecture, communication protocols, and security features.


## 7. Technical Assessment of E-Bus Systems

Provides a solid technical foundation for the project by understanding the e-bus systems' architecture, communication protocols, and embedded software. Addresses Issue 2.4 from expert-review.md.

### Data to Collect

- Network architecture diagrams.
- Communication protocol specifications.
- Embedded software analysis reports.
- ICS security standards and frameworks documentation.

### Simulation Steps

- Use network analysis tools (e.g., Wireshark) to capture and analyze network traffic within the e-bus systems.
- Perform reverse engineering of the communication protocols using reverse engineering tools (e.g., IDA Pro, Ghidra).
- Analyze the embedded software using static and dynamic analysis techniques to identify potential vulnerabilities.

### Expert Validation Steps

- Engage external ICS security experts to review the technical assessment and provide guidance on best practices.
- Consult with transportation engineers to understand the operational aspects of the e-bus systems.
- Review the technical assessment with cybersecurity architects to ensure alignment with the overall security architecture.

### Responsible Parties

- E-Bus Systems Engineer
- Cybersecurity Architect

### Assumptions

- **High:** Access to the e-bus systems is readily available for technical assessment purposes.
- **Medium:** The technical documentation provided by the vendors is accurate and complete.

### SMART Validation Objective

By 2026-Q1, complete a detailed technical assessment of the e-bus systems, focusing on network architecture, communication protocols, and embedded software, ensuring a solid technical foundation for the project.

### Notes

- Uncertainty: The complexity of the e-bus systems and the potential for undocumented features or vulnerabilities.
- Risk: Without detailed technical information, the implemented security measures may be ineffective or even introduce new vulnerabilities.
- Missing Data: Specific details on the e-bus systems' architecture, communication protocols, and embedded software.


## 8. Sophisticated Vendor Relationship Strategy

Ensures a more nuanced and effective approach to vendor relationships, considering the geopolitical context and the vendors' motivations. Addresses Issue 2.5 from expert-review.md.

### Data to Collect

- Vendor ownership structure information.
- Geopolitical context analysis.
- Incentive program documentation.
- Communication records with vendors.
- Government agency engagement records.

### Simulation Steps

- Conduct a stakeholder analysis using a stakeholder mapping tool (e.g., Miro) to identify the key stakeholders and their motivations.
- Simulate vendor negotiations using a negotiation simulation tool (e.g., The Negotiation Experts) to evaluate the effectiveness of different negotiation strategies.

### Expert Validation Steps

- Consult with experts in international business and diplomacy to develop a more sophisticated vendor relationship strategy.
- Engage with government agencies and industry associations to facilitate communication and collaboration with the vendors.
- Review the vendor relationship strategy with legal professionals to ensure compliance with relevant regulations.

### Responsible Parties

- Vendor Liaison & Contract Specialist
- Risk & Compliance Manager

### Assumptions

- **Medium:** The vendors are willing to engage in open and honest communication with the project team.
- **Medium:** Incentives can be effectively used to encourage vendor cooperation.

### SMART Validation Objective

By 2026-Q2, develop a more sophisticated vendor relationship strategy that considers the geopolitical context and the vendors' motivations, exploring options for building trust and offering incentives for cooperation.

### Notes

- Uncertainty: The vendors' willingness to cooperate and the effectiveness of different negotiation strategies.
- Risk: A poorly executed vendor relationship strategy could lead to delays, increased costs, and failure to secure the e-bus systems.
- Missing Data: Background information on the vendors' ownership structure and their relationship with the Chinese government.


## 9. Comprehensive Incident Response and Forensics Capabilities

Ensures that the project can effectively respond to and learn from cyberattacks, improving the overall security posture. Addresses Issue 2.6 from expert-review.md.

### Data to Collect

- Incident response plan documentation.
- Digital forensics tools and training records.
- Relationships with law enforcement agencies and cybersecurity incident response teams.
- Data logging capabilities of the e-bus systems.
- Network infrastructure documentation.

### Simulation Steps

- Conduct incident response simulations using a cybersecurity training platform (e.g., Cyberbit, Immersive Labs) to assess the effectiveness of the incident response plan.
- Perform digital forensics analysis on simulated cyberattacks using digital forensics tools (e.g., EnCase, FTK) to identify the root cause of the attack and preserve evidence.

### Expert Validation Steps

- Consult with experts in incident response and forensics to develop a comprehensive incident response plan.
- Engage law enforcement agencies and cybersecurity incident response teams to establish relationships and coordinate incident response activities.
- Review the incident response plan with legal professionals to ensure compliance with relevant regulations.

### Responsible Parties

- Incident Response Coordinator
- Cybersecurity Architect

### Assumptions

- **High:** The incident response plan can be effectively executed in a real-world scenario.
- **Medium:** Sufficient resources are available for incident response and forensics activities.

### SMART Validation Objective

By 2026-Q2, develop a comprehensive incident response plan, invest in digital forensics tools and training, and establish relationships with law enforcement agencies and cybersecurity incident response teams, ensuring the ability to effectively respond to and learn from cyberattacks.

### Notes

- Uncertainty: The complexity of cyberattacks and the potential for new and unknown attack vectors.
- Risk: Without adequate incident response and forensics capabilities, the project will be unable to effectively respond to and learn from cyberattacks.
- Missing Data: Details on the data logging capabilities of the e-bus systems and the network infrastructure.

## Summary

This project plan outlines the data collection and validation steps necessary to enhance the cybersecurity of Danish e-buses. It focuses on addressing key issues identified in the expert review, including budget allocation, data privacy, threat intelligence, geopolitical risks, 'no-remote-kill' design verification, transportation-specific cyber threats, technical assessment of e-bus systems, vendor relationship strategy, and incident response capabilities. The plan includes detailed simulation and expert validation steps to ensure the accuracy and effectiveness of the data collected. The immediate actionable tasks focus on validating the most sensitive assumptions first, particularly those related to budget sufficiency, threat intelligence integration, and incident response plan effectiveness.