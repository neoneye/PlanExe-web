<p class="section-subtitle">Actions that must be completed before proceeding.</p>
### B1: Address training gaps

**Domain:** Human Stability

**Issues:**

- <code>TRAINING_GAPS</code>: Training needs assessment + skill gap analysis report
- <code>TALENT_UNKNOWN</code>: Talent market scan report (availability, salary ranges, channels)

**Acceptance Criteria:**

- Stakeholder map complete
- Skills gap analysis complete
- Change plan v1 approved

**Artifacts Required:**

- Stakeholder\_Map\.xlsx
- SkillsGap\_Analysis\.pdf
- ChangePlan\_v1\.pdf

**Owner:** PMO


**Rough Order of Magnitude (ROM):** MEDIUM cost, 30 days


### B2: Increase contingency

**Domain:** Economic Resilience

**Issues:**

- <code>CONTINGENCY_LOW</code>: Budget v2 with ≥10% contingency + Monte Carlo risk workbook

**Acceptance Criteria:**

- \>=10% contingency approved
- Monte Carlo risk workbook attached

**Artifacts Required:**

- Budget\_v2\.pdf
- Risk\_MC\.xlsx

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 14 days


### B3: Address DPIA gaps

**Domain:** Rights & Legality

**Issues:**

- <code>DPIA_GAPS</code>: Bundle the license files for the top data sources and the corresponding DPIAs.

**Acceptance Criteria:**

- Licenses bundled
- DPIAs bundled
- Retention policy links added

**Artifacts Required:**

- DataSources\_Licenses\.zip
- DPIAs\.zip
- RetentionPolicies\.url

**Owner:** Legal


**Rough Order of Magnitude (ROM):** MEDIUM cost, 45 days


### B4: Assess geological risks

**Domain:** Technical Feasibility

**Issues:**

- <code>GEO_RISK_UNASSESSED</code>: Independent geological survey + risk memo

**Acceptance Criteria:**

- Geological survey complete
- Risk memo attached
- Utility interconnection letter received

**Artifacts Required:**

- Geological\_Survey\.pdf
- Risk\_Memo\.pdf
- Utility\_Letter\.pdf

**Owner:** Engineering Lead


**Rough Order of Magnitude (ROM):** HIGH cost, 90 days


### B5: Define critical path

**Domain:** Program Delivery

**Issues:**

- <code>CRITICAL_PATH_UNKNOWN</code>: Integrated master schedule (CPM) with logic ties and baseline

**Acceptance Criteria:**

- PMO charter complete
- Integrated master schedule complete

**Artifacts Required:**

- PMO\_Charter\.pdf
- Master\_Schedule\.mpp

**Owner:** PMO


**Rough Order of Magnitude (ROM):** LOW cost, 7 days

