# Purpose

**Purpose:** business

**Purpose Detailed:** Mitigating cybersecurity risks in public transportation infrastructure by isolating critical systems from remote access and establishing secure procurement practices.

**Topic:** Securing public transportation e-buses from remote access vulnerabilities

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan focuses on mitigating cybersecurity risks in public transportation e-buses. It involves physically isolating critical systems, which requires physical access to the buses and their systems. The plan also includes tightening procurement practices, which may involve physical meetings and inspections. Therefore, the plan is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Access to e-buses for physical inspection and modification
- Facilities for cybersecurity testing and analysis
- Meeting spaces for vendor negotiations and procurement
- Secure locations for data storage and rollback systems

## Location 1
Denmark

Copenhagen

Copenhagen public transport depot

**Rationale**: The plan specifies a 90-day Copenhagen pilot, making a Copenhagen public transport depot a necessary location for initial testing and implementation.

## Location 2
Denmark

Aarhus

Aarhus University, Department of Computer Science

**Rationale**: Aarhus University's Department of Computer Science could provide expertise in cybersecurity and secure systems design, aiding in the 'no-remote-kill' design verification and cyber attestation requirements.

## Location 3
Denmark

Odense

SDU Robotics, University of Southern Denmark

**Rationale**: SDU Robotics at the University of Southern Denmark offers facilities and expertise in robotics and embedded systems, relevant for analyzing and modifying the e-bus control systems.

## Location 4
Denmark

National

Various locations across Denmark

**Rationale**: For the national rollout, various locations across Denmark will be needed to implement the security measures on the e-bus fleet.

## Location Summary
The plan requires a location in Copenhagen for the pilot program, expertise from universities such as Aarhus University and the University of Southern Denmark, and various locations across Denmark for the national rollout.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** Local currency for project execution in Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Supply Chain
Reliance on Chinese-made e-buses creates a dependency on foreign suppliers, potentially leading to delays in obtaining necessary parts or support for implementing security measures. Geopolitical tensions could further exacerbate this risk.

**Impact:** Delays of 2-6 months in project implementation, potential cost increases of 10-20% due to supply chain disruptions, and difficulties in obtaining necessary vendor cooperation.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop contingency plans for alternative suppliers or in-house solutions for critical components. Establish clear communication channels with existing vendors and proactively address potential supply chain vulnerabilities. Consider legal protections against vendor non-compliance.

## Risk 2 - Technical
Air-gapping critical systems may introduce unforeseen technical challenges and compatibility issues with existing e-bus infrastructure. The process of isolating drive/brake/steer systems could inadvertently affect their performance or reliability.

**Impact:** A delay of 3-6 months due to unforeseen technical challenges. Increased maintenance costs by 20-30% due to the complexity of air-gapped systems. Potential safety risks if isolation is not implemented correctly.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough testing and simulations of air-gapped systems before full-scale implementation. Engage with cybersecurity experts and engineers experienced in embedded systems to identify and mitigate potential technical risks. Establish a robust monitoring system to detect any performance or reliability issues post-implementation.

## Risk 3 - Vendor Relationship
Adopting a firm or aggressive vendor relationship strategy could lead to non-cooperation from Yutong and other Chinese e-bus manufacturers, hindering access to critical system information and delaying the implementation of security measures. Legal battles could be costly and time-consuming.

**Impact:** Delays of 4-8 months in obtaining necessary system information. Increased legal costs of DKK 5-10 million. Potential for vendors to withhold support or updates, compromising long-term security.

**Likelihood:** Medium

**Severity:** High

**Action:** Prioritize clear and open communication with vendors, emphasizing the importance of security and compliance. Offer incentives for cooperation, such as long-term service contracts or joint research opportunities. Explore legal options for enforcing existing contracts and ensuring vendor compliance. Consider a phased approach, starting with cordial relations and escalating only if necessary.

## Risk 4 - Operational
Implementing a secure operator-controlled gateway for remote diagnostics and updates may introduce new operational complexities and require extensive training for operators. Inadequate training could lead to errors in managing the gateway, potentially compromising security.

**Impact:** A delay of 1-2 months in operator training. Increased operational costs by 10-15% due to the complexity of managing the gateway. Potential for security breaches due to operator error.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop comprehensive training programs for operators, including hands-on exercises and simulations. Establish clear procedures for managing the gateway and responding to security incidents. Implement a robust monitoring system to detect any unauthorized access or suspicious activity.

## Risk 5 - Procurement
Implementing a 'security-by-design' procurement framework may limit the pool of eligible vendors and potentially increase procurement costs. Smaller vendors may lack the resources or expertise to meet stringent security requirements.

**Impact:** A delay of 2-4 months in vendor selection. Increased procurement costs by 15-25%. Potential for reduced competition and innovation in the e-bus market.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Provide support and guidance to smaller vendors to help them meet security requirements. Explore options for joint ventures or partnerships between smaller and larger vendors. Consider a phased approach to implementing the 'security-by-design' framework, starting with less stringent requirements and gradually increasing them over time.

## Risk 6 - Regulatory & Permitting
New regulations or standards related to cybersecurity in public transportation could emerge during the project timeline, requiring adjustments to the project plan and potentially causing delays.

**Impact:** A delay of 1-3 months in project implementation. Increased compliance costs of DKK 1-3 million. Potential for project scope changes to align with new regulations.

**Likelihood:** Low

**Severity:** Medium

**Action:** Monitor regulatory developments closely and engage with relevant authorities to stay informed. Build flexibility into the project plan to accommodate potential changes in regulations. Allocate a contingency budget for compliance costs.

## Risk 7 - Social
Public perception of the security measures could be negative if they are perceived as overly intrusive or disruptive to public transportation services. Negative publicity could undermine public trust and support for the project.

**Impact:** Reduced public support for the project. Potential for delays or cancellations due to public pressure. Damage to the reputation of the project stakeholders.

**Likelihood:** Low

**Severity:** Medium

**Action:** Communicate the benefits of the security measures to the public clearly and transparently. Address any concerns or misconceptions proactively. Engage with community stakeholders to gather feedback and incorporate it into the project plan.

## Risk 8 - Financial
The budget of DKK 120M may be insufficient to cover all project costs, especially if unforeseen technical challenges or vendor non-cooperation arise. Cost overruns could jeopardize the project's success.

**Impact:** Project delays or cancellations due to lack of funding. Reduced scope or quality of security measures. Damage to the reputation of the project stakeholders.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed budget breakdown and track expenses closely. Identify potential cost-saving measures without compromising security. Secure additional funding sources or contingency funds to cover potential cost overruns.

## Risk 9 - Environmental
Modifying the e-buses could impact their energy efficiency or emissions, potentially conflicting with environmental regulations or sustainability goals.

**Impact:** Increased energy consumption or emissions. Potential for non-compliance with environmental regulations. Damage to the reputation of the project stakeholders.

**Likelihood:** Low

**Severity:** Low

**Action:** Assess the environmental impact of any modifications to the e-buses. Implement measures to mitigate any negative impacts. Ensure compliance with all relevant environmental regulations.

## Risk 10 - Security
The secure operator-controlled gateway itself could become a target for cyberattacks, potentially providing attackers with access to critical e-bus systems. Inadequate security measures for the gateway could compromise the entire project.

**Impact:** Compromise of critical e-bus systems. Potential for remote control of e-buses by attackers. Damage to public safety and security.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement robust security measures for the gateway, including strong authentication, access controls, and intrusion detection systems. Conduct regular security audits and penetration testing to identify and address vulnerabilities. Establish a clear incident response plan for dealing with security breaches.

## Risk summary
The most critical risks are related to vendor relationships, technical challenges in air-gapping, and financial constraints. A confrontational vendor relationship could hinder access to critical system information, while technical difficulties in isolating systems could lead to performance issues or safety risks. Insufficient funding could jeopardize the project's overall success. Mitigation strategies should focus on fostering collaboration with vendors, conducting thorough testing of air-gapped systems, and securing additional funding sources or contingency funds. The trade-off between security and maintainability is central, requiring careful consideration of the isolation depth strategy. Overlapping mitigation strategies include clear communication with vendors, comprehensive training for operators, and robust security measures for the secure operator-controlled gateway.

# Make Assumptions


## Question 1 - What is the detailed breakdown of the DKK 120M budget across the Copenhagen pilot and the national rollout phases, including specific allocations for personnel, technology, vendor negotiations, and contingency?

**Assumptions:** Assumption: 70% of the budget (DKK 84M) is allocated to the national rollout, and 30% (DKK 36M) to the Copenhagen pilot. This split reflects the larger scale and complexity of the national deployment. Industry benchmarks suggest pilot projects typically consume 20-40% of the total budget.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the budget allocation and potential cost overruns.
Details: A detailed budget breakdown is crucial to identify potential cost overruns. The assumption of a 70/30 split needs validation. Risks include underestimation of labor costs, unexpected technical challenges, and vendor price increases. Mitigation strategies involve rigorous cost tracking, value engineering, and securing contingency funds. Opportunity: Negotiating favorable vendor contracts to reduce costs.

## Question 2 - What are the key milestones for the Copenhagen pilot and the national rollout, including specific dates for vendor engagement, system isolation, testing, operator training, and final deployment?

**Assumptions:** Assumption: The Copenhagen pilot will have three major milestones: 1) Vendor engagement and system assessment completed within 30 days. 2) System isolation and testing completed within 60 days. 3) Operator training and pilot deployment completed within 90 days. These milestones are based on typical project timelines for similar cybersecurity initiatives.

**Assessments:** Title: Timeline Adherence Assessment
Description: Evaluation of the project timeline and potential delays.
Details: The aggressive 12-month timeline is a significant risk. Delays in vendor engagement, technical challenges, or regulatory hurdles could impact the entire project. Mitigation strategies include proactive risk management, parallel task execution, and flexible resource allocation. Opportunity: Streamlining processes and leveraging automation to accelerate deployment.

## Question 3 - What specific roles and skill sets are required for the project team, including cybersecurity experts, engineers, project managers, and legal counsel, and how will these resources be allocated across the Copenhagen pilot and national rollout?

**Assumptions:** Assumption: The project requires a core team of 10 full-time equivalents (FTEs), including 3 cybersecurity experts, 4 engineers, 2 project managers, and 1 legal counsel. These resources will be allocated proportionally between the Copenhagen pilot and national rollout based on workload demands. This assumption is based on the project's scope and complexity.

**Assessments:** Title: Resource Allocation Assessment
Description: Evaluation of the adequacy and allocation of project resources.
Details: Insufficient or poorly allocated resources could lead to delays and quality issues. Risks include difficulty in recruiting skilled personnel, high turnover rates, and skill gaps. Mitigation strategies involve competitive compensation packages, training programs, and outsourcing specialized tasks. Opportunity: Leveraging existing internal resources and partnerships with universities to supplement the project team.

## Question 4 - What specific regulations and standards apply to cybersecurity in public transportation in Denmark, and how will the project ensure compliance with these requirements?

**Assumptions:** Assumption: The project must comply with the EU's Network and Information Security (NIS) Directive and relevant Danish national cybersecurity regulations. Compliance will be ensured through regular audits, adherence to industry best practices, and engagement with regulatory authorities. This assumption is based on the legal framework governing cybersecurity in Denmark.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Evaluation of the project's compliance with relevant regulations and standards.
Details: Failure to comply with regulations could result in fines, legal action, and reputational damage. Risks include changes in regulations, ambiguous requirements, and lack of expertise. Mitigation strategies involve continuous monitoring of regulatory developments, engaging with legal experts, and implementing robust compliance procedures. Opportunity: Proactively shaping regulatory standards and influencing industry best practices.

## Question 5 - What specific safety risks are associated with modifying the e-bus systems, particularly the drive/brake/steer systems, and what measures will be implemented to mitigate these risks and ensure passenger safety?

**Assumptions:** Assumption: Modifying the e-bus systems could introduce safety risks related to system stability, reliability, and emergency response. These risks will be mitigated through rigorous testing, safety certifications, and fail-safe mechanisms. This assumption is based on the critical nature of the e-bus systems and the need to prioritize passenger safety.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of potential safety risks and mitigation measures.
Details: Safety risks are paramount and must be addressed proactively. Risks include system malfunctions, unintended consequences of modifications, and inadequate emergency response procedures. Mitigation strategies involve thorough risk assessments, independent safety audits, and comprehensive emergency response plans. Opportunity: Enhancing safety features and improving overall system reliability.

## Question 6 - What is the anticipated environmental impact of the project, including energy consumption, emissions, and waste disposal, and what measures will be implemented to minimize any negative impacts and promote sustainability?

**Assumptions:** Assumption: The project's environmental impact will be minimal, with a focus on energy efficiency, waste reduction, and responsible disposal of electronic components. Environmental impact assessments will be conducted to identify and mitigate any potential negative impacts. This assumption is based on Denmark's commitment to sustainability and environmental protection.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the project's environmental footprint and sustainability measures.
Details: Environmental concerns are increasingly important and must be addressed responsibly. Risks include increased energy consumption, emissions from transportation, and improper disposal of electronic waste. Mitigation strategies involve energy-efficient technologies, waste recycling programs, and compliance with environmental regulations. Opportunity: Promoting sustainable practices and reducing the project's carbon footprint.

## Question 7 - How will stakeholders, including e-bus operators, passengers, vendors, and regulatory authorities, be involved in the project, and what mechanisms will be used to gather feedback and address their concerns?

**Assumptions:** Assumption: Stakeholder engagement will be crucial for the project's success. Stakeholders will be involved through regular meetings, surveys, and public forums. Feedback will be actively solicited and incorporated into the project plan. This assumption is based on the importance of building trust and support for the project.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluation of stakeholder involvement and communication strategies.
Details: Lack of stakeholder engagement could lead to resistance and project delays. Risks include conflicting interests, communication breakdowns, and negative public perception. Mitigation strategies involve proactive communication, transparent decision-making, and collaborative problem-solving. Opportunity: Building strong relationships with stakeholders and fostering a sense of shared ownership.

## Question 8 - What specific operational systems will be affected by the project, including maintenance, diagnostics, and emergency response systems, and how will these systems be adapted to ensure continued functionality and security?

**Assumptions:** Assumption: The project will impact operational systems related to e-bus maintenance, diagnostics, and emergency response. These systems will be adapted through software updates, hardware modifications, and revised operating procedures. This assumption is based on the need to maintain operational efficiency and security.

**Assessments:** Title: Operational Systems Integration Assessment
Description: Evaluation of the impact on operational systems and integration strategies.
Details: Disruptions to operational systems could lead to service disruptions and increased costs. Risks include system incompatibilities, data loss, and security vulnerabilities. Mitigation strategies involve thorough testing, phased implementation, and robust backup and recovery procedures. Opportunity: Improving operational efficiency and enhancing system security.

# Distill Assumptions

- National rollout receives DKK 84M, Copenhagen pilot receives DKK 36M of the budget.
- Copenhagen pilot: vendor engagement in 30 days, isolation/testing in 60, deployment in 90.
- The project requires a core team of 10 FTEs with specific cybersecurity expertise.
- The project must comply with the EU's NIS Directive and Danish cybersecurity regulations.
- Modifying e-bus systems introduces safety risks mitigated through testing and certifications.
- The project's environmental impact will be minimal through energy efficiency and waste reduction.
- Stakeholder engagement is crucial through meetings, surveys, and feedback incorporation.
- The project will impact operational systems, requiring software updates and revised procedures.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment with Cybersecurity Specialization

## Domain-specific considerations

- Cybersecurity vulnerabilities in transportation systems
- Vendor dependency and supply chain risks
- Regulatory compliance and data privacy
- Operational impact of security measures
- Stakeholder communication and public perception

## Issue 1 - Unrealistic Budget Allocation and Contingency Planning
The assumption that DKK 84M is sufficient for the national rollout and DKK 36M for the Copenhagen pilot may be unrealistic. The national rollout involves significantly more buses, locations, and potential complexities, likely requiring a larger budget allocation. Furthermore, the plan lacks a clearly defined contingency budget to address unforeseen technical challenges, vendor disputes, or regulatory changes. Without a sufficient contingency, the project is highly vulnerable to cost overruns and delays.

**Recommendation:** Conduct a detailed bottom-up cost estimate for both the Copenhagen pilot and the national rollout, considering all potential expenses (personnel, technology, vendor costs, legal fees, training, etc.). Allocate a minimum of 15% of the total budget (DKK 18M) as a contingency fund to address unforeseen issues. Regularly review and update the budget based on actual expenses and emerging risks. Explore options for securing additional funding sources or lines of credit to cover potential cost overruns.

**Sensitivity:** Underestimating the national rollout costs by 20% (DKK 16.8M) could deplete the contingency fund and delay the project completion by 3-6 months. A 10% increase in vendor costs (DKK 12M) could reduce the project's ROI by 5-8%. Without a contingency fund, even minor cost overruns could jeopardize the project's success.

## Issue 2 - Insufficient Detail on Data Privacy and GDPR Compliance
The plan mentions compliance with the EU's NIS Directive but lacks specific details on how it will address data privacy concerns and GDPR requirements. E-buses collect and process significant amounts of personal data (location, travel patterns, etc.). Failure to comply with GDPR could result in substantial fines and reputational damage. The plan needs to explicitly address data minimization, purpose limitation, data security, and data subject rights.

**Recommendation:** Conduct a thorough data privacy impact assessment (DPIA) to identify potential risks and vulnerabilities. Implement robust data security measures, including encryption, access controls, and data anonymization techniques. Develop a comprehensive data privacy policy that complies with GDPR requirements. Provide training to all project personnel on data privacy principles and best practices. Establish a clear process for handling data subject requests (access, rectification, erasure).

**Sensitivity:** A failure to uphold GDPR principles may result in fines ranging from 2-4% of annual turnover. A data breach affecting passenger data could lead to legal liabilities and reputational damage, potentially reducing public trust in the transportation system by 10-20%.

## Issue 3 - Lack of Active Threat Intelligence and Adaptable Security Measures
The plan focuses on isolating systems and reforming procurement but lacks a proactive approach to threat intelligence gathering and adaptable security measures. The cybersecurity landscape is constantly evolving, and new vulnerabilities are discovered regularly. Without active threat intelligence, the project may become vulnerable to zero-day exploits or targeted attacks. The security measures need to be adaptable and responsive to emerging threats.

**Recommendation:** Establish a threat intelligence program to monitor emerging threats and vulnerabilities relevant to e-bus systems. Implement a vulnerability management process to identify and remediate security flaws proactively. Develop an incident response plan to address security breaches effectively. Conduct regular penetration testing and security audits to assess the effectiveness of security measures. Implement a security information and event management (SIEM) system to detect and respond to security incidents in real-time.

**Sensitivity:** A successful cyberattack exploiting a zero-day vulnerability could compromise critical e-bus systems, leading to service disruptions and potential safety risks. The cost of responding to a major security incident could range from DKK 2-5 million, and the reputational damage could significantly impact public trust.

## Review conclusion
The plan demonstrates a good understanding of the core cybersecurity challenges in public transportation. However, it needs to address the identified missing assumptions related to budget allocation, data privacy, and threat intelligence to ensure project success and long-term security. Prioritizing these areas will significantly enhance the project's resilience and reduce the risk of cost overruns, regulatory penalties, and security breaches.