**Goal Statement:** Sever or operator-gateway all vendor remote paths, air-gap drive/brake/steer from cloud/OTA, and tighten procurement to require verifiable ‘no-remote-kill’ designs with independent cyber attestations, starting with Copenhagen, and publish an isolation/rollback playbook operators can execute in hours.

## SMART Criteria

- **Specific:** Enhance the cybersecurity of Danish e-buses by eliminating remote kill-switch vulnerabilities and establishing secure procurement practices.
- **Measurable:** The goal will be measured by the successful isolation of critical e-bus systems from remote access, the implementation of a rollback playbook, and the adoption of secure procurement standards.
- **Achievable:** The goal is achievable within the given budget and timeline, leveraging cybersecurity expertise and a phased deployment approach.
- **Relevant:** This goal is relevant to ensuring the safety and security of public transportation in Denmark, protecting against potential cyberattacks.
- **Time-bound:** The goal will be achieved within 12 months, with a 90-day Copenhagen pilot followed by a national rollout.

## Dependencies

- Establish Pilot Project Framework
- Procure Necessary Equipment
- Develop Isolation and Rollback Playbook
- Initiate Vendor Engagement Process
- Conduct Risk Assessment
- Establish Vendor Compliance Protocols
- Implement Data Privacy Measures
- Create Incident Response Plan

## Resources Required

- Cybersecurity testing tools
- Access to e-buses
- Secure data storage solution

## Related Goals

- Enhance public transportation safety
- Improve cybersecurity infrastructure
- Establish secure procurement practices

## Tags

- cybersecurity
- e-buses
- public transportation
- remote access
- procurement
- Denmark

## Risk Assessment and Mitigation Strategies


### Key Risks

- Supply chain disruptions
- Technical challenges with air-gapping
- Vendor non-cooperation
- Secure gateway vulnerabilities
- Procurement limitations
- Regulatory changes
- Negative public perception
- Budget insufficiency
- Environmental impact
- Secure gateway cyberattacks

### Diverse Risks

- Operational risks
- Systematic risks
- Business risks

### Mitigation Plans

- Develop contingency plans for alternative suppliers and maintain open communication with vendors.
- Engage cybersecurity experts and conduct thorough testing to address technical challenges.
- Establish clear communication channels, offer incentives, and explore legal options to ensure vendor cooperation.
- Implement robust security measures, conduct regular audits, and develop an incident response plan for the secure gateway.
- Support smaller vendors, explore joint ventures, and adopt a phased approach to mitigate procurement limitations.
- Monitor regulatory developments, maintain flexibility, and allocate a contingency budget to address regulatory changes.
- Communicate the benefits of security measures, address public concerns, and engage stakeholders to manage public perception.
- Develop a detailed budget breakdown, implement cost-saving measures, and explore additional funding sources to address budget insufficiency.
- Assess the environmental impact of modifications and implement mitigation measures to ensure compliance.
- Implement robust security measures, conduct regular audits, and develop an incident response plan to protect the secure gateway from cyberattacks.

## Stakeholder Analysis


### Primary Stakeholders

- Project Managers
- Cybersecurity Experts
- Engineers
- Legal Advisors
- E-bus Operators

### Secondary Stakeholders

- E-bus Vendors
- Regulatory Bodies
- Public Transportation Users
- Aarhus University
- University of Southern Denmark

### Engagement Strategies

- Provide regular project updates and progress reports to primary stakeholders.
- Maintain open communication with vendors to ensure compliance and address concerns.
- Engage with regulatory bodies to ensure compliance with relevant regulations.
- Communicate the benefits of security measures to public transportation users.
- Collaborate with Aarhus University and University of Southern Denmark for expertise and support.

## Regulatory and Compliance Requirements


### Permits and Licenses


### Compliance Standards

- EU NIS Directive
- Danish cybersecurity regulations
- GDPR

### Regulatory Bodies

- Danish Transport Authority
- European Union Agency for Cybersecurity (ENISA)

### Compliance Actions

- Implement compliance plan for EU NIS Directive
- Implement compliance plan for Danish cybersecurity regulations
- Conduct Data Privacy Impact Assessment (DPIA)
- Implement GDPR-compliant data privacy policy
- Train personnel on data privacy