### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and ensures alignment with organizational goals, given the project's high visibility, budget, and potential impact on public transportation.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to project scope or budget (above DKK 5M).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review and approve initial project plan.

**Membership:**

- Senior Management Representative (Chair)
- Head of Cybersecurity
- Head of Public Transportation Operations
- Head of Procurement
- Independent Cybersecurity Expert (External)

**Decision Rights:** Strategic decisions related to project scope, budget (above DKK 5M), timeline, and risk management.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of major changes to project scope or budget.
- Review of vendor performance.
- Updates on regulatory compliance.

**Escalation Path:** Executive Management Team
### 2. Core Project Team

**Rationale for Inclusion:** Manages day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Essential for operational efficiency and coordination.

**Responsibilities:**

- Develop and maintain detailed project plans.
- Manage project budget and resources.
- Coordinate project activities and tasks.
- Monitor project progress and identify potential issues.
- Implement risk mitigation strategies.
- Report project status to the Project Steering Committee.
- Make operational decisions within approved budget thresholds (below DKK 5M).

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.

**Membership:**

- Project Manager
- Lead Cybersecurity Engineer
- Lead Systems Engineer
- Procurement Specialist
- Legal Advisor

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and task management (below DKK 5M).

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with team members. Escalation to the Project Steering Committee for unresolved issues.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current issues and risks.
- Assignment of tasks and responsibilities.
- Budget tracking and reporting.
- Vendor coordination.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on cybersecurity, systems engineering, and procurement, ensuring the project adopts best practices and mitigates technical risks.

**Responsibilities:**

- Provide technical expertise on cybersecurity, systems engineering, and procurement.
- Review and approve technical designs and specifications.
- Assess the security of e-bus systems and identify vulnerabilities.
- Recommend mitigation strategies for technical risks.
- Evaluate vendor proposals and assess their technical capabilities.
- Advise on the implementation of secure gateway and rollback procedures.

**Initial Setup Actions:**

- Define scope of expertise.
- Establish communication channels.
- Review project technical documentation.

**Membership:**

- Senior Cybersecurity Architect
- Senior Systems Engineer
- Independent Cybersecurity Consultant (External)
- Representative from Aarhus University
- Representative from University of Southern Denmark

**Decision Rights:** Technical recommendations and approvals related to cybersecurity, systems engineering, and procurement.

**Decision Mechanism:** Decisions made by consensus, with the Senior Cybersecurity Architect having the final say in case of disagreement. Documented dissenting opinions.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Assessment of security vulnerabilities.
- Discussion of technical risks and mitigation strategies.
- Evaluation of vendor proposals.
- Updates on emerging cybersecurity threats.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to ethical standards, regulatory requirements (including GDPR and the EU NIS Directive), and anti-corruption policies, safeguarding the organization's reputation and minimizing legal risks.

**Responsibilities:**

- Oversee compliance with ethical standards, regulatory requirements (GDPR, EU NIS Directive), and anti-corruption policies.
- Conduct data privacy impact assessments (DPIAs).
- Develop and implement GDPR-compliant data privacy policies.
- Establish a whistleblower mechanism for reporting suspected misconduct.
- Review procurement processes to ensure fairness and transparency.
- Monitor project activities for potential conflicts of interest.
- Ensure compliance with 'no-remote-kill' design requirements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Establish reporting procedures.
- Review relevant regulations and policies.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer
- Data Protection Officer
- Internal Audit Representative
- Independent Ethics Advisor (External)

**Decision Rights:** Compliance decisions related to ethical standards, regulatory requirements, and anti-corruption policies.

**Decision Mechanism:** Decisions made by majority vote, with the Legal Counsel having the tie-breaking vote. Documented dissenting opinions.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of compliance with GDPR and EU NIS Directive.
- Discussion of data privacy issues.
- Review of procurement processes.
- Investigation of reported misconduct.
- Updates on regulatory changes.

**Escalation Path:** Executive Management Team