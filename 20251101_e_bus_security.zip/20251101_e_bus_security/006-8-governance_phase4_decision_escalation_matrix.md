**Budget Overrun Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of revised budget and scope, followed by a vote.
Rationale: Exceeds the Core Project Team's approved financial authority (DKK 5M limit) and requires strategic realignment.
Negative Consequences: Project delays, scope reduction, or failure to achieve project goals due to insufficient funding.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee assessment of the risk impact and approval of additional resource allocation.
Rationale: The Core Project Team lacks the authority to allocate significant additional resources to mitigate a critical risk.
Negative Consequences: Failure to adequately mitigate the risk, leading to project delays, increased costs, or compromised security.

**Technical Advisory Group Deadlock on Isolation Strategy**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the competing technical recommendations and selection of the optimal approach.
Rationale: The Technical Advisory Group cannot reach a consensus on a critical technical decision, requiring strategic guidance.
Negative Consequences: Delayed implementation of security measures, potentially leaving critical vulnerabilities unaddressed.

**Proposed Major Scope Change Affecting Project Timeline**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the proposed scope change, impact assessment, and approval of revised project plan.
Rationale: Significant scope changes impact the project's strategic objectives and require Steering Committee approval.
Negative Consequences: Project delays, budget overruns, or failure to meet original project goals.

**Reported Ethical Concern Involving a Vendor**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigation, followed by recommendations for corrective action.
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Reputational damage, legal penalties, or compromised project integrity.

**Ethics & Compliance Committee Deadlock on Vendor Compliance**
Escalation Level: Executive Management Team
Approval Process: Executive Management Team review of the competing compliance recommendations and selection of the optimal approach.
Rationale: The Ethics & Compliance Committee cannot reach a consensus on a critical compliance decision, requiring strategic guidance.
Negative Consequences: Compromised compliance with regulations, reputational damage, or legal penalties.