This plan implies one or more physical locations.

## Requirements for physical locations

- Access to e-buses for physical inspection and modification
- Facilities for cybersecurity testing and analysis
- Meeting spaces for vendor negotiations and procurement
- Secure locations for data storage and rollback systems

## Location 1
Denmark

Copenhagen

Copenhagen public transport depot

**Rationale**: The plan specifies a 90-day Copenhagen pilot, making a Copenhagen public transport depot a necessary location for initial testing and implementation.

## Location 2
Denmark

Aarhus

Aarhus University, Department of Computer Science

**Rationale**: Aarhus University's Department of Computer Science could provide expertise in cybersecurity and secure systems design, aiding in the 'no-remote-kill' design verification and cyber attestation requirements.

## Location 3
Denmark

Odense

SDU Robotics, University of Southern Denmark

**Rationale**: SDU Robotics at the University of Southern Denmark offers facilities and expertise in robotics and embedded systems, relevant for analyzing and modifying the e-bus control systems.

## Location 4
Denmark

National

Various locations across Denmark

**Rationale**: For the national rollout, various locations across Denmark will be needed to implement the security measures on the e-bus fleet.

## Location Summary
The plan requires a location in Copenhagen for the pilot program, expertise from universities such as Aarhus University and the University of Southern Denmark, and various locations across Denmark for the national rollout.