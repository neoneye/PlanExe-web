<p class="section-subtitle">Bundled actions that reduce risk and move domains toward GREEN.</p>
### FP0: Pre-Commit Gate

**Priority:** Immediate

**Blockers:** <code>B2</code>, <code>B3</code>

### FP1: Enhance Human Factors and Training

**Priority:** High

**Blockers:** <code>B1</code>

### FP2: Evaluate and Mitigate Geological Risks

**Priority:** Medium

**Blockers:** <code>B4</code>

### FP3: Establish Project Critical Path and Governance

**Priority:** Immediate

**Blockers:** <code>B5</code>