## Domain of the expert reviewer
Project Management and Risk Assessment with Cybersecurity Specialization

## Domain-specific considerations

- Cybersecurity vulnerabilities in transportation systems
- Vendor dependency and supply chain risks
- Regulatory compliance and data privacy
- Operational impact of security measures
- Stakeholder communication and public perception

## Issue 1 - Unrealistic Budget Allocation and Contingency Planning
The assumption that DKK 84M is sufficient for the national rollout and DKK 36M for the Copenhagen pilot may be unrealistic. The national rollout involves significantly more buses, locations, and potential complexities, likely requiring a larger budget allocation. Furthermore, the plan lacks a clearly defined contingency budget to address unforeseen technical challenges, vendor disputes, or regulatory changes. Without a sufficient contingency, the project is highly vulnerable to cost overruns and delays.

**Recommendation:** Conduct a detailed bottom-up cost estimate for both the Copenhagen pilot and the national rollout, considering all potential expenses (personnel, technology, vendor costs, legal fees, training, etc.). Allocate a minimum of 15% of the total budget (DKK 18M) as a contingency fund to address unforeseen issues. Regularly review and update the budget based on actual expenses and emerging risks. Explore options for securing additional funding sources or lines of credit to cover potential cost overruns.

**Sensitivity:** Underestimating the national rollout costs by 20% (DKK 16.8M) could deplete the contingency fund and delay the project completion by 3-6 months. A 10% increase in vendor costs (DKK 12M) could reduce the project's ROI by 5-8%. Without a contingency fund, even minor cost overruns could jeopardize the project's success.

## Issue 2 - Insufficient Detail on Data Privacy and GDPR Compliance
The plan mentions compliance with the EU's NIS Directive but lacks specific details on how it will address data privacy concerns and GDPR requirements. E-buses collect and process significant amounts of personal data (location, travel patterns, etc.). Failure to comply with GDPR could result in substantial fines and reputational damage. The plan needs to explicitly address data minimization, purpose limitation, data security, and data subject rights.

**Recommendation:** Conduct a thorough data privacy impact assessment (DPIA) to identify potential risks and vulnerabilities. Implement robust data security measures, including encryption, access controls, and data anonymization techniques. Develop a comprehensive data privacy policy that complies with GDPR requirements. Provide training to all project personnel on data privacy principles and best practices. Establish a clear process for handling data subject requests (access, rectification, erasure).

**Sensitivity:** A failure to uphold GDPR principles may result in fines ranging from 2-4% of annual turnover. A data breach affecting passenger data could lead to legal liabilities and reputational damage, potentially reducing public trust in the transportation system by 10-20%.

## Issue 3 - Lack of Active Threat Intelligence and Adaptable Security Measures
The plan focuses on isolating systems and reforming procurement but lacks a proactive approach to threat intelligence gathering and adaptable security measures. The cybersecurity landscape is constantly evolving, and new vulnerabilities are discovered regularly. Without active threat intelligence, the project may become vulnerable to zero-day exploits or targeted attacks. The security measures need to be adaptable and responsive to emerging threats.

**Recommendation:** Establish a threat intelligence program to monitor emerging threats and vulnerabilities relevant to e-bus systems. Implement a vulnerability management process to identify and remediate security flaws proactively. Develop an incident response plan to address security breaches effectively. Conduct regular penetration testing and security audits to assess the effectiveness of security measures. Implement a security information and event management (SIEM) system to detect and respond to security incidents in real-time.

**Sensitivity:** A successful cyberattack exploiting a zero-day vulnerability could compromise critical e-bus systems, leading to service disruptions and potential safety risks. The cost of responding to a major security incident could range from DKK 2-5 million, and the reputational damage could significantly impact public trust.

## Review conclusion
The plan demonstrates a good understanding of the core cybersecurity challenges in public transportation. However, it needs to address the identified missing assumptions related to budget allocation, data privacy, and threat intelligence to ensure project success and long-term security. Prioritizing these areas will significantly enhance the project's resilience and reduce the risk of cost overruns, regulatory penalties, and security breaches.