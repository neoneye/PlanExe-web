### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Circulate Draft SteerCo ToR for review by Senior Management, Head of Cybersecurity, Head of Public Transportation Operations, Head of Procurement, and the Independent Cybersecurity Expert.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Management formally appoints the Chair of the Project Steering Committee (Senior Management Representative).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with Senior Management, formally confirms the remaining Project Steering Committee members (Head of Cybersecurity, Head of Public Transportation Operations, Head of Procurement, Independent Cybersecurity Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment of Chair

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 7. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 8. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start

### 9. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Start

### 10. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Access to Project Management Tools

**Dependencies:**

- Project Start

### 11. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Project Start

### 12. Project Manager confirms the Core Project Team members (Lead Cybersecurity Engineer, Lead Systems Engineer, Procurement Specialist, Legal Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Membership List
- Appointment Confirmation Emails

**Dependencies:**

- Detailed Project Schedule

### 13. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Core Project Team Membership List

### 14. Hold the initial Core Project Team kick-off meeting to review project goals, roles, and responsibilities.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 15. Project Manager defines the scope of expertise for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope of Expertise Document

**Dependencies:**

- Project Steering Committee Kick-off Meeting

### 16. Project Manager establishes communication channels for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Channels Document

**Dependencies:**

- Project Steering Committee Kick-off Meeting

### 17. Project Manager reviews project technical documentation with the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Advisory Group Review Feedback

**Dependencies:**

- Project Steering Committee Kick-off Meeting

### 18. Project Manager confirms the Technical Advisory Group members (Senior Cybersecurity Architect, Senior Systems Engineer, Independent Cybersecurity Consultant, Representative from Aarhus University, Representative from University of Southern Denmark).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Membership List
- Appointment Confirmation Emails

**Dependencies:**

- Technical Advisory Group Scope of Expertise Document
- Technical Advisory Group Communication Channels Document
- Technical Advisory Group Review Feedback

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Technical Advisory Group Membership List

### 20. Hold the initial Technical Advisory Group kick-off meeting to review project goals and technical approach.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 21. Legal Counsel drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Steering Committee Kick-off Meeting

### 22. Circulate Draft Ethics & Compliance Committee ToR for review by Compliance Officer, Data Protection Officer, Internal Audit Representative, and the Independent Ethics Advisor.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 23. Legal Counsel incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Senior Management formally appoints the Chair of the Ethics & Compliance Committee (Legal Counsel).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 25. Legal Counsel, in consultation with Senior Management, formally confirms the remaining Ethics & Compliance Committee members (Compliance Officer, Data Protection Officer, Internal Audit Representative, Independent Ethics Advisor).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Membership List
- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Appointment of Chair

### 26. Legal Counsel establishes reporting procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Reporting Procedures Document

**Dependencies:**

- Ethics & Compliance Committee Membership List

### 27. Legal Counsel reviews relevant regulations and policies with the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Regulatory Review Summary

**Dependencies:**

- Ethics & Compliance Committee Membership List

### 28. Legal Counsel schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Ethics & Compliance Committee Membership List

### 29. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals and compliance requirements.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda