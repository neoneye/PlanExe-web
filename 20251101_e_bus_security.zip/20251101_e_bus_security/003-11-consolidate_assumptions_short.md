# Purpose
# Securing Public Transportation E-Buses

- Mitigating cybersecurity risks in public transportation infrastructure.
- Isolating critical systems from remote access.
- Establishing secure procurement practices.

## E-Bus Remote Access Vulnerabilities

- Focus on securing e-buses.


# Plan Type
This plan requires physical locations. It cannot be executed digitally.

Explanation: This plan mitigates cybersecurity risks in public transportation e-buses. It involves physically isolating critical systems, requiring physical access. Tightening procurement practices may involve physical meetings and inspections. The plan is classified as physical.

# Physical Locations
This plan implies one or more physical locations.

## Requirements for physical locations

- Access to e-buses
- Cybersecurity testing facilities
- Meeting spaces
- Secure data storage

## Location 1
Denmark, Copenhagen, Copenhagen public transport depot

Rationale: 90-day Copenhagen pilot.

## Location 2
Denmark, Aarhus, Aarhus University, Department of Computer Science

Rationale: Cybersecurity and secure systems design expertise. 'No-remote-kill' design verification and cyber attestation.

## Location 3
Denmark, Odense, SDU Robotics, University of Southern Denmark

Rationale: Robotics and embedded systems expertise for analyzing/modifying e-bus control systems.

## Location 4
Denmark, National, Various locations across Denmark

Rationale: National rollout.

## Location Summary
Copenhagen location for pilot, Aarhus University and University of Southern Denmark for expertise, and various locations across Denmark for national rollout.

# Currency Strategy
## Currencies

- DKK: Local currency.

Primary currency: DKK

Currency strategy: DKK will be used for all transactions. No additional international risk management is needed.

# Identify Risks
# Risk 1 - Supply Chain

- Reliance on Chinese e-buses creates dependency, potential delays, geopolitical tensions.
- Impact: Delays (2-6 months), cost increases (10-20%), vendor cooperation issues.
- Likelihood: Medium
- Severity: Medium
- Action: Contingency plans for alternative suppliers, communication with vendors, legal protections.

## Risk 2 - Technical

- Air-gapping may introduce technical challenges, compatibility issues.
- Impact: Delay (3-6 months), increased maintenance (20-30%), safety risks.
- Likelihood: Medium
- Severity: High
- Action: Testing, cybersecurity experts, monitoring system.

## Risk 3 - Vendor Relationship

- Aggressive vendor strategy could lead to non-cooperation, legal battles.
- Impact: Delays (4-8 months), increased legal costs (DKK 5-10 million), vendor withholding.
- Likelihood: Medium
- Severity: High
- Action: Communication, incentives, legal options, phased approach.

## Risk 4 - Operational

- Secure gateway may introduce complexities, require training.
- Impact: Delay (1-2 months), increased costs (10-15%), security breaches.
- Likelihood: Medium
- Severity: Medium
- Action: Training programs, procedures, monitoring system.

## Risk 5 - Procurement

- 'Security-by-design' may limit vendors, increase costs.
- Impact: Delay (2-4 months), increased costs (15-25%), reduced competition.
- Likelihood: Medium
- Severity: Medium
- Action: Support for smaller vendors, joint ventures, phased approach.

## Risk 6 - Regulatory & Permitting

- New cybersecurity regulations could emerge.
- Impact: Delay (1-3 months), increased costs (DKK 1-3 million), scope changes.
- Likelihood: Low
- Severity: Medium
- Action: Monitor developments, flexibility, contingency budget.

## Risk 7 - Social

- Public perception of security measures could be negative.
- Impact: Reduced support, delays, damage to reputation.
- Likelihood: Low
- Severity: Medium
- Action: Communicate benefits, address concerns, engage stakeholders.

## Risk 8 - Financial

- Budget (DKK 120M) may be insufficient.
- Impact: Delays, reduced scope, damage to reputation.
- Likelihood: Medium
- Severity: High
- Action: Budget breakdown, cost-saving measures, additional funding.

## Risk 9 - Environmental

- Modifications could impact energy efficiency/emissions.
- Impact: Increased consumption/emissions, non-compliance, damage to reputation.
- Likelihood: Low
- Severity: Low
- Action: Assess impact, mitigation measures, compliance.

## Risk 10 - Security

- Secure gateway could be a target for cyberattacks.
- Impact: Compromise of systems, remote control, damage to safety.
- Likelihood: Medium
- Severity: High
- Action: Security measures, audits, incident response plan.

## Risk summary

- Critical risks: vendor relationships, technical challenges, financial constraints.
- Mitigation: collaboration, testing, funding.
- Trade-off: security vs. maintainability.
- Overlapping strategies: communication, training, security measures.


# Make Assumptions
# Question 1 - Budget Breakdown

- Assumption: 70% (DKK 84M) national rollout, 30% (DKK 36M) Copenhagen pilot.
- Assessment: Financial Feasibility

 - Budget breakdown crucial.
 - Validate 70/30 split.
 - Risks: Labor costs, technical challenges, vendor prices.
 - Mitigation: Cost tracking, value engineering, contingency.
 - Opportunity: Vendor contract negotiation.

## Question 2 - Key Milestones

- Assumption: Copenhagen pilot milestones: 30 days (vendor), 60 days (testing), 90 days (deployment).
- Assessment: Timeline Adherence

 - Risk: Aggressive timeline.
 - Delays impact: Vendor, technical, regulatory.
 - Mitigation: Risk management, parallel tasks, resource allocation.
 - Opportunity: Streamlining, automation.

## Question 3 - Roles and Skill Sets

- Assumption: 10 FTEs: 3 cybersecurity, 4 engineers, 2 project managers, 1 legal.
- Assessment: Resource Allocation

 - Risks: Insufficient resources, recruitment, turnover, skill gaps.
 - Mitigation: Compensation, training, outsourcing.
 - Opportunity: Internal resources, university partnerships.

## Question 4 - Regulations and Standards

- Assumption: Comply with EU NIS Directive and Danish regulations.
- Assessment: Regulatory Compliance

 - Risks: Fines, legal action, reputational damage.
 - Mitigation: Monitoring, legal experts, compliance procedures.
 - Opportunity: Shaping regulatory standards.

## Question 5 - Safety Risks

- Assumption: Modifications introduce safety risks.
- Assessment: Safety and Risk Management

 - Risks: System malfunctions, unintended consequences, inadequate response.
 - Mitigation: Risk assessments, safety audits, emergency plans.
 - Opportunity: Enhancing safety features.

## Question 6 - Environmental Impact

- Assumption: Minimal environmental impact.
- Assessment: Environmental Impact

 - Risks: Energy consumption, emissions, waste disposal.
 - Mitigation: Energy-efficient technologies, recycling, compliance.
 - Opportunity: Sustainable practices, carbon footprint reduction.

## Question 7 - Stakeholder Involvement

- Assumption: Stakeholder engagement is crucial.
- Assessment: Stakeholder Engagement

 - Risks: Conflicting interests, communication breakdowns, negative perception.
 - Mitigation: Proactive communication, transparent decisions, collaboration.
 - Opportunity: Building relationships, shared ownership.

## Question 8 - Operational Systems

- Assumption: Impact on maintenance, diagnostics, emergency response.
- Assessment: Operational Systems Integration

 - Risks: System incompatibilities, data loss, vulnerabilities.
 - Mitigation: Testing, phased implementation, backup/recovery.
 - Opportunity: Improving efficiency, enhancing security.

# Distill Assumptions
# Project Plan

- National rollout: DKK 84M. Copenhagen pilot: DKK 36M.

## Timeline

- Copenhagen pilot: Vendor engagement (30 days), isolation/testing (60 days), deployment (90 days).

## Resources

- Core team: 10 FTEs with cybersecurity expertise.

## Compliance

- Comply with EU NIS Directive and Danish cybersecurity regulations.

## Risks

- Modifying e-bus systems introduces safety risks. Mitigation: testing and certifications.

## Impact

- Minimal environmental impact through energy efficiency and waste reduction.
- Impacts operational systems, requiring software updates and revised procedures.

## Stakeholder Engagement

- Crucial through meetings, surveys, and feedback incorporation.


# Review Assumptions
# Domain of the expert reviewer
Project Management and Risk Assessment with Cybersecurity Specialization

## Domain-specific considerations

- Cybersecurity vulnerabilities in transportation systems
- Vendor dependency and supply chain risks
- Regulatory compliance and data privacy
- Operational impact of security measures
- Stakeholder communication and public perception

## Issue 1 - Unrealistic Budget Allocation and Contingency Planning
Assumption: DKK 84M for national rollout and DKK 36M for Copenhagen pilot may be unrealistic. Lacks contingency budget for technical challenges, vendor disputes, or regulatory changes. Vulnerable to cost overruns and delays.

Recommendation:

- Conduct detailed cost estimate for both pilot and rollout.
- Allocate 15% contingency fund (DKK 18M).
- Regularly review/update budget.
- Explore additional funding sources.

Sensitivity:

- Underestimating rollout costs by 20% (DKK 16.8M) could deplete contingency and delay project by 3-6 months.
- 10% increase in vendor costs (DKK 12M) could reduce ROI by 5-8%.
- Without contingency, minor overruns jeopardize project.

## Issue 2 - Insufficient Detail on Data Privacy and GDPR Compliance
Plan mentions EU's NIS Directive but lacks details on data privacy/GDPR. E-buses collect personal data. Failure to comply could result in fines/reputational damage. Needs to address data minimization, purpose limitation, data security, and data subject rights.

Recommendation:

- Conduct data privacy impact assessment (DPIA).
- Implement data security measures (encryption, access controls, anonymization).
- Develop GDPR-compliant data privacy policy.
- Train personnel on data privacy.
- Establish process for data subject requests.

Sensitivity:

- Failure to uphold GDPR may result in fines (2-4% of annual turnover).
- Data breach could lead to legal liabilities and reduce public trust by 10-20%.

## Issue 3 - Lack of Active Threat Intelligence and Adaptable Security Measures
Plan focuses on isolating systems/reforming procurement but lacks proactive threat intelligence and adaptable security. Cybersecurity landscape evolves. Vulnerable to zero-day exploits/targeted attacks. Security measures need to be adaptable.

Recommendation:

- Establish threat intelligence program.
- Implement vulnerability management process.
- Develop incident response plan.
- Conduct penetration testing/security audits.
- Implement SIEM system.

Sensitivity:

- Cyberattack could compromise systems, leading to service disruptions/safety risks.
- Cost of responding to incident could range from DKK 2-5 million, impacting public trust.

## Review conclusion
Plan demonstrates understanding of cybersecurity challenges. Needs to address missing assumptions related to budget, data privacy, and threat intelligence. Prioritizing these areas will enhance resilience and reduce risks.