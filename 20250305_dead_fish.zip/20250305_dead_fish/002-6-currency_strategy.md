This plan involves money.

## Currencies

- **DKK:** Local currency for expenses related to the monitoring program in Denmark, including equipment, personnel, and laboratory services.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.