This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** Launching a pollution monitoring program *requires* physical deployment of sensors in Roskilde Fjord, regular physical sample collection, and on-site analysis. This is *unequivocally* a physical endeavor.