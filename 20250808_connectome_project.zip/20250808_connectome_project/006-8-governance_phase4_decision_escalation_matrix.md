**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for budget overruns and financial instability.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Contingency Plan
Rationale: Requires strategic decision-making and potential reallocation of resources.
Negative Consequences: Project delays, increased costs, and potential project failure.

**PMO Deadlock on Vendor Selection with Ethical Implications**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Review and Recommendation
Rationale: Requires independent ethical review and resolution.
Negative Consequences: Compromised ethical standards, legal challenges, and reputational damage.

**Proposed Major Scope Change Impacting Ethical Considerations**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote, with Ethics & Compliance Committee Input
Rationale: Requires strategic alignment and ethical review due to significant impact on project objectives and ethical framework.
Negative Consequences: Project delays, budget overruns, and potential ethical violations.

**Reported Ethical Concern Regarding Volunteer Consent Process**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation and Recommendation
Rationale: Requires immediate and independent investigation to ensure ethical compliance and volunteer safety.
Negative Consequences: Legal repercussions, reputational damage, and compromised volunteer safety.

**Technical Advisory Group Deadlock on Data Fidelity Standards**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO Review and Decision, considering TAG input
Rationale: Requires resolution to ensure data quality and project objectives are met.
Negative Consequences: Compromised data integrity, inability to achieve project goals.

**Stakeholder Engagement Group Unable to Resolve Community Concerns**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO Review and Decision, potentially involving external mediation
Rationale: Requires higher-level intervention to maintain community trust and project support.
Negative Consequences: Public opposition, project delays, and reputational damage.