This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD.
- **UYU:** Local expenses in Uruguay.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from hyperinflation, and that for significant projects the primary currency must be USD. UYU may be used for local transactions.