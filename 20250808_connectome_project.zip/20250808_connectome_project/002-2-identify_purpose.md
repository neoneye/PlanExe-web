**Purpose:** business

**Purpose Detailed:** Large-scale biomedical research initiative with the objective of creating digitized human brain datasets for future emulation, involving significant financial investment and infrastructure development.

**Topic:** Pilot project 'Upload Intelligence' - Phase 1: Neural connectome mapping and preservation in Uruguay