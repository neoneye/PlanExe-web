This plan implies one or more physical locations.

## Requirements for physical locations

- Permissive biomedical research laws
- Little ethics oversight
- Suitable lab space
- Data center capacity
- Logistical support
- Advanced facilities
- Redundant power systems
- Dedicated logistics infrastructure

## Location 1
Uruguay

Montevideo

Science Park in Montevideo

**Rationale**: Montevideo is the capital and largest city of Uruguay, offering existing infrastructure and potential for establishing a research campus. A science park would provide a collaborative environment and access to resources.

## Location 2
Uruguay

Near a major hospital in Uruguay

Near Hospital de Clínicas, Montevideo

**Rationale**: Proximity to a major hospital facilitates access to terminally ill volunteers and medical expertise, streamlining the process of harvesting and stabilizing brain tissue.

## Location 3
Uruguay

Free Zone in Uruguay

Zona Franca, Uruguay

**Rationale**: Operating within a free zone offers tax benefits and streamlined import/export procedures, facilitating the acquisition of advanced equipment and the shipment of data.

## Location Summary
The project requires a physical presence in Uruguay due to the need for harvesting, stabilizing, and digitizing human brains. Montevideo is suggested due to its existing infrastructure and potential for establishing a research campus. Proximity to a major hospital facilitates access to terminally ill volunteers and medical expertise. Operating within a free zone offers tax benefits and streamlined import/export procedures.