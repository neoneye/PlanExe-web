### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (CEO, CFO, CTO, Chief Ethics Officer, External Advisors).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Management formally appoints the Project Steering Committee Chair (CEO).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Steering Committee Chair confirms membership of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SteerCo Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, objectives, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Circulate Draft PMO ToR for review by nominated members (Project Director, Project Managers, Risk Manager, Finance Manager, Communications Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 10. Project Manager finalizes the Project Management Office ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Director confirms membership of the Project Management Office.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed PMO Membership List

**Dependencies:**

- Final PMO ToR v1.0

### 12. Project Manager schedules the initial Project Management Office kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Invitation

**Dependencies:**

- Confirmed PMO Membership List

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Kick-off Meeting Invitation

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 15. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Chief Ethics Officer, Independent Ethics Expert, Independent Legal Counsel, Volunteer Advocate, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 16. Project Manager finalizes the Ethics & Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Senior Management formally appoints the Chief Ethics Officer (or equivalent senior ethics role) as Interim Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 18. Interim Chair confirms membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Ethics Officer (Interim Chair)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 19. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 20. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, objectives, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 21. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 22. Circulate Draft Technical Advisory Group ToR for review by nominated members (Lead Nanotechnology Engineer, Lead Imaging Specialist, Lead Data Scientist, Independent Technical Experts).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 23. Project Manager finalizes the Technical Advisory Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Project Director formally appoints the Lead Data Scientist as Interim Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 25. Interim Chair confirms membership of the Technical Advisory Group.

**Responsible Body/Role:** Lead Data Scientist (Interim Chair)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 26. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Technical Advisory Group Membership List

### 27. Hold the initial Technical Advisory Group kick-off meeting to review ToR, objectives, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Invitation

### 28. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 29. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Communications Manager, Community Relations Manager, Volunteer Coordinator, Government Relations Liaison, Hospital Liaison, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 30. Project Manager finalizes the Stakeholder Engagement Group ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 31. Project Director formally appoints the Communications Manager as Interim Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 32. Interim Chair confirms membership of the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager (Interim Chair)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Stakeholder Engagement Group Membership List

**Dependencies:**

- Appointment Confirmation Email
- Final Stakeholder Engagement Group ToR v1.0

### 33. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Stakeholder Engagement Group Membership List

### 34. Hold the initial Stakeholder Engagement Group kick-off meeting to review ToR, objectives, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation