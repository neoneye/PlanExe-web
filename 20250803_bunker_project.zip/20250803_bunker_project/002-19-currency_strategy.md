This plan involves money.

## Currencies

- **EUR:** The project budget is specified in EUR, and Denmark is part of the European Union.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions within Denmark will also use EUR.