**Budget Request Exceeding PMO Authority (€5 million)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit delegated to PMO; requires strategic oversight and alignment with overall project budget.
Negative Consequences: Potential budget overrun, impacting project financial viability and requiring scope reduction.

**Critical Risk Materialization (e.g., Regulatory Delay causing >3 month schedule impact)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Significant impact on project timeline and strategic objectives; requires higher-level intervention and resource allocation.
Negative Consequences: Project delays, increased costs, and potential failure to meet strategic objectives.

**PMO Deadlock on Vendor Selection (tie vote after multiple rounds)**
Escalation Level: Project Steering Committee
Approval Process: Senior Executive Sponsor (Chair) Tie-Breaking Vote
Rationale: Inability to reach a consensus within the PMO necessitates a decision from a higher authority to avoid project delays.
Negative Consequences: Project delays, potential selection of a suboptimal vendor, and strained team relationships.

**Proposed Major Scope Change (e.g., adding a new level to the bunker)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval based on Impact Assessment
Rationale: Significant impact on project scope, budget, and schedule; requires strategic review and approval to ensure alignment with project objectives.
Negative Consequences: Budget overruns, schedule delays, and potential disruption of project execution.

**Reported Ethical Concern (e.g., suspected bribery in procurement)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Executive Leadership Team
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with applicable laws and regulations.
Negative Consequences: Legal penalties, reputational damage, and potential project cancellation.

**Technical Advisory Group cannot agree on a critical design element**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on TAG input and risk assessment
Rationale: Disagreement among technical experts requires a decision from a higher authority to ensure project progress and technical integrity.
Negative Consequences: Potential for technical flaws, safety risks, and project delays.