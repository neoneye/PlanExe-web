### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the VIP Bunker project, given its high budget (€200 million), strategic importance, and complex risk profile.

**Responsibilities:**

- Approve project scope, budget, and schedule baselines.
- Provide strategic guidance and direction to the Project Management Office.
- Review and approve major project changes and deviations from the baseline plan (above €5 million).
- Monitor project performance against strategic objectives.
- Oversee risk management and ensure effective mitigation strategies are in place.
- Approve key strategic decisions related to EMP Mitigation, Material Adaptation, Construction Methodology, Security Hardening, and Occupant Well-being.
- Resolve escalated issues and conflicts.
- Ensure alignment with organizational strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference and decision-making protocols.
- Appoint a chairperson.
- Establish meeting schedule and communication protocols.
- Review and approve the project charter and initial risk assessment.

**Membership:**

- Senior Executive Sponsor (Chair)
- Head of Security
- Head of Engineering
- Head of Finance
- Independent External Advisor (Civil Engineering)
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget (above €5 million), schedule, and risk management. Approval of major changes and deviations from the baseline plan.

**Decision Mechanism:** Decisions are made by majority vote, with the Senior Executive Sponsor holding the tie-breaking vote. Any decision impacting occupant well-being requires unanimous approval.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and mitigation strategies.
- Review and approval of change requests (above €5 million).
- Financial performance review.
- Strategic decision-making (EMP Mitigation, Material Adaptation, Construction Methodology, Security Hardening, Occupant Well-being).
- Escalated issues from the Project Management Office.

**Escalation Path:** Senior Executive Leadership Team
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the VIP Bunker project, ensuring adherence to the project plan, budget, and schedule. Provides operational risk management and support to the project team.

**Responsibilities:**

- Develop and maintain the project management plan.
- Manage project budget and schedule.
- Track project progress and performance.
- Identify and manage project risks and issues.
- Coordinate project team activities.
- Manage communication with stakeholders.
- Ensure adherence to project governance policies and procedures.
- Prepare and present project status reports to the Project Steering Committee.
- Manage change requests (below €5 million).
- Implement quality control procedures.

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop a project communication plan.
- Set up project tracking and reporting systems.
- Recruit and train project team members.

**Membership:**

- Project Manager (Head of PMO)
- Construction Manager
- Security Systems Engineer
- Life Support Systems Engineer
- Procurement Manager
- Risk Manager
- Quality Assurance Manager

**Decision Rights:** Operational decisions related to project execution, budget (below €5 million), schedule, and risk management. Approval of change requests below €5 million.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the relevant team members. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key risks and issues.
- Review and approval of change requests (below €5 million).
- Financial performance review.
- Action item tracking.
- Resource allocation.
- Quality control updates.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on critical aspects of the VIP Bunker project, including UHPC construction, EMP shielding, and life support systems.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance and support to the project team.
- Assess the feasibility and risks of technical solutions.
- Conduct independent technical reviews and audits.
- Ensure compliance with relevant technical standards and regulations.
- Advise on the selection of appropriate technologies and materials.
- Monitor the performance of technical systems and equipment.
- Provide recommendations for technical improvements and innovations.

**Initial Setup Actions:**

- Define the scope of technical expertise required.
- Recruit and appoint qualified technical experts.
- Establish communication protocols with the project team.
- Develop a schedule for technical reviews and audits.

**Membership:**

- UHPC Expert (Independent)
- EMP Shielding Expert (Independent)
- Life Support Systems Expert (Independent)
- Geotechnical Engineer
- Structural Engineer
- Security Systems Engineer

**Decision Rights:** Provides recommendations and approvals on technical designs, specifications, and solutions. Has the authority to halt work if critical safety or performance issues are identified.

**Decision Mechanism:** Decisions are made by consensus among the technical experts. In case of disagreement, the Project Steering Committee will make the final decision, considering the TAG's input.

**Meeting Cadence:** Bi-weekly during design and construction phases, quarterly during testing and operational phases.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical risks and issues.
- Presentation of technical solutions and recommendations.
- Review of technical audit findings.
- Assessment of technical system performance.
- Updates on relevant technical standards and regulations.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws, regulations, and ethical standards throughout the VIP Bunker project, mitigating risks of corruption, fraud, and non-compliance.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Conduct regular ethics and compliance training for project personnel.
- Monitor compliance with applicable laws, regulations, and ethical standards.
- Investigate allegations of ethical misconduct or non-compliance.
- Recommend corrective actions to address ethical or compliance violations.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee the whistleblower mechanism and protect whistleblowers from retaliation.
- Review and approve contracts and procurement processes to ensure transparency and fairness.
- Conduct regular audits of project expenses and financial controls.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a whistleblower mechanism.
- Recruit and appoint committee members.
- Develop a compliance training program.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer (Independent)
- Internal Auditor
- HR Representative
- Community Representative (Independent)

**Decision Rights:** Has the authority to investigate allegations of ethical misconduct or non-compliance and recommend corrective actions. Can halt project activities if serious ethical or compliance violations are identified.

**Decision Mechanism:** Decisions are made by majority vote. The Legal Counsel has the tie-breaking vote. Any decision impacting data privacy requires unanimous approval.

**Meeting Cadence:** Quarterly, or as needed to address specific ethical or compliance concerns.

**Typical Agenda Items:**

- Review of ethics and compliance policies and procedures.
- Discussion of potential ethical or compliance risks.
- Investigation of alleged ethical misconduct or non-compliance.
- Review of audit findings.
- Updates on relevant laws and regulations.
- Review of whistleblower reports.

**Escalation Path:** Senior Executive Leadership Team, Audit Committee of the Board (if applicable)
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the local community, regulatory bodies, and VIP occupants, to ensure project acceptance and minimize potential conflicts.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with the local community.
- Provide updates to regulatory bodies on project progress.
- Communicate with VIP occupants regarding project status and well-being.
- Address stakeholder concerns and grievances.
- Manage media relations and public communications.
- Organize public events and presentations.
- Monitor stakeholder perceptions and feedback.
- Develop and implement community benefit programs.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels with stakeholders.
- Recruit and train stakeholder engagement team members.

**Membership:**

- Communications Manager (Chair)
- Community Liaison Officer
- Regulatory Affairs Specialist
- VIP Representative
- Public Relations Officer

**Decision Rights:** Makes decisions related to stakeholder communication and engagement strategies. Can recommend changes to the project plan to address stakeholder concerns.

**Decision Mechanism:** Decisions are made by consensus among the group members. In case of disagreement, the Project Manager will make the final decision, considering the group's input.

**Meeting Cadence:** Monthly, or as needed to address specific stakeholder concerns.

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder concerns and feedback.
- Presentation of project updates.
- Planning of public events and presentations.
- Review of media coverage.
- Assessment of stakeholder perceptions.

**Escalation Path:** Project Steering Committee