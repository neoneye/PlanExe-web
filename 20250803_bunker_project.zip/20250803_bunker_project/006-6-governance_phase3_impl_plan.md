### 1. Identify and appoint an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Appointment Confirmation

**Dependencies:**

- Project Sponsor Identified

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee, based on the defined responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Interim Chair Appointment Confirmation

### 3. Interim Chair reviews and provides feedback on the draft SteerCo ToR.

**Responsible Body/Role:** Interim Chair (Project Steering Committee)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2 with Interim Chair Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 4. Project Manager finalizes the SteerCo ToR based on Interim Chair feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2 with Interim Chair Feedback

### 5. Senior Executive Sponsor formally appoints the remaining members of the Project Steering Committee (Head of Security, Head of Engineering, Head of Finance, Independent External Advisor).

**Responsible Body/Role:** Senior Executive Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails to SteerCo Members

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. Schedule the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails to SteerCo Members

### 7. Hold the initial kick-off meeting for the Project Steering Committee to review the ToR, decision-making protocols, and initial project charter.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Charter

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 8. Project Manager establishes project management processes and procedures for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Processes and Procedures

**Dependencies:**


### 9. Project Manager develops a project communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Communication Plan

**Dependencies:**


### 10. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System Setup
- Reporting Templates

**Dependencies:**


### 11. Project Manager recruits and trains project team members for the PMO (Construction Manager, Security Systems Engineer, Life Support Systems Engineer, Procurement Manager, Risk Manager, Quality Assurance Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Team Members Onboarded
- Training Records

**Dependencies:**


### 12. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Members Onboarded

### 13. Project Manager defines the scope of technical expertise required for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TAG Scope Definition Document

**Dependencies:**


### 14. Project Manager recruits and appoints qualified technical experts for the TAG (UHPC Expert, EMP Shielding Expert, Life Support Systems Expert, Geotechnical Engineer, Structural Engineer, Security Systems Engineer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Members Appointed
- Appointment Confirmation Emails

**Dependencies:**

- TAG Scope Definition Document

### 15. Project Manager establishes communication protocols between the TAG and the project team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Communication Protocols Document

**Dependencies:**

- TAG Members Appointed

### 16. Project Manager develops a schedule for technical reviews and audits by the TAG.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Review and Audit Schedule

**Dependencies:**

- TAG Communication Protocols Document

### 17. Hold initial TAG meeting to review project scope and planned activities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Review and Audit Schedule

### 18. Legal Counsel develops an ethics and compliance policy for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Policy

**Dependencies:**


### 19. Compliance Officer establishes a whistleblower mechanism for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Whistleblower Mechanism Documentation

**Dependencies:**


### 20. Legal Counsel recruits and appoints committee members for the Ethics & Compliance Committee (Compliance Officer, Internal Auditor, HR Representative, Community Representative).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Members Appointed
- Appointment Confirmation Emails

**Dependencies:**

- Draft Ethics and Compliance Policy
- Whistleblower Mechanism Documentation

### 21. Compliance Officer develops a compliance training program for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Compliance Training Program Materials

**Dependencies:**

- Ethics & Compliance Committee Members Appointed

### 22. Hold initial Ethics & Compliance Committee meeting to review policies and procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Compliance Training Program Materials

### 23. Communications Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder List

**Dependencies:**


### 24. Communications Manager develops a stakeholder engagement plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder List

### 25. Communications Manager establishes communication channels with stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Stakeholder Communication Channels Established

**Dependencies:**

- Draft Stakeholder Engagement Plan

### 26. Communications Manager recruits and trains stakeholder engagement team members for the Stakeholder Engagement Group (Community Liaison Officer, Regulatory Affairs Specialist, VIP Representative, Public Relations Officer).

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Stakeholder Engagement Team Members Onboarded
- Training Records

**Dependencies:**

- Stakeholder Communication Channels Established

### 27. Hold initial Stakeholder Engagement Group meeting to review the engagement plan and communication channels.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Team Members Onboarded