
## Audit - Corruption Risks

- Bribery of local officials to expedite permits or overlook non-compliance with regulations.
- Kickbacks from UHPC suppliers in exchange for awarding contracts, potentially compromising material quality.
- Conflicts of interest involving project team members with undisclosed financial ties to subcontractors or suppliers.
- Misuse of confidential project information for personal gain, such as insider trading based on land values near the bunker location.
- Trading favors with contractors, such as awarding contracts to companies owned by friends or family, regardless of their qualifications.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, leading to overpayment for goods and services.
- Use of project funds for personal expenses or unauthorized activities by project personnel.
- Double-billing for the same work or materials by contractors.
- Inefficient allocation of resources, such as overspending on non-critical aspects of the project while underfunding essential security measures.
- Misreporting project progress to justify continued funding, even if milestones are not being met.

## Audit - Procedures

- Conduct regular internal audits of project expenses, with a focus on high-value contracts and procurement processes (quarterly).
- Implement a robust contract review process, requiring independent legal and technical review of all contracts exceeding €1 million.
- Perform periodic site inspections to verify that construction is proceeding according to approved plans and specifications (monthly).
- Conduct a post-project external audit to assess the overall effectiveness of project management and financial controls.
- Implement a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution.

## Audit - Transparency Measures

- Establish a public project website with regular updates on project progress, budget expenditures, and key decisions.
- Publish minutes of key project meetings, including those of the project steering committee, on the project website.
- Implement a transparent procurement process, with documented selection criteria for all major vendors and contractors.
- Create a budget dashboard showing planned versus actual expenditures, updated monthly.
- Establish a clear policy on conflicts of interest, requiring all project personnel to disclose any potential conflicts and recuse themselves from related decisions.