### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Project Sponsor Identified

### 2. Circulate Draft SteerCo ToR for review by proposed members (CEO/Executive Sponsor, Head of Operations, Head of Finance, Independent External Advisor, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review
- Nominated Members List Available

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Incorporate feedback and finalize the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback Received

### 4. Senior Sponsor formally appoints the Project Steering Committee Chair (CEO/Executive Sponsor).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- SteerCo Chair Appointed

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Senior Sponsor formally appoints Project Steering Committee members (Head of Operations, Head of Finance, Independent External Advisor, Project Manager).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- SteerCo Members Appointed

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- SteerCo Chair Appointed
- SteerCo Members Appointed

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- SteerCo Initial Priorities Defined

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 8. Project Manager drafts initial project management methodologies and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Methodologies and Tools

**Dependencies:**

- Project Plan Approved

### 9. Project Manager develops initial Project Communication Plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Communication Plan

**Dependencies:**

- Project Plan Approved

### 10. Project Manager defines roles and responsibilities of project team members for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Defined Roles and Responsibilities for PMO Members

**Dependencies:**

- Project Plan Approved

### 11. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking and Reporting Systems Established

**Dependencies:**

- Defined Roles and Responsibilities for PMO Members

### 12. Project Manager confirms PMO membership (Construction Manager, Marketing Manager, Finance Officer, Procurement Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Members Confirmed

**Dependencies:**

- Defined Roles and Responsibilities for PMO Members

### 13. Schedule the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Invitation

**Dependencies:**

- PMO Members Confirmed

### 14. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Kick-off Meeting Invitation

### 15. Project Manager defines the scope of technical expertise required for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Defined Scope of Technical Expertise

**Dependencies:**

- Project Plan Approved

### 16. Project Manager identifies and recruits qualified technical experts (Structural Engineer, Electrical Engineer, Plumbing Engineer, Architect, Construction Consultant, Sustainability Consultant) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Technical Experts Recruited

**Dependencies:**

- Defined Scope of Technical Expertise

### 17. Project Manager establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Protocols Established

**Dependencies:**

- Technical Experts Recruited

### 18. Project Manager defines reporting requirements for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Requirements Defined

**Dependencies:**

- Technical Experts Recruited

### 19. Schedule the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Invitation

**Dependencies:**

- Reporting Requirements Defined

### 20. Hold the initial Technical Advisory Group kick-off meeting to review scope, communication protocols, and reporting requirements.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Invitation

### 21. Legal Counsel defines the scope of ethics and compliance requirements for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Defined Scope of Ethics and Compliance Requirements

**Dependencies:**

- Project Plan Approved

### 22. Legal Counsel appoints committee members (Compliance Officer, HR Representative, Independent Ethics Advisor, Project Manager) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Members Appointed

**Dependencies:**

- Defined Scope of Ethics and Compliance Requirements

### 23. Legal Counsel establishes reporting mechanisms for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Mechanisms Established

**Dependencies:**

- Ethics & Compliance Committee Members Appointed

### 24. Legal Counsel develops training materials for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Training Materials Developed

**Dependencies:**

- Ethics & Compliance Committee Members Appointed

### 25. Schedule the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Training Materials Developed

### 26. Hold the initial Ethics & Compliance Committee kick-off meeting to review scope, reporting mechanisms, and training materials.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 27. Marketing Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Key Stakeholders Identified

**Dependencies:**

- Project Plan Approved

### 28. Marketing Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Plan Developed

**Dependencies:**

- Key Stakeholders Identified

### 29. Marketing Manager establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**

- Communication Plan Developed

### 30. Marketing Manager defines reporting requirements for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Reporting Requirements Defined

**Dependencies:**

- Communication Plan Developed

### 31. Project Manager confirms Stakeholder Engagement Group membership (Public Relations Officer, Community Liaison, Investor Relations Manager, Project Manager).

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Members Confirmed

**Dependencies:**

- Reporting Requirements Defined

### 32. Schedule the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

**Dependencies:**

- Stakeholder Engagement Group Members Confirmed

### 33. Hold the initial Stakeholder Engagement Group kick-off meeting to review communication plan, channels, and reporting requirements.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation