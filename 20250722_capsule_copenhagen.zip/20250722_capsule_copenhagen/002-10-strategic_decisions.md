## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of 'Risk vs. Growth' (Market Validation & Expansion Strategy), 'Cost vs. Reliability' (Supply Chain), 'Cost vs. Accessibility' (Location), 'Scope vs. Specialization' (Target Market), and 'Capital Expenditure vs. Production Capacity' (Manufacturing). These levers collectively govern the project's core strategic direction, ensuring phased deployment, market validation, and scalable manufacturing.

### Decision 1: Market Validation Strategy
**Lever ID:** `8f4b7630-1e92-4084-a4a6-2c637f7825cb`

**The Core Decision:** The Market Validation Strategy lever focuses on determining the best approach to confirm the viability and demand for the capsule hotel concept. It controls the scale and intensity of the initial launch, marketing efforts, and partnership development. The objective is to gather data on occupancy rates, customer feedback, and revenue generation to inform future scaling decisions. Key success metrics include occupancy rate, customer satisfaction scores, and the time it takes to reach profitability.

**Why It Matters:** Immediate: Slow initial revenue growth → Systemic: Reduced investor confidence and delayed scaling → Strategic: Failure to secure funding for subsequent phases and mass production.

**Strategic Choices:**

1. Prioritize small-scale launch with minimal marketing, relying on organic growth and word-of-mouth.
2. Implement phased launches with targeted marketing campaigns and data-driven adjustments based on occupancy rates and customer feedback.
3. Aggressively pursue pre-launch partnerships with travel agencies and corporate clients, offering discounted rates to secure guaranteed occupancy and generate early revenue.

**Trade-Off / Risk:** Controls Risk vs. Reward. Weakness: The options don't explicitly address competitor analysis and differentiation within the Copenhagen hospitality market.

**Strategic Connections:**

**Synergy:** This lever strongly supports the Expansion and Scaling Strategy (c4761334-c894-4a45-a21f-e7aa19796b1a). Effective market validation provides the data needed to make informed decisions about scaling the business. It also works well with Target Market Segmentation Strategy (ef235096-67b8-45c5-be73-8a0f5af6661f).

**Conflict:** A low-cost, minimal marketing approach can conflict with the Service Differentiation Strategy (da8b7d7e-7318-465f-8bcf-fb29db6da44f) if it fails to attract the target demographic or communicate the unique value proposition. It also conflicts with Location Optimization Strategy (cdf1814f-c6f5-402d-936b-96b934f6fd9d).

**Justification:** *Critical*, Critical because it directly informs the Expansion and Scaling Strategy and impacts funding. The phased deployment hinges on validating demand, making this a central risk mitigation lever.

### Decision 2: Supply Chain Resilience Strategy
**Lever ID:** `7740a688-5191-43e5-8e02-2967f79ee6e4`

**The Core Decision:** The Supply Chain Resilience Strategy lever manages the sourcing and procurement of capsule components. It controls the number of suppliers, their geographic location, and the level of vertical integration. The objective is to minimize disruptions, manage costs, and ensure consistent quality. Key success metrics include supply chain stability, component costs, and lead times for procurement.

**Why It Matters:** Immediate: Supply chain disruptions → Systemic: Delays in construction and increased material costs → Strategic: Failure to meet project deadlines and budget overruns.

**Strategic Choices:**

1. Rely on a single supplier for all capsule components to minimize administrative overhead and potentially negotiate lower prices.
2. Diversify the supply chain by sourcing components from multiple suppliers in different geographic locations to mitigate risk.
3. Establish a vertically integrated supply chain by acquiring key suppliers or developing in-house manufacturing capabilities for critical components.

**Trade-Off / Risk:** Controls Cost vs. Reliability. Weakness: The options do not consider the environmental impact of different sourcing strategies.

**Strategic Connections:**

**Synergy:** This lever is synergistic with the Manufacturing Scalability Strategy (d21970b7-606a-43ba-8522-ff332c5959bc). A resilient supply chain is crucial for scaling production. It also enhances Modular Design Adaptation Strategy (a290cf12-8999-4866-b15f-d90d8740e6af).

**Conflict:** A strategy focused solely on cost reduction through a single supplier can conflict with the Operational Efficiency Strategy (a57bfbed-6d8e-4675-b3da-b11102d0b63e) if disruptions lead to delays and increased operational costs. It also conflicts with Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb).

**Justification:** *High*, High because it directly impacts construction timelines and costs, influencing Manufacturing Scalability. It manages the trade-off between cost and reliability, crucial for phased deployment.

### Decision 3: Manufacturing Scalability Strategy
**Lever ID:** `d21970b7-606a-43ba-8522-ff332c5959bc`

**The Core Decision:** The Manufacturing Scalability Strategy lever determines how the capsule modules will be produced as demand increases. It controls the production method, location, and level of automation. The objective is to efficiently meet demand while managing capital investment and production costs. Key success metrics include production capacity, unit production cost, and time to scale production.

**Why It Matters:** Immediate: Limited production capacity → Systemic: Inability to meet future demand for capsule modules → Strategic: Missed opportunities for expansion and market leadership.

**Strategic Choices:**

1. Outsource capsule manufacturing to a third-party contract manufacturer to avoid capital investment in a dedicated factory.
2. Establish a dedicated factory with traditional manufacturing processes to produce capsule modules at scale.
3. Develop a distributed manufacturing network using a fleet of mobile 3D printing robots that can be deployed on-site to produce capsule modules on-demand.

**Trade-Off / Risk:** Controls Capital Expenditure vs. Production Capacity. Weakness: The options don't address the skills gap and training requirements associated with different manufacturing technologies.

**Strategic Connections:**

**Synergy:** This lever works in synergy with the Supply Chain Resilience Strategy (7740a688-5191-43e5-8e02-2967f79ee6e4). A robust supply chain is essential for scaling manufacturing. It also supports Expansion and Scaling Strategy (c4761334-c894-4a45-a21f-e7aa19796b1a).

**Conflict:** Outsourcing manufacturing can conflict with the Modular Design Adaptation Strategy (a290cf12-8999-4866-b15f-d90d8740e6af) if it limits the ability to make design changes quickly and efficiently. It also conflicts with Operational Efficiency Strategy (a57bfbed-6d8e-4675-b3da-b11102d0b63e).

**Justification:** *High*, High because it determines how the capsule modules will be produced, impacting capital expenditure and production capacity. It's essential for meeting future demand and scaling the business.

### Decision 4: Location Optimization Strategy
**Lever ID:** `cdf1814f-c6f5-402d-936b-96b934f6fd9d`

**The Core Decision:** The Location Optimization Strategy lever determines the ideal location for the capsule hotel. It controls the selection criteria, negotiation process, and partnership development. The objective is to secure a location that maximizes occupancy rates, revenue generation, and brand visibility. Key success metrics include occupancy rate, average daily rate, and customer foot traffic.

**Why It Matters:** Suboptimal location impacts occupancy rates and operational costs. Immediate: Lower foot traffic → Systemic: Reduced revenue by 15% and increased marketing spend → Strategic: Diminished profitability and slower ROI, hindering future expansion.

**Strategic Choices:**

1. Secure a location based on readily available, affordable real estate, prioritizing cost savings over optimal accessibility.
2. Lease a centrally located property with high foot traffic, balancing rental costs with potential revenue from increased occupancy.
3. Partner with existing transportation hubs (e.g., train stations, airports) to integrate capsule units, leveraging existing infrastructure and high-traffic areas. This includes revenue sharing agreements.

**Trade-Off / Risk:** Controls Cost vs. Accessibility. Weakness: The options do not explicitly address the long-term impact of location on brand perception and customer loyalty.

**Strategic Connections:**

**Synergy:** This lever is highly synergistic with the Target Market Segmentation Strategy (ef235096-67b8-45c5-be73-8a0f5af6661f). A well-chosen location caters to the target demographic. It also enhances Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb).

**Conflict:** Prioritizing cost savings over accessibility can conflict with the Service Differentiation Strategy (da8b7d7e-7318-465f-8bcf-fb29db6da44f) if the location is inconvenient or unattractive to the target market. It also conflicts with Operational Efficiency Strategy (a57bfbed-6d8e-4675-b3da-b11102d0b63e).

**Justification:** *High*, High because it directly impacts occupancy rates and revenue generation. It controls the trade-off between cost and accessibility, crucial for attracting the target market.

### Decision 5: Expansion and Scaling Strategy
**Lever ID:** `c4761334-c894-4a45-a21f-e7aa19796b1a`

**The Core Decision:** The Expansion and Scaling Strategy outlines how the capsule hotel will grow beyond the initial location. It controls the pace of expansion, funding sources, and operational model. Objectives include increasing market share, building brand recognition, and achieving economies of scale. Success is measured by the number of locations, revenue growth, and profitability across the network. The strategy must consider capital availability and market demand.

**Why It Matters:** Poor scaling strategy leads to overextension or missed opportunities. Immediate: Cash flow problems → Systemic: Inability to meet demand or manage operations effectively → Strategic: Loss of market share and damaged reputation.

**Strategic Choices:**

1. Expand slowly and organically, reinvesting profits from the initial location into subsequent locations.
2. Seek venture capital funding to accelerate expansion, opening multiple locations simultaneously in strategic markets.
3. Franchise the capsule hotel concept to independent operators, leveraging their local market knowledge and capital while maintaining brand consistency through a centralized management platform and blockchain-secured royalty payments.

**Trade-Off / Risk:** Controls Risk vs. Growth. Weakness: The options lack a clear articulation of the criteria for selecting new locations and managing franchise relationships.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Manufacturing Scalability Strategy (d21970b7-606a-43ba-8522-ff332c5959bc). Efficient manufacturing is crucial for rapid expansion. It also works well with Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb).

**Conflict:** Aggressive expansion can conflict with the Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb) if new markets are not properly assessed. It also conflicts with Supply Chain Resilience Strategy (7740a688-5191-43e5-8e02-2967f79ee6e4) if the supply chain cannot support rapid growth.

**Justification:** *Critical*, Critical because it outlines how the capsule hotel will grow, impacting market share and brand recognition. It controls the pace of expansion and funding sources, essential for long-term success.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Operational Efficiency Strategy
**Lever ID:** `a57bfbed-6d8e-4675-b3da-b11102d0b63e`

**The Core Decision:** The Operational Efficiency Strategy lever focuses on optimizing resource utilization and streamlining processes within the capsule hotel. It controls the level of automation, staffing models, and technology adoption. The objective is to minimize operating costs, enhance the guest experience, and maximize profitability. Key success metrics include occupancy rate, operating expenses, and customer satisfaction scores.

**Why It Matters:** Immediate: Streamlined operations reduce labor costs → Systemic: Improved profitability and scalability → Strategic: Creates a sustainable business model and attracts potential investors.

**Strategic Choices:**

1. Rely on manual processes and traditional staffing models to maintain a personal touch and control costs.
2. Implement automated check-in/check-out systems, smart cleaning schedules, and energy-efficient technologies to optimize resource utilization.
3. Utilize blockchain-based smart contracts for automated payments, dynamic pricing, and decentralized reputation management, creating a transparent and efficient ecosystem for guests and operators.

**Trade-Off / Risk:** Controls Human Touch vs. Automation. Weakness: The options fail to address the potential for job displacement due to automation.

**Strategic Connections:**

**Synergy:** This lever amplifies the benefits of Location Optimization Strategy (cdf1814f-c6f5-402d-936b-96b934f6fd9d). An efficient operation can maximize revenue from a prime location. It also works well with Service Differentiation Strategy (da8b7d7e-7318-465f-8bcf-fb29db6da44f).

**Conflict:** Relying solely on manual processes can conflict with the Manufacturing Scalability Strategy (d21970b7-606a-43ba-8522-ff332c5959bc) if it creates bottlenecks and limits the ability to scale operations efficiently. It also conflicts with Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb).

**Justification:** *Medium*, Medium because it optimizes resource utilization and streamlines processes, impacting profitability. While important, it's less central than market validation or manufacturing scalability.

### Decision 7: Service Differentiation Strategy
**Lever ID:** `da8b7d7e-7318-465f-8bcf-fb29db6da44f`

**The Core Decision:** The Service Differentiation Strategy defines how the capsule hotel will distinguish itself from competitors. It controls the range and quality of services offered, aiming to attract specific customer segments and justify pricing. Key objectives include increased customer satisfaction, higher occupancy rates, and positive brand perception. Success is measured by customer reviews, repeat business, and revenue per available capsule (RevPAC). The strategy must align with the target market and operational capabilities.

**Why It Matters:** Lack of service differentiation leads to commoditization and price competition. Immediate: Lower perceived value → Systemic: Reduced customer loyalty and reliance on price discounts → Strategic: Eroded profit margins and difficulty attracting premium customers.

**Strategic Choices:**

1. Offer basic, standardized capsule accommodations with minimal additional services to maintain low prices.
2. Provide enhanced amenities such as premium bedding, high-speed Wi-Fi, and a complimentary breakfast to attract a broader customer base.
3. Curate personalized experiences through AI-powered concierge services, offering customized recommendations for local attractions and tailored capsule environments (lighting, sound, temperature). This includes partnerships with local businesses for exclusive deals.

**Trade-Off / Risk:** Controls Cost vs. Customer Experience. Weakness: The options fail to consider the operational complexity and staffing requirements associated with higher service levels.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Target Market Segmentation Strategy (ef235096-67b8-45c5-be73-8a0f5af6661f). A clear understanding of the target market informs the services that will resonate most effectively. It also works well with Location Optimization Strategy (cdf1814f-c6f5-402d-936b-96b934f6fd9d).

**Conflict:** A high degree of service differentiation can conflict with the Operational Efficiency Strategy (a57bfbed-6d8e-4675-b3da-b11102d0b63e), as personalized services may increase operational complexity and costs. It also conflicts with Supply Chain Resilience Strategy (7740a688-5191-43e5-8e02-2967f79ee6e4) if premium services require specialized supplies.

**Justification:** *Medium*, Medium because it defines how the capsule hotel will distinguish itself, impacting customer satisfaction. It's important for attracting customers but less critical than location or market validation.

### Decision 8: Modular Design Adaptation Strategy
**Lever ID:** `a290cf12-8999-4866-b15f-d90d8740e6af`

**The Core Decision:** The Modular Design Adaptation Strategy dictates the flexibility and customization of the capsule modules. It controls the design and materials used, impacting cost, sustainability, and adaptability to different locations. Objectives include minimizing initial investment, maximizing space utilization, and catering to diverse customer needs. Success is measured by construction costs, speed of deployment, and customer satisfaction with the capsule design and functionality.

**Why It Matters:** Inefficient modular design increases manufacturing costs and limits scalability. Immediate: Higher initial investment → Systemic: Slower deployment and reduced cost savings from mass production → Strategic: Delayed profitability and compromised competitive advantage.

**Strategic Choices:**

1. Utilize a basic, pre-fabricated container design with minimal customization to reduce initial costs.
2. Develop a flexible modular design that allows for easy customization and adaptation to different site configurations, balancing cost and adaptability.
3. Employ advanced 3D-printing techniques and sustainable materials to create highly customizable and eco-friendly capsule modules, attracting environmentally conscious customers and reducing long-term operational costs.

**Trade-Off / Risk:** Controls Cost vs. Customization. Weakness: The options do not adequately address the regulatory hurdles and building code compliance associated with innovative construction methods.

**Strategic Connections:**

**Synergy:** This lever has strong synergy with the Manufacturing Scalability Strategy (d21970b7-606a-43ba-8522-ff332c5959bc). A well-designed modular system facilitates efficient mass production. It also works well with Location Optimization Strategy (cdf1814f-c6f5-402d-936b-96b934f6fd9d).

**Conflict:** A highly customizable design can conflict with the Operational Efficiency Strategy (a57bfbed-6d8e-4675-b3da-b11102d0b63e), increasing complexity in assembly and maintenance. It also conflicts with Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb) if design changes are frequent.

**Justification:** *Medium*, Medium because it dictates the flexibility and customization of the capsule modules, impacting cost and adaptability. It's important for scalability but less critical than manufacturing strategy.

### Decision 9: Target Market Segmentation Strategy
**Lever ID:** `ef235096-67b8-45c5-be73-8a0f5af6661f`

**The Core Decision:** The Target Market Segmentation Strategy defines the specific customer groups the capsule hotel will focus on. It controls marketing efforts, service offerings, and pricing strategies. Objectives include maximizing occupancy rates, building brand loyalty, and achieving profitability. Success is measured by market share, customer acquisition cost, and customer lifetime value. The strategy must align with the location and service offerings.

**Why It Matters:** Misaligned target market reduces occupancy rates and marketing effectiveness. Immediate: Low initial bookings → Systemic: Increased marketing costs and negative word-of-mouth → Strategic: Delayed breakeven and potential business failure.

**Strategic Choices:**

1. Focus solely on budget-conscious travelers and backpackers seeking the cheapest accommodation option.
2. Target a broader demographic including business travelers, digital nomads, and event attendees, offering tiered pricing and services.
3. Niche down to specific communities (e.g., esports enthusiasts, remote workers) by creating themed capsule environments and hosting relevant events, fostering a strong sense of community and loyalty.

**Trade-Off / Risk:** Controls Scope vs. Specialization. Weakness: The options do not fully explore the potential for partnerships with local businesses to attract specific customer segments.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Service Differentiation Strategy (da8b7d7e-7318-465f-8bcf-fb29db6da44f). Understanding the target market informs the services that will resonate most effectively. It also works well with Market Validation Strategy (8f4b7630-1e92-4084-a4a6-2c637f7825cb).

**Conflict:** Focusing on a niche market can conflict with the Expansion and Scaling Strategy (c4761334-c894-4a45-a21f-e7aa19796b1a) if the target market is limited in size. It also conflicts with Location Optimization Strategy (cdf1814f-c6f5-402d-936b-96b934f6fd9d) if the target market is not present in the chosen location.

**Justification:** *High*, High because it defines the specific customer groups, impacting marketing efforts and service offerings. It's crucial for maximizing occupancy rates and achieving profitability.
