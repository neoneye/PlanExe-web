
## Audit - Corruption Risks

- Bribery of local officials to expedite permitting processes or overlook non-compliance with building codes.
- Kickbacks from suppliers in exchange for awarding contracts for capsule components or construction materials.
- Conflicts of interest where project team members have undisclosed financial interests in supplier companies.
- Misuse of confidential project information for personal gain, such as insider trading related to real estate values near the hotel location.
- Trading favors with contractors, such as awarding contracts to friends or family members without proper competitive bidding.

## Audit - Misallocation Risks

- Misuse of project funds for personal expenses or unauthorized activities.
- Double billing or inflated invoices from suppliers or contractors.
- Inefficient allocation of resources, such as overspending on marketing in one phase while underfunding construction in another.
- Unauthorized use of project assets, such as using construction equipment for personal projects.
- Poor record-keeping and inadequate documentation of project expenses, making it difficult to track spending and identify discrepancies.

## Audit - Procedures

- Conduct periodic internal audits of project finances, including a review of all invoices, contracts, and expense reports (quarterly, internal audit team).
- Implement a robust contract review process with pre-defined approval thresholds for all supplier and contractor agreements (before contract signing, legal/finance department).
- Perform regular compliance checks to ensure adherence to Danish building codes, fire safety regulations, and zoning laws (monthly, external consultant).
- Establish a clear expense approval workflow with multiple levels of authorization based on expense amount (ongoing, finance department).
- Conduct a post-project external audit to assess overall project performance, financial management, and compliance with regulations (post-project completion, external audit firm).

## Audit - Transparency Measures

- Establish a project progress and budget dashboard accessible to key stakeholders, including investors and the project team (real-time, project management software).
- Publish minutes of key project meetings, such as steering committee meetings and major decision-making sessions (monthly, project website/shared drive).
- Implement a confidential whistleblower mechanism for reporting suspected fraud, corruption, or unethical behavior (ongoing, independent third party).
- Make relevant project policies and reports, such as the risk management plan and environmental impact assessment, publicly available (project website).
- Document the selection criteria and rationale for major decisions, such as vendor selection and location choices, and make this information available for review (upon request, project management office).