# Purpose

**Purpose:** business

**Purpose Detailed:** Establishment of a capsule hotel business with phased deployment and eventual mass production of accommodation modules.

**Topic:** Capsule Hotel Business Plan

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* a physical location in Copenhagen, construction of the capsule hotel, procurement of materials, and ongoing maintenance. The phased deployment and eventual factory for mass production *further solidify* its physical nature.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Central location in Copenhagen
- High foot traffic
- Affordable real estate
- Space for 200 capsule units
- Proximity to transportation hubs

## Location 1
Denmark

Indre By, Copenhagen

Near Nørreport Station, Copenhagen

**Rationale**: A location near Nørreport Station offers excellent accessibility due to its central location and transportation links, aligning with the need for high foot traffic and proximity to transportation hubs.

## Location 2
Denmark

Vesterbro, Copenhagen

Near Copenhagen Central Station, Copenhagen

**Rationale**: Vesterbro, close to Copenhagen Central Station, provides a balance of affordability and accessibility, catering to budget-conscious travelers while still being centrally located.

## Location 3
Denmark

Østerbro, Copenhagen

Near Parken Stadium, Copenhagen

**Rationale**: Østerbro, particularly near Parken Stadium, offers potential for event-driven occupancy and a diverse customer base, aligning with the need for high foot traffic and a broader demographic.

## Location Summary
The suggested locations in Indre By (near Nørreport Station), Vesterbro (near Copenhagen Central Station), and Østerbro (near Parken Stadium) in Copenhagen are recommended due to their central locations, accessibility, and potential to attract the target market for a capsule hotel. These locations balance cost, accessibility, and foot traffic, aligning with the project's strategic goals.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** Local currency for all transactions within Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Obtaining necessary building permits and licenses for a novel accommodation type (capsule hotel) in Copenhagen may face delays or rejections due to unfamiliarity or stricter interpretations of existing regulations. This includes fire safety, building codes, and zoning regulations.

**Impact:** A delay of 6-12 months in project commencement, increased costs of 200,000-500,000 DKK due to redesigns or legal fees, and potential inability to operate the hotel.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with local authorities (Kommune) early in the planning phase to understand requirements, proactively address concerns, and potentially seek pre-approval for key aspects of the design. Hire a local expert in Danish building regulations.

## Risk 2 - Technical
The 40ft HC container design with 12 capsules may not meet Danish building codes or fire safety standards. Integrating necessary utilities (electricity, plumbing, ventilation) within the container structure could present unforeseen technical challenges.

**Impact:** Redesign of the capsule layout, increased construction costs of 100,000-300,000 DKK, and potential delays of 3-6 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a thorough technical feasibility study and engage with structural engineers and fire safety consultants familiar with Danish regulations. Develop detailed technical drawings and specifications before commencing construction.

## Risk 3 - Financial
The 35 million DKK budget may be insufficient to cover all project costs, especially considering potential cost overruns due to unforeseen issues, fluctuating material prices, or delays. Phased funding may be difficult to secure if initial phases underperform.

**Impact:** Project delays, reduced scope, or inability to complete the project. Cost overruns of 10-20% (3.5-7 million DKK).

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed cost breakdown and contingency plan. Secure additional funding sources or lines of credit. Implement rigorous cost control measures and track expenses closely. Establish clear performance metrics for each phase to ensure continued funding.

## Risk 4 - Operational
Maintaining cleanliness and hygiene in a high-turnover capsule hotel environment, especially with the 'quiet please' rule and limited cleaning hours (11:00-15:00), could be challenging. Managing guest behavior and ensuring adherence to the quiet policy may require significant staff resources.

**Impact:** Negative customer reviews, reduced occupancy rates, and increased cleaning costs. Potential for noise complaints from guests or neighbors.

**Likelihood:** High

**Severity:** Medium

**Action:** Implement a robust cleaning schedule and train staff on hygiene protocols. Develop clear guidelines for guest behavior and enforce the 'quiet please' rule effectively. Consider noise-dampening materials in the capsule design. Implement a system for addressing guest complaints promptly.

## Risk 5 - Market & Competitive
The capsule hotel concept may not be well-received in the Copenhagen market, or existing hotels and hostels may offer competitive pricing or amenities. Changes in tourism trends or economic conditions could impact demand.

**Impact:** Lower occupancy rates, reduced revenue, and potential business failure. Difficulty attracting the target market.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough market research to assess demand and identify competitors. Develop a strong marketing strategy to differentiate the capsule hotel and attract the target market. Monitor tourism trends and economic conditions closely. Implement flexible pricing strategies to adapt to changing market conditions.

## Risk 6 - Supply Chain
Reliance on a single or limited number of suppliers for capsule components could lead to delays or disruptions in the supply chain, especially if suppliers are located overseas. Fluctuations in currency exchange rates could impact material costs.

**Impact:** Delays in construction, increased material costs, and potential project delays of 2-4 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Diversify the supply chain by sourcing components from multiple suppliers in different geographic locations. Negotiate favorable payment terms with suppliers. Monitor currency exchange rates and hedge against potential fluctuations. Establish contingency plans for alternative sourcing options.

## Risk 7 - Social
The 'men-only' policy could face criticism or legal challenges based on discrimination. Negative public perception could impact brand image and occupancy rates.

**Impact:** Legal challenges, negative publicity, and reduced occupancy rates. Damage to brand reputation.

**Likelihood:** Low

**Severity:** High

**Action:** Consult with legal counsel to ensure compliance with anti-discrimination laws. Consider the potential impact on brand image and public perception. Explore alternative policies that address the target market's needs without excluding other groups. Be prepared to defend the 'men-only' policy with a clear and justifiable rationale.

## Risk 8 - Security
Security risks associated with shared accommodation, including theft, vandalism, or harassment. Ensuring the safety and security of guests and their belongings is crucial.

**Impact:** Theft, vandalism, or harassment incidents. Negative customer reviews and damage to brand reputation. Potential legal liabilities.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement robust security measures, including CCTV surveillance, secure access control, and individual lockers for guests. Train staff on security protocols and emergency procedures. Develop a clear policy for handling security incidents and complaints. Consider insurance coverage for theft or damage to guest belongings.

## Risk 9 - Integration with Existing Infrastructure
Connecting the container-based capsule hotel to existing city infrastructure (water, sewage, electricity) may present challenges, especially if the chosen location has limited capacity or requires significant upgrades.

**Impact:** Increased construction costs, delays in project completion, and potential limitations on operational capacity.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a thorough assessment of existing infrastructure capacity at potential locations. Engage with utility providers early in the planning phase to understand connection requirements and costs. Develop contingency plans for alternative infrastructure solutions.

## Risk 10 - Environmental
Disposal of waste and wastewater from the capsule hotel could pose environmental challenges, especially if the chosen location lacks adequate waste management facilities. Sourcing sustainable materials for capsule construction is important for minimizing environmental impact.

**Impact:** Environmental damage, regulatory fines, and negative public perception. Increased waste disposal costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement a comprehensive waste management plan that includes recycling and responsible disposal of waste and wastewater. Prioritize the use of sustainable materials in capsule construction. Obtain necessary environmental permits and comply with all environmental regulations.

## Risk summary
The most critical risks are Regulatory & Permitting, Financial, and Market & Competitive. Delays in obtaining permits could significantly delay the project and increase costs. Financial risks associated with cost overruns and funding availability could jeopardize the project's completion. Market risks related to the acceptance of the capsule hotel concept and competition could impact occupancy rates and revenue. Mitigation strategies should focus on proactive engagement with authorities, rigorous cost control, and a strong marketing strategy. The 'men-only' policy carries a social risk that needs careful consideration and legal review.

# Make Assumptions


## Question 1 - What are the specific revenue projections for each phase of the capsule hotel deployment (20, 100, 200 units), and what key performance indicators (KPIs) will be used to track financial performance?

**Assumptions:** Assumption: Revenue will increase linearly with the number of units deployed, assuming an average occupancy rate of 70% and an average daily rate (ADR) of 300 DKK per capsule. This is based on initial market research and comparable hotel performance in Copenhagen.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the financial viability of the phased deployment strategy.
Details: A linear revenue increase may not be realistic due to market saturation or seasonal variations. Risk: Lower-than-expected occupancy rates or ADR could jeopardize financial viability. Mitigation: Implement dynamic pricing strategies, targeted marketing campaigns, and explore partnerships to boost occupancy. Benefit: Achieving projected revenue targets will ensure continued funding for subsequent phases. Opportunity: Explore ancillary revenue streams (e.g., vending machines, partnerships with local businesses) to enhance profitability. Quantifiable Metric: Track monthly revenue, occupancy rate, ADR, and RevPAR (Revenue Per Available Room) to assess financial performance.

## Question 2 - What is the detailed timeline for each phase of the project, including key milestones such as site acquisition, construction, permitting, and launch, and how will potential delays be managed?

**Assumptions:** Assumption: Each phase (20, 100, 200 units) will take approximately 6 months for planning, permitting, construction, and launch, with a 1-month buffer for unforeseen delays. This is based on typical construction timelines for similar projects in Copenhagen.

**Assessments:** Title: Timeline and Milestone Assessment
Description: Evaluation of the project timeline and key milestones.
Details: A 6-month timeline per phase may be optimistic, especially considering potential permitting delays. Risk: Delays in one phase could cascade to subsequent phases. Mitigation: Secure necessary permits early in the planning phase, establish strong relationships with contractors, and implement project management software to track progress. Benefit: Adhering to the timeline will ensure timely project completion and minimize cost overruns. Opportunity: Streamline construction processes and leverage pre-fabricated components to accelerate the timeline. Quantifiable Metric: Track the completion date of each milestone and compare it to the planned date to identify potential delays.

## Question 3 - What specific personnel and expertise are required for each phase of the project (e.g., construction workers, hotel staff, marketing team), and how will these resources be acquired and managed?

**Assumptions:** Assumption: Each phase will require a core team of 5 construction workers, 3 hotel staff (manager, cleaner, receptionist), and access to a marketing consultant. Resources will be acquired through local hiring and outsourcing. This is based on typical staffing requirements for similar-sized hotels.

**Assessments:** Title: Resource and Personnel Assessment
Description: Evaluation of the resources and personnel required for the project.
Details: Acquiring skilled construction workers and experienced hotel staff in Copenhagen may be challenging due to labor shortages. Risk: Difficulty finding qualified personnel could delay project completion or impact service quality. Mitigation: Offer competitive salaries and benefits, partner with local training institutions, and explore outsourcing options. Benefit: Having a skilled and motivated team will ensure efficient project execution and high-quality service. Opportunity: Implement cross-training programs to enhance staff flexibility and reduce reliance on specialized personnel. Quantifiable Metric: Track the number of employees hired, employee turnover rate, and staff training hours to assess resource management effectiveness.

## Question 4 - What specific Danish regulations and building codes apply to capsule hotels, particularly regarding fire safety, accessibility, and zoning, and how will compliance be ensured?

**Assumptions:** Assumption: The capsule hotel will need to comply with Danish building codes (Bygningsreglementet), fire safety regulations (Brandteknisk Bygningslovgivning), and zoning regulations (Planloven). Compliance will be ensured through consultation with local authorities and adherence to industry best practices.

**Assessments:** Title: Governance and Regulations Assessment
Description: Evaluation of the regulatory and legal requirements for the project.
Details: Navigating Danish building codes and fire safety regulations for a novel accommodation type like a capsule hotel may be complex. Risk: Non-compliance could result in project delays, fines, or even closure. Mitigation: Engage with local authorities early in the planning phase, hire a local expert in Danish building regulations, and conduct thorough inspections. Benefit: Ensuring compliance will minimize legal risks and ensure the long-term viability of the project. Opportunity: Leverage sustainable building practices to meet environmental regulations and enhance brand image. Quantifiable Metric: Track the number of permits obtained, the number of inspections passed, and the number of regulatory violations to assess compliance effectiveness.

## Question 5 - What specific safety measures will be implemented to protect guests and staff from potential hazards, such as fire, theft, or accidents, and how will these measures be communicated and enforced?

**Assumptions:** Assumption: Safety measures will include fire alarms, sprinklers, CCTV surveillance, secure access control, and trained staff. These measures will be communicated through signage, guest briefings, and staff training. This is based on standard safety protocols for hotels.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the safety measures and risk management protocols for the project.
Details: Ensuring the safety and security of guests in a shared accommodation environment is crucial. Risk: Failure to implement adequate safety measures could result in accidents, injuries, or even fatalities. Mitigation: Conduct a thorough risk assessment, implement robust safety protocols, and provide regular staff training. Benefit: Creating a safe and secure environment will enhance customer satisfaction and protect the business from liability. Opportunity: Leverage technology (e.g., smart sensors, AI-powered surveillance) to enhance safety and security. Quantifiable Metric: Track the number of safety incidents, the number of security breaches, and the number of staff training hours to assess safety and risk management effectiveness.

## Question 6 - What measures will be taken to minimize the environmental impact of the capsule hotel, including energy consumption, waste generation, and water usage, and how will these measures be communicated to stakeholders?

**Assumptions:** Assumption: Environmental impact will be minimized through energy-efficient lighting and appliances, water-saving fixtures, and a comprehensive waste management plan. These measures will be communicated through marketing materials and on-site signage. This is based on common sustainability practices in the hospitality industry.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the environmental impact of the project and the measures taken to minimize it.
Details: Minimizing the environmental impact of the capsule hotel is important for attracting environmentally conscious customers and complying with regulations. Risk: Failure to implement sustainable practices could result in negative publicity and regulatory fines. Mitigation: Prioritize the use of sustainable materials, implement energy-efficient technologies, and develop a comprehensive waste management plan. Benefit: Reducing the environmental footprint will enhance brand image and attract environmentally conscious customers. Opportunity: Obtain environmental certifications (e.g., Green Key) to demonstrate commitment to sustainability. Quantifiable Metric: Track energy consumption, water usage, and waste generation to assess environmental performance.

## Question 7 - How will local residents, businesses, and community groups be involved in the planning and operation of the capsule hotel, and what mechanisms will be used to address their concerns and feedback?

**Assumptions:** Assumption: Stakeholder involvement will include consultations with local residents and businesses, participation in community events, and a feedback mechanism for addressing concerns. This is based on standard community engagement practices.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the stakeholder involvement strategy for the project.
Details: Engaging with local stakeholders is crucial for building support and minimizing potential conflicts. Risk: Failure to address stakeholder concerns could result in negative publicity and project delays. Mitigation: Conduct regular consultations with local residents and businesses, address concerns promptly, and participate in community events. Benefit: Building strong relationships with stakeholders will enhance the project's reputation and ensure its long-term success. Opportunity: Partner with local businesses to offer exclusive deals to guests and support the local economy. Quantifiable Metric: Track the number of stakeholder consultations, the number of concerns raised, and the number of partnerships established to assess stakeholder involvement effectiveness.

## Question 8 - What specific operational systems will be used to manage bookings, check-ins, cleaning schedules, and guest communication, and how will these systems be integrated to ensure efficient operations?

**Assumptions:** Assumption: Operational systems will include a property management system (PMS) for bookings and check-ins, a mobile app for guest communication, and a task management system for cleaning schedules. These systems will be integrated through APIs to ensure seamless data flow. This is based on standard operational practices for hotels.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the operational systems required for the project.
Details: Efficient operational systems are crucial for managing bookings, check-ins, cleaning schedules, and guest communication. Risk: Inefficient systems could result in errors, delays, and customer dissatisfaction. Mitigation: Select a robust PMS, implement a user-friendly mobile app, and integrate these systems through APIs. Benefit: Streamlined operations will enhance efficiency, reduce costs, and improve customer satisfaction. Opportunity: Leverage AI-powered chatbots and automation to enhance guest communication and streamline operations. Quantifiable Metric: Track booking accuracy, check-in time, cleaning completion rate, and customer satisfaction scores to assess operational system effectiveness.

# Distill Assumptions

- 70% occupancy and 300 DKK ADR per capsule will yield linear revenue.
- Each phase (20, 100, 200 units) takes 6 months, plus a 1-month delay buffer.
- Each phase needs 5 construction workers, 3 hotel staff, and a marketing consultant.
- Capsule hotel complies with Danish building, fire safety, and zoning regulations.
- Safety: fire alarms, sprinklers, CCTV, secure access, trained staff, signage, briefings.
- Minimize impact via efficient lighting, water-saving fixtures, and waste management plan.
- Stakeholder involvement: consultations, community events, and feedback mechanisms will be used.
- PMS for bookings, mobile app for communication, and task management for cleaning.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment

## Domain-specific considerations

- Financial viability and ROI
- Regulatory compliance and permitting
- Operational efficiency and scalability
- Market acceptance and competitive landscape
- Supply chain resilience and cost management

## Issue 1 - Unrealistic Revenue Projections and Occupancy Rate Assumption
The assumption of a linear revenue increase based on a fixed 70% occupancy rate and 300 DKK ADR across all phases is overly simplistic and potentially unrealistic. Market saturation, seasonality, competitor actions, and varying demand across different locations (Indre By, Vesterbro, Østerbro) will likely impact occupancy and ADR. The plan lacks a detailed market analysis to support these figures, especially for a novel concept in Copenhagen.

**Recommendation:** Conduct a thorough market analysis to refine revenue projections. This should include: (1) A detailed competitor analysis, assessing pricing and occupancy rates of comparable accommodations (hostels, budget hotels) in each proposed location. (2) A sensitivity analysis of occupancy rates and ADR, considering seasonality, economic conditions, and potential competitor responses. (3) Development of a dynamic pricing strategy to optimize revenue based on demand. (4) A pilot program with a smaller number of capsules to gather real-world data on occupancy and ADR before scaling up.

**Sensitivity:** A 10% decrease in occupancy rate (baseline: 70%) could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. A 10% decrease in ADR (baseline: 300 DKK) could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. Combined, these could reduce ROI by 6-10%.

## Issue 2 - Overly Optimistic Timeline and Permitting Process
The assumption of a 6-month timeline for each phase (planning, permitting, construction, launch) with only a 1-month buffer is highly optimistic, especially considering the potential complexities of obtaining permits for a novel accommodation type in Copenhagen. The plan lacks a detailed understanding of the Danish permitting process and potential delays due to regulatory hurdles, environmental impact assessments, or stakeholder objections.

**Recommendation:** Develop a more realistic timeline based on a thorough understanding of the Danish permitting process. This should include: (1) Early engagement with local authorities (Kommune) to understand specific requirements and potential challenges. (2) A detailed breakdown of permitting timelines, including application preparation, review periods, and potential appeals processes. (3) A contingency plan to address potential delays, such as alternative site options or expedited permitting procedures. (4) Securing pre-approvals for key design elements to minimize potential redesigns during the permitting process.

**Sensitivity:** A 3-month delay in obtaining necessary permits (baseline: 6 months) could increase project costs by 5-10% (1.75-3.5 million DKK) due to extended holding costs, contractor delays, and potential redesigns. This delay could also postpone the ROI by 3-6 months.

## Issue 3 - Insufficient Consideration of Operational Costs and Staffing Requirements
The assumption of a fixed staffing model (3 hotel staff per phase) and limited consideration of operational costs (cleaning, maintenance, utilities, marketing) is a significant oversight. The plan lacks a detailed operational plan that addresses the specific challenges of managing a high-turnover capsule hotel, including cleaning protocols, guest management, security, and maintenance. The 'quiet please' rule and limited cleaning hours may require additional staff or specialized cleaning equipment.

**Recommendation:** Develop a detailed operational plan that addresses the specific challenges of managing a capsule hotel. This should include: (1) A comprehensive staffing model that considers peak occupancy periods, cleaning requirements, and security needs. (2) A detailed cost breakdown of operational expenses, including cleaning supplies, utilities, maintenance, and marketing. (3) Implementation of automated systems (check-in/check-out, cleaning schedules) to optimize efficiency and reduce staffing costs. (4) A robust training program for staff on hygiene protocols, guest management, and security procedures.

**Sensitivity:** Underestimating operational costs by 10% (baseline: X million DKK) could reduce the project's ROI by 2-4%. Requiring one additional staff member per shift (baseline: 3) could increase annual labor costs by 100,000-200,000 DKK, potentially decreasing the project's ROI by 1-2%.

## Review conclusion
The capsule hotel business plan demonstrates a good understanding of the core strategic decisions required for success. However, the plan relies on several optimistic assumptions regarding revenue projections, timelines, and operational costs. Addressing these issues through detailed market analysis, realistic timeline planning, and comprehensive operational planning is crucial for mitigating risks and ensuring the project's financial viability and long-term success.