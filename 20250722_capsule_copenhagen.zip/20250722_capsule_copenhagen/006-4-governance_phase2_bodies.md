### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with organizational goals and managing strategic risks.  Essential given the project's phased deployment, significant capital expenditure, and the need for market validation.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Review and approve major project milestones and deliverables.
- Monitor project progress and performance against strategic objectives.
- Identify and manage strategic risks and issues.
- Approve budget changes exceeding 500,000 DKK.
- Approve changes to the 'men-only' policy.

**Initial Setup Actions:**

- Define Terms of Reference and operating procedures.
- Appoint committee members.
- Establish communication protocols.
- Define escalation paths.

**Membership:**

- CEO/Executive Sponsor
- Head of Operations
- Head of Finance
- Independent External Advisor (Hospitality Industry)
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and strategic risks. Approval of budget changes exceeding 500,000 DKK. Approval of major strategic decisions as outlined in the 'strategic_decisions.md' file.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Executive Sponsor has the deciding vote.

**Meeting Cadence:** Monthly, or more frequently as needed during critical project phases.

**Typical Agenda Items:**

- Review of project progress and performance.
- Discussion of strategic risks and issues.
- Approval of major project milestones and deliverables.
- Review of budget and financial performance.
- Review of market conditions and competitive landscape.
- Review of compliance with regulatory requirements.

**Escalation Path:** Unresolved issues are escalated to the CEO/Executive Sponsor for final decision.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to project plans, budgets, and timelines.  Crucial for coordinating the various project activities and managing operational risks.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track project progress.
- Identify and manage operational risks and issues.
- Coordinate project activities and ensure effective communication.
- Prepare project reports and presentations.
- Manage budget and expenses below 500,000 DKK.
- Ensure compliance with project governance policies and procedures.

**Initial Setup Actions:**

- Establish project management methodologies and tools.
- Develop project communication plan.
- Define roles and responsibilities of project team members.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager
- Construction Manager
- Marketing Manager
- Finance Officer
- Procurement Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within approved budget and scope. Management of budget and expenses below 500,000 DKK.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the relevant team members.  Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, or more frequently as needed during critical project phases.

**Typical Agenda Items:**

- Review of project progress and performance.
- Discussion of operational risks and issues.
- Review of budget and financial performance.
- Coordination of project activities.
- Review of action items from previous meetings.

**Escalation Path:** Issues exceeding the Project Manager's authority or impacting strategic objectives are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on container design, utility integration, and construction methods.  Essential for ensuring the technical feasibility and safety of the capsule hotel.

**Responsibilities:**

- Review and approve container design and construction plans.
- Provide guidance on utility integration and infrastructure requirements.
- Assess the technical feasibility of proposed solutions.
- Identify and mitigate technical risks.
- Ensure compliance with relevant building codes and safety regulations.
- Advise on sustainable building practices and materials.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Identify and recruit qualified technical experts.
- Establish communication protocols.
- Define reporting requirements.

**Membership:**

- Structural Engineer
- Electrical Engineer
- Plumbing Engineer
- Architect
- Construction Consultant
- Sustainability Consultant

**Decision Rights:** Technical decisions related to container design, utility integration, construction methods, and compliance with building codes and safety regulations.  Recommendations on technical solutions and risk mitigation strategies.

**Decision Mechanism:** Decisions made by consensus among the technical experts.  In case of disagreement, the Project Manager makes the final decision based on the weight of evidence and expert opinion.

**Meeting Cadence:** Bi-weekly during design and construction phases, monthly thereafter.

**Typical Agenda Items:**

- Review of container design and construction plans.
- Discussion of utility integration and infrastructure requirements.
- Assessment of technical risks and mitigation strategies.
- Review of compliance with building codes and safety regulations.
- Discussion of sustainable building practices and materials.

**Escalation Path:** Technical issues with significant cost or schedule implications are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with ethical standards, legal regulations (including GDPR), and the 'men-only' policy.  Critical for mitigating legal and reputational risks.

**Responsibilities:**

- Develop and implement ethics and compliance policies and procedures.
- Ensure compliance with GDPR and other relevant data privacy regulations.
- Review and approve the 'men-only' policy and address any legal or ethical concerns.
- Monitor project activities for potential ethical violations or compliance breaches.
- Investigate and resolve any reported ethical or compliance issues.
- Provide training to project team members on ethics and compliance requirements.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Define scope of ethics and compliance requirements.
- Appoint committee members.
- Establish reporting mechanisms.
- Develop training materials.

**Membership:**

- Legal Counsel
- Compliance Officer
- HR Representative
- Independent Ethics Advisor
- Project Manager

**Decision Rights:** Decisions related to ethics and compliance policies, GDPR compliance, and the 'men-only' policy.  Authority to investigate and resolve ethical or compliance issues.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Quarterly, or more frequently as needed to address specific ethical or compliance concerns.

**Typical Agenda Items:**

- Review of ethics and compliance policies and procedures.
- Discussion of GDPR compliance and data privacy issues.
- Review of the 'men-only' policy and any related legal or ethical concerns.
- Investigation and resolution of reported ethical or compliance issues.
- Review of training programs on ethics and compliance requirements.

**Escalation Path:** Unresolved ethical or compliance issues are escalated to the CEO/Executive Sponsor.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the local community, Copenhagen Municipality, and investors.  Essential for building support for the project and addressing any concerns.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Communicate project updates and progress to key stakeholders.
- Solicit feedback from stakeholders and address any concerns.
- Organize community events and consultations.
- Maintain relationships with the Copenhagen Municipality and other relevant authorities.
- Manage investor relations and provide regular financial reports.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication plan.
- Establish communication channels.
- Define reporting requirements.

**Membership:**

- Marketing Manager
- Public Relations Officer
- Community Liaison
- Investor Relations Manager
- Project Manager

**Decision Rights:** Decisions related to stakeholder communication, community engagement, and investor relations.  Recommendations on addressing stakeholder concerns and building support for the project.

**Decision Mechanism:** Decisions made by consensus among the group members.  In case of disagreement, the Project Manager makes the final decision.

**Meeting Cadence:** Monthly, or more frequently as needed to address specific stakeholder concerns.

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder feedback and concerns.
- Planning of community events and consultations.
- Review of investor relations activities.
- Review of communication materials.

**Escalation Path:** Stakeholder issues with significant impact on the project are escalated to the Project Steering Committee.