# Purpose
# Capsule Hotel Business Plan

## Purpose

- Establish capsule hotel business.
- Phased deployment.
- Mass production of modules.


# Plan Type
- Requires physical locations.

## Details

- Copenhagen location required.
- Capsule hotel construction.
- Material procurement.
- Ongoing maintenance.
- Phased deployment.
- Factory for mass production.


# Physical Locations
This plan implies one or more physical locations.

## Requirements for physical locations

- Central location in Copenhagen
- High foot traffic
- Affordable real estate
- Space for 200 capsule units
- Proximity to transportation hubs

## Location 1
Denmark

Indre By, Copenhagen

Near Nørreport Station, Copenhagen

Rationale: Near Nørreport Station offers excellent accessibility due to its central location and transportation links.

## Location 2
Denmark

Vesterbro, Copenhagen

Near Copenhagen Central Station, Copenhagen

Rationale: Vesterbro, close to Copenhagen Central Station, provides a balance of affordability and accessibility.

## Location 3
Denmark

Østerbro, Copenhagen

Near Parken Stadium, Copenhagen

Rationale: Østerbro, near Parken Stadium, offers potential for event-driven occupancy and a diverse customer base.

## Location Summary
The suggested locations in Indre By (near Nørreport Station), Vesterbro (near Copenhagen Central Station), and Østerbro (near Parken Stadium) in Copenhagen are recommended due to their central locations and accessibility.

# Currency Strategy
## Currencies

- DKK: Local currency.

Primary currency: DKK

Currency strategy: DKK will be used for all transactions. No international risk management is needed.

# Identify Risks
# Risk 1 - Regulatory & Permitting

- Delays/rejections due to unfamiliarity with capsule hotels. Fire safety, building codes, zoning.
- Impact: 6-12 month delay, 200,000-500,000 DKK cost increase, potential inability to operate.
- Likelihood: Medium
- Severity: High
- Action: Engage authorities early, seek pre-approval, hire local expert.

# Risk 2 - Technical

- Container design may not meet codes. Utility integration challenges.
- Impact: Redesign, 100,000-300,000 DKK cost increase, 3-6 month delay.
- Likelihood: Medium
- Severity: Medium
- Action: Feasibility study, engage engineers/consultants, detailed drawings.

# Risk 3 - Financial

- Insufficient budget, cost overruns, phased funding issues.
- Impact: Delays, reduced scope, project failure. 10-20% (3.5-7 million DKK) overruns.
- Likelihood: Medium
- Severity: High
- Action: Detailed cost breakdown, contingency plan, secure funding, cost control, performance metrics.

# Risk 4 - Operational

- Cleanliness/hygiene challenges, managing guest behavior, 'quiet please' rule.
- Impact: Negative reviews, reduced occupancy, increased cleaning costs, noise complaints.
- Likelihood: High
- Severity: Medium
- Action: Robust cleaning schedule, staff training, guest guidelines, noise-dampening, complaint system.

# Risk 5 - Market & Competitive

- Capsule hotel concept not well-received, competition, tourism/economic changes.
- Impact: Lower occupancy, reduced revenue, business failure, difficulty attracting target market.
- Likelihood: Medium
- Severity: High
- Action: Market research, strong marketing, monitor trends, flexible pricing.

# Risk 6 - Supply Chain

- Reliance on limited suppliers, overseas suppliers, currency fluctuations.
- Impact: Construction delays, increased costs, 2-4 week delays.
- Likelihood: Medium
- Severity: Medium
- Action: Diversify suppliers, negotiate terms, monitor rates, contingency plans.

# Risk 7 - Social

- 'Men-only' policy criticism/legal challenges.
- Impact: Legal challenges, negative publicity, reduced occupancy, brand damage.
- Likelihood: Low
- Severity: High
- Action: Consult legal counsel, consider impact, explore alternatives, justify policy.

# Risk 8 - Security

- Theft, vandalism, harassment in shared accommodation.
- Impact: Incidents, negative reviews, brand damage, legal liabilities.
- Likelihood: Medium
- Severity: Medium
- Action: Security measures, CCTV, access control, lockers, staff training, incident policy, insurance.

# Risk 9 - Integration with Existing Infrastructure

- Connecting to city infrastructure (water, sewage, electricity) challenges.
- Impact: Increased costs, delays, operational limitations.
- Likelihood: Medium
- Severity: Medium
- Action: Assess infrastructure capacity, engage providers, contingency plans.

# Risk 10 - Environmental

- Waste/wastewater disposal, sustainable materials.
- Impact: Environmental damage, fines, negative perception, increased costs.
- Likelihood: Low
- Severity: Medium
- Action: Waste management plan, sustainable materials, environmental permits, compliance.

# Risk summary

- Critical risks: Regulatory & Permitting, Financial, Market & Competitive.
- Mitigation: Proactive engagement, cost control, strong marketing.
- 'Men-only' policy: Social risk, legal review needed.


# Make Assumptions
# Question 1 - Revenue Projections & KPIs

- Assumption: Linear revenue increase with units deployed, 70% occupancy, 300 DKK ADR.
- Assessment: Financial Feasibility

 - Details: Linear increase may be unrealistic.
 - Risk: Lower occupancy/ADR.
 - Mitigation: Dynamic pricing, targeted marketing, partnerships.
 - Benefit: Continued funding.
 - Opportunity: Ancillary revenue streams.
 - Metric: Monthly revenue, occupancy, ADR, RevPAR.

# Question 2 - Timeline & Delays

- Assumption: 6 months per phase (20, 100, 200 units) + 1-month buffer.
- Assessment: Timeline and Milestone

 - Details: 6 months may be optimistic.
 - Risk: Delays cascade.
 - Mitigation: Early permits, contractor relationships, project management software.
 - Benefit: Timely completion, minimize costs.
 - Opportunity: Streamline construction, pre-fabricated components.
 - Metric: Track milestone completion vs. planned date.

# Question 3 - Personnel & Expertise

- Assumption: 5 construction workers, 3 hotel staff, marketing consultant per phase.
- Assessment: Resource and Personnel

 - Details: Acquiring skilled labor may be challenging.
 - Risk: Difficulty finding qualified personnel.
 - Mitigation: Competitive salaries, training partnerships, outsourcing.
 - Benefit: Efficient execution, high-quality service.
 - Opportunity: Cross-training programs.
 - Metric: Employees hired, turnover rate, training hours.

# Question 4 - Danish Regulations & Building Codes

- Assumption: Comply with Bygningsreglementet, Brandteknisk Bygningslovgivning, Planloven.
- Assessment: Governance and Regulations

 - Details: Navigating codes for capsule hotels may be complex.
 - Risk: Non-compliance.
 - Mitigation: Engage authorities early, hire local expert, inspections.
 - Benefit: Minimize legal risks, long-term viability.
 - Opportunity: Sustainable building practices.
 - Metric: Permits obtained, inspections passed, regulatory violations.

# Question 5 - Safety Measures

- Assumption: Fire alarms, sprinklers, CCTV, secure access, trained staff.
- Assessment: Safety and Risk Management

 - Details: Ensuring guest safety is crucial.
 - Risk: Inadequate safety measures.
 - Mitigation: Risk assessment, robust protocols, staff training.
 - Benefit: Customer satisfaction, protect from liability.
 - Opportunity: Smart sensors, AI surveillance.
 - Metric: Safety incidents, security breaches, training hours.

# Question 6 - Environmental Impact

- Assumption: Energy-efficient appliances, water-saving fixtures, waste management plan.
- Assessment: Environmental Impact

 - Details: Minimizing impact is important.
 - Risk: Negative publicity, regulatory fines.
 - Mitigation: Sustainable materials, energy-efficient tech, waste plan.
 - Benefit: Enhance brand image, attract customers.
 - Opportunity: Environmental certifications.
 - Metric: Energy consumption, water usage, waste generation.

# Question 7 - Stakeholder Involvement

- Assumption: Consultations, community events, feedback mechanism.
- Assessment: Stakeholder Involvement

 - Details: Engaging stakeholders is crucial.
 - Risk: Failure to address concerns.
 - Mitigation: Consultations, address concerns, participate in events.
 - Benefit: Enhance reputation, long-term success.
 - Opportunity: Partner with local businesses.
 - Metric: Consultations, concerns raised, partnerships established.

# Question 8 - Operational Systems

- Assumption: PMS, mobile app, task management system, integrated via APIs.
- Assessment: Operational Systems

 - Details: Efficient systems are crucial.
 - Risk: Inefficient systems.
 - Mitigation: Robust PMS, user-friendly app, API integration.
 - Benefit: Enhance efficiency, reduce costs, improve satisfaction.
 - Opportunity: AI chatbots, automation.
 - Metric: Booking accuracy, check-in time, cleaning rate, satisfaction scores.

# Distill Assumptions
# Project Plan

- 70% occupancy and 300 DKK ADR per capsule yields linear revenue.
- Phases (20, 100, 200 units) take 6 months each, plus 1-month buffer.
- Each phase needs 5 construction workers, 3 hotel staff, and a marketing consultant.

## Compliance

- Complies with Danish building, fire safety, and zoning regulations.

## Safety

- Fire alarms, sprinklers, CCTV, secure access, trained staff, signage, briefings.

## Sustainability

- Minimize impact via efficient lighting, water-saving fixtures, and waste management plan.

## Stakeholder Engagement

- Consultations, community events, and feedback mechanisms.

## Technology

- PMS for bookings, mobile app for communication, task management for cleaning.


# Review Assumptions
# Domain of the expert reviewer
Project Management and Risk Assessment

# Domain-specific considerations

- Financial viability and ROI
- Regulatory compliance and permitting
- Operational efficiency and scalability
- Market acceptance and competitive landscape
- Supply chain resilience and cost management

# Issue 1 - Unrealistic Revenue Projections and Occupancy Rate Assumption
The assumption of a linear revenue increase based on a fixed 70% occupancy rate and 300 DKK ADR is overly simplistic. Market saturation, seasonality, competitor actions, and varying demand across locations will likely impact occupancy and ADR. The plan lacks detailed market analysis.

## Recommendation:
Conduct a thorough market analysis to refine revenue projections:

- Detailed competitor analysis, assessing pricing and occupancy rates of comparable accommodations.
- Sensitivity analysis of occupancy rates and ADR, considering seasonality and economic conditions.
- Development of a dynamic pricing strategy to optimize revenue based on demand.
- Pilot program to gather real-world data before scaling up.

## Sensitivity:
A 10% decrease in occupancy rate could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. A 10% decrease in ADR could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. Combined, these could reduce ROI by 6-10%.

# Issue 2 - Overly Optimistic Timeline and Permitting Process
The assumption of a 6-month timeline for each phase with only a 1-month buffer is highly optimistic, considering the potential complexities of obtaining permits. The plan lacks a detailed understanding of the Danish permitting process.

## Recommendation:
Develop a more realistic timeline based on a thorough understanding of the Danish permitting process:

- Early engagement with local authorities to understand specific requirements.
- Detailed breakdown of permitting timelines.
- Contingency plan to address potential delays.
- Securing pre-approvals for key design elements.

## Sensitivity:
A 3-month delay in obtaining necessary permits could increase project costs by 5-10% due to extended holding costs, contractor delays, and potential redesigns. This delay could also postpone the ROI by 3-6 months.

# Issue 3 - Insufficient Consideration of Operational Costs and Staffing Requirements
The assumption of a fixed staffing model and limited consideration of operational costs is a significant oversight. The plan lacks a detailed operational plan that addresses the specific challenges of managing a high-turnover capsule hotel.

## Recommendation:
Develop a detailed operational plan that addresses the specific challenges of managing a capsule hotel:

- Comprehensive staffing model that considers peak occupancy periods, cleaning requirements, and security needs.
- Detailed cost breakdown of operational expenses.
- Implementation of automated systems to optimize efficiency and reduce staffing costs.
- Robust training program for staff on hygiene protocols, guest management, and security procedures.

## Sensitivity:
Underestimating operational costs by 10% could reduce the project's ROI by 2-4%. Requiring one additional staff member per shift could increase annual labor costs by 100,000-200,000 DKK, potentially decreasing the project's ROI by 1-2%.

# Review conclusion
The capsule hotel business plan demonstrates a good understanding of the core strategic decisions required for success. However, the plan relies on several optimistic assumptions regarding revenue projections, timelines, and operational costs. Addressing these issues is crucial for mitigating risks and ensuring the project's financial viability and long-term success.