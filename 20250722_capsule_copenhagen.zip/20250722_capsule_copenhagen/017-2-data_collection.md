## 1. Market Demand and Financial Viability

Critical for validating the business model, securing funding, and making informed decisions about pricing and service offerings. Addresses the 'Market Validation Strategy' and 'Expansion and Scaling Strategy' decisions.

### Data to Collect

- Copenhagen hospitality market data (occupancy rates, ADR, RevPAR)
- Competitor analysis (pricing, services, target market)
- Target market demographics and preferences
- Willingness to pay for capsule accommodation
- Seasonality and event-driven demand fluctuations
- Detailed cost breakdown (construction, operation, marketing)
- Potential revenue streams (accommodation, ancillary services)

### Simulation Steps

- Use STR Global or similar hospitality data providers to gather market statistics.
- Simulate occupancy rates and revenue based on different pricing scenarios using Excel or Google Sheets.
- Conduct online surveys using SurveyMonkey or Google Forms to gauge customer interest and willingness to pay.
- Use Monte Carlo simulation in Python (with libraries like NumPy and SciPy) to model revenue under various market conditions.

### Expert Validation Steps

- Consult with a hospitality management consultant specializing in the Copenhagen market.
- Engage a real estate market analyst with expertise in Copenhagen property valuation.
- Seek feedback from local tourism agencies and business associations.

### Responsible Parties

- Project Lead
- Marketing & Sales Specialist
- Financial Controller

### Assumptions

- **High:** The Copenhagen tourism market will remain stable or grow over the next three years.
- **High:** The capsule hotel concept will be well-received by the target market.
- **High:** A 70% occupancy rate and 300 DKK ADR per capsule yields linear revenue.

### SMART Validation Objective

Within 4 weeks, gather sufficient market data and expert opinions to validate or refine the revenue projections, occupancy rate assumptions, and target market segmentation, achieving a confidence level of 80% in the financial model.

### Notes

- Uncertainty: Limited historical data on capsule hotels in Copenhagen.
- Risk: Market acceptance may be lower than anticipated.
- Missing Data: Detailed competitor analysis is needed.


## 2. Regulatory Compliance and Permitting

Essential for ensuring legal compliance, obtaining necessary permits, and avoiding costly delays or legal challenges. Addresses the 'Regulatory & Permitting' risk and the 'Social' risk related to the 'men-only' policy.

### Data to Collect

- Danish building codes and regulations (Bygningsreglementet, Brandteknisk Bygningslovgivning, Planloven)
- Fire safety regulations and requirements
- Zoning regulations and restrictions
- Permitting process and timelines
- Accessibility requirements for individuals with disabilities
- Legal implications of the 'men-only' policy

### Simulation Steps

- Research Danish building codes and regulations using online resources and government websites.
- Use online tools to simulate fire safety scenarios and assess compliance.
- Consult with online legal databases to understand the legal implications of the 'men-only' policy.
- Use project management software (e.g., Asana, Jira) to simulate permitting timelines based on available information.

### Expert Validation Steps

- Engage a local expert in Danish building codes and regulations.
- Consult with a fire safety engineer certified in Denmark.
- Seek legal counsel from a Danish lawyer specializing in discrimination law.
- Consult with Copenhagen Municipality planning department.

### Responsible Parties

- Project Lead
- Real Estate & Legal Specialist
- Fire Safety & Compliance Officer

### Assumptions

- **High:** The necessary permits and licenses will be obtained in a timely manner.
- **High:** Complies with Danish building, fire safety, and zoning regulations.
- **High:** The 'men-only' policy will not face significant legal challenges (or a viable alternative will be implemented).

### SMART Validation Objective

Within 6 weeks, obtain a clear understanding of all applicable Danish building codes, fire safety regulations, zoning requirements, and the legal implications of the 'men-only' policy, documenting the findings and developing a compliance plan with a 90% confidence level.

### Notes

- Uncertainty: Interpretation of regulations for novel accommodation concepts.
- Risk: Non-compliance could lead to project delays or closure.
- Missing Data: Specific regulations applicable to capsule hotels in Copenhagen.


## 3. Supply Chain Feasibility and Cost

Crucial for ensuring a reliable and cost-effective supply chain, managing construction timelines, and mitigating the risk of cost overruns. Addresses the 'Supply Chain Resilience Strategy' and 'Manufacturing Scalability Strategy' decisions.

### Data to Collect

- Supplier identification and vetting (container modification, capsule components)
- Material costs (steel, insulation, fixtures)
- Transportation costs (container shipping, local delivery)
- Manufacturing costs (labor, equipment, overhead)
- Lead times for procurement and delivery
- Quality control processes and standards
- Contingency plans for supply chain disruptions

### Simulation Steps

- Use online sourcing platforms (e.g., Alibaba, ThomasNet) to identify potential suppliers.
- Obtain quotes from multiple suppliers for key materials and components.
- Use online logistics calculators to estimate transportation costs.
- Simulate manufacturing costs based on different production scenarios using Excel or Google Sheets.
- Use supply chain management software to model lead times and identify potential bottlenecks.

### Expert Validation Steps

- Consult with a supply chain and logistics expert with experience in modular construction.
- Engage a container modification specialist to assess the feasibility and cost of modifying shipping containers.
- Seek feedback from construction and manufacturing professionals on material costs and labor rates.

### Responsible Parties

- Project Lead
- Construction & Manufacturing Coordinator
- Financial Controller

### Assumptions

- **High:** The supply chain will remain reliable and cost-effective.
- **Medium:** Reliance on limited suppliers, overseas suppliers, currency fluctuations.

### SMART Validation Objective

Within 5 weeks, identify and vet at least three potential suppliers for key materials and components, obtain detailed cost quotes, and develop a supply chain management plan with a 90% confidence level in the cost estimates and lead times.

### Notes

- Uncertainty: Fluctuations in material costs and shipping rates.
- Risk: Supply chain disruptions could delay construction and increase costs.
- Missing Data: Detailed specifications for container modifications are needed.


## 4. Location Suitability and Accessibility

Critical for securing a location that maximizes occupancy rates, revenue generation, and brand visibility. Addresses the 'Location Optimization Strategy' decision.

### Data to Collect

- Foot traffic data for potential locations
- Accessibility data (proximity to transportation hubs, public transport)
- Demographic data for surrounding areas
- Rental costs and lease terms for potential properties
- Zoning regulations and restrictions
- Proximity to competitors and complementary businesses
- Parking availability and costs

### Simulation Steps

- Use online mapping tools (e.g., Google Maps) to assess proximity to transportation hubs and public transport.
- Use demographic data providers (e.g., Esri) to analyze the demographics of surrounding areas.
- Research rental costs and lease terms for potential properties using online real estate databases.
- Use GIS software to visualize foot traffic data and identify high-traffic areas.

### Expert Validation Steps

- Engage a real estate market analyst with expertise in the Copenhagen market.
- Consult with local business associations and community leaders.
- Conduct site visits to assess foot traffic and accessibility firsthand.

### Responsible Parties

- Project Lead
- Real Estate & Legal Specialist
- Marketing & Sales Specialist

### Assumptions

- **High:** Central location in Copenhagen
- **High:** High foot traffic
- **Medium:** Affordable real estate

### SMART Validation Objective

Within 4 weeks, identify and evaluate at least three potential locations in Copenhagen, gathering data on foot traffic, accessibility, demographics, rental costs, and zoning regulations, and ranking the locations based on their suitability with a 90% confidence level.

### Notes

- Uncertainty: Availability of suitable properties in central Copenhagen.
- Risk: Suboptimal location could negatively impact occupancy rates and revenue.
- Missing Data: Detailed foot traffic data for specific locations.

## Summary

This document outlines the data collection areas, simulation steps, expert validation steps, and assumptions required to validate the feasibility of establishing a capsule hotel in Copenhagen. The focus is on market demand, regulatory compliance, supply chain feasibility, and location suitability. Immediate actionable tasks include conducting market research, engaging with local authorities, and identifying potential suppliers.