This plan involves money.

## Currencies

- **DKK:** Local currency for all transactions within Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone (DKK) will be used for all transactions. No additional international risk management is needed.