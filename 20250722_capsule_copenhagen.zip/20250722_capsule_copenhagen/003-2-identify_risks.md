
## Risk 1 - Regulatory & Permitting
Obtaining necessary building permits and licenses for a novel accommodation type (capsule hotel) in Copenhagen may face delays or rejections due to unfamiliarity or stricter interpretations of existing regulations. This includes fire safety, building codes, and zoning regulations.

**Impact:** A delay of 6-12 months in project commencement, increased costs of 200,000-500,000 DKK due to redesigns or legal fees, and potential inability to operate the hotel.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with local authorities (Kommune) early in the planning phase to understand requirements, proactively address concerns, and potentially seek pre-approval for key aspects of the design. Hire a local expert in Danish building regulations.

## Risk 2 - Technical
The 40ft HC container design with 12 capsules may not meet Danish building codes or fire safety standards. Integrating necessary utilities (electricity, plumbing, ventilation) within the container structure could present unforeseen technical challenges.

**Impact:** Redesign of the capsule layout, increased construction costs of 100,000-300,000 DKK, and potential delays of 3-6 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a thorough technical feasibility study and engage with structural engineers and fire safety consultants familiar with Danish regulations. Develop detailed technical drawings and specifications before commencing construction.

## Risk 3 - Financial
The 35 million DKK budget may be insufficient to cover all project costs, especially considering potential cost overruns due to unforeseen issues, fluctuating material prices, or delays. Phased funding may be difficult to secure if initial phases underperform.

**Impact:** Project delays, reduced scope, or inability to complete the project. Cost overruns of 10-20% (3.5-7 million DKK).

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a detailed cost breakdown and contingency plan. Secure additional funding sources or lines of credit. Implement rigorous cost control measures and track expenses closely. Establish clear performance metrics for each phase to ensure continued funding.

## Risk 4 - Operational
Maintaining cleanliness and hygiene in a high-turnover capsule hotel environment, especially with the 'quiet please' rule and limited cleaning hours (11:00-15:00), could be challenging. Managing guest behavior and ensuring adherence to the quiet policy may require significant staff resources.

**Impact:** Negative customer reviews, reduced occupancy rates, and increased cleaning costs. Potential for noise complaints from guests or neighbors.

**Likelihood:** High

**Severity:** Medium

**Action:** Implement a robust cleaning schedule and train staff on hygiene protocols. Develop clear guidelines for guest behavior and enforce the 'quiet please' rule effectively. Consider noise-dampening materials in the capsule design. Implement a system for addressing guest complaints promptly.

## Risk 5 - Market & Competitive
The capsule hotel concept may not be well-received in the Copenhagen market, or existing hotels and hostels may offer competitive pricing or amenities. Changes in tourism trends or economic conditions could impact demand.

**Impact:** Lower occupancy rates, reduced revenue, and potential business failure. Difficulty attracting the target market.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough market research to assess demand and identify competitors. Develop a strong marketing strategy to differentiate the capsule hotel and attract the target market. Monitor tourism trends and economic conditions closely. Implement flexible pricing strategies to adapt to changing market conditions.

## Risk 6 - Supply Chain
Reliance on a single or limited number of suppliers for capsule components could lead to delays or disruptions in the supply chain, especially if suppliers are located overseas. Fluctuations in currency exchange rates could impact material costs.

**Impact:** Delays in construction, increased material costs, and potential project delays of 2-4 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Diversify the supply chain by sourcing components from multiple suppliers in different geographic locations. Negotiate favorable payment terms with suppliers. Monitor currency exchange rates and hedge against potential fluctuations. Establish contingency plans for alternative sourcing options.

## Risk 7 - Social
The 'men-only' policy could face criticism or legal challenges based on discrimination. Negative public perception could impact brand image and occupancy rates.

**Impact:** Legal challenges, negative publicity, and reduced occupancy rates. Damage to brand reputation.

**Likelihood:** Low

**Severity:** High

**Action:** Consult with legal counsel to ensure compliance with anti-discrimination laws. Consider the potential impact on brand image and public perception. Explore alternative policies that address the target market's needs without excluding other groups. Be prepared to defend the 'men-only' policy with a clear and justifiable rationale.

## Risk 8 - Security
Security risks associated with shared accommodation, including theft, vandalism, or harassment. Ensuring the safety and security of guests and their belongings is crucial.

**Impact:** Theft, vandalism, or harassment incidents. Negative customer reviews and damage to brand reputation. Potential legal liabilities.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement robust security measures, including CCTV surveillance, secure access control, and individual lockers for guests. Train staff on security protocols and emergency procedures. Develop a clear policy for handling security incidents and complaints. Consider insurance coverage for theft or damage to guest belongings.

## Risk 9 - Integration with Existing Infrastructure
Connecting the container-based capsule hotel to existing city infrastructure (water, sewage, electricity) may present challenges, especially if the chosen location has limited capacity or requires significant upgrades.

**Impact:** Increased construction costs, delays in project completion, and potential limitations on operational capacity.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a thorough assessment of existing infrastructure capacity at potential locations. Engage with utility providers early in the planning phase to understand connection requirements and costs. Develop contingency plans for alternative infrastructure solutions.

## Risk 10 - Environmental
Disposal of waste and wastewater from the capsule hotel could pose environmental challenges, especially if the chosen location lacks adequate waste management facilities. Sourcing sustainable materials for capsule construction is important for minimizing environmental impact.

**Impact:** Environmental damage, regulatory fines, and negative public perception. Increased waste disposal costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement a comprehensive waste management plan that includes recycling and responsible disposal of waste and wastewater. Prioritize the use of sustainable materials in capsule construction. Obtain necessary environmental permits and comply with all environmental regulations.

## Risk summary
The most critical risks are Regulatory & Permitting, Financial, and Market & Competitive. Delays in obtaining permits could significantly delay the project and increase costs. Financial risks associated with cost overruns and funding availability could jeopardize the project's completion. Market risks related to the acceptance of the capsule hotel concept and competition could impact occupancy rates and revenue. Mitigation strategies should focus on proactive engagement with authorities, rigorous cost control, and a strong marketing strategy. The 'men-only' policy carries a social risk that needs careful consideration and legal review.