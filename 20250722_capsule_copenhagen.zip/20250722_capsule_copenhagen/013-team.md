# Roles

## 1. Project Lead / General Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated oversight and strategic alignment throughout the project's lifecycle. This role is critical for the project's success and requires a long-term commitment.

**Explanation**:
Oversees all aspects of the project, ensuring alignment with strategic goals and managing overall execution.

**Consequences**:
Lack of overall coordination, missed deadlines, budget overruns, and failure to achieve strategic objectives.

**People Count**:
1

**Typical Activities**:
Defining project scope and objectives, creating detailed project plans, managing project teams, monitoring progress, identifying and mitigating risks, ensuring quality control, and communicating with stakeholders.

**Background Story**:
Astrid Nielsen, born and raised in Copenhagen, has always been fascinated by efficiency and organization. She holds an MBA from Copenhagen Business School and has over 10 years of experience in project management, primarily in the construction and hospitality industries. Astrid is known for her meticulous planning, problem-solving skills, and ability to keep projects on track and within budget. She's particularly relevant because of her deep understanding of the local market, regulations, and business practices, making her ideal for navigating the complexities of establishing a new business in Copenhagen.

**Equipment Needs**:
Laptop with project management software (e.g., Asana, Jira), communication tools (e.g., Slack, Microsoft Teams), and access to financial data. Mobile phone.

**Facility Needs**:
Dedicated office space with reliable internet access for planning, meetings, and communication.

## 2. Real Estate & Legal Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Expertise is needed for a specific phase (location securing, legal compliance). An independent contractor provides specialized knowledge without a long-term commitment. Could be full_time_employee if the company has ongoing real estate and legal needs.

**Explanation**:
Secures the location, handles lease negotiations, and ensures compliance with Danish laws and regulations, including the 'men-only' policy.

**Consequences**:
Inability to secure a suitable location, legal challenges, and potential project delays or failure due to non-compliance.

**People Count**:
min 1, max 2, depending on workload and legal complexity

**Typical Activities**:
Conducting property searches, negotiating lease agreements, reviewing legal documents, advising on regulatory compliance, representing the company in legal matters, and managing legal risks.

**Background Story**:
Jens Petersen, a seasoned real estate lawyer from Aarhus, specializes in commercial property and regulatory compliance. He holds a law degree from Aarhus University and has spent the last 15 years advising businesses on property acquisition, lease negotiations, and navigating Danish regulations. Jens is particularly adept at identifying potential legal pitfalls and developing strategies to mitigate risks. His expertise is crucial for securing the ideal location for the capsule hotel and ensuring compliance with all relevant laws, including the sensitive 'men-only' policy.

**Equipment Needs**:
Laptop with legal research databases, document management software, and secure communication tools. Mobile phone.

**Facility Needs**:
Access to a private office or meeting room for confidential client consultations and legal research.

## 3. Construction & Manufacturing Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Expertise is needed for a specific phase (construction and manufacturing). An independent contractor provides specialized knowledge without a long-term commitment. Could be agency_temp if the company outsources the construction and manufacturing.

**Explanation**:
Manages the construction and manufacturing of the capsule units, ensuring quality, cost-effectiveness, and adherence to timelines.

**Consequences**:
Construction delays, cost overruns, poor quality capsule units, and inability to meet project deadlines.

**People Count**:
min 1, max 2, depending on the level of outsourcing

**Typical Activities**:
Sourcing construction materials, managing construction teams, coordinating manufacturing processes, ensuring quality control, monitoring project timelines, and managing budgets.

**Background Story**:
Klaus Schmidt, originally from Hamburg, Germany, is a highly experienced construction and manufacturing coordinator with a background in engineering and supply chain management. He has worked on numerous large-scale construction projects across Europe, specializing in modular construction and efficient manufacturing processes. Klaus is known for his ability to optimize construction timelines, manage costs effectively, and ensure high-quality workmanship. His expertise is essential for overseeing the construction of the capsule units and establishing a reliable supply chain.

**Equipment Needs**:
Laptop with CAD software, project management software, and communication tools. Mobile phone. Access to construction site and manufacturing facilities.

**Facility Needs**:
Access to construction site, manufacturing facilities, and a dedicated workspace for planning and coordination.

## 4. Operations Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires ongoing management of hotel operations, ensuring efficiency and guest satisfaction. This role is critical for the hotel's daily functioning and requires a long-term commitment.

**Explanation**:
Develops and implements operational procedures, including cleaning schedules, guest management, and security protocols, ensuring a smooth and efficient operation.

**Consequences**:
Inefficient operations, poor guest experience, increased costs, and potential safety or security issues.

**People Count**:
1

**Typical Activities**:
Developing operational procedures, managing hotel staff, ensuring guest satisfaction, handling complaints, managing budgets, and overseeing security protocols.

**Background Story**:
Signe Hansen, a Copenhagen native, has spent her entire career in the hospitality industry, working her way up from front desk clerk to operations manager at a boutique hotel. She has a deep understanding of hotel operations, guest management, and customer service. Signe is passionate about creating a positive guest experience and ensuring smooth and efficient operations. Her experience is invaluable for developing and implementing operational procedures for the capsule hotel.

**Equipment Needs**:
Computer with property management system (PMS) software, communication tools, and access to security systems. Mobile phone.

**Facility Needs**:
Dedicated office space within the hotel, access to all hotel facilities, and a communication system for staff coordination.

## 5. Marketing & Sales Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Expertise is needed for a specific phase (marketing and sales). An independent contractor provides specialized knowledge without a long-term commitment. Could be agency_temp if the company outsources the marketing and sales.

**Explanation**:
Develops and executes marketing strategies to attract the target market, manage pricing, and maximize occupancy rates.

**Consequences**:
Low occupancy rates, difficulty attracting the target market, and failure to achieve revenue projections.

**People Count**:
1

**Typical Activities**:
Developing marketing strategies, conducting market research, managing social media accounts, creating marketing materials, managing advertising campaigns, and analyzing marketing performance.

**Background Story**:
Rasmus Olsen, a freelance marketing consultant based in Odense, has a proven track record of developing successful marketing campaigns for businesses in the tourism and hospitality sectors. He holds a degree in marketing from the University of Southern Denmark and has a deep understanding of digital marketing strategies, social media engagement, and brand building. Rasmus is particularly skilled at identifying target markets and crafting compelling marketing messages. His expertise is crucial for attracting the target market to the capsule hotel and maximizing occupancy rates.

**Equipment Needs**:
Laptop with marketing analytics software, social media management tools, and graphic design software. Mobile phone.

**Facility Needs**:
Access to a dedicated workspace with reliable internet access for marketing campaign development and analysis.

## 6. Financial Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires ongoing management of the project budget and financial viability. This role is critical for the project's financial health and requires a long-term commitment.

**Explanation**:
Manages the project budget, tracks expenses, and ensures financial viability throughout the project lifecycle.

**Consequences**:
Budget overruns, financial mismanagement, and potential project failure due to lack of funds.

**People Count**:
1

**Typical Activities**:
Managing project budgets, tracking expenses, preparing financial statements, ensuring compliance with tax regulations, and providing financial advice.

**Background Story**:
Mette Christensen, a certified public accountant from Copenhagen, has over 15 years of experience in financial management, specializing in small and medium-sized businesses. She has a strong understanding of Danish accounting principles and tax regulations. Mette is known for her meticulous attention to detail, financial acumen, and ability to manage budgets effectively. Her expertise is essential for managing the project budget and ensuring financial viability.

**Equipment Needs**:
Computer with accounting software, financial analysis tools, and secure access to financial data. Mobile phone.

**Facility Needs**:
Dedicated office space with secure data storage and access to financial records.

## 7. Fire Safety & Compliance Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires ongoing monitoring and enforcement of fire safety regulations. This role is critical for the safety of the hotel and requires a long-term commitment.

**Explanation**:
Ensures the capsule hotel design and operations comply with all fire safety regulations and building codes, conducting regular inspections and drills.

**Consequences**:
Failure to comply with fire safety regulations, potential safety hazards, and legal liabilities.

**People Count**:
1

**Typical Activities**:
Conducting fire safety inspections, reviewing building plans, ensuring compliance with fire safety regulations, developing fire safety plans, and conducting fire drills.

**Background Story**:
Henrik Jensen, a retired fire safety inspector from the Copenhagen Fire Department, has spent his entire career ensuring compliance with fire safety regulations. He has a deep understanding of Danish building codes and fire safety standards. Henrik is passionate about ensuring the safety of buildings and their occupants. His expertise is crucial for ensuring the capsule hotel design and operations comply with all fire safety regulations.

**Equipment Needs**:
Inspection tools, fire safety equipment, and access to building plans and safety regulations. Mobile phone.

**Facility Needs**:
Access to all areas of the hotel for inspections, a dedicated workspace for reviewing safety plans, and a communication system for reporting issues.

## 8. Customer Service & Community Liaison

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Requires ongoing customer service and community engagement. Part-time employees can provide flexible support based on guest volume and community activities.

**Explanation**:
Handles guest inquiries, manages complaints, and engages with the local community to address concerns and build positive relationships.

**Consequences**:
Negative customer reviews, damage to brand reputation, and potential conflicts with the local community.

**People Count**:
min 2, max 3, depending on the number of guests and community engagement activities

**Typical Activities**:
Handling guest inquiries, managing complaints, engaging with the local community, organizing community events, and building positive relationships.

**Background Story**:
Sofie Larsen, a recent graduate from the University of Copenhagen with a degree in communications, has a passion for customer service and community engagement. She has experience working in customer service roles and volunteering for local community organizations. Sofie is known for her excellent communication skills, empathy, and ability to build positive relationships. Her skills are essential for handling guest inquiries, managing complaints, and engaging with the local community.

**Equipment Needs**:
Computer with customer service software, communication tools, and access to community engagement platforms. Mobile phone.

**Facility Needs**:
Dedicated workspace within the hotel, access to guest areas, and a communication system for handling inquiries and complaints.

---

# Omissions

## 1. Accessibility Consultant

The plan mentions compliance with building codes but doesn't explicitly address accessibility for individuals with disabilities.  Danish regulations likely have specific requirements for accessibility, and failing to address this could lead to legal issues and limit the potential customer base.

**Recommendation**:
Engage an accessibility consultant to review the capsule hotel design and ensure compliance with Danish accessibility regulations.  Incorporate accessible features into the design, such as wider capsules, accessible restrooms, and ramps or elevators where necessary.

## 2. Sustainability Expert

While the plan mentions using sustainable materials, it lacks a comprehensive sustainability strategy.  Consumers are increasingly environmentally conscious, and a strong sustainability focus can be a competitive advantage.

**Recommendation**:
Consult with a sustainability expert to develop a comprehensive sustainability strategy for the capsule hotel.  This could include using recycled materials, implementing energy-efficient technologies, and reducing waste.  Consider obtaining environmental certifications to enhance the hotel's brand image.

## 3. Community Engagement Plan

The stakeholder analysis mentions engaging with the local community, but lacks a detailed plan for doing so.  Proactive community engagement can help address concerns and build positive relationships.

**Recommendation**:
Develop a detailed community engagement plan that includes regular consultations, community events, and a feedback mechanism.  Address potential concerns about noise, traffic, and the 'men-only' policy.  Partner with local businesses to create mutually beneficial relationships.

---

# Potential Improvements

## 1. Clarify Responsibilities of Project Lead and Operations Manager

There's potential overlap between the Project Lead/General Manager and the Operations Manager roles.  Clarifying their distinct responsibilities will prevent confusion and ensure efficient management.

**Recommendation**:
Clearly define the responsibilities of the Project Lead/General Manager (focus on overall project execution and strategic alignment) and the Operations Manager (focus on day-to-day hotel operations and guest satisfaction).  Create a RACI matrix (Responsible, Accountable, Consulted, Informed) to clarify roles and responsibilities for key tasks.

## 2. Formalize Communication Protocols

The plan mentions communication tools but lacks formal communication protocols.  Establishing clear communication channels and reporting procedures will improve team coordination and prevent misunderstandings.

**Recommendation**:
Establish formal communication protocols, including regular team meetings, progress reports, and a designated communication channel for urgent issues.  Use project management software to track tasks, deadlines, and communication.

## 3. Refine Target Market Segmentation

The plan mentions targeting business travelers, digital nomads, and event attendees, but lacks a detailed understanding of their specific needs and preferences.  Refining the target market segmentation will allow for more effective marketing and service offerings.

**Recommendation**:
Conduct further market research to identify the specific needs and preferences of the target market segments.  Develop tailored marketing campaigns and service offerings to appeal to each segment.  Consider offering different capsule types or amenities to cater to different customer needs.