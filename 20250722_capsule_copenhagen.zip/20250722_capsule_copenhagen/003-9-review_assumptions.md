## Domain of the expert reviewer
Project Management and Risk Assessment

## Domain-specific considerations

- Financial viability and ROI
- Regulatory compliance and permitting
- Operational efficiency and scalability
- Market acceptance and competitive landscape
- Supply chain resilience and cost management

## Issue 1 - Unrealistic Revenue Projections and Occupancy Rate Assumption
The assumption of a linear revenue increase based on a fixed 70% occupancy rate and 300 DKK ADR across all phases is overly simplistic and potentially unrealistic. Market saturation, seasonality, competitor actions, and varying demand across different locations (Indre By, Vesterbro, Østerbro) will likely impact occupancy and ADR. The plan lacks a detailed market analysis to support these figures, especially for a novel concept in Copenhagen.

**Recommendation:** Conduct a thorough market analysis to refine revenue projections. This should include: (1) A detailed competitor analysis, assessing pricing and occupancy rates of comparable accommodations (hostels, budget hotels) in each proposed location. (2) A sensitivity analysis of occupancy rates and ADR, considering seasonality, economic conditions, and potential competitor responses. (3) Development of a dynamic pricing strategy to optimize revenue based on demand. (4) A pilot program with a smaller number of capsules to gather real-world data on occupancy and ADR before scaling up.

**Sensitivity:** A 10% decrease in occupancy rate (baseline: 70%) could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. A 10% decrease in ADR (baseline: 300 DKK) could reduce annual revenue by 10%, potentially decreasing the project's ROI by 3-5%. Combined, these could reduce ROI by 6-10%.

## Issue 2 - Overly Optimistic Timeline and Permitting Process
The assumption of a 6-month timeline for each phase (planning, permitting, construction, launch) with only a 1-month buffer is highly optimistic, especially considering the potential complexities of obtaining permits for a novel accommodation type in Copenhagen. The plan lacks a detailed understanding of the Danish permitting process and potential delays due to regulatory hurdles, environmental impact assessments, or stakeholder objections.

**Recommendation:** Develop a more realistic timeline based on a thorough understanding of the Danish permitting process. This should include: (1) Early engagement with local authorities (Kommune) to understand specific requirements and potential challenges. (2) A detailed breakdown of permitting timelines, including application preparation, review periods, and potential appeals processes. (3) A contingency plan to address potential delays, such as alternative site options or expedited permitting procedures. (4) Securing pre-approvals for key design elements to minimize potential redesigns during the permitting process.

**Sensitivity:** A 3-month delay in obtaining necessary permits (baseline: 6 months) could increase project costs by 5-10% (1.75-3.5 million DKK) due to extended holding costs, contractor delays, and potential redesigns. This delay could also postpone the ROI by 3-6 months.

## Issue 3 - Insufficient Consideration of Operational Costs and Staffing Requirements
The assumption of a fixed staffing model (3 hotel staff per phase) and limited consideration of operational costs (cleaning, maintenance, utilities, marketing) is a significant oversight. The plan lacks a detailed operational plan that addresses the specific challenges of managing a high-turnover capsule hotel, including cleaning protocols, guest management, security, and maintenance. The 'quiet please' rule and limited cleaning hours may require additional staff or specialized cleaning equipment.

**Recommendation:** Develop a detailed operational plan that addresses the specific challenges of managing a capsule hotel. This should include: (1) A comprehensive staffing model that considers peak occupancy periods, cleaning requirements, and security needs. (2) A detailed cost breakdown of operational expenses, including cleaning supplies, utilities, maintenance, and marketing. (3) Implementation of automated systems (check-in/check-out, cleaning schedules) to optimize efficiency and reduce staffing costs. (4) A robust training program for staff on hygiene protocols, guest management, and security procedures.

**Sensitivity:** Underestimating operational costs by 10% (baseline: X million DKK) could reduce the project's ROI by 2-4%. Requiring one additional staff member per shift (baseline: 3) could increase annual labor costs by 100,000-200,000 DKK, potentially decreasing the project's ROI by 1-2%.

## Review conclusion
The capsule hotel business plan demonstrates a good understanding of the core strategic decisions required for success. However, the plan relies on several optimistic assumptions regarding revenue projections, timelines, and operational costs. Addressing these issues through detailed market analysis, realistic timeline planning, and comprehensive operational planning is crucial for mitigating risks and ensuring the project's financial viability and long-term success.