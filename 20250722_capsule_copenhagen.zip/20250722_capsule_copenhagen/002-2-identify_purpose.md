**Purpose:** business

**Purpose Detailed:** Establishment of a capsule hotel business with phased deployment and eventual mass production of accommodation modules.

**Topic:** Capsule Hotel Business Plan