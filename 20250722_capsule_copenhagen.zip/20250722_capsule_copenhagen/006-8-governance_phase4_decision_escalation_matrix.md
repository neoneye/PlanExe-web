**Budget Request Exceeding PMO Authority (500,000 DKK)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential budget overruns, delays in project execution, and misalignment with strategic objectives.

**Critical Risk Materialization (e.g., Regulatory Rejection)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Materialization of a critical risk threatens project success and requires strategic decision-making.
Negative Consequences: Project delays, increased costs, potential project failure, and legal liabilities.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Lack of consensus within the PMO on a key operational decision requires higher-level arbitration.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and increased project costs.

**Proposed Major Scope Change (e.g., Unit Count)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope impact strategic objectives and require Steering Committee approval.
Negative Consequences: Misalignment with strategic goals, budget overruns, schedule delays, and reduced project ROI.

**Reported Ethical Concern (e.g., 'Men-Only' Policy Challenge)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation to CEO/Executive Sponsor
Rationale: Ethical violations require independent review and potential corrective action to protect the organization's reputation and legal standing.
Negative Consequences: Legal challenges, reputational damage, loss of stakeholder trust, and financial penalties.

**Technical Issues with Significant Cost or Schedule Implications**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Proposed Solutions
Rationale: Technical issues exceeding the Technical Advisory Group's authority require strategic decision-making.
Negative Consequences: Project delays, increased costs, and potential project failure.

**Unresolved Ethical or Compliance Issues**
Escalation Level: CEO/Executive Sponsor
Approval Process: CEO/Executive Sponsor Review and Final Decision
Rationale: Unresolved ethical or compliance issues require the highest level of authority to ensure appropriate action.
Negative Consequences: Legal challenges, reputational damage, and financial penalties.

**Stakeholder Issues with Significant Impact on the Project**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Proposed Solutions
Rationale: Stakeholder issues exceeding the Stakeholder Engagement Group's authority require strategic decision-making.
Negative Consequences: Loss of stakeholder support, project delays, and increased costs.