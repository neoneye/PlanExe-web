### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project start ASAP
- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project start ASAP
- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project start ASAP
- Project Plan Approved

### 4. Project Sponsor identifies and nominates initial members for the Project Steering Committee (PSC), Ethics & Compliance Committee (ECC), and Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Nominated Members List for PSC
- Nominated Members List for ECC
- Nominated Members List for TAG

**Dependencies:**

- Draft SteerCo ToR v0.1
- Draft ECC ToR v0.1
- Draft TAG ToR v0.1

### 5. Circulate Draft PSC ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PSC ToR v0.2
- Feedback Summary

**Dependencies:**

- Nominated Members List for PSC
- Draft SteerCo ToR v0.1

### 6. Circulate Draft ECC ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- ECC ToR v0.2
- Feedback Summary

**Dependencies:**

- Nominated Members List for ECC
- Draft ECC ToR v0.1

### 7. Circulate Draft TAG ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- Nominated Members List for TAG
- Draft TAG ToR v0.1

### 8. Project Sponsor finalizes and approves the Terms of Reference (ToR) for the Project Steering Committee (PSC), Ethics & Compliance Committee (ECC), and Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0
- Approved ECC ToR v1.0
- Approved TAG ToR v1.0

**Dependencies:**

- PSC ToR v0.2
- ECC ToR v0.2
- TAG ToR v0.2
- Feedback Summary

### 9. Senior Representative from NITI Aayog is formally appointed as the Chair of the Project Steering Committee (PSC) by the Vice Chairman, NITI Aayog.

**Responsible Body/Role:** Vice Chairman, NITI Aayog

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0
- Nominated Members List for PSC

### 10. Independent Legal Expert is formally appointed as the Chair of the Ethics & Compliance Committee (ECC) by the Project Sponsor.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved ECC ToR v1.0
- Nominated Members List for ECC

### 11. Professor of Statistics is formally appointed as the Chair of the Technical Advisory Group (TAG) by the Project Sponsor.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved TAG ToR v1.0
- Nominated Members List for TAG

### 12. Project Sponsor formally confirms the membership of the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PSC Membership Confirmation

**Dependencies:**

- Approved SteerCo ToR v1.0
- Appointment Confirmation Email

### 13. Project Sponsor formally confirms the membership of the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- ECC Membership Confirmation

**Dependencies:**

- Approved ECC ToR v1.0
- Appointment Confirmation Email

### 14. Project Sponsor formally confirms the membership of the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Membership Confirmation

**Dependencies:**

- Approved TAG ToR v1.0
- Appointment Confirmation Email

### 15. Schedule and hold the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PSC Kick-off Meeting Scheduled
- Meeting Minutes with Action Items

**Dependencies:**

- PSC Membership Confirmation
- Approved SteerCo ToR v1.0

### 16. Schedule and hold the initial kick-off meeting for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Scheduled
- Meeting Minutes with Action Items

**Dependencies:**

- ECC Membership Confirmation
- Approved ECC ToR v1.0

### 17. Schedule and hold the initial kick-off meeting for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Scheduled
- Meeting Minutes with Action Items

**Dependencies:**

- TAG Membership Confirmation
- Approved TAG ToR v1.0

### 18. Establish PMO structure and staffing.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- PMO Organizational Chart
- Job Descriptions for PMO Staff

**Dependencies:**

- Project start ASAP

### 19. Develop project management processes and tools for the PMO.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Management Handbook
- List of Approved Project Management Tools

**Dependencies:**

- PMO Organizational Chart

### 20. Define data collection and reporting protocols for the PMO.

**Responsible Body/Role:** Data Analyst

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Data Collection Manual
- Reporting Templates

**Dependencies:**

- List of Approved Project Management Tools

### 21. Establish communication channels with stakeholders for the PMO.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Stakeholder Communication Plan
- List of Communication Channels

**Dependencies:**

- Data Collection Manual

### 22. Develop risk management framework for the PMO.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Risk Management Plan
- Risk Register

**Dependencies:**

- Stakeholder Communication Plan