Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on public policy and economic development, aiming to implement a 4-day work week, which does not inherently involve physics-related impossibilities.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (4DWW) + market (India) + tech/process + policy (legal amendments) without independent evidence at comparable scale. There is no mention of precedent for implementing a 4DWW program nationally, especially including the informal sector.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Program Director / Deliverable: Validation Report / Date: Q4 2025


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan defines strategic choices for key decisions like 'Informal Sector Integration' and 'Program Scope Strategy', it lacks one-pagers that clearly articulate the business-level mechanism-of-action (inputs→process→customer value), owner, and measurable outcomes for each.

**Mitigation**: PMO: Develop one-pagers for each strategic decision (Informal Sector Integration, Program Scope Strategy, etc.) outlining the value hypothesis, success metrics, and decision hooks by Q1 2025.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies several relevant risks (regulatory, political, financial, social, informal sector integration), but it does not explicitly analyze cascades or provide a dated review cadence. For example, "Delays in approvals could delay implementation" is listed, but the cascade to financial impact is not.

**Mitigation**: Risk Management & Compliance Officer: Map risk cascades (e.g., permit delay → missed peak season → revenue shortfall) and schedule a quarterly review of the risk register by Q1 2025.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Regulatory and permitting delays" as a key risk, but there is no detailed matrix outlining required permits, lead times, or dependencies. Without this, timeline realism cannot be assessed.

**Mitigation**: Legal Counsel: Create a permit/approval matrix detailing all required permits, typical lead times, and dependencies by Q1 2025.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not mention any funding sources, their status (LOI/term sheet/closed), the draw schedule, or the runway length. The plan mentions a budget (INR 2,000 crore) but provides no details on how this budget will be secured.

**Mitigation**: PMO: Develop a dated financing plan listing funding sources, their status, draw schedule, covenants, and a NO-GO on missed financing gates by Q1 2025.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan allocates INR 2,000 crore (~USD 240M) over 48 months for a national-level program encompassing both the formal and informal sectors, but there are no benchmarks or vendor quotes to substantiate this figure. The plan does not normalize costs per area.

**Mitigation**: Head of Finance: Benchmark costs (≥3), obtain vendor quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by Q1 2025.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., "Systemic: 10% improvement in informal worker wages") as single numbers without providing a range, confidence interval, or discussing alternative scenarios. There is no sensitivity analysis.

**Mitigation**: Head of Finance: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the most critical projection (e.g., wage improvement) by Q1 2025.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications, interface definitions, test plans, or integration maps. The plan focuses on policy and strategy but omits engineering details.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by Q2 2025.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several claims without providing verifiable evidence. For example, the plan states, "Systemic: 25% faster scaling through data-driven insights" without providing any data or analysis to support this claim. There is no evidence pack.

**Mitigation**: PMO: Compile an evidence pack containing verifiable artifacts (documents, links, IDs) to support all critical claims in the plan by Q1 2025.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project mentions 'Informal Sector Integration' without defining SMART acceptance criteria. The plan states, "The objective is to improve the livelihoods of informal workers while ensuring program equity" but lacks specific, verifiable qualities.

**Mitigation**: Informal Sector Specialist: Define SMART criteria for 'Informal Sector Integration', including a KPI for formalization rate (e.g., 5,000 workers formalized) by Q1 2025.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Recognition programs' as an incentive. This feature adds cost without clear support for core goals (improve productivity, enhance equity). It's not clear how recognition directly drives productivity or equity.

**Mitigation**: Project Team: Produce a one-page benefit case for 'Recognition programs', including a KPI, owner, and estimated cost, or move the feature to the project backlog. Date: Q1 2025


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies roles (Program Director, Legal Counsel, etc.) but does not identify a 'unicorn' role. The Informal Sector Specialist is critical due to the novelty of integrating the informal sector, requiring specialized knowledge.

**Mitigation**: PMO: Conduct a talent market analysis for the Informal Sector Specialist role, assessing availability and required compensation, by Q4 2024.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions regulatory and permitting delays as a key risk, but there is no detailed matrix outlining required permits, lead times, or dependencies. Without this, timeline realism cannot be assessed.

**Mitigation**: Legal Counsel: Create a permit/approval matrix detailing all required permits, typical lead times, and dependencies by Q1 2025.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "sustainability plan" and "secure funding" as actions to address the risk of "Waning enthusiasm or lack of sustained benefits. Lack of funding" but lacks specifics on funding sources, operational costs, or maintenance.

**Mitigation**: Head of Finance: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by Q2 2025.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions physical locations (PMO, pilot sites) but lacks evidence of zoning compliance, occupancy limits, or fire safety. The plan states "Office space for PMO" but does not address zoning.

**Mitigation**: Facilities Team: Conduct a fatal-flaw screen for zoning/occupancy/fire at PMO and pilot sites; define NO-GO thresholds by Q1 2025.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not mention SLAs with vendors or tested failovers. The plan mentions "IT infrastructure for data collection and analysis" but lacks details on redundancy or business continuity.

**Mitigation**: IT Team: Secure SLAs with key vendors, add a secondary data path, and test failover by Q2 2025.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Program Management Office (PMO)' is incentivized to deliver the project on time and within budget, while 'State Labor Departments' are incentivized to protect worker rights and ensure compliance with labor laws, potentially leading to conflicts over flexibility vs. stability.

**Mitigation**: PMO: Establish a shared OKR between the PMO and State Labor Departments focused on 'Successful pilot program implementation in X states by Q4 2025' to align incentives.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Adaptive Implementation Strategy mentions quarterly decision gates, but lacks KPIs, review owners, and change-control thresholds. Vague 'ability to adapt to challenges' is insufficient.

**Mitigation**: PMO: Add a monthly review with KPI dashboard, owners, and a lightweight change board with thresholds (when to re-plan/stop) by Q1 2025.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Regulatory & Permitting, Political factors, Informal Sector Integration) but does not map interactions. For example, regulatory delays could trigger political opposition and hinder informal sector integration, creating a multi-domain failure.

**Mitigation**: Risk Management & Compliance Officer: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by Q2 2025.