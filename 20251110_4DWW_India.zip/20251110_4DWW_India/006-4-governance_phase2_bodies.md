### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides strategic oversight and direction, ensuring alignment with national objectives and managing high-level risks.  Essential given the program's national scale, political sensitivity, and significant budget.

**Responsibilities:**

- Approve overall project strategy and key milestones.
- Review and approve annual budget and resource allocation.
- Monitor progress against strategic objectives and KPIs.
- Oversee risk management and mitigation strategies for strategic risks.
- Resolve strategic conflicts and escalate issues as needed.
- Approve major changes to project scope or direction.
- Ensure alignment with NITI Aayog's strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference (TOR).
- Appoint Chair and Secretary.
- Establish meeting schedule and communication protocols.
- Review and approve initial project plan and budget.
- Define escalation paths and decision-making processes.

**Membership:**

- Senior Representative from NITI Aayog (Chair)
- Secretary, Ministry of Labour and Employment
- Chief Economic Advisor, Department of Economic Affairs
- Independent Expert in Labor Economics
- Program Director (PMO)
- Representative from a major Industry Body (e.g., CII, FICCI)

**Decision Rights:** Strategic decisions related to project scope, budget (above INR 50 crore), key milestones, and risk management. Approval of major policy changes or deviations from the approved project plan.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote.  Any dissenting opinions to be formally recorded.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Discussion and approval of budget revisions.
- Review of risk register and mitigation strategies.
- Strategic updates from the Program Director.
- Stakeholder feedback and engagement updates.
- Decision gate reviews (continue/expand/pause/rollback).

**Escalation Path:** Vice Chairman, NITI Aayog
### 2. Program Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, operational risk management, and decisions below strategic thresholds.  Critical for coordinating the complex pilot programs and ensuring consistent data collection and reporting.

**Responsibilities:**

- Manage day-to-day project activities and resources.
- Develop and maintain project plans, schedules, and budgets.
- Implement risk management plans and escalate issues as needed.
- Collect, analyze, and report on project data and KPIs.
- Coordinate pilot programs and stakeholder engagement activities.
- Ensure compliance with legal and regulatory requirements.
- Prepare reports for the Project Steering Committee.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management processes and tools.
- Define data collection and reporting protocols.
- Establish communication channels with stakeholders.
- Develop risk management framework.

**Membership:**

- Program Director (Head of PMO)
- Legal Counsel
- Data Analyst
- Communications Manager
- Stakeholder Engagement Officer
- Project Managers (for Formal and Informal Sector Tracks)

**Decision Rights:** Operational decisions related to project execution, budget management (below INR 50 crore), resource allocation, and risk mitigation.  Approval of pilot program selection and implementation plans.

**Decision Mechanism:** Decisions made by the Program Director, in consultation with PMO team members.  Any disagreements to be escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of operational issues and risks.
- Review of data and KPIs.
- Coordination of pilot program activities.
- Stakeholder engagement updates.
- Budget tracking and expenditure review.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Provides independent assurance on ethical conduct, data privacy, and regulatory compliance.  Essential given the sensitive nature of the data collected and the potential for conflicts of interest.

**Responsibilities:**

- Review and approve data privacy and security plans.
- Monitor compliance with ethical guidelines and regulatory requirements.
- Investigate allegations of fraud, corruption, or misconduct.
- Provide guidance on ethical issues and conflicts of interest.
- Conduct regular audits of compliance processes.
- Ensure adherence to GDPR-like legislation if applicable.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Finalize Terms of Reference (TOR).
- Appoint Chair and members.
- Establish meeting schedule and communication protocols.
- Develop ethical guidelines and compliance procedures.
- Establish a whistleblower mechanism.

**Membership:**

- Independent Legal Expert (Chair)
- Data Protection Officer
- Representative from a reputable NGO focused on transparency and accountability
- Senior Representative from NITI Aayog (non-voting member)
- Internal Audit Manager

**Decision Rights:** Decisions related to ethical conduct, data privacy, and regulatory compliance.  Authority to recommend corrective actions and sanctions for violations.

**Decision Mechanism:** Decisions made by majority vote, with the Chair having the tie-breaking vote.  Any dissenting opinions to be formally recorded.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of data privacy and security incidents.
- Discussion of ethical issues and conflicts of interest.
- Review of compliance audit reports.
- Updates on regulatory changes.
- Review of whistleblower reports.
- Assessment of the effectiveness of compliance procedures.

**Escalation Path:** Vice Chairman, NITI Aayog
### 4. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Provides specialized technical input on data collection, analysis, and evaluation methodologies.  Ensures the rigor and validity of the program's findings.

**Responsibilities:**

- Advise on the design of the unified measurement framework.
- Review and validate data collection and analysis methodologies.
- Provide technical expertise on productivity measurement and evaluation.
- Assess the feasibility and scalability of technical solutions.
- Review and approve data schemas and audit protocols.
- Ensure data quality and integrity.

**Initial Setup Actions:**

- Finalize Terms of Reference (TOR).
- Identify and recruit technical experts.
- Establish meeting schedule and communication protocols.
- Review existing data collection and analysis methodologies.
- Define data quality standards.

**Membership:**

- Professor of Statistics (Chair)
- Economist specializing in labor productivity
- Data Scientist with experience in large-scale data analysis
- IT Specialist with expertise in data integration
- Representative from a leading research institution
- Program Director (PMO) - non-voting member

**Decision Rights:** Recommendations on technical aspects of data collection, analysis, and evaluation.  Approval of data schemas and audit protocols.

**Decision Mechanism:** Decisions made by consensus, with the Chair facilitating discussion and resolving disagreements.  Any unresolved issues to be escalated to the Project Steering Committee.

**Meeting Cadence:** As needed, but at least quarterly

**Typical Agenda Items:**

- Review of data collection and analysis methodologies.
- Discussion of technical challenges and solutions.
- Validation of data quality and integrity.
- Assessment of the feasibility of new technologies.
- Review of audit protocols.
- Updates on data privacy and security measures.

**Escalation Path:** Project Steering Committee