This plan implies one or more physical locations.

## Requirements for physical locations

- Office space for PMO
- Pilot locations in IT/services, manufacturing/SMEs
- Locations with controlled diversity (company size, unionization, gender mix)
- Accessibility for audits and data collection

## Location 1
India

New Delhi

NITI Aayog Office, Sansad Marg, New Delhi

**Rationale**: As the apex Program Management Office (PMO) will be under NITI Aayog, locating the PMO in their existing office in New Delhi provides administrative efficiency and aligns with the plan's governance structure.

## Location 2
India

Bengaluru

IT Parks and Industrial Areas

**Rationale**: Bengaluru is a major IT hub in India, making it suitable for formal sector pilots in IT/services. It also has a mix of company sizes and unionization, fulfilling the controlled diversity requirement.

## Location 3
India

Mumbai

Financial and Industrial Districts

**Rationale**: Mumbai is a major financial and industrial center with a diverse range of businesses, making it suitable for formal sector pilots in manufacturing and SMEs. It also offers a mix of company sizes and unionization.

## Location 4
India

Coimbatore

Textile and Manufacturing Hubs

**Rationale**: Coimbatore is a significant manufacturing hub, particularly for textiles, providing a suitable location for formal sector pilots in manufacturing and SMEs. It also offers a mix of company sizes and unionization.

## Location Summary
The plan requires a PMO location in New Delhi at the NITI Aayog office, along with pilot locations in Bengaluru, Mumbai, and Coimbatore to conduct formal sector pilots in IT/services, manufacturing, and SMEs, ensuring controlled diversity and accessibility for audits.