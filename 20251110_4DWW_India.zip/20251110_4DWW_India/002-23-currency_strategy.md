This plan involves money.

## Currencies

- **INR:** Indian Rupees for local expenses, salaries, incentives, and operational costs within India.
- **USD:** U.S. Dollars for budgeting and reporting, given the project's scale and the need for international comparability, as well as for potential international transactions or procurement.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. INR will be used for local transactions. Hedging strategies may be considered to manage exchange rate risks between USD and INR for larger transactions.