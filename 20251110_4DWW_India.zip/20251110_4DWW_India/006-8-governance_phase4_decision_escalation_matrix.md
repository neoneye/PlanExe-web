**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit set for PMO operational decisions (INR 50 crore). Requires strategic review and approval due to significant financial impact.
Negative Consequences: Potential budget overrun, scope reduction, or project delays if not approved.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Materialization of a risk with high severity (e.g., political, regulatory) threatens project success and requires strategic guidance and resource allocation.
Negative Consequences: Project failure, significant delays, reputational damage, or legal penalties if not addressed effectively.

**PMO Deadlock on Pilot Cohort Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Decision
Rationale: Inability of the PMO to reach consensus on pilot cohort selection impacts project timeline and diversity objectives. Requires higher-level arbitration.
Negative Consequences: Delays in pilot launch, biased data, difficulty drawing conclusions, and potential failure to meet diversity targets.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Vote
Rationale: Significant changes to project scope (e.g., adding new sectors or geographies) require strategic alignment and budget reallocation.
Negative Consequences: Project delays, budget overruns, and potential misalignment with strategic objectives if not properly evaluated and approved.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Allegations of fraud, corruption, or misconduct require independent investigation and assessment to ensure ethical conduct and regulatory compliance.
Negative Consequences: Legal liabilities, loss of trust, disruption of operations, and damage to reputation if not addressed impartially.

**Technical Advisory Group (TAG) cannot agree on data schemas**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Decision
Rationale: Inability of the TAG to reach consensus on data schemas impacts project timeline and data integrity objectives. Requires higher-level arbitration.
Negative Consequences: Delays in pilot launch, biased data, difficulty drawing conclusions, and potential failure to meet data integrity targets.