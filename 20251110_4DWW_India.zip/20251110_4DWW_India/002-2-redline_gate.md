**Verdict:** 🟢 ALLOW

**Rationale:** The prompt outlines a plan for a 4-day work week program in India, focusing on administrative simplicity, political viability, and measurable gains, which is a benign request.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |