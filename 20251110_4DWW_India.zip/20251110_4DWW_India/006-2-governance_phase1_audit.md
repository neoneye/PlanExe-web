
## Audit - Corruption Risks

- Bribery of officials in state labor departments to expedite approvals or overlook non-compliance during pilot programs.
- Kickbacks from vendors providing IT infrastructure or data collection services to the PMO.
- Conflicts of interest within the PMO, where personnel may have undisclosed financial ties to companies participating in the pilots or providing services to the program.
- Nepotism in the selection of companies for pilot programs, favoring those with connections to government officials or PMO staff.
- Misuse of confidential data collected during the pilots for personal gain or to benefit favored companies, such as providing competitive intelligence.

## Audit - Misallocation Risks

- Inflated invoices or double-billing for services provided by consultants or vendors.
- Misuse of funds allocated for incentives, such as payroll tax rebates or productivity-sharing grants, for unrelated expenses or personal enrichment.
- Inefficient allocation of resources to pilot programs that are not yielding measurable results, without proper evaluation or adjustment.
- Unauthorized use of PMO assets, such as vehicles or office equipment, for personal purposes.
- Misreporting of progress or results to justify continued funding or to conceal failures in pilot programs.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, including invoices, payments, and expense reports, with a focus on identifying irregularities or discrepancies.
- Perform annual external audits of the program's financial statements and compliance with relevant regulations, conducted by an independent auditing firm.
- Implement a contract review process with pre-defined thresholds for independent legal review of contracts with vendors and pilot companies.
- Establish a whistleblower mechanism with clear procedures for reporting suspected fraud or corruption, and ensure protection for whistleblowers.
- Conduct periodic compliance checks to ensure that pilot companies are adhering to labor laws, safety standards, and data privacy regulations.

## Audit - Transparency Measures

- Publish a quarterly progress dashboard on the NITI Aayog website, showing key metrics such as the number of companies participating in the pilots, productivity gains, and equity outcomes.
- Publish minutes of key PMO meetings on the NITI Aayog website, redacting any confidential or commercially sensitive information.
- Establish a publicly accessible register of all vendors and consultants providing services to the program, including their contact information and the nature of their services.
- Make the program's policies and procedures, including the cohort selection rubric and the M&E handbook, publicly available on the NITI Aayog website.
- Implement a system for responding to public inquiries about the program, providing timely and accurate information about its activities and outcomes.