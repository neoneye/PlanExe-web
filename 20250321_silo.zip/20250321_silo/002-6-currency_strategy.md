This plan involves money.

## Currencies

- **USD:** Primary funding and likely budgeting currency, especially given the scale and international investment.
- **RUB:** Potential costs associated with construction and resource procurement if Siberia is chosen as a location.
- **CHF:** Potential costs associated with construction and resource procurement if the Swiss Alps are chosen as a location.

**Primary currency:** USD

**Currency strategy:** Due to the international scope and significant investment, USD will be used for budgeting and reporting. Hedging strategies should be considered to mitigate exchange rate fluctuations with RUB and CHF if construction occurs in Russia or Switzerland, respectively. For local transactions in Russia or Switzerland, RUB or CHF may be used, but all major financial planning will be conducted in USD.