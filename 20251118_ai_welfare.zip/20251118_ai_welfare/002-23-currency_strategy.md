This plan involves money.

## Currencies

- **CHF:** The project is anchored in Geneva, Switzerland, where CHF is the local currency.
- **USD:** For international funding and potential use in contracts with international partners.
- **EUR:** For transactions within Europe and potential funding from European entities.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting due to the international nature of the project and funding sources. CHF will be used for local transactions in Switzerland. Hedging strategies may be considered to mitigate exchange rate fluctuations.