# Roles

## 1. AI Ethics Researcher

**Contract Type**: `full_time_employee`

**Contract Type Justification**: AI Ethics Researchers are crucial for the core research mandate and require dedicated, long-term commitment.

**Explanation**:
Crucial for foundational research on AI sentience metrics and ethical implications, ensuring the Commission's work is grounded in sound ethical principles.

**Consequences**:
Inadequate ethical framework, potential for biased or harmful standards, reduced credibility with the ethical AI community.

**People Count**:
min 2, max 4, depending on the scope of research projects and the need for diverse expertise (e.g., philosophy, cognitive science).

**Typical Activities**:
Conducting foundational research on AI sentience metrics, developing ethical frameworks for AI welfare standards, advising on ethical implications of AI development, publishing research findings, and participating in expert panels.

**Background Story**:
Dr. Anya Sharma, originally from Mumbai, India, is a leading AI ethicist with a PhD in Philosophy from Oxford University. Her doctoral research focused on the moral status of artificial intelligence, giving her a deep understanding of the philosophical underpinnings of AI sentience and welfare. Anya has worked with several international organizations, advising on ethical frameworks for AI development and deployment. Her expertise in both Western and Eastern philosophical traditions makes her uniquely suited to navigate the complex ethical landscape of AI.

**Equipment Needs**:
High-performance computer, access to relevant AI models and datasets, specialized software for ethical analysis and simulation.

**Facility Needs**:
Office space, access to research libraries, collaboration spaces for interdisciplinary discussions.

## 2. Standards Development Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Standards Development Specialists require a deep understanding of the ISO framework and a sustained effort to develop effective standards.

**Explanation**:
Essential for navigating the ISO framework, developing practical and enforceable AI welfare standards, and ensuring alignment with international norms.

**Consequences**:
Ineffective standards, difficulty integrating with the ISO framework, reduced adoption by industry and governments.

**People Count**:
2

**Typical Activities**:
Navigating the ISO framework, developing practical and enforceable AI welfare standards, ensuring alignment with international norms, coordinating with ISO committees, and managing the standards development process.

**Background Story**:
Jean-Pierre Dubois, a Swiss native from Lausanne, has spent over 20 years working with the International Organization for Standardization (ISO). He holds a Master's degree in International Law from the University of Geneva and has extensive experience in developing and implementing international standards across various industries. Jean-Pierre's deep understanding of the ISO framework, coupled with his strong negotiation skills, makes him the ideal person to navigate the complexities of integrating the AI Sentience & Welfare Commission within the ISO ecosystem.

**Equipment Needs**:
Standard office equipment, access to ISO standards documentation, communication tools for international collaboration.

**Facility Needs**:
Office space, access to ISO meeting facilities (virtual and physical), collaboration spaces.

## 3. Adversarial Robustness Engineer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Adversarial Robustness Engineers are essential for ensuring the reliability of AI sentience metrics, requiring dedicated, ongoing effort.

**Explanation**:
Critical for testing and validating AI sentience metrics, identifying vulnerabilities, and ensuring the robustness of proposed standards against gaming or manipulation.

**Consequences**:
Development of flawed or easily gamed metrics, reduced confidence in the standards, potential for unintended consequences.

**People Count**:
min 2, max 3, to cover a range of adversarial techniques and AI model types.

**Typical Activities**:
Testing and validating AI sentience metrics, identifying vulnerabilities, ensuring the robustness of proposed standards against gaming or manipulation, developing adversarial attack strategies, and collaborating with AI researchers to improve metric reliability.

**Background Story**:
Kenji Tanaka, born and raised in Tokyo, Japan, is a renowned cybersecurity expert and adversarial machine learning specialist. He holds a PhD in Computer Science from MIT and has worked for both government agencies and private sector companies, focusing on identifying and mitigating vulnerabilities in AI systems. Kenji's expertise in adversarial techniques and his deep understanding of AI model architectures make him uniquely qualified to test and validate AI sentience metrics.

**Equipment Needs**:
High-performance computer, access to diverse AI models, specialized software for adversarial attacks and vulnerability analysis, cloud computing resources.

**Facility Needs**:
Secure lab environment, access to high-bandwidth internet, collaboration spaces for red teaming exercises.

## 4. International Relations Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: International Relations Liaisons require a sustained effort to foster international cooperation and navigate geopolitical complexities.

**Explanation**:
Necessary for fostering international cooperation, engaging with diverse stakeholders, and navigating geopolitical complexities to ensure global relevance and adoption of AI welfare standards.

**Consequences**:
Limited international buy-in, potential for conflicting standards, reduced global impact of the Commission's work.

**People Count**:
min 1, max 2, depending on the breadth of international engagement and the need for regional expertise.

**Typical Activities**:
Fostering international cooperation, engaging with diverse stakeholders, navigating geopolitical complexities, developing tailored engagement strategies for different regions, and promoting the adoption of AI welfare standards globally.

**Background Story**:
Isabella Rossi, an Italian diplomat from Rome, has spent her career fostering international cooperation on various global issues. She holds a Master's degree in International Relations from Johns Hopkins University and has worked with the United Nations and the European Union on projects related to human rights and sustainable development. Isabella's extensive network of international contacts and her deep understanding of geopolitical dynamics make her the ideal person to foster international cooperation on AI welfare standards.

**Equipment Needs**:
Standard office equipment, communication tools for international outreach, travel budget for attending international conferences and meetings.

**Facility Needs**:
Office space, access to conference rooms, facilities for hosting international delegations.

## 5. Legal Counsel (Swiss Law)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Legal Counsel (Swiss Law) is needed for specific legal tasks and compliance, making an independent contractor suitable.

**Explanation**:
Vital for establishing a legal entity in Switzerland, ensuring compliance with Swiss laws and regulations, and navigating legal risks associated with AI welfare standards.

**Consequences**:
Legal challenges, non-compliance with Swiss laws, potential for fines or penalties, reputational damage.

**People Count**:
1

**Typical Activities**:
Establishing a legal entity in Switzerland, ensuring compliance with Swiss laws and regulations, advising on legal risks associated with AI welfare standards, drafting legal documents, and representing the Commission in legal matters.

**Background Story**:
Franz Weber, a seasoned Swiss lawyer from Zurich, specializes in non-profit law and regulatory compliance. He holds a law degree from the University of Zurich and has over 15 years of experience advising non-profit organizations on legal matters in Switzerland. Franz's deep understanding of Swiss laws and regulations makes him the ideal person to establish a legal entity for the AI Sentience & Welfare Commission in Switzerland and ensure compliance with all relevant legal requirements.

**Equipment Needs**:
Standard office equipment, access to legal databases and resources, secure communication channels for confidential client information.

**Facility Needs**:
Private office space, access to legal research libraries, conference rooms for client meetings.

## 6. Project Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Project Managers are essential for coordinating research efforts and managing timelines, requiring dedicated, ongoing commitment.

**Explanation**:
Essential for coordinating research efforts, managing timelines and budgets, and ensuring the efficient execution of the Commission's work.

**Consequences**:
Delays, budget overruns, lack of coordination, reduced efficiency, failure to meet project goals.

**People Count**:
min 1, max 2, depending on the number of active projects and the complexity of the research program.

**Typical Activities**:
Coordinating research efforts, managing timelines and budgets, ensuring the efficient execution of the Commission's work, developing project plans, tracking progress, and reporting on key milestones.

**Background Story**:
Mei Ling, a Chinese-American project manager from San Francisco, has a proven track record of successfully managing complex research projects in the tech industry. She holds an MBA from Stanford University and has extensive experience in coordinating cross-functional teams and managing budgets. Mei's organizational skills and her ability to keep projects on track make her the ideal person to manage the AI Sentience & Welfare Commission's research efforts.

**Equipment Needs**:
Standard office equipment, project management software, communication tools for team coordination.

**Facility Needs**:
Office space, access to project management dashboards, meeting rooms for team meetings.

## 7. Communications & Public Engagement Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Communications & Public Engagement Specialists require a sustained effort to build trust and support for the Commission's work.

**Explanation**:
Crucial for developing a communication strategy, engaging with the public and media, and addressing concerns about AI sentience and welfare to build trust and support for the Commission's work.

**Consequences**:
Misinformation, public distrust, political opposition, reduced funding, difficulty attracting talent.

**People Count**:
min 1, max 2, to handle media relations, public outreach, and stakeholder engagement.

**Typical Activities**:
Developing a communication strategy, engaging with the public and media, addressing concerns about AI sentience and welfare, building trust and support for the Commission's work, managing media relations, and creating public outreach materials.

**Background Story**:
David O'Connell, an Irish journalist from Dublin, has spent his career communicating complex scientific and ethical issues to the public. He holds a Master's degree in Journalism from Columbia University and has worked for several major news organizations, covering topics ranging from climate change to biotechnology. David's communication skills and his ability to translate complex information into accessible language make him the ideal person to develop a communication strategy for the AI Sentience & Welfare Commission.

**Equipment Needs**:
Standard office equipment, media monitoring tools, social media management software, graphic design software.

**Facility Needs**:
Office space, access to media databases, presentation facilities, collaboration spaces for content creation.

## 8. AI Welfare Auditing Tool Developer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: AI Welfare Auditing Tool Developers are needed to build tangible value-add tools, requiring dedicated, ongoing effort.

**Explanation**:
Needed to build tangible value-add tools (e.g., an AI Welfare Auditing Tool, a Sentience Risk Assessment API, and a “Certified Humane Frontier Model” seal) to give labs, cloud providers, insurers, and regulators clear reasons to adopt ISO-style standards.

**Consequences**:
Lack of practical tools for assessing AI welfare, reduced adoption of standards, limited impact on AI development practices.

**People Count**:
min 2, max 4, depending on the number of tools to be developed and the complexity of the AI systems being audited.

**Typical Activities**:
Building tangible value-add tools (e.g., an AI Welfare Auditing Tool, a Sentience Risk Assessment API, and a “Certified Humane Frontier Model” seal), developing software code, testing and debugging software, and collaborating with AI researchers to improve tool functionality.

**Background Story**:
Rajesh Patel, an Indian software engineer from Bangalore, has extensive experience in developing AI auditing tools and risk assessment APIs. He holds a Master's degree in Computer Science from Carnegie Mellon University and has worked for several leading AI companies, focusing on developing tools for monitoring and evaluating AI systems. Rajesh's technical skills and his deep understanding of AI model architectures make him uniquely qualified to develop AI welfare auditing tools for the Commission.

**Equipment Needs**:
High-performance computer, access to relevant AI models and datasets, software development tools, cloud computing resources for testing and deployment.

**Facility Needs**:
Software development lab, access to testing environments, collaboration spaces for team development.

---

# Omissions

## 1. Expertise in Animal Welfare/Sentience

The team composition lacks explicit expertise in animal welfare or animal sentience. While AI sentience is the focus, insights from the established field of animal welfare could inform the development of metrics and standards, particularly regarding the identification and mitigation of suffering.

**Recommendation**:
Consult with or recruit an expert in animal welfare or animal sentience to provide guidance on identifying and measuring indicators of suffering, and to ensure that the AI welfare standards are informed by established principles in the field.

## 2. Dedicated Fundraising/Development Role

The plan relies heavily on philanthropic funding, but there isn't a dedicated role focused on fundraising and donor relations. This increases the risk of funding shortfalls.

**Recommendation**:
Assign a team member (perhaps the Communications & Public Engagement Specialist initially) to dedicate a portion of their time to fundraising activities, including donor research, proposal writing, and relationship management. As the organization grows, consider hiring a dedicated fundraising professional.

## 3. User Experience (UX) Researcher/Designer

The plan mentions developing tools like an AI Welfare Auditing Tool and a Sentience Risk Assessment API. Without a UX focus, these tools may be difficult to use, hindering adoption.

**Recommendation**:
Integrate UX research and design into the Product & Adoption Team. This could involve contracting a UX specialist to conduct user research and design user-friendly interfaces for the developed tools. Focus on making the tools accessible and intuitive for the target users (labs, cloud providers, insurers, regulators).

---

# Potential Improvements

## 1. Clarify Responsibilities of AI Ethics Researcher

The description of the AI Ethics Researcher role is broad. Clarifying their specific responsibilities will prevent overlap and ensure all ethical considerations are addressed.

**Recommendation**:
Delineate specific areas of focus for each AI Ethics Researcher (if multiple are hired), such as: (1) foundational research on sentience metrics, (2) development of ethical frameworks, and (3) advising on specific AI development projects. This will ensure comprehensive coverage and prevent duplication of effort.

## 2. Formalize Collaboration between Adversarial Robustness Engineer and AI Ethics Researcher

The plan mentions an Adversarial Robustness Program, but doesn't explicitly link it to ethical considerations. Robustness testing should consider ethical implications.

**Recommendation**:
Establish a formal process for collaboration between the Adversarial Robustness Engineer and the AI Ethics Researcher. This could involve regular meetings to discuss potential vulnerabilities and ethical implications of proposed metrics, ensuring that robustness testing is informed by ethical considerations.

## 3. Define Success Metrics for International Relations Liaison

The description of the International Relations Liaison role lacks specific success metrics. Defining these metrics will help measure the effectiveness of their efforts.

**Recommendation**:
Establish clear success metrics for the International Relations Liaison, such as: (1) number of participating countries, (2) adoption rate of standards in different regions, and (3) level of engagement from diverse stakeholders. This will provide a framework for evaluating their performance and ensuring they are contributing to the Commission's goals.