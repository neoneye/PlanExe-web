### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, ensuring alignment with the overall project goals and objectives.  Essential for managing the complex interplay of research, standards development, and international collaboration.

**Responsibilities:**

- Approve the project's strategic direction and overall plan.
- Monitor progress against key milestones and performance indicators.
- Approve significant budget allocations and reallocations (above $1M).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve major changes to project scope or timeline.
- Ensure alignment with ISO standards and requirements.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review and approve the initial project plan.
- Define risk appetite and tolerance levels.

**Membership:**

- CEO of the AI Sentience & Welfare Commission (Chair)
- Representative from a major philanthropic funder
- Representative from a participating government
- Representative from a frontier AI lab
- Independent AI Ethics Expert
- ISO Representative (non-voting)

**Decision Rights:** Strategic decisions related to project scope, budget (above $1M), timeline, and risk management.  Approval of major deliverables and milestones.

**Decision Mechanism:** Decisions are made by majority vote, with the CEO having the tie-breaking vote.  Significant decisions require unanimous agreement from funder representatives.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of budget allocations and reallocations.
- Review of stakeholder engagement activities.
- Strategic updates from the Project Management Office.
- Review of compliance reports.

**Escalation Path:** Board of Directors of the AI Sentience & Welfare Commission
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient resource allocation, risk management, and communication.  Critical for coordinating the various research programs and standards development activities.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and resources (below $1M approval threshold).
- Track project progress and report on key performance indicators.
- Identify and manage project risks and issues.
- Coordinate communication among project stakeholders.
- Support the Project Steering Committee.
- Ensure compliance with project governance policies and procedures.

**Initial Setup Actions:**

- Establish project management methodology and tools.
- Develop project communication plan.
- Define roles and responsibilities for project team members.
- Set up project tracking and reporting systems.
- Establish risk management framework.

**Membership:**

- Project Manager (Head of PMO)
- Lead AI Researcher
- Lead Standards Development Specialist
- Finance Officer
- Communications Officer
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $1M), and risk management within defined thresholds.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the PMO team.  Disagreements are escalated to the CEO.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current risks and issues.
- Approval of resource requests.
- Review of communication activities.
- Updates from research and standards development teams.
- Budget tracking and reporting.

**Escalation Path:** CEO of the AI Sentience & Welfare Commission
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on AI sentience metrics, risk assessment tools, and other technical aspects of the project.  Ensures the scientific rigor and validity of the project's outputs.

**Responsibilities:**

- Review and provide feedback on research proposals and findings.
- Advise on the development of AI sentience metrics and risk assessment tools.
- Evaluate the technical feasibility and validity of proposed standards.
- Identify emerging technical risks and challenges.
- Provide guidance on the Adversarial Robustness Program.
- Ensure alignment with the latest scientific advancements in AI and related fields.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Identify and recruit leading AI researchers and experts.
- Establish meeting schedule and communication protocols.
- Develop a framework for evaluating technical proposals.
- Define criteria for assessing the validity of AI sentience metrics.

**Membership:**

- Leading AI Researcher (Chair)
- Cognitive Scientist
- Philosopher specializing in AI ethics
- AI Safety Engineer
- Independent AI Expert (external)
- Representative from the Adversarial Robustness Program

**Decision Rights:** Provides recommendations on technical matters related to AI sentience metrics, risk assessment tools, and standards development.  Does not have decision-making authority but its advice is highly influential.

**Decision Mechanism:** Decisions are made by consensus, with the Chair facilitating discussion and resolving disagreements.  Dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research proposals and findings.
- Discussion of AI sentience metrics and risk assessment tools.
- Evaluation of proposed standards.
- Identification of emerging technical risks.
- Updates from the Adversarial Robustness Program.
- Review of relevant scientific literature.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, Swiss non-profit laws, and ISO governance standards.  Crucial for maintaining public trust and avoiding legal liabilities.

**Responsibilities:**

- Develop and maintain a code of ethics for the project.
- Ensure compliance with GDPR and other data privacy regulations.
- Monitor compliance with Swiss non-profit laws and ISO governance standards.
- Review and approve research proposals from an ethical perspective.
- Investigate and resolve ethical complaints and violations.
- Provide training on ethical issues to project team members.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of ethics.
- Establish compliance policies and procedures.
- Set up a system for reporting and investigating ethical complaints.
- Develop a training program on ethical issues.
- Define data privacy protocols.

**Membership:**

- Legal Counsel (Chair)
- Ethicist
- Data Protection Officer
- Representative from the ISO
- Independent Legal Expert (external)
- Representative from the Communications Team

**Decision Rights:** Authority to investigate ethical complaints, recommend corrective actions, and ensure compliance with relevant regulations.  Can halt research activities if ethical concerns are not adequately addressed.

**Decision Mechanism:** Decisions are made by majority vote, with the Legal Counsel having the tie-breaking vote.  Significant ethical concerns require unanimous agreement.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of ethical complaints and violations.
- Discussion of compliance issues.
- Approval of research proposals from an ethical perspective.
- Updates on data privacy regulations.
- Review of the code of ethics.
- Training on ethical issues.

**Escalation Path:** Board of Directors of the AI Sentience & Welfare Commission
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including AI researchers, ethicists, legal experts, policymakers, the general public, and AI developers.  Ensures transparency, builds trust, and fosters collaboration.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Organize workshops, conferences, and online forums.
- Conduct public consultations.
- Develop and disseminate communication materials.
- Manage media relations.
- Monitor public perception of the project.
- Address stakeholder concerns and feedback.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Set up a system for tracking stakeholder feedback.
- Define key messages.

**Membership:**

- Communications Officer (Chair)
- Public Relations Specialist
- Representative from the Research Team
- Representative from the Standards Development Team
- Representative from a participating government
- Representative from a major philanthropic funder

**Decision Rights:** Decisions related to stakeholder engagement activities, communication strategies, and public relations.  Approval of communication materials and public statements.

**Decision Mechanism:** Decisions are made by the Communications Officer, in consultation with the Stakeholder Engagement Group.  Controversial issues are escalated to the CEO.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of communication strategies.
- Approval of communication materials.
- Updates on media relations.
- Monitoring of public perception.
- Review of stakeholder feedback.

**Escalation Path:** CEO of the AI Sentience & Welfare Commission