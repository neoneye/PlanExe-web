Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on ethical and regulatory aspects of AI, not on altering the laws of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (AI welfare standards) + market (AI industry) + tech/process (ISO framework) + policy (international regulations) without independent evidence at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: Q4 2025


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "responsible AI development", "innovation", and "sustainable" without defining their meaning or how they will be measured. The plan lacks a business-level mechanism-of-action for these strategic concepts.

**Mitigation**: Project Manager: Create one-pagers for each strategic concept, defining the mechanism-of-action, value hypotheses, success metrics, and decision hooks, by Q2 2025.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies diverse risks (financial, technical, social, etc.) and includes mitigation plans. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Funding challenges" are listed, but the cascade to talent loss or delayed research isn't mapped.

**Mitigation**: Project Manager: Expand the risk register to map potential risk cascades and second-order effects, adding controls and a dated review cadence, by Q3 2025.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Permits for operating a non-profit organization in the Geneva metro area," but lacks details on lead times or dependencies.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds, by Q1 2025.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "Funding of approximately $300M per year" but lacks detail on committed sources, draw schedule, and covenants. The plan assumes $300M annual budget from philanthropic grants (50%), government (30%), AI labs (20%) but lacks term sheets.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources and their status (e.g., LOI/term sheet/closed), draw schedule, covenants, and a NO-GO on missed financing gates, by Q1 2025.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states an annual budget of $300M but lacks benchmarks or vendor quotes to substantiate this figure. There is no per-area cost normalization for the Geneva office space. The plan omits contingency.

**Mitigation**: CFO: Obtain ≥3 benchmarks for similar organizations, normalize costs per area, obtain vendor quotes, add 10-20% contingency, and adjust budget or de-scope by Q2 2025.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., $300M annual budget, AI Welfare Standard v1.0 by Q4 2030) as single numbers without providing a range or discussing alternative scenarios. There is no sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the $300M annual budget and AI Welfare Standard v1.0 completion date by Q2 2025.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions "Define AI Sentience Metrics" and "Develop Risk Assessment Tools" but lacks specs, interface contracts, acceptance tests, integration plan, and non-functional requirements.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for AI sentience metrics and risk assessment tools by Q3 2025.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "Agree on functional linkage with the International Organization for Standardization (ISO)" but lacks a Letter of Intent or Memorandum of Understanding. There is no evidence of ISO buy-in.

**Mitigation**: Project Manager: Obtain a Letter of Intent or Memorandum of Understanding from the ISO by Q1 2025, or change scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "AI Welfare Standard v1.0 by Q4 2030" but lacks SMART acceptance criteria, including a KPI. The plan omits the specific, verifiable qualities of the standard.

**Mitigation**: Standards Development Specialist: Define SMART acceptance criteria for AI Welfare Standard v1.0, including a KPI for adoption rate (e.g., 50% adoption by top 100 AI labs) by Q2 2025.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a 'Certified Humane Frontier Model' seal as an adoption incentive. This feature does not appear to directly support the core project goals of defining AI sentience metrics or establishing welfare standards.

**Mitigation**: Product & Adoption Team: Produce a one-page benefit case justifying the 'Certified Humane Frontier Model' seal, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by Q2 2025.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires an "Adversarial Robustness Engineer" to test and validate AI sentience metrics. This role is both highly specialized and likely difficult to fill, given the nascent stage of AI sentience research.

**Mitigation**: HR: Validate the talent market for Adversarial Robustness Engineers, including salary expectations and availability, as an early go/no-go check by Q1 2025.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Permits for operating a non-profit organization in the Geneva metro area," but lacks details on lead times or dependencies.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds, by Q1 2025.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Long-Term Sustainability risks" and a "sustainability plan", but lacks specifics on funding mechanisms beyond the initial mandate. The plan omits a resource strategy, maintenance schedule, succession plan, technology roadmap, or adaptation mechanisms.

**Mitigation**: CFO: Develop a long-term operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms by Q3 2025.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Permits for operating a non-profit organization in the Geneva metro area," but lacks details on lead times or dependencies. The permit/approval matrix is absent.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds, by Q1 2025.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address redundancy or failover for external dependencies. The plan mentions office space in Geneva, but lacks a backup location. The plan omits SLAs with cloud providers.

**Mitigation**: IT: Secure SLAs with cloud providers, add a secondary office location, and test failover by Q4 2025.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Funding Allocation Strategy' is managed by the Commission, incentivized to allocate funds effectively. The 'Standards Enforcement Strategy' is managed by governments, incentivized to protect their citizens. These incentives may conflict.

**Mitigation**: Project Manager: Define a shared, measurable objective (OKR) for both the Commission and governments, aligning them on a common outcome, by Q2 2025.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to the project plan by Q2 2025.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Financial, Technical, Long-Term Sustainability) but lacks a cross-impact analysis. A funding shortfall (Financial risk) could trigger talent loss (Operational risk) and delay research (Technical risk), creating a multi-domain failure.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by Q3 2025.