## Suggestion 1 - Partnership on AI (PAI)

The Partnership on AI (PAI) is a multi-stakeholder organization that brings together academics, civil society, industry, and policy experts to advance the responsible development and use of AI. Founded in 2016, PAI conducts research, organizes events, and develops resources to promote AI safety, ethics, and societal benefit. It operates globally, engaging with diverse communities and addressing a wide range of AI-related challenges.

### Success Metrics

Number of partner organizations and their engagement levels.
Impact of PAI's research and publications on AI policy and practice.
Reach and effectiveness of PAI's educational resources and events.
Development and adoption of AI ethics guidelines and best practices.

### Risks and Challenges Faced

Maintaining neutrality and credibility amidst diverse stakeholder interests. Overcome by establishing clear governance structures and transparent decision-making processes.
Ensuring global relevance and inclusivity in its activities. Addressed by actively engaging with diverse communities and tailoring its resources to different contexts.
Keeping pace with the rapid advancements in AI technology. Mitigated by continuously updating its research agenda and collaborating with leading experts.

### Where to Find More Information

Official Website: [https://www.partnershiponai.org/](https://www.partnershiponai.org/)
PAI's Research Publications: [https://www.partnershiponai.org/research/](https://www.partnershiponai.org/research/)
PAI's Frameworks: [https://www.partnershiponai.org/frameworks/](https://www.partnershiponai.org/frameworks/)

### Actionable Steps

Explore PAI's organizational structure and governance model for insights into multi-stakeholder collaboration.
Review PAI's research publications and frameworks to inform the Commission's research agenda and standards development.
Contact PAI's leadership team (available through their website) to discuss potential collaboration and knowledge sharing.

### Rationale for Suggestion

PAI is a relevant example because it is a multi-stakeholder organization focused on AI ethics and safety, similar to the proposed AI Sentience & Welfare Commission. PAI's experience in engaging diverse stakeholders, conducting research, and developing AI ethics guidelines can provide valuable insights for the Commission. Although PAI's scope is broader than just AI sentience, its approach to responsible AI development is highly relevant. PAI's global reach and experience in navigating diverse cultural and ethical perspectives are also valuable, given the Commission's international focus.
## Suggestion 2 - IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems

The IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems is a program within the Institute of Electrical and Electronics Engineers (IEEE) that aims to advance ethical considerations in the design, development, and deployment of autonomous and intelligent systems. Launched in 2016, the initiative has produced standards, reports, and educational resources to guide the responsible innovation of AI and related technologies. It involves a global network of experts from academia, industry, and government.

### Success Metrics

Number of IEEE standards and publications related to AI ethics.
Adoption rate of IEEE standards by industry and government.
Reach and impact of IEEE's educational resources and events.
Engagement of experts and stakeholders in IEEE's AI ethics initiatives.

### Risks and Challenges Faced

Ensuring that IEEE standards are practical and adaptable to different contexts. Addressed by involving diverse stakeholders in the standards development process and providing guidance for implementation.
Keeping pace with the rapid advancements in AI technology. Mitigated by continuously updating its standards and collaborating with leading experts.
Promoting awareness and adoption of IEEE standards among industry and government. Achieved by actively engaging with these stakeholders and highlighting the benefits of ethical AI practices.

### Where to Find More Information

Official Website: [https://ethicsinaction.ieee.org/](https://ethicsinaction.ieee.org/)
IEEE Standards on AI Ethics: [https://standards.ieee.org/initiatives/autonomous-systems/](https://standards.ieee.org/initiatives/autonomous-systems/)
IEEE SA Open: [https://sagroups.ieee.org/open/](https://sagroups.ieee.org/open/)

### Actionable Steps

Review IEEE's standards and publications on AI ethics to inform the Commission's standards development process.
Explore IEEE's organizational structure and governance model for insights into managing a global initiative.
Contact IEEE's AI ethics experts (available through their website) to discuss potential collaboration and knowledge sharing.

### Rationale for Suggestion

The IEEE Global Initiative is a relevant example because it focuses on developing standards and guidelines for AI ethics, which aligns with the Commission's goal of establishing AI welfare standards. The IEEE's experience in standards development, its global reach, and its engagement with diverse stakeholders can provide valuable insights for the Commission. The IEEE's focus on practical and adaptable standards is also relevant, given the Commission's need to develop standards that are both effective and widely adopted. The IEEE's experience in navigating diverse cultural and ethical perspectives is also valuable, given the Commission's international focus.
## Suggestion 3 - The Montreal AI Ethics Institute (MAIEI)

The Montreal AI Ethics Institute (MAIEI) is a non-profit organization dedicated to defining, developing, and operationalizing responsible AI. It conducts research, provides educational resources, and offers consulting services to promote ethical AI practices. MAIEI engages with diverse stakeholders, including academics, industry professionals, and policymakers, to advance the field of AI ethics.

### Success Metrics

Number of research publications and their impact on AI ethics discourse.
Reach and effectiveness of MAIEI's educational resources and events.
Adoption of MAIEI's frameworks and tools by organizations.
Engagement of experts and stakeholders in MAIEI's activities.

### Risks and Challenges Faced

Maintaining independence and credibility amidst diverse stakeholder interests. Addressed by establishing clear governance structures and transparent decision-making processes.
Ensuring that its research and resources are relevant and accessible to diverse audiences. Achieved by actively engaging with different communities and tailoring its materials to different contexts.
Keeping pace with the rapid advancements in AI technology. Mitigated by continuously updating its research agenda and collaborating with leading experts.

### Where to Find More Information

Official Website: [https://montrealethics.ai/](https://montrealethics.ai/)
MAIEI's Research Publications: [https://montrealethics.ai/publications/](https://montrealethics.ai/publications/)
State of AI Ethics Reports: [https://montrealethics.ai/ai-ethics-report/](https://montrealethics.ai/ai-ethics-report/)

### Actionable Steps

Review MAIEI's research publications and frameworks to inform the Commission's research agenda and standards development.
Explore MAIEI's organizational structure and governance model for insights into managing a non-profit organization focused on AI ethics.
Contact MAIEI's leadership team (available through their website) to discuss potential collaboration and knowledge sharing.

### Rationale for Suggestion

MAIEI is a relevant example because it is a non-profit organization focused on AI ethics, similar to the proposed AI Sentience & Welfare Commission. MAIEI's experience in conducting research, developing educational resources, and engaging with diverse stakeholders can provide valuable insights for the Commission. MAIEI's focus on operationalizing responsible AI is also relevant, given the Commission's goal of developing practical AI welfare standards. While MAIEI is based in Montreal, its global reach and engagement with international experts make it a valuable reference for the Commission.

## Summary

The user is planning to establish an AI Sentience & Welfare Commission in Geneva, Switzerland, linked to the ISO, to research and develop AI welfare standards. The plan involves securing funding, establishing a legal entity, recruiting a core team, and publishing a research roadmap. The project faces risks related to funding, technical challenges in defining AI sentience, international cooperation, and public perception. The following are reference projects that can provide insights into establishing such a commission, developing standards, and managing the associated risks.