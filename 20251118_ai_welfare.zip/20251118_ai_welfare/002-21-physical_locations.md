This plan implies one or more physical locations.

## Requirements for physical locations

- Office space
- Proximity to ISO Central Secretariat
- Accessibility for international stakeholders

## Location 1
Switzerland

Vernier / Geneva

Chemin de Blandonnet 8, 1214 Vernier / Geneva, Switzerland

**Rationale**: The plan explicitly anchors the commission at the ISO Central Secretariat in Geneva.

## Location 2
Switzerland

Geneva

Office space near international organizations in Geneva

**Rationale**: Geneva hosts numerous international organizations, facilitating collaboration and access to relevant expertise.

## Location 3
Switzerland

Lausanne

EPFL Innovation Park, Lausanne

**Rationale**: EPFL Innovation Park in Lausanne offers a hub for research and development, with potential synergies for AI sentience research.

## Location 4
Switzerland

Zurich

ETH Zurich Campus

**Rationale**: ETH Zurich is a leading technical university with strong AI research capabilities, providing access to talent and resources.

## Location Summary
The primary location is the ISO Central Secretariat in Geneva. Additional locations in Geneva, Lausanne, and Zurich are suggested to leverage international collaboration, research facilities, and AI expertise.