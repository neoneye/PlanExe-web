# Purpose
# AI Sentience and Welfare Commission

- Establish an international commission.
- Research and develop standards for AI sentience and welfare.
- Mitigate potential suffering in advanced AI systems.
- Provide regulatory clarity for AI development.

## Goals

- Define metrics for AI sentience.
- Establish welfare standards for sentient AI.
- Develop ethical guidelines for AI development.
- Propose international regulations.

## Scope

- Focus on advanced AI systems.
- Address potential suffering in AI.
- Cover ethical and regulatory aspects.

## Assumptions

- AI sentience is possible.
- International cooperation is achievable.
- Early standards development is beneficial.

## Risks

- Lack of international agreement.
- Difficulty in defining sentience.
- Resistance from AI developers.

## Recommendations

- Secure funding for the commission.
- Engage experts in AI ethics and law.
- Foster international collaboration.
- Prioritize research on sentience metrics.


# Plan Type
This plan requires physical locations.

Explanation:

- Requires physical location (Chemin de Blandonnet 8, 1214 Vernier / Geneva, Switzerland) for the AI Sentience & Welfare Commission.
- Involves funding, staffing, and physical meetings.
- Requires physical development and testing of AI systems.


# Physical Locations
# Physical Locations

## Requirements

- Office space
- Proximity to ISO Central Secretariat
- Accessibility for international stakeholders

## Location 1
Switzerland, Vernier / Geneva, Chemin de Blandonnet 8, 1214 Vernier / Geneva
Rationale: Anchored at ISO Central Secretariat.

## Location 2
Switzerland, Geneva, Office space near international organizations
Rationale: Facilitates collaboration and access to expertise.

## Location 3
Switzerland, Lausanne, EPFL Innovation Park
Rationale: Hub for research and development, synergies for AI research.

## Location 4
Switzerland, Zurich, ETH Zurich Campus
Rationale: Access to talent and resources in AI research.

## Location Summary
Primary location: ISO Central Secretariat in Geneva. Additional locations: Geneva, Lausanne, and Zurich to leverage collaboration, research, and AI expertise.

# Currency Strategy
## Currencies

- CHF: Local currency in Geneva, Switzerland.
- USD: For international funding and contracts.
- EUR: For European transactions and funding.

Primary currency: USD

Currency strategy: Use USD for budgeting and reporting. Use CHF for local transactions. Consider hedging.

# Identify Risks
# Risk 1 - Financial

- Funding challenges: philanthropic volatility, government changes, lab hesitancy.
- Impact: Reduced capacity, delayed research, talent loss, 20-50% budget shortfall.
- Likelihood: Medium
- Severity: High
- Action: Diversify funding, value proposition, reserve fund, tiered membership.

# Risk 2 - Regulatory & Permitting

- Legal entity establishment in Switzerland and ISO agreements may face delays.
- Impact: 3-6 month delay, 50-100k CHF extra cost, restructuring.
- Likelihood: Medium
- Severity: Medium
- Action: Legal counsel, engage agencies/ISO, contingency plans.

# Risk 3 - Technical

- Developing AI sentience metrics and risk tools is complex.
- Impact: Failure to develop standards, loss of confidence, 12-18 month delay.
- Likelihood: High
- Severity: High
- Action: Recruit experts, collaboration, invest in Adversarial Robustness, iterative approach.

# Risk 4 - Social

- Public perception is sensitive and subject to misinformation.
- Impact: Reduced trust, political opposition, talent difficulty, 10-20% funding reduction.
- Likelihood: Medium
- Severity: Medium
- Action: Communication strategy, engage media, address concerns.

# Risk 5 - Operational

- Attracting and retaining talent may be difficult.
- Impact: Difficulty achieving goals, reduced productivity, turnover, 6-12 month delay.
- Likelihood: Medium
- Severity: Medium
- Action: Talent strategy, competitive compensation, positive environment, partner with institutions.

# Risk 6 - Supply Chain

- Access to computing resources and AI models may be limited.
- Impact: Research delays, increased costs, 3-6 month delay.
- Likelihood: Low
- Severity: Medium
- Action: Relationships with providers, contingency plans, in-house infrastructure.

# Risk 7 - Security

- Research data and AI models vulnerable to cyberattacks.
- Impact: Data loss, reputational damage, compromise of AI, 3-6 month delay.
- Likelihood: Medium
- Severity: High
- Action: Cybersecurity measures, audits, staff training.

# Risk 8 - Integration with Existing Infrastructure

- Integrating with ISO and other standards bodies may be challenging.
- Impact: Slower adoption, reduced impact, duplication, 6-12 month delay.
- Likelihood: Medium
- Severity: Medium
- Action: Communication channels, participate in committees, glossary.

# Risk 9 - Market/Competitive

- Competing AI welfare standards may emerge.
- Impact: Reduced funding, loss of share, inability to achieve goals, 10-20% reduction.
- Likelihood: Medium
- Severity: Medium
- Action: Value proposition, build relationships, monitor landscape.

# Risk 10 - Long-Term Sustainability

- Maintaining funding beyond initial mandate may be difficult.
- Impact: Reduced funding, loss of momentum, closure.
- Likelihood: Medium
- Severity: High
- Action: Sustainability plan, diversify funding, demonstrate value, build reputation.

# Risk summary

- Critical risks: funding, AI metrics, regulatory landscape.
- Mitigation: diversify funding, invest in research, engage bodies/public.
- Trade-off: speed vs rigor.
- Overlapping strategies: communication and engagement.


# Make Assumptions
# Question 1 - Funding Mechanisms and Contingency Plans

- Assumption: $300M annual budget from philanthropic grants (50%), government (30%), AI labs (20%).
- Assessment: Financial Sustainability

 - Details: Philanthropic volatility, government political shifts, lab hesitancy.
 - Mitigation: Diversify funding, reserve fund, tiered membership.
 - Metric: Track funding percentages quarterly.

# Question 2 - Key Milestones and Deliverables (2025-2030)

- Assumption: Legal entity (Q1 2026), funding (Q2 2026), Research Roadmap (Q4 2026), Sentience Metrics (Q4 2028), AI Welfare Standard (Q4 2030).
- Assessment: Timeline Adherence

 - Details: Delays impact timeline.
 - Mitigation: Project management system, weekly tracking, quarterly reports.
 - Metric: Monitor milestone completion rate.

# Question 3 - Core Team Roles and Expertise

- Assumption: AI researchers, ethicists, legal experts, project managers, communication specialists.
- Assessment: Resource Acquisition

 - Details: Difficulty attracting talent hinders progress.
 - Mitigation: Talent management strategy, competitive compensation, positive environment, partnerships.
 - Metric: Track employee satisfaction and turnover.

# Question 4 - Legal and Regulatory Requirements (Switzerland/ISO)

- Assumption: Swiss non-profit, data privacy, labor laws; ISO governance, transparency.
- Assessment: Regulatory Compliance

 - Details: Non-compliance leads to fines, legal issues, reputational damage.
 - Mitigation: Legal counsel, government engagement, contingency plans.
 - Metric: Track compliance issues identified/resolved.

# Question 5 - Safety Protocols and Risk Mitigation

- Assumption: Safety protocols prevent unintended consequences.
- Assessment: Safety and Risk Management

 - Details: Inadequate protocols lead to accidents, breaches, damage.
 - Mitigation: Cybersecurity, audits, training, ethical guidelines.
 - Metric: Track security incidents and violations.

# Question 6 - Environmental Impact

- Assumption: Minimize impact via sustainable practices.
- Assessment: Environmental Impact

 - Details: Failure damages reputation.
 - Mitigation: Environmental audit, energy-efficient tech, sustainable transport.
 - Metric: Track energy, emissions, waste.

# Question 7 - Stakeholder Engagement

- Assumption: Engage stakeholders for AI welfare standards.
- Assessment: Stakeholder Engagement

 - Details: Failure leads to lack of buy-in.
 - Mitigation: Engagement plan, consultations, transparent communication.
 - Metric: Track stakeholder engagement, participation, feedback.

# Question 8 - Operational Systems and Technologies

- Assumption: Cloud platforms, project management software, communication tools.
- Assessment: Operational Efficiency

 - Details: Inefficient systems hinder progress.
 - Mitigation: IT infrastructure, software training, communication protocols.
 - Metric: Track system uptime, response time, user satisfaction.

# Distill Assumptions
# Project Plan

- Annual budget: $300M (Philanthropy 50%, Government 30%, AI Labs 20%)
- Legal entity in Switzerland by Q1 2026
- AI Welfare Standard v1.0 by Q4 2030

## Team

- AI researchers, ethicists, legal experts, project managers, communication specialists.

## Compliance

- Swiss laws on non-profits, data privacy, labor
- ISO governance standards

## Safety

- Prevent data breaches, misuse of AI, harm.

## Sustainability

- Minimize environmental impact
- Renewable energy, waste reduction, energy efficiency

## Stakeholder Engagement

- Workshops, conferences, online forums, public consultations

## Tools

- Cloud platforms, project management software, communication tools


# Review Assumptions
# Domain of the expert reviewer
Project Management and Risk Assessment

## Domain-specific considerations

- Financial viability and funding diversification
- Regulatory compliance and legal risks
- Technical feasibility and innovation risks
- Stakeholder engagement and public perception
- Operational efficiency and talent management
- Environmental sustainability
- Security and data protection

## Issue 1 - Over-Reliance on Philanthropic Funding
Assumption: 50% of $300M annual budget from philanthropy is a risk.

- Philanthropic funding is volatile.
- Plan lacks strategy for donor relationships and funding diversification.

Recommendation:

- Develop fundraising strategy: donor pipeline, relationship management, diversification targets.
- Explore impact investing, corporate sponsorships, revenue-generating activities.
- Establish reserve fund (1 year operating expenses).
- Model funding scenarios (best, worst, most likely).

Sensitivity:

- 20% reduction in philanthropic funding could delay AI Welfare Standard v1.0 by 6-9 months or reduce research scope by 15-20%.
- Complete loss of funding requires restructuring.

## Issue 2 - Lack of Specificity in AI Sentience Metrics Development
Assumption: Robust AI sentience metrics can be developed within timeframe.

- Field is nascent, no guarantee of success.
- Plan lacks details on research methodology, data, validation.
- No concrete milestones for Adversarial Robustness Program.
- Plan doesn't address expert disagreement on AI sentience.

Recommendation:

- Develop research roadmap: milestones, deliverables, validation.
- Establish expert advisory panel.
- Invest in Adversarial Robustness Program.
- Conduct peer reviews, publish findings.
- Establish criteria for resolving disagreements.

Sensitivity:

- 6-month delay in metrics could delay AI Welfare Standard v1.0 by 9-12 months or reduce adoption by 20-30%.
- Unreliable metrics could reduce ROI by 30-50%.

## Issue 3 - Insufficient Consideration of Geopolitical and Cultural Factors
Plan acknowledges global engagement but lacks strategy for geopolitical tensions and cultural differences.

- Balanced regional engagement is optimistic.
- Rivalries, ethics, tech development create barriers.
- Plan doesn't address countries rejecting standards.

Recommendation:

- Conduct geopolitical/cultural risk assessment.
- Develop tailored engagement strategies.
- Partner with local organizations.
- Develop adaptable standard process.
- Monitor global trends.

Sensitivity:

- If key countries reject standards, adoption could be reduced by 40-60%.
- Failure to address cultural differences could lead to ethical issues and reduce public trust by 20-30%.

## Review conclusion
Plan is ambitious but needs to address:

- Over-reliance on philanthropic funding.
- Lack of specificity in AI sentience metrics.
- Insufficient consideration of geopolitical/cultural factors.
