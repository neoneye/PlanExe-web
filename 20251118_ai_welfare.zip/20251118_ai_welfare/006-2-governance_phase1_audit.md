
## Audit - Corruption Risks

- Bribery of ISO officials to expedite or influence the standards development process.
- Kickbacks from AI labs or cloud providers in exchange for favorable treatment in the 'Certified Humane Frontier Model' seal program.
- Conflicts of interest arising from Commission members having financial ties to AI companies that could benefit from lax welfare standards.
- Misuse of confidential information regarding AI sentience metrics to provide an unfair advantage to specific AI labs.
- Nepotism or favoritism in the awarding of research grants or contracts to individuals or organizations with personal connections to Commission members.

## Audit - Misallocation Risks

- Inflated consulting fees paid to firms with ties to Commission members.
- Duplication of research efforts due to poor coordination between the Sentience Metrics & Theory Program and the Adversarial Robustness Program.
- Inefficient allocation of funds to marketing and promotion of the 'Certified Humane Frontier Model' seal at the expense of core research activities.
- Unauthorized use of Commission funds for personal travel or entertainment expenses.
- Misreporting of progress on AI sentience metrics development to justify continued funding.

## Audit - Procedures

- Annual independent financial audits conducted by a reputable accounting firm to ensure proper use of funds.
- Periodic internal reviews of grant allocation processes to ensure fairness and transparency.
- Regular compliance checks to ensure adherence to Swiss non-profit laws, data privacy regulations, and ISO governance standards.
- Post-project reviews of the 'Certified Humane Frontier Model' seal program to assess its effectiveness and identify potential conflicts of interest.
- Expense report audits with a threshold of CHF 5000, reviewed and approved by the CFO and CEO.

## Audit - Transparency Measures

- Publicly accessible dashboard displaying the Commission's budget, funding sources, and research progress.
- Publication of minutes from key meetings of the Commission's governing body, including discussions on funding allocation and standard development.
- Establishment of a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations.
- Public access to the Commission's policies and procedures, including those related to grant awarding, contract procurement, and conflict of interest management.
- Documented selection criteria and justification for all major decisions, including the selection of research projects, vendors, and Commission members.