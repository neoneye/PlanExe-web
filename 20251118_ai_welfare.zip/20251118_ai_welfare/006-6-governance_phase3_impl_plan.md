### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (representatives from philanthropic funder, participating government, frontier AI lab, independent AI Ethics Expert, ISO Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager incorporates feedback and finalizes the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor formally appoints the CEO of the AI Sentience & Welfare Commission as the Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- CEO Appointed

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0
- Nominated Members List Available

### 6. Hold initial Project Steering Committee kick-off meeting to review and approve the initial project plan, define risk appetite and tolerance levels, and establish a meeting schedule.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan
- Defined Risk Appetite and Tolerance Levels
- Meeting Schedule

**Dependencies:**

- Meeting Invitation
- Agenda
- Final SteerCo ToR v1.0
- CEO Appointed
- Nominated Members List Available

### 7. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 8. Circulate Draft PMO ToR for review by Lead AI Researcher, Lead Standards Development Specialist, Finance Officer, Communications Officer, and Risk Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Team Members Identified

### 9. Project Manager incorporates feedback and finalizes the PMO ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final PMO ToR v1.0
- Team Members Identified

### 11. Hold PMO Kick-off Meeting & assign initial tasks: establish project management methodology and tools, develop project communication plan, define roles and responsibilities for project team members, set up project tracking and reporting systems, and establish risk management framework.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Project Management Methodology and Tools
- Project Communication Plan
- Defined Roles and Responsibilities
- Project Tracking and Reporting Systems
- Risk Management Framework

**Dependencies:**

- Meeting Invitation
- Agenda
- Final PMO ToR v1.0
- Team Members Identified

### 12. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 13. Circulate Draft TAG ToR for review by potential members (Cognitive Scientist, Philosopher specializing in AI ethics, AI Safety Engineer, Independent AI Expert, Representative from the Adversarial Robustness Program).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Potential Members Identified

### 14. Project Manager incorporates feedback and finalizes the TAG ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 15. Project Manager identifies and recruits a Leading AI Researcher to serve as the Technical Advisory Group Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Chair Appointment Confirmation

**Dependencies:**

- Final TAG ToR v1.0

### 16. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final TAG ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified

### 17. Hold initial Technical Advisory Group kick-off meeting to define scope of technical expertise required, establish meeting schedule and communication protocols, develop a framework for evaluating technical proposals, and define criteria for assessing the validity of AI sentience metrics.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Scope of Technical Expertise
- Established Meeting Schedule and Communication Protocols
- Framework for Evaluating Technical Proposals
- Criteria for Assessing AI Sentience Metrics

**Dependencies:**

- Meeting Invitation
- Agenda
- Final TAG ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified

### 18. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 19. Circulate Draft ECC ToR for review by potential members (Ethicist, Data Protection Officer, Representative from the ISO, Independent Legal Expert, Representative from the Communications Team).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1
- Potential Members Identified

### 20. Project Manager incorporates feedback and finalizes the ECC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 21. Project Manager identifies and recruits Legal Counsel to serve as the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Chair Appointment Confirmation

**Dependencies:**

- Final ECC ToR v1.0

### 22. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final ECC ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified

### 23. Hold initial Ethics & Compliance Committee kick-off meeting to develop a code of ethics, establish compliance policies and procedures, set up a system for reporting and investigating ethical complaints, develop a training program on ethical issues, and define data privacy protocols.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Code of Ethics
- Compliance Policies and Procedures
- System for Reporting and Investigating Ethical Complaints
- Training Program on Ethical Issues
- Data Privacy Protocols

**Dependencies:**

- Meeting Invitation
- Agenda
- Final ECC ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified

### 24. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 25. Circulate Draft SEG ToR for review by potential members (Public Relations Specialist, Representative from the Research Team, Representative from the Standards Development Team, Representative from a participating government, Representative from a major philanthropic funder).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1
- Potential Members Identified

### 26. Project Manager incorporates feedback and finalizes the SEG ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 27. Project Manager identifies and recruits the Communications Officer to serve as the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Chair Appointment Confirmation

**Dependencies:**

- Final SEG ToR v1.0

### 28. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Final SEG ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified

### 29. Hold initial Stakeholder Engagement Group kick-off meeting to develop and implement a stakeholder engagement plan, establish communication channels, set up a system for tracking stakeholder feedback, and define key messages.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Stakeholder Engagement Plan
- Established Communication Channels
- System for Tracking Stakeholder Feedback
- Defined Key Messages

**Dependencies:**

- Meeting Invitation
- Agenda
- Final SEG ToR v1.0
- Chair Appointment Confirmation
- Potential Members Identified