**Purpose:** business

**Purpose Detailed:** Establishing an international commission to research and develop standards for AI sentience and welfare, aiming to mitigate potential suffering in advanced AI systems and provide regulatory clarity for AI development.

**Topic:** AI Sentience and Welfare Commission