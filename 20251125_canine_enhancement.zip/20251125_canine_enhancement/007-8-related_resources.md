## Suggestion 1 - AquaBounty Technologies' AquAdvantage Salmon

AquaBounty Technologies developed AquAdvantage Salmon, a genetically engineered Atlantic salmon that grows faster than its non-genetically engineered counterparts. The project involved inserting a growth hormone gene from the Pacific Chinook salmon and a promoter from the ocean pout into the Atlantic salmon genome. The goal was to increase production efficiency and reduce the environmental impact of salmon farming. The project spanned several years, involved extensive regulatory reviews, and ultimately led to the approval for commercial production and sale in the United States and Canada.

### Success Metrics

Regulatory approval from the FDA in 2015 (after initial application in 1995) and Health Canada in 2016.
Increased growth rate of the salmon, reducing the time to market.
Commercial production and sale of AquAdvantage Salmon in North America.
Demonstrated environmental benefits through reduced feed consumption and waste production.

### Risks and Challenges Faced

Regulatory hurdles: Overcoming concerns about the safety and environmental impact of genetically engineered animals required extensive data and engagement with regulatory agencies. This was mitigated through comprehensive risk assessments and adherence to regulatory guidelines.
Public perception: Addressing public concerns about genetically modified organisms (GMOs) involved transparent communication and education efforts. AquaBounty engaged with stakeholders to address concerns and provide scientific evidence supporting the safety of their product.
Technical challenges: Ensuring the genetic stability and health of the genetically engineered salmon required careful monitoring and breeding practices. This was managed through rigorous quality control measures and health monitoring protocols.

### Where to Find More Information

AquaBounty Technologies Official Website: [https://www.aquabounty.com/](https://www.aquabounty.com/)
FDA Approval Announcement: [https://wayback.archive-it.org/7993/20170112014456/http://www.fda.gov/NewsEvents/Newsroom/PressAnnouncements/ucm476439.htm](https://wayback.archive-it.org/7993/20170112014456/http://www.fda.gov/NewsEvents/Newsroom/PressAnnouncements/ucm476439.htm)
Health Canada Approval Announcement: [https://www.canada.ca/en/health-canada/news/2016/05/statement-health-canada-completes-safety-assessment-aquadvantage-salmon.html](https://www.canada.ca/en/health-canada/news/2016/05/statement-health-canada-completes-safety-assessment-aquadvantage-salmon.html)

### Actionable Steps

Contact AquaBounty Technologies: Reach out to their investor relations or public relations departments for insights into their regulatory approval process and public engagement strategies. Email inquiries can be sent through their website.
Review FDA and Health Canada documentation: Access the publicly available documents related to the approval of AquAdvantage Salmon to understand the data requirements and risk assessments involved. Search the FDA and Health Canada websites for "AquAdvantage Salmon."
Consult with regulatory experts: Engage with consultants specializing in regulatory affairs for genetically engineered animals to understand the specific requirements in South Korea.

### Rationale for Suggestion

This project is highly relevant due to its focus on genetically engineering an animal for commercial purposes. It provides valuable insights into navigating regulatory hurdles, addressing public perception, and managing technical challenges associated with genetic modification. The experience of AquaBounty in securing regulatory approval and commercializing a genetically engineered animal can inform the regulatory navigation and ethical oversight strategies for the canine project. Although geographically distant, the regulatory and ethical challenges are universally applicable.
## Suggestion 2 - Recombinetics' Gene-Edited Hornless Dairy Cattle

Recombinetics (now Acceligen) developed gene-edited hornless dairy cattle using TALENs gene editing technology. The project aimed to eliminate the need for dehorning, a common practice in dairy farming that can cause pain and stress to the animals. The gene editing involved introducing a naturally occurring hornless allele into the cattle genome. The project demonstrated the potential of gene editing to improve animal welfare and reduce the labor associated with traditional farming practices. However, regulatory challenges in defining the status of gene-edited animals have impacted commercialization.

### Success Metrics

Successful gene editing to produce hornless dairy cattle.
Demonstration of the potential to improve animal welfare by eliminating the need for dehorning.
Publication of scientific studies validating the gene-editing approach.
Initial positive reception from the dairy industry.

### Risks and Challenges Faced

Regulatory uncertainty: The regulatory status of gene-edited animals remains unclear in many jurisdictions, including the United States. This uncertainty has hindered commercialization efforts. Recombinetics engaged with regulatory agencies to advocate for a risk-based approach to regulation.
Public acceptance: Addressing concerns about the safety and ethics of gene editing required transparent communication and engagement with stakeholders. Recombinetics emphasized the animal welfare benefits of their technology.
Technical challenges: Ensuring the precision and stability of the gene edits required careful design and validation. This was managed through rigorous quality control measures and genomic analysis.

### Where to Find More Information

Acceligen Official Website: [https://acceligen.com/](https://acceligen.com/)
Scientific Publications: Search for publications by Recombinetics or Acceligen on gene-edited hornless cattle in scientific databases such as PubMed.
USDA Statement on Gene Editing: [https://www.usda.gov/media/press-releases/2018/03/08/usda-secretary-perdue-issues-statement-plant-breeding-innovation](https://www.usda.gov/media/press-releases/2018/03/08/usda-secretary-perdue-issues-statement-plant-breeding-innovation)

### Actionable Steps

Contact Acceligen: Reach out to their business development or scientific affairs departments for insights into their gene-editing techniques and regulatory experiences. Contact information is available on their website.
Review USDA guidelines: Examine the USDA's statements and guidelines on gene editing to understand the regulatory landscape in the United States. Search the USDA website for "gene editing."
Consult with animal welfare experts: Engage with experts in animal welfare and ethics to address potential concerns and develop a responsible approach to gene editing.

### Rationale for Suggestion

This project is relevant because it involves gene editing in livestock to improve animal welfare, which aligns with the ethical considerations of the canine project. The challenges faced by Recombinetics in navigating regulatory uncertainty and addressing public acceptance are directly applicable to the canine project. The use of gene editing technologies and the focus on animal welfare make this a valuable reference. Although the project is based in the US, the ethical and regulatory considerations are globally relevant, especially given the plan's focus on ethical oversight.
## Suggestion 3 - Korean Bioengineered Pig Heart for Xenotransplantation

Researchers in South Korea have been actively involved in developing genetically modified pigs for xenotransplantation, particularly focusing on modifying pig hearts to be more compatible with the human immune system. These projects involve multiple gene edits to reduce the risk of rejection and improve the long-term viability of the transplanted organs. While specific project names are often not widely publicized due to ongoing research and competitive reasons, the overall effort represents a significant advancement in animal biotechnology within South Korea.

### Success Metrics

Successful gene editing of pig hearts to reduce immunogenicity.
Demonstrated compatibility of modified pig hearts with human immune cells in vitro.
Prolonged survival of transplanted pig hearts in primate models.
Advancement towards clinical trials for xenotransplantation in humans.

### Risks and Challenges Faced

Immune rejection: Overcoming the challenges of immune rejection required multiple gene edits and immunosuppressive therapies. Researchers focused on knocking out pig genes that trigger immune responses and adding human genes to promote acceptance.
Virus transmission: Addressing the risk of transmitting porcine endogenous retroviruses (PERVs) to humans involved inactivating PERV genes in the pig genome. This required advanced gene-editing techniques and careful screening.
Ethical concerns: Addressing ethical concerns about using animals for xenotransplantation involved transparent communication and adherence to ethical guidelines. Researchers emphasized the potential benefits for human health and the rigorous oversight of their research.

### Where to Find More Information

Scientific Publications: Search for publications on xenotransplantation and genetically modified pigs by South Korean researchers in scientific databases such as PubMed and Scopus.
Korean Research Institutes: Explore the websites of leading research institutes in South Korea, such as the Korea Research Institute of Bioscience and Biotechnology (KRIBB), for information on their xenotransplantation research.
News Articles: Search for news articles and reports on xenotransplantation research in South Korea from reputable news sources.

### Actionable Steps

Contact KRIBB: Reach out to researchers at KRIBB involved in xenotransplantation research for insights into their gene-editing techniques and ethical considerations. Contact information is available on their website.
Review scientific literature: Conduct a thorough review of scientific publications on xenotransplantation and genetically modified pigs to understand the latest advancements and challenges.
Consult with xenotransplantation experts: Engage with experts in xenotransplantation and animal biotechnology to gain insights into the regulatory landscape and ethical considerations in South Korea.

### Rationale for Suggestion

This project is highly relevant due to its geographical proximity (South Korea) and focus on complex genetic engineering in animals. The challenges faced in overcoming immune rejection, addressing virus transmission, and navigating ethical concerns are directly applicable to the canine project. The expertise and infrastructure available in South Korea for animal biotechnology make this a valuable reference. The project's focus on multiple gene edits and ethical considerations aligns well with the canine project's ambitious goals and ethical oversight framework. The fact that the project is based in South Korea makes it particularly relevant, as it provides insights into the local regulatory landscape and ethical considerations.

## Summary

Based on the provided project plan to genetically engineer a canine to maximize dopamine and oxytocin release in humans, with a focus on aesthetics, behavior, and ethical considerations, I recommend the following projects as references. These projects offer insights into genetic engineering, ethical oversight, and commercialization strategies, particularly within the context of animal biotechnology.