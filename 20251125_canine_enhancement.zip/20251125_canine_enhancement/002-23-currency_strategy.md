This plan involves money.

## Currencies

- **USD:** The budget is specified in USD.
- **KRW:** Local expenses in South Korea.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. KRW will be used for local transactions in South Korea. Hedging against exchange rate fluctuations between USD and KRW may be necessary.