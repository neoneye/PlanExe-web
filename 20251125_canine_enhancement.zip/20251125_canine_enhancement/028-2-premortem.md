A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The regulatory approval process in South Korea will proceed smoothly and within the estimated 12-month timeframe. | Engage in preliminary discussions with MFDS and APQA to gauge their initial perspectives on the project and identify potential concerns. | MFDS or APQA expresses significant reservations or indicates that the approval process is likely to exceed 18 months. |
| A2 | The genetic modifications will reliably produce the desired aesthetic and behavioral traits without causing unforeseen health problems or reducing lifespan. | Conduct extensive in vitro testing on canine cell lines to assess the effects of the genetic modifications on cellular function and identify potential off-target effects. | In vitro testing reveals significant off-target effects or indicates that the genetic modifications are unlikely to produce the desired traits. |
| A3 | The public will generally accept genetically engineered companion animals, and ethical concerns can be adequately addressed through transparent communication and ethical practices. | Conduct a survey of potential customers and the general public to gauge their attitudes towards genetically engineered companion animals and identify their primary ethical concerns. | The survey reveals widespread negative attitudes towards genetically engineered companion animals or indicates that ethical concerns are unlikely to be addressed through current communication strategies. |
| A4 | The Sooam Biotech Research Foundation will continue to provide adequate infrastructure and support for the duration of the project. | Obtain a written commitment from Sooam Biotech Research Foundation confirming their ongoing support and outlining the specific resources they will provide. | Sooam Biotech Research Foundation expresses uncertainty about their ability to provide long-term support or indicates that the resources they can offer are limited. |
| A5 | Existing pet care infrastructure (veterinary clinics, pet stores, training facilities) will be readily adaptable to the needs of genetically engineered dogs. | Consult with a representative sample of veterinary clinics, pet stores, and training facilities to assess their willingness and ability to accommodate the unique needs of genetically engineered dogs. | A significant number of veterinary clinics, pet stores, or training facilities express reluctance or inability to accommodate the genetically engineered dogs. |
| A6 | The project will be able to secure and maintain adequate insurance coverage for potential liabilities related to the genetically engineered dogs. | Consult with insurance providers to obtain quotes for liability insurance coverage and assess the feasibility of securing adequate coverage at a reasonable cost. | Insurance providers are unwilling to offer liability insurance coverage or the cost of coverage is prohibitively expensive. |
| A7 | The cost of key inputs (e.g., specialized animal feed, genetic modification reagents) will remain stable and within the project's budget projections. | Obtain long-term supply contracts with key vendors, locking in prices for critical inputs over the next 3-5 years. | Vendors are unwilling to offer long-term contracts at prices within the project's budget projections, or the contracts contain clauses that allow for significant price increases. |
| A8 | The genetically engineered dogs will be able to successfully reproduce and maintain genetic stability across multiple generations. | Conduct multi-generational breeding studies to assess the reproductive success and genetic stability of the genetically engineered dogs. | The genetically engineered dogs exhibit reduced fertility, increased rates of genetic mutations, or a loss of desired traits across multiple generations. |
| A9 | There will be sufficient demand from qualified and responsible owners who are willing and able to provide appropriate care for the genetically engineered dogs. | Develop a detailed owner screening process and conduct a pilot program with a small group of carefully selected owners to assess their ability to provide adequate care and support. | The owner screening process reveals a lack of qualified and responsible applicants, or the pilot program reveals significant challenges in providing adequate care and support. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Black Hole | Process/Financial | A1 | Regulatory Affairs Specialist | CRITICAL (20/25) |
| FM2 | The Genetic Lottery | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Unloved Creation | Market/Human | A3 | Commercialization and Marketing Strategist | CRITICAL (15/25) |
| FM4 | The Foundation Crumbles | Process/Financial | A4 | Project Manager | CRITICAL (15/25) |
| FM5 | The Unprepared World | Technical/Logistical | A5 | Veterinary Ethologist | HIGH (12/25) |
| FM6 | The Uninsurable Risk | Market/Human | A6 | Financial Controller | HIGH (10/25) |
| FM7 | The Inflationary Spiral | Process/Financial | A7 | Financial Controller | CRITICAL (15/25) |
| FM8 | The Genetic Dead End | Technical/Logistical | A8 | Lead Geneticist | CRITICAL (15/25) |
| FM9 | The Irresponsible Guardians | Market/Human | A9 | Commercialization and Marketing Strategist | HIGH (10/25) |


### Failure Modes

#### FM1 - The Regulatory Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Regulatory Affairs Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial viability hinges on timely regulatory approval in South Korea. However, the regulatory landscape for genetically engineered animals is uncertain and evolving. If the approval process is significantly delayed or ultimately denied, the project will face severe financial consequences.

*   Initial assumption of a 12-month approval timeline proves wildly optimistic.
*   Unexpected regulatory hurdles and requests for additional data lead to repeated delays.
*   Legal and consulting fees escalate dramatically as the project attempts to navigate the complex regulatory environment.
*   Investor confidence erodes, making it difficult to secure additional funding.
*   The project runs out of money before obtaining regulatory approval, forcing termination.

##### Early Warning Signs
- Initial feedback from MFDS or APQA is negative or non-committal.
- Requests for additional data or studies exceed initial expectations.
- The regulatory approval timeline is revised upwards by more than 6 months.
- Legal and consulting fees exceed budgeted amounts by more than 25%.

##### Tripwires
- Approval timeline exceeds 18 months
- Legal/Consulting fees exceed $7.5 million
- MFDS/APQA requests a full environmental impact statement

##### Response Playbook
- Contain: Immediately freeze all non-essential spending to conserve resources.
- Assess: Conduct a thorough review of the regulatory landscape and identify alternative approval pathways.
- Respond: Explore alternative jurisdictions with more favorable regulatory environments or pivot to a less regulated product.


**STOP RULE:** Regulatory approval is denied by both MFDS and APQA, and no viable alternative jurisdictions are identified within 6 months.

---

#### FM2 - The Genetic Lottery

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's technical success depends on the ability to reliably produce the desired aesthetic and behavioral traits through genetic modification. However, the relationship between genes and phenotype is complex and unpredictable. If the genetic modifications fail to produce the desired traits or cause unforeseen health problems, the project will be unable to deliver a marketable product.

*   Initial in vitro testing shows promise, but in vivo results are inconsistent and unpredictable.
*   The genetically modified dogs exhibit a range of undesirable traits, including behavioral problems and health issues.
*   Attempts to refine the genetic modifications are unsuccessful, leading to further complications.
*   The project is unable to produce a stable line of dogs with the desired traits.
*   The project is terminated due to technical infeasibility.

##### Early Warning Signs
- In vivo testing results are inconsistent or contradictory.
- The genetically modified dogs exhibit a high incidence of health problems.
- Attempts to refine the genetic modifications are unsuccessful.
- The project is unable to produce a stable line of dogs with the desired traits.

##### Tripwires
- Success rate of desired genetic modification <= 20%
- Incidence of severe health defects >= 15%
- More than 5 failed attempts to stabilize the genome

##### Response Playbook
- Contain: Halt all further in vivo testing to prevent further harm to animals.
- Assess: Conduct a thorough review of the genetic modification strategy and identify potential sources of error.
- Respond: Explore alternative genetic modification techniques or pivot to a less ambitious set of traits.


**STOP RULE:** After 18 months of in vivo testing, the project is unable to produce a stable line of dogs with the desired traits and acceptable health outcomes.

---

#### FM3 - The Unloved Creation

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Commercialization and Marketing Strategist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's commercial success depends on public acceptance of genetically engineered companion animals. However, ethical concerns and negative perceptions could lead to widespread rejection of the product, regardless of its technical merits. If the public is unwilling to embrace the genetically modified dogs, the project will be unable to generate sufficient revenue to justify its investment.

*   Initial market research is positive, but public sentiment shifts dramatically after the launch.
*   Animal welfare organizations launch a campaign against the project, highlighting ethical concerns and potential harms to the dogs.
*   Social media is flooded with negative comments and images, damaging the project's reputation.
*   Sales are far below expectations, and retailers refuse to stock the product.
*   The project is terminated due to lack of market demand.

##### Early Warning Signs
- Animal welfare organizations express strong opposition to the project.
- Social media sentiment towards the project is overwhelmingly negative.
- Retailers express reluctance to stock the product.
- Pre-order numbers are significantly below expectations.

##### Tripwires
- Negative sentiment on social media >= 60%
- Pre-order volume <= 500 units
- Major retailers refuse to carry the product

##### Response Playbook
- Contain: Immediately launch a crisis communication campaign to address public concerns.
- Assess: Conduct a thorough review of the public's concerns and identify potential areas for compromise.
- Respond: Modify the project to address ethical concerns or pivot to a different target market with more favorable attitudes.


**STOP RULE:** After 24 months of commercial launch, the project is unable to achieve a positive return on investment due to lack of market demand.

---

#### FM4 - The Foundation Crumbles

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's reliance on Sooam Biotech Research Foundation for infrastructure and support creates a single point of failure. If Sooam Biotech experiences financial difficulties, changes in leadership, or a shift in priorities, the project could lose access to critical resources, leading to delays, increased costs, and potential termination.

*   Sooam Biotech experiences a sudden financial downturn due to unrelated business ventures.
*   A new director is appointed at Sooam Biotech who is less supportive of the project.
*   Sooam Biotech's infrastructure becomes outdated or inadequate to meet the project's evolving needs.
*   The project is forced to relocate to a new facility, incurring significant costs and delays.
*   The project is terminated due to lack of infrastructure and support.

##### Early Warning Signs
- Sooam Biotech announces cost-cutting measures or restructuring.
- Key personnel at Sooam Biotech leave the organization.
- Sooam Biotech's financial reports indicate declining revenues or profits.
- The project experiences delays due to infrastructure limitations at Sooam Biotech.

##### Tripwires
- Sooam Biotech announces a budget cut of >= 15%
- Key personnel at Sooam Biotech resign
- Project experiences a delay of >= 90 days due to infrastructure issues

##### Response Playbook
- Contain: Immediately identify alternative facilities and resources.
- Assess: Evaluate the financial stability and long-term commitment of Sooam Biotech.
- Respond: Negotiate a revised agreement with Sooam Biotech or relocate the project to a new facility.


**STOP RULE:** Sooam Biotech is unable to provide adequate infrastructure and support for more than 6 months, and no viable alternative facilities are identified.

---

#### FM5 - The Unprepared World

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Veterinary Ethologist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes that existing pet care infrastructure will be readily adaptable to the needs of genetically engineered dogs. However, these dogs may have unique dietary, medical, or behavioral needs that existing infrastructure is not equipped to handle. This could lead to difficulties in providing adequate care, increased costs, and negative impacts on animal welfare.

*   Veterinary clinics lack the expertise or equipment to treat health problems specific to genetically engineered dogs.
*   Pet stores are unwilling to stock specialized food or supplies required by the dogs.
*   Training facilities are unable to develop effective training programs for the dogs due to their unique behavioral traits.
*   Owners struggle to find adequate care for their dogs, leading to neglect or abandonment.
*   The project is unable to provide adequate support for owners, leading to negative publicity and reduced market demand.

##### Early Warning Signs
- Veterinary clinics express reluctance to treat genetically engineered dogs.
- Pet stores are unwilling to stock specialized food or supplies.
- Training facilities are unable to develop effective training programs.
- Owners report difficulties in finding adequate care for their dogs.

##### Tripwires
- Less than 25% of surveyed vets are willing to treat the dogs
- Less than 30% of pet stores are willing to stock specialized supplies
- Training success rate is <= 40%

##### Response Playbook
- Contain: Develop a network of specialized veterinary clinics and training facilities.
- Assess: Identify the specific needs of the genetically engineered dogs and assess the capabilities of existing infrastructure.
- Respond: Develop specialized training programs and provide resources to support owners.


**STOP RULE:** The project is unable to establish a network of veterinary clinics and training facilities capable of providing adequate care for the genetically engineered dogs within 12 months.

---

#### FM6 - The Uninsurable Risk

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Financial Controller
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project's financial viability depends on the ability to secure adequate liability insurance coverage for potential risks associated with the genetically engineered dogs. However, insurance providers may be unwilling to offer coverage or may charge prohibitively high premiums due to the novel nature of the product and the potential for unforeseen liabilities. This could expose the project to significant financial risks and limit its commercial potential.

*   Insurance providers are unwilling to offer liability insurance coverage due to the novel nature of the product.
*   The cost of liability insurance coverage is prohibitively expensive, significantly increasing operating costs.
*   The project is exposed to significant financial risks due to potential liabilities related to the genetically engineered dogs.
*   Potential customers are reluctant to purchase the dogs due to concerns about liability.
*   The project is terminated due to lack of insurance coverage and potential financial risks.

##### Early Warning Signs
- Insurance providers express reluctance to offer liability insurance coverage.
- The cost of liability insurance coverage exceeds budgeted amounts by more than 50%.
- Potential customers express concerns about liability.

##### Tripwires
- No insurance provider offers liability coverage
- Insurance premiums exceed $2 million per year
- Customer surveys show liability concerns >= 40%

##### Response Playbook
- Contain: Explore alternative insurance options, such as self-insurance or captive insurance.
- Assess: Evaluate the potential liabilities associated with the genetically engineered dogs and assess the feasibility of mitigating these risks.
- Respond: Modify the project to reduce potential liabilities or pivot to a different product with lower risk.


**STOP RULE:** The project is unable to secure adequate liability insurance coverage at a reasonable cost after 12 months of searching.

---

#### FM7 - The Inflationary Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's financial model assumes stable input costs. However, unforeseen events, such as global supply chain disruptions or increased demand for specialized reagents, could lead to significant cost increases, jeopardizing the project's profitability and potentially forcing a reduction in scope or termination.

*   A global pandemic disrupts the supply chain for specialized animal feed, causing prices to skyrocket.
*   Increased demand for CRISPR-Cas9 reagents from other research projects leads to shortages and price increases.
*   The cost of veterinary care for the genetically engineered dogs is higher than anticipated due to unforeseen health complications.
*   The project is forced to reduce the scope of its research or cut corners on animal welfare to stay within budget.
*   The project is terminated due to financial infeasibility.

##### Early Warning Signs
- Vendors announce price increases for key inputs.
- Supply chain disruptions are reported in the biotechnology industry.
- The cost of veterinary care for the genetically engineered dogs exceeds budgeted amounts.
- The project is forced to delay or cancel planned research activities due to budget constraints.

##### Tripwires
- Animal feed costs increase by >= 20%
- Reagent costs increase by >= 25%
- Veterinary costs exceed budget by >= 30%

##### Response Playbook
- Contain: Immediately identify alternative suppliers and negotiate lower prices.
- Assess: Conduct a thorough review of the budget and identify potential cost-saving measures.
- Respond: Reduce the scope of the project or seek additional funding.


**STOP RULE:** The project is unable to secure sufficient funding to cover increased input costs, and the projected ROI falls below 10%.

---

#### FM8 - The Genetic Dead End

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Lead Geneticist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's long-term sustainability depends on the ability of the genetically engineered dogs to reproduce and maintain genetic stability across multiple generations. However, the genetic modifications could disrupt reproductive function or lead to genetic instability, making it difficult to maintain a viable breeding population.

*   The genetically engineered dogs exhibit reduced fertility or infertility.
*   The offspring of the genetically engineered dogs exhibit a high rate of genetic mutations or deformities.
*   The desired traits are lost or diluted across multiple generations.
*   The project is unable to maintain a stable breeding population.
*   The project is terminated due to technical infeasibility and lack of long-term sustainability.

##### Early Warning Signs
- The genetically engineered dogs exhibit reduced fertility or infertility.
- The offspring of the genetically engineered dogs exhibit a high rate of genetic mutations or deformities.
- The desired traits are lost or diluted across multiple generations.
- The project experiences difficulties in maintaining a stable breeding population.

##### Tripwires
- Fertility rate drops below 50%
- Mutation rate exceeds 5%
- Loss of desired traits in >= 20% of offspring

##### Response Playbook
- Contain: Implement assisted reproductive technologies to improve fertility.
- Assess: Conduct a thorough genetic analysis to identify the causes of genetic instability.
- Respond: Refine the genetic modification strategy or explore alternative breeding techniques.


**STOP RULE:** The project is unable to establish a self-sustaining breeding population of genetically engineered dogs after 3 years of breeding efforts.

---

#### FM9 - The Irresponsible Guardians

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Commercialization and Marketing Strategist
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project's success hinges on finding qualified and responsible owners who are willing and able to provide appropriate care for the genetically engineered dogs. However, if there is a lack of suitable owners, the dogs could be neglected, abused, or abandoned, leading to ethical concerns, negative publicity, and project failure.

*   The owner screening process reveals a lack of qualified applicants.
*   Owners are unable to provide adequate care for the dogs due to financial constraints, lack of time, or other factors.
*   The dogs are neglected, abused, or abandoned by their owners.
*   Animal welfare organizations raise concerns about the well-being of the dogs.
*   The project is terminated due to ethical concerns and negative publicity.

##### Early Warning Signs
- The owner screening process yields few qualified applicants.
- Owners report difficulties in providing adequate care for the dogs.
- Animal welfare organizations express concerns about the well-being of the dogs.
- There are reports of neglect, abuse, or abandonment of the dogs.

##### Tripwires
- Less than 10% of applicants pass the owner screening
- Reports of neglect/abuse exceed 3% of dogs sold
- Animal welfare groups call for a boycott

##### Response Playbook
- Contain: Strengthen the owner screening process and provide additional support to owners.
- Assess: Conduct a thorough review of the owner selection and support programs.
- Respond: Modify the commercialization strategy to target a more responsible and qualified owner base or partner with animal welfare organizations to provide ongoing support.


**STOP RULE:** The project is unable to ensure the well-being of the genetically engineered dogs due to a lack of qualified and responsible owners, and ethical concerns persist despite mitigation efforts.
