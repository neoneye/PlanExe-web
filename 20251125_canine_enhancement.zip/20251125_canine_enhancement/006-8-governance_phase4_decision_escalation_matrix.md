**Budget Overrun Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the overrun, revised budget proposal, and approval by majority vote (CEO has tie-breaker).
Rationale: Exceeds the Core Project Team's delegated financial authority and requires strategic review and approval at a higher level.
Negative Consequences: Project delays, scope reduction, or termination due to lack of funds.

**Unresolved Ethical Concern Raised by Ethics Advisory Board**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the ethical concern, the Ethics Advisory Board's recommendation, and a vote on the proposed resolution. Independent Ethics Advisor's approval is required.
Rationale: Ethical concerns require a higher level of scrutiny and decision-making to ensure alignment with ethical standards and public perception.
Negative Consequences: Negative publicity, regulatory sanctions, project termination, damage to reputation.

**Technical Deadlock within Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the conflicting technical opinions, consultation with external experts if needed, and a final decision based on the best available evidence.
Rationale: Technical disagreements can stall progress and require a higher-level decision to ensure the project remains on track.
Negative Consequences: Project delays, technical failures, increased costs, inability to achieve desired phenotype.

**Proposed Major Scope Change Impacting Project Goals**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the proposed scope change, its impact on project goals, budget, and timeline, and approval by majority vote.
Rationale: Significant scope changes require strategic review and approval to ensure they align with the overall project objectives and remain feasible.
Negative Consequences: Project failure, budget overruns, timeline delays, inability to achieve desired outcomes.

**Regulatory Approval Delay Beyond Contingency Plan**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the regulatory situation, assessment of alternative strategies, and a decision on the best course of action (e.g., further engagement, legal challenge, or project termination).
Rationale: Significant regulatory delays can jeopardize the project's viability and require a strategic response.
Negative Consequences: Project termination, loss of investment, inability to commercialize the product.