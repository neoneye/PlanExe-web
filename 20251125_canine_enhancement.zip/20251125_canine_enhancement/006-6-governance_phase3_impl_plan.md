### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Governance Structure Defined

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics Advisory Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Advisory Board ToR v0.1

**Dependencies:**

- Project Start
- Project Governance Structure Defined

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start
- Project Governance Structure Defined

### 4. Project Manager drafts initial role and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Project Team Roles and Responsibilities v0.1

**Dependencies:**

- Project Start
- Project Governance Structure Defined

### 5. Circulate Draft SteerCo ToR v0.1 for review by CEO, CSO, and CFO of Sooam Biotech Research Foundation.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Finalize SteerCo ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 7. CEO of Sooam Biotech Research Foundation formally appoints Steering Committee Chair (can be themselves or another member).

**Responsible Body/Role:** CEO of Sooam Biotech Research Foundation

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 8. Project Steering Committee Chair, in consultation with CEO, confirms remaining Steering Committee members (CSO, CFO, Independent Ethics Advisor, Lead Geneticist, Project Manager).

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email

### 9. Schedule initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation List

### 10. Hold initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 11. Circulate Draft Ethics Advisory Board ToR v0.1 for review by the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics Advisory Board ToR v0.1

### 12. Finalize Ethics Advisory Board ToR based on feedback from the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Advisory Board ToR v1.0

**Dependencies:**

- Feedback Summary

### 13. Project Steering Committee formally appoints Ethics Advisory Board Chair (Independent Ethicist).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Advisory Board ToR v1.0

### 14. Ethics Advisory Board Chair, in consultation with the Project Steering Committee, confirms remaining Ethics Advisory Board members (Animal Welfare Advocate, Veterinarian, Public Representative, Legal Counsel).

**Responsible Body/Role:** Ethics Advisory Board Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email

### 15. Schedule initial Ethics Advisory Board kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation List

### 16. Hold initial Ethics Advisory Board kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Ethics Advisory Board

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 17. Circulate Draft Technical Advisory Group ToR v0.1 for review by the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 18. Finalize Technical Advisory Group ToR based on feedback from the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 19. Project Steering Committee formally appoints Technical Advisory Group Chair (External Expert in CRISPR-Cas9 or Prime Editing).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 20. Technical Advisory Group Chair, in consultation with the Project Steering Committee, confirms remaining Technical Advisory Group members (Expert in Prime Editing or CRISPR-Cas9, Bioinformatics Specialist, Geneticist, Veterinarian).

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email

### 21. Schedule initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Membership Confirmation List

### 22. Hold initial Technical Advisory Group kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 23. Project Manager, in consultation with Lead Geneticist, Lead Veterinarian, Lead Behaviorist, Regulatory Specialist, Data Manager, and Lab Manager, finalizes Core Project Team Roles and Responsibilities.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Core Project Team Roles and Responsibilities v1.0

**Dependencies:**

- Draft Core Project Team Roles and Responsibilities v0.1

### 24. Project Manager formally establishes the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Team Establishment Announcement

**Dependencies:**

- Final Core Project Team Roles and Responsibilities v1.0

### 25. Schedule initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Team Establishment Announcement

### 26. Hold initial Core Project Team kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation