### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, given the project's high budget, complex ethical considerations, and potential regulatory hurdles.  Essential for high-level decision-making and risk management.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to project scope, budget, or timeline (>$5M).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Ensure alignment with organizational goals and ethical standards.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Review and approve project charter.

**Membership:**

- Chief Executive Officer (CEO) of Sooam Biotech Research Foundation
- Chief Scientific Officer (CSO) of Sooam Biotech Research Foundation
- Chief Financial Officer (CFO) of Sooam Biotech Research Foundation
- Independent Ethics Advisor (External)
- Lead Geneticist
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget (>$5M), timeline, and risk management. Final approval on major project deliverables and milestones.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO has the deciding vote.  Any decision impacting ethical considerations requires the Independent Ethics Advisor's approval.

**Meeting Cadence:** Quarterly, or more frequently as needed.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance.
- Discussion of key risks and mitigation strategies.
- Approval of major changes to project scope, budget, or timeline.
- Review of ethical considerations and compliance.
- Stakeholder engagement updates.

**Escalation Path:** Board of Directors of Sooam Biotech Research Foundation for issues exceeding the Steering Committee's authority or unresolved conflicts.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Essential for operational efficiency and effective communication.

**Responsibilities:**

- Develop and maintain project plans.
- Manage project budget and resources.
- Track project progress and report on status.
- Identify and resolve project issues.
- Coordinate project activities across different teams.
- Manage operational risks and implement mitigation strategies.
- Ensure compliance with project standards and procedures.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project tracking systems.
- Develop detailed project schedule.
- Define operational risk thresholds.

**Membership:**

- Project Manager
- Lead Geneticist
- Lead Veterinarian
- Lead Behaviorist
- Regulatory Specialist
- Data Manager
- Lab Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and issue resolution (below $500k).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with relevant team members.  Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Coordination of project activities.
- Review of budget and resource utilization.
- Action item tracking.

**Escalation Path:** Project Steering Committee for issues exceeding the Project Manager's authority or unresolved conflicts.
### 3. Ethics Advisory Board

**Rationale for Inclusion:** Provides independent ethical guidance and oversight, given the project's complex ethical considerations and potential impact on animal welfare and public perception.  Essential for maintaining ethical integrity and building public trust.

**Responsibilities:**

- Review and approve project protocols from an ethical perspective.
- Provide guidance on ethical issues related to the project.
- Monitor animal welfare and ensure compliance with ethical standards.
- Engage with the public and address ethical concerns.
- Advise the Project Steering Committee on ethical matters.
- Conduct regular ethical audits of the project.
- Ensure compliance with relevant ethical guidelines and regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define ethical review process.
- Develop ethical guidelines for the project.

**Membership:**

- Independent Ethicist (Chair)
- Animal Welfare Advocate
- Veterinarian (independent of the project)
- Public Representative
- Legal Counsel (specializing in bioethics)

**Decision Rights:** Ethical approval of project protocols, including genetic modification strategies, animal care procedures, and commercialization plans.  Authority to halt project activities if ethical concerns are not adequately addressed.

**Decision Mechanism:** Decisions made by majority vote. The Chair has the deciding vote in case of a tie. A negative vote from the Animal Welfare Advocate or Independent Ethicist will trigger a mandatory review by the Project Steering Committee.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review of project protocols for ethical compliance.
- Discussion of ethical issues and concerns.
- Review of animal welfare data.
- Public engagement updates.
- Ethical audit reports.
- Review of adverse events.

**Escalation Path:** Project Steering Committee for unresolved ethical issues or concerns.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance, given the project's reliance on advanced genetic engineering techniques and the potential for technical challenges.  Essential for ensuring technical feasibility and mitigating technical risks.

**Responsibilities:**

- Review and advise on genetic engineering strategies.
- Provide guidance on technical challenges and risks.
- Evaluate the effectiveness of genetic modifications.
- Monitor for off-target effects and other technical issues.
- Recommend solutions to technical problems.
- Assess the feasibility of achieving desired phenotypes.
- Ensure the technical integrity of the project.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define technical review process.
- Identify key technical risks.

**Membership:**

- Expert in CRISPR-Cas9 technology (External)
- Expert in Prime Editing technology (External)
- Bioinformatics Specialist
- Geneticist (from Sooam Biotech, but different from the Lead Geneticist)
- Veterinarian (with expertise in genetics)

**Decision Rights:** Technical approval of genetic modification strategies and protocols.  Authority to recommend changes to technical approaches to mitigate risks or improve effectiveness.

**Decision Mechanism:** Decisions made by consensus.  If consensus cannot be reached, the issue is escalated to the Project Steering Committee for resolution.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review of genetic engineering strategies.
- Discussion of technical challenges and risks.
- Evaluation of genetic modification effectiveness.
- Review of off-target effect data.
- Technical audit reports.
- Review of new technologies.

**Escalation Path:** Project Steering Committee for unresolved technical issues or disagreements.