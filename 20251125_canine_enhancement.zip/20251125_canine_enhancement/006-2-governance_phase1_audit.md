
## Audit - Corruption Risks

- Bribery of regulatory officials at the Ministry of Food and Drug Safety (MFDS) or Animal and Plant Quarantine Agency (APQA) to expedite approvals or overlook non-compliance issues.
- Kickbacks from suppliers of CRISPR-Cas9 kits, Prime Editing kits, or other laboratory equipment in exchange for preferential selection, potentially compromising quality or inflating costs.
- Conflicts of interest involving members of the ethics advisory board who may have financial ties to the project or competing interests that could bias their ethical assessments.
- Nepotism in hiring practices, favoring unqualified candidates for key roles (e.g., geneticists, veterinarians) based on personal connections rather than merit, potentially impacting project quality.
- Misuse of confidential project information (e.g., genetic data, market research) by internal personnel for personal gain or to benefit competing organizations.

## Audit - Misallocation Risks

- Misuse of the 100M USD budget for personal expenses or unrelated projects by project managers or senior staff.
- Double spending on research activities or equipment purchases due to poor coordination or inadequate record-keeping.
- Inefficient allocation of resources, such as overspending on aesthetic design while underfunding critical health monitoring protocols.
- Unauthorized use of project assets, such as laboratory equipment or genetically modified dogs, for personal research or commercial ventures.
- Misreporting of project progress or results to secure continued funding or inflate the project's perceived success, despite technical or ethical setbacks.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, including expense reports, invoices, and procurement contracts, to detect irregularities and ensure compliance with budget guidelines. Responsibility: Internal Audit Team.
- Perform annual external audits of the project's financial statements and compliance with regulatory requirements, including the Animal Protection Act and GMO guidelines. Responsibility: Independent Audit Firm.
- Implement a contract review process with pre-defined thresholds (e.g., contracts exceeding 500,000 USD) requiring independent legal and financial review to prevent inflated pricing or unfavorable terms. Responsibility: Legal and Finance Departments.
- Establish a documented expense approval workflow with clear authorization limits and supporting documentation requirements to prevent unauthorized spending. Responsibility: Finance Department.
- Conduct periodic compliance checks to ensure adherence to ethical guidelines and animal welfare protocols, including inspections of animal housing facilities and reviews of health monitoring data. Responsibility: Ethics Advisory Board and Veterinary Team.

## Audit - Transparency Measures

- Establish a project progress dashboard accessible to key stakeholders, including geneticists, veterinarians, and regulatory specialists, displaying key milestones, budget expenditures, and risk assessments. Responsibility: Project Management Office.
- Publish minutes of key meetings of the project's governing bodies, such as the ethics advisory board and project steering committee, on a secure online platform accessible to relevant stakeholders. Responsibility: Project Management Office.
- Implement a confidential whistleblower mechanism allowing employees to report suspected ethical violations, financial irregularities, or other misconduct without fear of retaliation. Responsibility: Legal Department.
- Make relevant project policies and reports, such as the animal welfare plan and environmental risk assessment, publicly available on the Sooam Biotech Research Foundation website. Responsibility: Communications Department.
- Document and publish the selection criteria and rationale for major decisions, such as the choice of genetic modification techniques or commercialization partners, to ensure transparency and accountability. Responsibility: Project Management Office.