**Purpose:** business

**Purpose Detailed:** Commercial development of a genetically engineered companion animal for maximizing human dopamine and oxytocin release, with significant financial investment.

**Topic:** Genetically engineered dopamine/oxytocin-releasing dog