This plan involves money.

## Currencies

- **SGD:** Local currency for Singapore, where the lab will be located and operational expenses will be incurred.
- **USD:** The project budget is specified in USD, and it is a stable international currency for large-scale budgeting and international transactions.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting will be USD, as the project budget is defined in USD. SGD will be used for local transactions within Singapore. Given the scale of the project, it is advisable to hedge against potential exchange rate fluctuations between USD and SGD to mitigate financial risks.