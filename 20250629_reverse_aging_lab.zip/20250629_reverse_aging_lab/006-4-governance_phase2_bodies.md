### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for the $500 million, 10-year initiative, ensuring alignment with organizational goals and managing strategic risks.

**Responsibilities:**

- Approve the project charter and overall project plan.
- Provide strategic guidance and direction to the Project Director.
- Approve major project milestones and deliverables.
- Review and approve annual budgets and funding requests exceeding $5 million.
- Monitor project progress against strategic objectives and key performance indicators (KPIs).
- Oversee risk management and mitigation strategies for strategic risks.
- Resolve strategic issues and conflicts that cannot be resolved at the project management level.
- Ensure alignment with organizational strategy and objectives.
- Approve changes to project scope, budget, or timeline exceeding 10% of the original plan.

**Initial Setup Actions:**

- Finalize the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Establish a meeting schedule and communication protocols.
- Review and approve the initial project charter and plan.
- Define the escalation process for unresolved issues.

**Membership:**

- Chief Executive Officer (CEO) or designate
- Chief Scientific Officer (CSO)
- Chief Financial Officer (CFO)
- Independent External Advisor (Biomedical Research Expert)
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (above $5 million), timeline, and strategic risk management.

**Decision Mechanism:** Decisions are made by majority vote, with the Chair having the tie-breaking vote. Any decision impacting the strategic direction of the project requires unanimous agreement from the CEO/designate and the Independent External Advisor.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic objectives and KPIs.
- Review and approval of budget and funding requests.
- Discussion and resolution of strategic issues and risks.
- Review of stakeholder engagement activities.
- Review of compliance with regulatory requirements.

**Escalation Path:** To the Board of Directors for issues exceeding the Committee's authority or unresolved conflicts.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized coordination, support, and oversight for day-to-day project execution, ensuring adherence to project plans, budgets, and timelines.

**Responsibilities:**

- Develop and maintain project management standards and methodologies.
- Provide project management support to the Project Director and project teams.
- Monitor project progress against plan and budget.
- Manage project risks and issues at the operational level.
- Track project deliverables and milestones.
- Prepare project status reports for the Project Steering Committee.
- Manage project documentation and communication.
- Coordinate project resources and activities.
- Manage the change control process for changes below the strategic threshold (less than 10% of budget or timeline).

**Initial Setup Actions:**

- Establish the PMO structure and staffing.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.
- Implement a project management information system (PMIS).

**Membership:**

- PMO Director
- Project Managers
- Project Coordinators
- Business Analyst
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within approved budgets and timelines.

**Decision Mechanism:** Decisions are made by the PMO Director, in consultation with project managers and relevant stakeholders. Conflicts are resolved through discussion and consensus-building, escalating to the Project Director if necessary.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project status and progress.
- Discussion of project risks and issues.
- Review of project deliverables and milestones.
- Review of project budget and expenditures.
- Coordination of project resources and activities.

**Escalation Path:** To the Project Director for issues exceeding the PMO's authority or unresolved conflicts.
### 3. Ethics Advisory Board

**Rationale for Inclusion:** Provides independent ethical review and guidance on all research activities, ensuring compliance with ethical standards and addressing potential ethical concerns related to reverse aging research.

**Responsibilities:**

- Review and approve research protocols involving human subjects.
- Provide guidance on ethical issues related to reverse aging research.
- Monitor research activities for compliance with ethical standards.
- Address ethical concerns raised by researchers, stakeholders, or the public.
- Develop and maintain ethical guidelines for the research lab.
- Promote ethical awareness and training among research staff.
- Advise on community engagement strategies to address ethical concerns.
- Ensure compliance with Singapore's Bioethics Advisory Committee (BAC) guidelines.

**Initial Setup Actions:**

- Finalize the Board's Terms of Reference.
- Appoint the Board Chair.
- Recruit members with expertise in ethics, law, and community engagement.
- Establish a meeting schedule and communication protocols.
- Develop ethical guidelines for the research lab.

**Membership:**

- Ethicist (Chair)
- Legal Expert
- Community Representative
- Medical Doctor
- Research Scientist (non-voting member)
- Data Protection Officer

**Decision Rights:** Ethical approval of research protocols involving human subjects and guidance on ethical issues related to reverse aging research.

**Decision Mechanism:** Decisions are made by majority vote, with the Chair having the tie-breaking vote. Decisions involving human subject research require unanimous approval from the Ethicist, Legal Expert, and Community Representative.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research protocols involving human subjects.
- Discussion of ethical issues related to reverse aging research.
- Review of ethical guidelines and policies.
- Review of community engagement activities.
- Review of data privacy and security measures.

**Escalation Path:** To the Project Steering Committee for unresolved ethical issues or conflicts with strategic objectives. To the Bioethics Advisory Committee (BAC) for issues requiring external guidance or regulatory interpretation.
### 4. Compliance and Audit Committee

**Rationale for Inclusion:** Ensures comprehensive compliance oversight, including GDPR, ethical standards, and relevant regulations, through regular audits and monitoring activities.

**Responsibilities:**

- Oversee compliance with all applicable laws, regulations, and ethical standards.
- Develop and implement a compliance program.
- Conduct regular audits to assess compliance with regulatory requirements.
- Investigate and resolve compliance violations.
- Report compliance issues to the Project Steering Committee.
- Provide training to research staff on compliance requirements.
- Monitor changes in laws and regulations and update compliance policies accordingly.
- Ensure compliance with Singapore Guidelines on Good Clinical Practice (SG-GCP), Personal Data Protection Act (PDPA), Biosafety Level 2 (BSL-2) standards, and environmental regulations.
- Oversee the whistleblower mechanism and ensure protection against retaliation.

**Initial Setup Actions:**

- Finalize the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Recruit members with expertise in compliance, law, and auditing.
- Establish a meeting schedule and communication protocols.
- Develop a compliance program and audit plan.

**Membership:**

- Compliance Officer (Chair)
- Legal Counsel
- Internal Auditor
- Data Protection Officer
- Environmental Safety Officer

**Decision Rights:** Decisions related to compliance policies, audit plans, and corrective actions for compliance violations.

**Decision Mechanism:** Decisions are made by majority vote, with the Chair having the tie-breaking vote. Decisions involving significant compliance violations require unanimous approval from the Compliance Officer and Legal Counsel.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of compliance audit results.
- Discussion of compliance issues and violations.
- Review of compliance policies and procedures.
- Review of changes in laws and regulations.
- Review of whistleblower reports.

**Escalation Path:** To the Project Steering Committee for unresolved compliance issues or significant violations. To relevant regulatory authorities for reporting of serious compliance breaches.