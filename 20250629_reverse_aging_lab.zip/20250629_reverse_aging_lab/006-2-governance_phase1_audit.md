
## Audit - Corruption Risks

- Bribery of regulatory officials (HSA, BAC) to expedite approvals for clinical trials or lab construction.
- Conflicts of interest in vendor selection for lab equipment or IT infrastructure, favoring companies with personal connections.
- Kickbacks from construction companies or equipment suppliers in exchange for inflated contracts.
- Misuse of confidential research data for personal gain or to benefit competing organizations.
- Nepotism in hiring decisions, leading to unqualified personnel being appointed to key positions.

## Audit - Misallocation Risks

- Inflated expenses for travel and accommodation by project staff, exceeding approved budgets.
- Duplication of research efforts due to poor communication and coordination between research teams.
- Unnecessary procurement of equipment or materials, exceeding actual research needs.
- Misreporting of research progress to justify continued funding, despite lack of significant results.
- Use of project funds for purposes outside the scope of the research lab's objectives, such as personal investments.

## Audit - Procedures

- Annual external audit of project finances, including a review of all expenditures and procurement processes, conducted by an independent auditing firm.
- Quarterly internal reviews of research progress against established milestones, led by a designated audit team.
- Regular compliance checks to ensure adherence to Singapore Guidelines on Good Clinical Practice (SG-GCP), Personal Data Protection Act (PDPA), and Biosafety Level 2 (BSL-2) standards, conducted by a compliance officer.
- Review of all contracts with vendors and contractors exceeding $100,000 by an independent legal counsel to ensure fair pricing and terms.
- Expense report audits to verify the legitimacy and accuracy of all travel, accommodation, and other reimbursable expenses, with a focus on high-value transactions.

## Audit - Transparency Measures

- Establish a public-facing project dashboard displaying key performance indicators (KPIs), budget allocation, and research progress.
- Publish minutes of all meetings of the Ethics Advisory Board and the Project Steering Committee on the project website.
- Implement a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with protection against retaliation.
- Make the project's data protection plan and environmental management plan publicly accessible on the project website.
- Document and publish the selection criteria and rationale for all major vendor and contractor decisions.