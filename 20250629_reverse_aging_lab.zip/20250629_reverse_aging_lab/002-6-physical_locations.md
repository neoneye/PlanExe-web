This plan implies one or more physical locations.

## Requirements for physical locations

- Progressive biomedical regulatory framework
- Streamlined ethical approval processes
- World-class scientific infrastructure
- Attractiveness to top international talent
- Space for a state-of-the-art research lab

## Location 1
Singapore

Biopolis, Singapore

Specific location within Biopolis to be determined

**Rationale**: Biopolis is Singapore's premier biomedical research hub, offering state-of-the-art facilities, a collaborative environment, and proximity to other research institutions and talent.

## Location 2
Singapore

National University of Singapore (NUS)

Specific location within NUS research campus to be determined

**Rationale**: NUS is a leading global university with strong research capabilities and infrastructure, providing access to a large pool of talent and potential collaborations.

## Location 3
Singapore

Science Park, Singapore

Specific location within Science Park to be determined

**Rationale**: Singapore Science Park offers a conducive environment for research and development activities, with a focus on innovation and technology, and provides access to various amenities and support services.

## Location Summary
The plan is to establish a Reverse Aging Research Lab in Singapore. Biopolis, NUS, and Science Park are all suitable locations in Singapore due to their existing research infrastructure, talent pool, and supportive ecosystems for biomedical research.