### 1. Project Sponsor designates an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Project Sponsor Identified

### 2. Interim Chair of the Project Steering Committee drafts the initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Appointment of Interim Chair

### 3. Circulate Draft SteerCo ToR for review by nominated members (CEO/designate, CSO, CFO, Independent External Advisor, Project Director).

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 4. Finalize the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 5. Project Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Sponsor formally confirms the Project Steering Committee membership (CEO/designate, CSO, CFO, Independent External Advisor, Project Director).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment of SteerCo Chair
- Final SteerCo ToR v1.0

### 7. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 8. Hold the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 9. Project Steering Committee reviews and approves the initial project charter and plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Project Charter
- Approved Project Plan

**Dependencies:**

- Meeting Minutes with Action Items

### 10. Project Director appoints the PMO Director.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 11. PMO Director establishes the PMO structure and staffing (Project Managers, Project Coordinators, Business Analyst, Risk Manager).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Organizational Chart
- Job Descriptions

**Dependencies:**

- Appointment of PMO Director

### 12. PMO Director develops project management templates and tools.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Organizational Chart

### 13. PMO Director defines project reporting requirements and establishes communication protocols.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document
- Communication Protocols Document

**Dependencies:**

- Project Management Templates

### 14. PMO Director implements a project management information system (PMIS).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- PMIS Implementation Plan
- Operational PMIS

**Dependencies:**

- Project Reporting Requirements Document

### 15. Schedule the initial PMO kick-off meeting.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Operational PMIS

### 16. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 17. Project Director designates an Interim Chair for the Ethics Advisory Board.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 18. Interim Chair of the Ethics Advisory Board drafts the initial Terms of Reference (ToR) for the Ethics Advisory Board.

**Responsible Body/Role:** Interim Chair, Ethics Advisory Board

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Ethics Advisory Board ToR v0.1

**Dependencies:**

- Appointment of Interim Chair

### 19. Circulate Draft Ethics Advisory Board ToR for review by potential members (Ethicist, Legal Expert, Community Representative, Medical Doctor, Research Scientist, Data Protection Officer).

**Responsible Body/Role:** Interim Chair, Ethics Advisory Board

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Ethics Advisory Board ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics Advisory Board ToR v0.1
- Identification of Potential Members

### 20. Finalize the Ethics Advisory Board Terms of Reference based on feedback.

**Responsible Body/Role:** Interim Chair, Ethics Advisory Board

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Ethics Advisory Board ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics Advisory Board ToR v0.2

### 21. Project Director formally appoints the Ethics Advisory Board Chair.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Advisory Board ToR v1.0

### 22. Ethics Advisory Board Chair recruits members with expertise in ethics, law, and community engagement (Ethicist, Legal Expert, Community Representative, Medical Doctor, Research Scientist, Data Protection Officer).

**Responsible Body/Role:** Ethics Advisory Board Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- List of Confirmed Ethics Advisory Board Members

**Dependencies:**

- Appointment of Ethics Advisory Board Chair

### 23. Project Director formally confirms the Ethics Advisory Board membership.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- List of Confirmed Ethics Advisory Board Members

### 24. Schedule the initial Ethics Advisory Board kick-off meeting.

**Responsible Body/Role:** Ethics Advisory Board Chair

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 25. Hold the initial Ethics Advisory Board kick-off meeting.

**Responsible Body/Role:** Ethics Advisory Board Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 26. Ethics Advisory Board develops ethical guidelines for the research lab.

**Responsible Body/Role:** Ethics Advisory Board

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Ethical Guidelines for the Research Lab

**Dependencies:**

- Meeting Minutes with Action Items

### 27. Project Director designates an Interim Chair for the Compliance and Audit Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**


### 28. Interim Chair of the Compliance and Audit Committee drafts the initial Terms of Reference (ToR) for the Compliance and Audit Committee.

**Responsible Body/Role:** Interim Chair, Compliance and Audit Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Compliance and Audit Committee ToR v0.1

**Dependencies:**

- Appointment of Interim Chair

### 29. Circulate Draft Compliance and Audit Committee ToR for review by potential members (Compliance Officer, Legal Counsel, Internal Auditor, Data Protection Officer, Environmental Safety Officer).

**Responsible Body/Role:** Interim Chair, Compliance and Audit Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Compliance and Audit Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Compliance and Audit Committee ToR v0.1
- Identification of Potential Members

### 30. Finalize the Compliance and Audit Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Interim Chair, Compliance and Audit Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Compliance and Audit Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Compliance and Audit Committee ToR v0.2

### 31. Project Director formally appoints the Compliance and Audit Committee Chair.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Compliance and Audit Committee ToR v1.0

### 32. Compliance and Audit Committee Chair recruits members with expertise in compliance, law, and auditing (Compliance Officer, Legal Counsel, Internal Auditor, Data Protection Officer, Environmental Safety Officer).

**Responsible Body/Role:** Compliance and Audit Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- List of Confirmed Compliance and Audit Committee Members

**Dependencies:**

- Appointment of Compliance and Audit Committee Chair

### 33. Project Director formally confirms the Compliance and Audit Committee membership.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- List of Confirmed Compliance and Audit Committee Members

### 34. Schedule the initial Compliance and Audit Committee kick-off meeting.

**Responsible Body/Role:** Compliance and Audit Committee Chair

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation Emails

### 35. Hold the initial Compliance and Audit Committee kick-off meeting.

**Responsible Body/Role:** Compliance and Audit Committee Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 36. Compliance and Audit Committee develops a compliance program and audit plan.

**Responsible Body/Role:** Compliance and Audit Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Compliance Program
- Audit Plan

**Dependencies:**

- Meeting Minutes with Action Items